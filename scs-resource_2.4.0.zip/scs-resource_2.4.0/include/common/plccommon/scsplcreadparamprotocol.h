#ifndef SCSPLCREADPARAMPROTOCOL_H
#define SCSPLCREADPARAMPROTOCOL_H
#include "scsplcprotocol.h"
BEGIN_NAMESPACE(Gemini)

class CscsPlcReadParamProtocol:public CscsAbstractPlcCommonProtocol{
public:
	CscsPlcReadParamProtocol();
	virtual ~CscsPlcReadParamProtocol();

	int composeProtocol(CscsByteArray& out, const CscsByteArray& in, void* ex=nullptr);
	int parseProtocol(const CscsByteArray& in);

protected:
	int writeToDataBase(const CscsByteArray& data);
};

END_NAMESPACE

#endif