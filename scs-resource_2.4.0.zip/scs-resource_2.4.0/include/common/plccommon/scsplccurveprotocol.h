#ifndef SCSPLCCURVEPROTOCOL_H
#define SCSPLCCURVEPROTOCOL_H
#include "scsplcprotocol.h"

/*
 * Created By J.Wong
 *曲线协议 
 */
BEGIN_NAMESPACE(Gemini)

class CscsPlcCurveProtocol:public CscsAbstractPlcCommonProtocol{
public:
	CscsPlcCurveProtocol();
	virtual ~CscsPlcCurveProtocol();
	int composeProtocol(CscsByteArray& out, const CscsByteArray& in, void* ex=nullptr);
	int parseProtocol(const CscsByteArray& in);
};
END_NAMESPACE

#endif