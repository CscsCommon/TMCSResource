#ifndef SCSPLCTRIGGERCONFIRMPROTOCOL_H
#define SCSPLCTRIGGERCONFIRMPROTOCOL_H
#include "scsplcprotocol.h"
BEGIN_NAMESPACE(Gemini)

/*
 * Created By J.Wong
 * 触发其资料回馈协议
 */
class CscsPlcTriggerConfirmProtocol:public CscsAbstractPlcTriggerProtocol{
public:
	CscsPlcTriggerConfirmProtocol();
	virtual ~CscsPlcTriggerConfirmProtocol();

	int composeProtocol(CscsByteArray& out, const CscsByteArray& in,void* ex=nullptr);
	int parseProtocol(const CscsByteArray& in);

protected:
	int writeToDataBase(const CscsByteArray& data);
	void setTemperPID();
	void setCurveData(uint curveNo,const void* pData, int nCount, uint triggerType);
};

END_NAMESPACE

#endif