#ifndef SCSPLCPROTOCOLFACTORY_H
#define SCSPLCPROTOCOLFACTORY_H
#include "scsplcdefs.h"
#include "scsplcprotocol.h"

BEGIN_NAMESPACE(Gemini)

class CscsAbstractPlcProtocol;
class CscsPlcProtocolFactoryPrivate;

class CscsPlcProtocolFactory{
public:
	CscsPlcProtocolFactory();
	virtual ~CscsPlcProtocolFactory();
	CscsAbstractPlcProtocol* protocol(int type);

private:
	CscsPlcProtocolFactoryPrivate* d;

	void initProtocols();
};

END_NAMESPACE

#endif