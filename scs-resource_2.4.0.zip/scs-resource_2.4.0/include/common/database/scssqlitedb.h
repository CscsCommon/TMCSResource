/*
 * Created by J.W 2019/05/26
 */
#ifndef SCSSQLITEDB_H
#define SCSSQLITEDB_H

#include <kernel/scsnocopy.hpp>
#include <kernel/scsnamespace.h>
#include <kernel/scsmutex.h>
#include "scsdatabase.h"
#include "scssqlitejsonhelper.hpp"
#include "scssqlitetuple.h"
#include "scsjson.h"
#include "scssqlitevariantvector.h"
#include "scssqlitecommonqueryhelper.hpp"

#include <iostream>

BEGIN_NAMESPACE(Gemini)


class CscsSqliteDB:public CscsNoCopyable{
public:
	CscsSqliteDB():m_dbHandle(nullptr),m_statement(nullptr),
	m_isConnected(false),m_code(0),
	m_jsonHelper(m_buf, m_code){

	}

	/**
	* 连接数据库
	* 如果数据库不存在，数据库将被创建并打开, 如果创建失败则设置失败标志
	* @param[in] fileName：数据库文件的位置。
	*/
	explicit CscsSqliteDB(const std::string& fileName):m_dbHandle(nullptr),m_statement(nullptr),
	m_isConnected(false),m_code(0),m_jsonHelper(m_buf,m_code){
		open(fileName);
	}

	~CscsSqliteDB(){
		close();
	}

	/**
	* 打开数据库
	*/
	void open(const std::string& fileName);

	/**
	**打开内存数据库
	**/
	void open();

	/**
	* 释放资源，关闭数据库
	*/
	bool close();
	/**
	* 是否已连接数据库
	*/
	inline bool isConnected() const
	{
		return m_isConnected;
	}

	/**
     ** db 锁
	**/
	inline CscsMutex*  db_mutex(){
		return &m_mtx;
	}
	/**
	* 不带占位符。执行sql，不带返回结果, 如insert,update,delete等
	* @param[in] query: sql语句, 不带占位符
	* @return bool, 成功返回true，否则返回false
	*/
	inline bool execute(const std::string& sqlStr)
	{
		m_code = sqlite3_exec(m_dbHandle, sqlStr.data(), nullptr, nullptr, nullptr);
		return SQLITE_OK == m_code;
	}

	inline bool excute(const std::string& sqlStr, int(*callback)(void*,int,char**, char**), void* param){
		m_code = sqlite3_exec(m_dbHandle, sqlStr.data(), callback, param, nullptr);
		return SQLITE_OK == m_code;
	}

	/**
	* 带占位符。执行sql，不带返回结果, 如insert,update,delete等
	* @param[in] query: sql语句, 可能带占位符"?"
	* @param[in] args: 参数列表，用来填充占位符
	* @return bool, 成功返回true，否则返回false
	*/
	template <typename... Args>
	bool execute(const std::string& sqlStr, Args && ... args)
	{
		if (!prepare(sqlStr))
		{
			done();
			return false;
		}

		bool ret=executeArgs(std::forward<Args>(args)...);
		done();
		return ret;
	}

	/**
	* 批量操作之前准备sql接口，必须和executeArgs一起调用，准备批量操作的sql
	* @return bool, 成功返回true，否则返回false
	*/
	inline bool prepare(const std::string& sqlStr)
	{
		m_code = sqlite3_prepare_v2(m_dbHandle, sqlStr.data(), -1, &m_statement, nullptr);
		if (m_code != SQLITE_OK)
		{
			return false;
		}

		return true;
	}

	/**
	* 批量操作接口，必须先调用Prepare接口
	* @param[in] args: 参数列表
	* @return bool, 成功返回true，否则返回false
	*/
	template <typename... Args>
	bool executeArgs(Args && ... args)
	{
		if (SQLITE_OK != bindSqliteParams(m_statement, 1, std::forward<Args>(args)...))
		{
			return false;
		}

		m_code = sqlite3_step(m_statement);

		sqlite3_reset(m_statement);
		return m_code == SQLITE_DONE;
	}

	template<typename Tuple>
	bool executeTuple(const std::string& sqlStr, Tuple&& t)
	{
		if (!prepare(sqlStr))
		{
			done();
			return false;
		}

		m_code =executeSqliteTuple(m_statement, typename MakeIndexes<std::tuple_size<Tuple>::value>::type(), std::forward<Tuple>(t));
		done();
		return m_code == SQLITE_DONE;
	}

	bool executeJson(const std::string& sqlStr, const char* json)
	{
		rapidjson::Document doc;
		doc.Parse<0>(json);
		if (doc.HasParseError())
		{
			cout << doc.GetParseError() << endl;
			return false;
		}

		if (!prepare(sqlStr))
		{
			done();
			return false;
		}
		bool ret=jsonTransaction(doc);
		done();
		return ret;
	}

	/**
	* 执行sql，返回函数执行的一个值, 执行简单的汇聚函数，如select count(*), select max(*)等
	* 返回结果可能有多种类型，返回Value类型，在外面通过get函数去取
	* @param[in] query: sql语句, 可能带占位符"?"
	* @param[in] args: 参数列表，用来填充占位符
	* @return int: 返回结果值，失败则返回-1
	*/
	template < typename R = sqlite_int64, typename... Args>
	R executeScalar(const std::string& sqlStr, Args&&... args)
	{
		if (!prepare(sqlStr)){
			done();
			return errorVal<R>();
		}
		if (SQLITE_OK != bindSqliteParams(m_statement, 1, std::forward<Args>(args)...))
		{
			return errorVal<R>();
		}

		m_code = sqlite3_step(m_statement);

		if (m_code != SQLITE_ROW){
			done();
			return errorVal<R>();
		}

		SqliteValue val = value<R>(m_statement, 0);
		R result= val.get<R>();
		done();
		return result;
	}

	template <typename... Args>
	std::shared_ptr<CscsJsonDocument> queryJson(const std::string& query, Args&&... args)
	{
		if (!prepareStatement(query, std::forward<Args>(args)...)){
			done();
			return nullptr;
		}

		//auto doc = std::make_shared<CscsJsonDocument>();
		CscsJsonDocument* doc=new CscsJsonDocument();
		m_buf.Clear();
		m_jsonHelper.buildJsonObject(m_statement);

		//doc->Parse<0>(m_buf.GetString());
		doc->parse(m_buf);
		done();
		return std::shared_ptr<CscsJsonDocument>(doc);
	}

	template <typename... Args>
	std::shared_ptr<CscsList<CscsSqliteVariantVector> > query(const std::string& query, Args&&... args)
	{
		if (!prepareStatement(query, std::forward<Args>(args)...)){
			done();
			return nullptr;
		}

		
		auto list=m_commonQueryHelper.buildCommonQuery(m_statement);

		done();
		return list;
	}

	inline bool begin()
	{
		return execute("BEGIN IMMEDIATE");
	}

	inline bool rollBack()
	{
		return execute("ROLLBACK");
	}

	inline bool commit()
	{
		return execute("COMMIT");
	}

	inline int lastErrorCode()
	{
		return m_code;
	}

	inline void done(){
		sqlite3_finalize(m_statement);
	}

private:
	int closeDBHandle()
	{
		int code = sqlite3_close(m_dbHandle);
		while (code == SQLITE_BUSY)
		{
			// set rc to something that will exit the while loop 
			code = SQLITE_OK;
			sqlite3_stmt * stmt = sqlite3_next_stmt(m_dbHandle, NULL);

			if (stmt == nullptr)
				break;

			code = sqlite3_finalize(stmt);
			if (code == SQLITE_OK)
			{
				code = sqlite3_close(m_dbHandle);
			}
		}

		return code;
	}

	template <typename... Args>
	bool prepareStatement(const std::string& sqlStr, Args&&... args)
	{
		if (!prepare(sqlStr))
		{
			return false;
		}

		if (SQLITE_OK != bindSqliteParams(m_statement, 1, std::forward<Args>(args)...))
		{
			return false;
		}

		return true;
	}

	//通过json串写到数据库中
	bool jsonTransaction(const rapidjson::Document& doc)
	{
		begin();

		for (size_t i = 0, size = doc.Size(); i < size; i++)
		{
			if (!(m_code=m_jsonHelper.executeJson(m_statement, doc[i])))
			{
				rollBack();
				break;
			}
		}

		if (!m_code)
			return false;

		commit();
		return true;
	}

private:
	/** 取列的值 **/
	template<typename R>
	SqliteValue value(sqlite3_stmt *stmt, const int& index)
	{
		R ret;
		return value(stmt,index,ret);
	}

	template<typename T>
	typename std::enable_if<std::is_floating_point<T>::value,SqliteValue>::type
	value(sqlite3_stmt* stmt, const int& index,T& t){
		int type = sqlite3_column_type(stmt, index);
		if(type!=SQLITE_FLOAT&&type!=SQLITE_NULL){
			throw std::invalid_argument("request data type error");
		}
		t=sqlite3_column_double(stmt, index);
		return t;
	}

	template<typename T>
	typename std::enable_if<std::is_integral<T>::value, SqliteValue>::type
	value(sqlite3_stmt* stmt, const int& index, T& t){
		int type = sqlite3_column_type(stmt, index);
		if(type!=SQLITE_INTEGER&&type!=SQLITE_NULL){
			throw std::invalid_argument("request data type error");
		}
		return intValue(stmt, index, t);
	}

	template<typename T>
	typename std::enable_if<std::is_same<T,int64_t>::value||std::is_same<T,uint64_t>::value, SqliteValue>::type
	intValue(sqlite3_stmt* stmt, const int& index, T& t){
		t=sqlite3_column_int64(stmt, index);
		return t;
	}

	template<typename T>
	typename std::enable_if<!is_same<T,int64_t>::value&&!is_same<T,uint64_t>::value, SqliteValue>::type
	intValue(sqlite3_stmt* stmt, const int& index, T& t){
		t=sqlite3_column_int(stmt, index);
		return t;
	}

	template<typename T>
	typename std::enable_if<std::is_same<char*, T>::value||std::is_same<const char*, T>::value, SqliteValue>::type
	value(sqlite3_stmt* stmt, const int& index, T& t){
		int type = sqlite3_column_type(stmt, index);
		if(type!=SQLITE_BLOB&&type!=SQLITE_TEXT&&type!=SQLITE_NULL){
			throw std::invalid_argument("request data type error");
		}
		if(type==SQLITE_BLOB){
			const char* data=(const char*)sqlite3_column_blob(stmt, index);
			int len=sqlite3_column_bytes(stmt, index);
			t=std::string(data,len);
		}
		else
			t=sqlite3_column_text(stmt, index);
		if(t==nullptr) return t;
		char* tmp=::malloc(strlen(t)+1);
		::memcpy(tmp,t,strlen(t)+1);
		return tmp;
	}

	template<typename T>
	typename std::enable_if<std::is_same<std::string,T>::value, SqliteValue>::type
	value(sqlite3_stmt* stmt, const int& index, T& t){

		int type = sqlite3_column_type(stmt, index);
		if(type!=SQLITE_BLOB&&type!=SQLITE_TEXT&&type!=SQLITE_NULL){
			throw std::invalid_argument("request data type error");
		}
		if(type==SQLITE_BLOB){
			const char* data=(const char*)sqlite3_column_blob(stmt, index);
			int len=sqlite3_column_bytes(stmt, index);
			t=std::string(data,len);
		}
		else if(type==SQLITE_TEXT)
			t=std::string((const char*)sqlite3_column_text(stmt, index));
		else
			t=std::string();
		return t;
	}


	template<typename T>
	typename std::enable_if<std::is_same<blob,T>::value, SqliteValue>::type
	value(sqlite3_stmt* stmt, const int& index, T& t){

		int type = sqlite3_column_type(stmt, index);
		if(type!=SQLITE_BLOB&&type!=SQLITE_TEXT&&type!=SQLITE_NULL){
			throw std::invalid_argument("request data type error");
		}
		char* data;
		int len;
		if(type==SQLITE_BLOB){
			data=(char*)sqlite3_column_blob(stmt, index);
			len=sqlite3_column_bytes(stmt, index);
		}
		else {
			data=(char*)sqlite3_column_text(stmt, index);
			len=(int)(strlen(data)+1);
		}
		blob tmp{data,len};
		return tmp;
	}

	template<typename T>
	typename std::enable_if<std::is_same<nullptr_t,T>::value,SqliteValue>::type
	value(sqlite3_stmt* stmt, const int& index, T& t){
		return nullptr;
	}



	template<typename T>
	typename std::enable_if <std::is_arithmetic<T>::value, T>::type
	errorVal()
	{
			return T(-9999);
	}

	template<typename T>
	typename std::enable_if <std::is_same<char*,T>::value
	||std::is_same<const char*,T>::value
	||std::is_same<std::string,T>::value, T>::type
	errorVal()
	{
			return "";
	}

	template<typename T>
	typename std::enable_if<std::is_same<blob,T>::value, T>::type
	errorVal()
	{
		return blob{0,0};
	}

	template<typename T>
	typename std::enable_if<std::is_same<nullptr_t,T>::value, T>::type
	errorVal()
	{
		return nullptr;
	}


private:
	sqlite3* m_dbHandle;
	sqlite3_stmt* m_statement;
	bool m_isConnected;
	int m_code;
	CscsSqliteJsonHelper m_jsonHelper;
	CscsSqliteCommonQueryHelper m_commonQueryHelper; 
	rapidjson::StringBuffer m_buf;
	CscsMutex m_mtx;
};


END_NAMESPACE

#endif