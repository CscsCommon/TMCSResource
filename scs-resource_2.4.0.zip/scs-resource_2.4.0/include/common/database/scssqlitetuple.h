/*
 * Created by J.W 2019/05/27
 */

#ifndef SCSSQLITETUPLE_H
#define SCSSQLITETUPLE_H
#include <kernel/scsnamespace.h>
#include <sqlite3.h>
#include "scsbindsqliteparams.h"
#include <tuple>

BEGIN_NAMESPACE(Gemini)

template<int...>
struct IndexTuple{};

template<int N, int... Indexes>
struct MakeIndexes : MakeIndexes<N - 1, N - 1, Indexes...>{};

template<int... indexes>
struct MakeIndexes<0, indexes...>
{
	typedef IndexTuple<indexes...> type;
};

template<int... Indexes, class Tuple>
int executeSqliteTuple(sqlite3_stmt *stmt, IndexTuple< Indexes... >&& in, Tuple&& t)
{
	if (SQLITE_OK != bindSqliteParams(stmt, 1, std::get<Indexes>(std::forward<Tuple>(t))...))
	{
		return false;
	}

	int code = sqlite3_step(stmt);
	sqlite3_reset(stmt);
	return code;
}

END_NAMESPACE


#endif