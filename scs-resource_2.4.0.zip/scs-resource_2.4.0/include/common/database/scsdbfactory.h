#ifndef SCSDBFACTORY_H
#define SCSDBFACTORY_H

#include <database/scssqlitedb.h>
#include <kernel/scsnocopy.hpp>

BEGIN_NAMESPACE(Gemini)

class CscsDBFactory : public CscsNoCopyable{

private:
    static CscsDBFactory *m_instance;
    static CscsSqliteDB  *m_fileDB;
    static CscsSqliteDB  *m_memoryDB;    

    CscsDBFactory();
    ~CscsDBFactory();

public:
    enum DBType{
        LocalFile,
        Memory
    };

    static CscsDBFactory* instance()
    {
        if(m_instance == nullptr)
        {
            m_instance = new CscsDBFactory();
        }
        return m_instance;
    }

    static void ruinInstance()
    {
        if(m_memoryDB != nullptr)
        {
            m_memoryDB->close();
            delete m_memoryDB;
            m_memoryDB = nullptr;
        }

        if(m_fileDB != nullptr)
        {
            m_fileDB->close();
            delete m_fileDB;
            m_fileDB = nullptr;
        }

        if(m_instance != nullptr)
        {
            delete m_instance;
            m_instance = nullptr;
        }
    }

    CscsSqliteDB* get(CscsDBFactory::DBType type = LocalFile, const std::string &fileName="database.db")
    {

        if(type == LocalFile && m_fileDB == nullptr)
        {
            m_fileDB = new CscsSqliteDB();
            m_fileDB->open(fileName);
        }else if(type == Memory && m_memoryDB == nullptr){
            m_memoryDB = new CscsSqliteDB();
            m_memoryDB->open();
        }

        if(type == LocalFile){
            return m_fileDB;
        }
        else if(type == Memory)
            return m_memoryDB;
        return nullptr;
    }       

};

END_NAMESPACE
#endif