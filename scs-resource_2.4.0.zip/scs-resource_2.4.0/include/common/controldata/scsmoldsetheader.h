#ifndef SCSMOLDSETHEADER_H
#define SCSMOLDSETHEADER_H
#include "scsabstractcontroldata.h"

BEGIN_NAMESPACE(Gemini)
class CscsMoldSetData;
class CscsMoldSetHeader:public CscsAbstractControlData{
public:
	CscsMoldSetHeader(CscsObject* parent=nullptr);
	~CscsMoldSetHeader();

	MoldHDR currentMoldHDRLog();
	MoldHDR moldHDRLog(const std::string& szMoldName);
	bool addMoldHDRLog(const MoldHDR& hdr);
	bool modifyMoldHDRLog(const MoldHDR& hdr);
	uint moldHDRLogCount();
	MoldHDR moldHDRLog(uint index)const;
	std::vector<MoldHDR> moldHDRLogs(uint start, uint count);
	bool restoreMoldHDRLog(const std::string& szMoldName);
	bool deleteMoldHDRLog(const std::string& szMoldName);
	bool restoreFromFile(const std::string& szFile);
	bool saveToFile(const std::string& szFile);
	
private:
	void prepareMoldHDRTable();
	uint   m_totalCount;
	static CscsMoldSetData* m_moldData;
	static std::string m_szFile;
	// static uint m_index;
};

END_NAMESPACE
#endif