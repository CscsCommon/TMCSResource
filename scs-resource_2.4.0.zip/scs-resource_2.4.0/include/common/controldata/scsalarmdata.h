/*
 * Created by J.Wong 2019/10/12
 */

#ifndef SCSALARMDATA_H
#define SCSALARMDATA_H
#include "scsabstractcontroldata.h"

BEGIN_NAMESPACE(Gemini)

class CscsAlarmData:public CscsAbstractControlData{

public:
	CscsAlarmData(CscsObject* parent=nullptr);
	~CscsAlarmData();

	bool addErrorLog(uint dwID, uint16 wSource=OilError,uint16 wAlarmType=ErrorType);
	bool clearErrorLog();
	uint errorLogCount()const;
	ErrorData currentErrorLog()const;
	ErrorData errorLog(uint index)const;
	std::vector<ErrorData> errorLogs(uint start, uint count)const;
	bool fixedErrorLog(ErrorData* error);
	bool fixedErrorLog(uint dwID, uint16 wSource=OilError);
	bool addErrorLog(ErrorData* error);
protected:
	void dataSensorEvent(CscsDataSensorEvent* e);
	void timerEvent(CscsTimerEvent* e);
	void checkError();

private:
	void checkPLCError();
	void checkPLCWarning();
	void checkDriverError();
	void checkAxisError();
	bool testBit(uint dwValue, uint16 wIndex);
	void prepareAlarmTable();
	void prepareErrorIDs();
	static ErrorData m_currentErrorData;
	static std::vector<std::string> m_driverErrorIDs;
	static std::vector<std::string> m_axisErrorIDs;
	static std::vector<std::string> m_plcErrorIDs;
	static std::vector<std::string> m_plcWarningIDs;
	uint m_shotCountID;
	int m_timerId;
	uint m_totalCount;
};

END_NAMESPACE

#endif