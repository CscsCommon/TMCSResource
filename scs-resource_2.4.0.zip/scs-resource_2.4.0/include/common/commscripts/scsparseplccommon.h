#ifndef SCSPARSEPLCCOMMON_H
#define SCSPARSEPLCCOMMON_H
#include <database/scsjson.h>
#include <vector>
#include <map>

/*
 * Created By J.Wong
 * 配置资料解析处理
 */
BEGIN_NAMESPACE(Gemini)

class CscsParseProtocolData{
public:
	CscsParseProtocolData();
	CscsParseProtocolData(const rapidjson::Value& val);
	
	const std::string& ip()const;
	uint port()const;
	bool isValid()const;
private:
	std::string _ip;
	uint _port; 
	bool _valid;
	void parse(const rapidjson::Value& val);
	friend class CscsParseProtocol;
};

class CscsParseArray{
public:
	CscsParseArray();
	CscsParseArray(const rapidjson::Value& v);
	
	const std::vector<uint>& array()const;
	bool isValid()const;

	void setArray(const std::vector<uint>& ids);
	void setValid(bool valid);

private:
	std::vector<uint> _array;
	bool _valid;
	void parse(const rapidjson::Value& val);
	friend class CscsParseTriggerParamSet;
	friend class CscsParseActual;
	friend class CscsParseTrigger;
};

class CscsParseParamsArray{
public:
	CscsParseParamsArray();
	CscsParseParamsArray(const rapidjson::Value& v);
	
	const std::vector<int>& array()const;
	bool isValid()const;

	void setArray(const std::vector<int>& params);
	void setValid(bool valid);
private:
	std::vector<int> _array;
	bool _valid;
	void parse(const rapidjson::Value& val);
	friend class CscsParseTriggerParamSet;
};

class CscsParseTriggerCondition{
public:
	CscsParseTriggerCondition();
	CscsParseTriggerCondition(const rapidjson::Value& val);
	uint type()const;
	const CscsParseParamsArray& params()const;
	bool isValid()const;

	void setType(uint type);
	void setParams(const CscsParseParamsArray& params);
	void setValid(bool valid);
private:
	uint _type;
	CscsParseParamsArray _params;
	bool _valid;
	void parse(const rapidjson::Value& val);
	friend class CscsParseTriggerParamSet;

};

class CscsParseTriggerParamSet{

public:
	CscsParseTriggerParamSet();
	CscsParseTriggerParamSet(const rapidjson::Value& val);
	
	const std::vector<CscsParseTriggerCondition>& conditions()const;
	bool isValid()const;

	void setConditions(std::vector<CscsParseTriggerCondition>& conditions);
	void setValid(bool valid);
private:
	std::vector<CscsParseTriggerCondition> _conditions;
	bool _valid;
	void parse(const rapidjson::Value& val);
	friend class CscsParseTriggerFeature;
};

class CscsParseTriggerFeature{
public:
	CscsParseTriggerFeature();
	CscsParseTriggerFeature(const rapidjson::Value& val);
	
	const std::vector<CscsParseTriggerParamSet>& triggerParams()const;
	bool isValid()const;

	void setTriggerParams(const std::vector<CscsParseTriggerParamSet>& triggerParams);
	void setValid(bool valid);

private:
	//TriggerSet
	std::vector<CscsParseTriggerParamSet> _triggerParams;
	bool _valid;
	void parse(const rapidjson::Value& val);
	friend class CscsParseTrigger;
};


class CscsParseProtocol{
public:
	CscsParseProtocol();
	CscsParseProtocol(const rapidjson::Value& val);
	
	const CscsParseProtocolData& source()const;
	const CscsParseProtocolData& host()const;
	uint version()const;
	uint priv()const;
	bool isValid()const;
private:
	CscsParseProtocolData _source;
	CscsParseProtocolData _host;
	uint _version;
	uint _priv;
	bool _valid;
	void parse(const rapidjson::Value& val);
	friend class CscsParsePlcCommon;
};


class CscsParseActual{
public:
	CscsParseActual();
	CscsParseActual(const rapidjson::Value& val);
	
	uint ID()const;
	uint cycleTime()const;
	const CscsParseArray& dataIDSet()const;
	bool isValid()const;
private:
	//ID
	uint _id;
	//CycleTime
	uint _cycleTime;
	//DataIDSet
	CscsParseArray _dataIDSet;
	bool _valid;
	void parse(const rapidjson::Value& val);
	friend class CscsParsePlcCommon;
};

class CscsParseLineStatus{
public:
	CscsParseLineStatus();
	CscsParseLineStatus(const rapidjson::Value& val);
	
	void setVersion(uint vers);
	void setPriv(uint priv);
	uint priv()const;
	uint version()const;

	uint ID()const;
	uint cycleTime()const;
	bool isValid()const;
private:
	//ID
	uint _id;
	//CycleTime
	uint _cycleTime;
	uint _version;
	uint _priv;
	bool _valid;
	void parse(const rapidjson::Value& val);
	friend class CscsParsePlcCommon;

};

class CscsParseTrigger{
public:
	CscsParseTrigger();
	CscsParseTrigger(const rapidjson::Value& val);
	
	uint ID()const;
	uint groupID()const;
	uint outTime()const;
	uint delayTime()const;
	uint sendCount()const;
	uint dataIDFlag()const;
	const CscsParseArray& dataIDSet()const;
	const CscsParseTriggerFeature& startTrigger()const;
	const CscsParseTriggerFeature& sendTrigger()const;
	const CscsParseTriggerFeature& stopTrigger()const;

	bool isValid()const;


	void setID(uint id);
	void setGroupID(uint groupID);
	void setOutTime(uint outTime);
	void setDelayTime(uint delayTime);
	void setSendCount(uint sendCount);
	void setDataIDFlag(uint dataIDFlag);
	void setDataIDSet(const CscsParseArray& dataIDSet);
	void setStartTrigger(const CscsParseTriggerFeature& start);
	void setSendTrigger(const  CscsParseTriggerFeature& send);
	void setStopTrigger(const  CscsParseTriggerFeature& stop);
	void setValid(bool valid);

private:
	//ID
	uint _id;
	//GroupID
	uint _groupID;
	//OutTime
	uint _outTime;
	//DelayTime
	uint _delayTime;
	//SendCount
	uint _sendCount;
	//DataIDFlag
	uint _dataIDFlag;
	//DataIDSet
	CscsParseArray _dataIDSet;
	//StartTrigger
	CscsParseTriggerFeature  _startTrigger;
	//SendTrigger
	CscsParseTriggerFeature	_sendTrigger;
	//StopTrigger
	CscsParseTriggerFeature	_stopTrigger;
	
	bool _valid;
	void parse(const rapidjson::Value& val);
	friend class CscsParsePlcCommon;

};

class CscsParseMoldBlock{
public:
	CscsParseMoldBlock();
	CscsParseMoldBlock(const rapidjson::Value& val);
	uint type()const;
	void setStartPos(uint pos);
	void setPackSize(uint size);
	const CscsParseArray& dataIDSet()const;
	const CscsParseArray& dataTypeSet()const;
	const CscsParseArray& dataStateSet()const;
	const CscsParseParamsArray& dataValueSet()const;
	bool isValid()const;

	uint queryStartPos()const;
	uint queryPackSize()const;

private:
	uint _type;
	uint _startPos;
	uint _packSize;
	uint _valid;
	CscsParseArray _dataIDSet;
	CscsParseArray _dataTypeSet;
	CscsParseArray _dataStateSet;
	CscsParseParamsArray _dataValueSet;
	void parse(const rapidjson::Value& val);
	friend class CscsParseMoldSet;
};

class CscsParseMoldSet{
public:
	CscsParseMoldSet();
	CscsParseMoldSet(const rapidjson::Value& val);
	uint ID()const;
	const std::map<uint,CscsParseMoldBlock>& moldList()const;
	bool isValid()const;

private:
	uint _id;
	uint _valid;
	std::map<uint,CscsParseMoldBlock> _moldList;
	void parse(const rapidjson::Value& val);
	friend class CscsParsePlcCommon;
};

class CscsParsePlcCommon{
public:
	CscsParsePlcCommon();
	CscsParsePlcCommon(const std::string& fileName);
	void parse(const std::string& fileName);
	const CscsParseProtocol& protocol()const;
	const CscsParseActual& actual()const;
	const CscsParseLineStatus& lineStatus()const;
	const CscsParseMoldSet& moldSet()const;
	const std::vector<CscsParseTrigger>& triggers()const;
	bool isValid()const;
private:
	CscsParseProtocol _protocol;
	CscsParseActual _actual;
	CscsParseLineStatus _lineStatus; 
	CscsParseMoldSet	_moldSet;
	std::vector<CscsParseTrigger> _triggers;
	bool _valid;
};

END_NAMESPACE

#endif