#ifndef SCSABSTRACTCOMMSOURCE_H
#define SCSABSTRACTCOMMSOURCE_H

#include <kernel/scsthread.h>
#include <kernel/scsbytearray.h>

BEGIN_NAMESPACE(Gemini)

class CscsParseTrigger;
class CscsParseMoldBlock;

class CscsAbstractCommSource:public CscsThread{
public:
	enum CommType{
		None=0,
		HMI=None,
		PLC,
		DSP55,
		DSP28,
		UserType=16
	};

	CscsAbstractCommSource(CommType type=CommType::None,CscsObject* parent=nullptr);
	~CscsAbstractCommSource();
	CommType commType()const{ return _type; }
	//准备通信数据文件
	virtual void setCommonFile(const std::string file){}

	virtual CscsByteArray    values(uint type)const{ return CscsByteArray();}
	virtual void  writeValues(uint type, const CscsByteArray& data){}
	//读资料参数
	virtual int  uploadParam(const std::vector<std::string>& ids){ return -1; }
	virtual int  uploadParam(const std::string& id){ return -1; }
	virtual int  uploadParam(const std::vector<uint>& ids){ return -1; }
	virtual int  uploadParam(uint id){ return -1; }
	virtual int  uploadParam(const CscsByteArray& data){ return -1; }
	


	//写资料参数
	virtual int  downloadParam(const std::map<std::string,CscsVariant>& params){ return -1; }
	virtual int  downloadParam(const std::string& id, const CscsVariant& value){ return -1; }
	virtual int  downloadParam(const std::map<uint,CscsVariant>& params){ return -1; }
	virtual int  downloadParam(uint id, const CscsVariant& value){ return -1; }
	virtual int  downloadParam(const CscsByteArray& data){ return -1; }


	//写动作指令
	virtual int  downloadAction(const std::vector<uint>& ids){ return -1; }
	virtual int  downloadAction(uint id){ return -1; }
	virtual int  downloadAction(const CscsByteArray& data){ return -1; }

	//下载触发器配置
	virtual int  downloadTrigger(const CscsParseTrigger& trigger){ return -1; }

	//下载模组资料
	virtual int  downloadMoldSet(const CscsParseMoldBlock& block){ return -1; }

	virtual int downloadMoldSet(){ return -1;}
	//连线状态
	virtual uint lineStatus()const{ return 0;}
	virtual const std::vector<uint32>& moldIDList()const{ return _null_list;}
	//协议不完善,暂不实现
	//请求曲线
	//virtual int	 uploadCurve(const CscsPlcCurveData& curve){ reutrn -1; }
private:
	CommType _type;
	std::vector<uint32> _null_list;
};
END_NAMESPACE
#endif