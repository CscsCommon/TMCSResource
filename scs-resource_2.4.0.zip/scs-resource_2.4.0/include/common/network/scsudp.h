#ifndef SCSUDP_H
#define SCSUDP_H
#include "scsabstractsocket.h"

BEGIN_NAMESPACE(Gemini)

class CscsUdp:public CscsAbstractSocket{

public:
	CscsUdp(CscsObject* parent=nullptr);
	virtual ~CscsUdp();

	bool 	bind(const CscsAddress& address, uint16 port, bool reuse=false);
	bool 	bind(uint16 port=0, bool reuse=false);

	bool 	hasPendingDatagrams()const;
	int64 	pendingDatagramSize()const;
	int64	readDatagram(char* data, int64 len, CscsAddress* host, uint16* port=0);
	int64	writeDatagram(const char* data, int64 len, const CscsAddress& host, uint16 port);
	int64 	writeDatagram(const bytearray& datagram, const CscsAddress& host, uint16 port){
		return writeDatagram(datagram.data(), datagram.size(), host, port);
	}

};

END_NAMESPACE
#endif