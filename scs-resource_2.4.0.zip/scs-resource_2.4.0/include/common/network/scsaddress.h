/*
 * Created by J.Wong 2018/10/12
 * 網絡地址操作api
 */
#ifndef SCSADDRESS_H
#define SCSADDRESS_H

 
 #include <kernel/scstypes.h>
 #include <string>
 #include "scsabstractsocket.h"

BEGIN_NAMESPACE(Gemini)

class CscsAddressPrivate;


class  CscsIPv6Address
{
public:
    inline uint8 &operator [](int index) { return c[index]; }
    inline uint8 operator [](int index) const { return c[index]; }
    uint8 c[16];
};

typedef CscsIPv6Address SCS_IPV6ADDR;

 class CscsAddress{
public:

  enum SpecialAddress{
      Null,
      Broadcast,
      LocalHost,
      LocalHostIPv6,
      Any,
      AnyIPv6
  };

  CscsAddress();
  CscsAddress(uint32 ip4addr);
  CscsAddress(const uint8* ip6addr, int len);
  CscsAddress(const std::string& string);
  CscsAddress(const CscsAddress& );
  CscsAddress(SpecialAddress address);
  virtual ~CscsAddress();

  CscsAddress& operator=(const CscsAddress& );


  void setAddress(uint32 ip4addr);
  void setAddress(const uint8* ip6addr, int len);
  bool setAddress(const std::string& address);
  void setAddress(const SCS_IPV6ADDR &ip6Addr);

  CscsAbstractSocket::NetWorkProtocol protocol()const;

  uint32 toIPv4Address()const;
  SCS_IPV6ADDR toIPv6Address()const;

  bool isIp4Addr()const;
  uint32 ip4Addr()const;

  bool isIp6Addr()const;
  SCS_IPV6ADDR ip6Addr()const;

  bool isNull()const;
  void clear();
  bool operator==(SpecialAddress address)const;
  bool operator==(const CscsAddress& )const;

  std::string toString()const;

  static std::list<CscsAddress> fromDomainName(const std::string& hostName);

private:
  CscsAddressPrivate* d;
 };

END_NAMESPACE

#endif
