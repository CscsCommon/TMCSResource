#ifndef SCSMODBUSTCPCLIENT_P_H
#define SCSMODBUSTCPCLIENT_P_H

#include <kernel/scsconnection.hpp>
#include <network/scsaddress.h>
#include <network/scstcp.h>
#include "scsmodbustcpclient.h"

#include "scsmodbusclient_p.h"


BEGIN_NAMESPACE(Gemini)


class CscsModbusTcpClientPrivate : public CscsModbusClientPrivate
{

public:
    void setupTcpSocket();
   
    CscsModbusTcpClient *mm_func();
};

END_NAMESPACE

#endif 