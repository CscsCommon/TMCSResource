#ifndef SCSMODBUSDEVICE_P_H
#define SCSMODBUSDEVICE_P_H
#include <kernel/scsvariant.h>
#include <kernel/scsobject_p.h>
#include <serialport/scsserialport.h>
#include "scsmodbusdevice.h"

BEGIN_NAMESPACE(Gemini)
class CscsModbusDevicePrivate:public CscsObjectPrivate{


public:
    CscsModbusDevicePrivate();

    CscsModbusDevice* mm_func() const;
    void setPrivateError(const CscsString &errorText, CscsModbusDevice::Error error);

    CscsModbusDevice::Error error;
    CscsString errorString;

    modbus_t *m_context;
    CscsString m_comPort;
    CscsSerialPort::DataBits m_dataBits;
    CscsSerialPort::Parity m_parity;
    CscsSerialPort::StopBits m_stopBits;
    CscsSerialPort::BaudRate m_baudRate;

    int m_networkPort;
    int m_slave;
    CscsString m_networkAddress;

    CscsHash<int, CscsVariant> m_userConnectionParams;    

};


END_NAMESPACE


#endif