
#ifndef SCSMODBUSCLIENT_H
#define SCSMODBUSCLIENT_H

#include <kernel/scsobject.h>
#include "scsmodbusdataunit.h"
#include "scsmodbusdevice.h"

BEGIN_NAMESPACE(Gemini)

class CscsModbusClientPrivate;

class CscsModbusClient : public CscsModbusDevice
{
  friend class CscsModbusClientPrivate;
public:

    explicit CscsModbusClient(CscsObject *parent = nullptr);
    ~CscsModbusClient();

    bool sendReadColis(int addr, int nb, uint8_t *dest);
    bool sendReadDiscreteInputs(int addr, int nb, uint8_t *dest);
    bool sendReadHoldingRegisters(int addr, int nb, uint16_t *dest);
    bool sendReadInputRegisters(int addr, int nb, uint16_t *dest);

    bool sendWriteSingleColis(int addr, int status);
    bool sendWriteMultiCoils(int addr, int nb, uint8_t *src);
    bool sendWriteSingleRegisters(int addr, uint16_t value);
    bool sendWriteMultigisters(int addr, int nb, uint16_t *src);

    int numberOfRetries() const;
    void setNumberOfRetries(int number);   

    CscsModbusClientPrivate *d_func() const;


protected:
    CscsModbusClient(CscsModbusClientPrivate *dd, CscsObject *parent = nullptr);

};

END_NAMESPACE

#endif