#ifndef SCSMODBUSSERVER_P_H
#define SCSMODBUSSERVER_P_H

#include <kernel/scsmap.h>
#include <kernel/scssocketnotifier.h>
#include <network/scsudp.h>
#include <network/scsaddress.h>
#include "scsmodbusdevice_p.h"
#include "scsmodbusdataunit.h"
#include "scsmodbusserver.h"

BEGIN_NAMESPACE(Gemini)
class CscsModbusServerPrivate : public CscsModbusDevicePrivate
{

public:

    CscsModbusServerPrivate();

    uint8_t processReadCoilsRequest( bool *ok, const int address);
    uint8_t processReadDiscreteInputsRequest( bool *ok, const int address);
    uint16_t processReadHoldingRegistersRequest( bool *ok, const int address);
    uint16_t processReadInputRegistersRequest( bool *ok, const int address);

    bool processWriteCoilsRequest(const int address, uint8_t value);
    bool processWriteDiscreteInputsRequest(const int address, uint8_t value);
    bool processWriteHoldingRegistersRequest(const int address, uint16_t value);
    bool processWriteInputRegistersRequest(const int address, uint16_t value);


    CscsVector<uint8_t> processReadMultiCoilsRequest( bool *ok, const int startAddress, int num);
    CscsVector<uint8_t> processReadMultiDiscreteInputsRequest( bool *ok, const int startAddress, int num);
    CscsVector<uint16_t> processReadMultiHoldingRegistersRequest( bool *ok, const int startAddress, int num);
    CscsVector<uint16_t> processReadMultiInputRegistersRequest( bool *ok, const int startAddress, int num);

    bool processWriteMultiCoilsRequest(int startAddress, const CscsVector<uint8_t> &datas);
    bool processWriteMultiDiscreteInputsRequest(int startAddress, const CscsVector<uint8_t> &datas);
    bool processWriteMultiHoldingRegistersRequest(int startAddress, const CscsVector<uint16_t> &datas);
    bool processWriteMultiInputRegistersRequest(int startAddress, const CscsVector<uint16_t> &datas);


    CscsModbusServer *mm_func() const;

    modbus_mapping_t *mb_mapping;
    uint8_t query[MODBUS_MAX_ADU_LENGTH]; 
    int m_request_length;
};

END_NAMESPACE

#endif