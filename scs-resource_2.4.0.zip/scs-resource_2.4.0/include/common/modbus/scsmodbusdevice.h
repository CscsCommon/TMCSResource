#ifndef SCSMODBUSDEVICE_H
#define SCSMODBUSDEVICE_H

#include <errno.h>
#include <modbus.h>
#include <kernel/scsobject.h>
#include <kernel/scsdevice.h>
#include <kernel/scsstring.h>
#include <serialport/scsserialport.h>


BEGIN_NAMESPACE(Gemini)

class CscsModbusDevicePrivate;
class CscsModbusDevice : public CscsObject
{

public:
    enum Error {
        NoError,
        ReadError,
        WriteError,
        ConnectionError,
        ConfigurationError,
        TimeoutError,
        ProtocolError,
        ReplyAbortedError,
        SocketError,
        UnknownError
    };

    enum ConnectionParameter {
        SerialPortNameParameter,
        SerialParityParameter,
        SerialBaudRateParameter,
        SerialDataBitsParameter,
        SerialStopBitsParameter,

        NetworkPortParameter,
        NetworkAddressParameter,

        UserParameter = 0x100
    };

    explicit CscsModbusDevice(CscsObject *parent = nullptr);
    ~CscsModbusDevice();

    CscsVariant connectionParameter(int parameter) const;
    void setConnectionParameter(int parameter, const CscsVariant &value);

    void setSlave(int slave);
    int slave() const; 

    Error error() const;
    CscsString errorString() const;

    bool setTimeout(uint32_t to_sec, uint32_t to_usec);
    void timeout(uint32_t *to_sec, uint32_t *to_usec);

    CscsModbusDevicePrivate* d_func() const;

SIGNALS:
    void errorOccurred(CscsModbusDevice::Error error){}

protected:
    CscsModbusDevice(CscsModbusDevicePrivate *dd, CscsObject *parent = nullptr);

    void setError(const CscsString &errorText, CscsModbusDevice::Error error);
    virtual bool open() = 0;
    virtual void close();
    int flush();

};


END_NAMESPACE

#endif