#ifndef SCSMODBUSRTUSERIALMASTER_H
#define SCSMODBUSRTUSERIALMASTER_H

#include "scsmodbusserver.h"
#include <serialport/scsserialport.h>
#include <kernel/scssocketnotifier.h>

BEGIN_NAMESPACE(Gemini)

class CscsModbusRtuSerialMasterPrivate;

class CscsModbusRtuSerialMaster : public CscsModbusServer
{

public:
    explicit CscsModbusRtuSerialMaster(CscsObject *parent = nullptr);
    ~CscsModbusRtuSerialMaster();

    CscsModbusRtuSerialMasterPrivate *d_func() const;
    bool open();
    void close() override;

    void processRequest();

protected:
    CscsModbusRtuSerialMaster(CscsModbusRtuSerialMasterPrivate *dd, CscsObject *parent = nullptr);

};



END_NAMESPACE

#endif 