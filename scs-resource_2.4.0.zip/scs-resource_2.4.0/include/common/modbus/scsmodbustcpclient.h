#ifndef SCSMODBUSTCPCLIENT_H
#define SCSMODBUSTCPCLIENT_H


#include "scsmodbusclient.h"

BEGIN_NAMESPACE(Gemini)

class CscsModbusTcpClientPrivate;

class CscsModbusTcpClient : public CscsModbusClient
{
friend class CscsModbusTcpClientPrivate;
public:
    explicit CscsModbusTcpClient(CscsObject *parent = nullptr);
    ~CscsModbusTcpClient();

    CscsModbusTcpClientPrivate *d_func();
    bool open() override;

protected:
    CscsModbusTcpClient(CscsModbusTcpClientPrivate *dd, CscsObject *parent = nullptr);

};

END_NAMESPACE

#endif