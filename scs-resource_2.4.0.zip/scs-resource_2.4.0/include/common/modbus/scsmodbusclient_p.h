#ifndef SCSMODBUSCLIENT_P_H
#define SCSMODBUSCLIENT_P_H

#include <kernel/scstimer.h>
#include "scsmodbusclient.h"

#include "scsmodbusdevice_p.h"


BEGIN_NAMESPACE(Gemini)

class CscsModbusClientPrivate : public CscsModbusDevicePrivate
{

public:
    CscsModbusClientPrivate();
    ~CscsModbusClientPrivate();
    
    int processReadCoils(int addr, int nb, uint8_t *dest);
    int processReadDiscrete(int addr, int nb, uint8_t *dest);
    int processReadRgisters(int addr, int nb, uint16_t *dest);
    int processReadMInputRegisters(int addr, int nb, uint16_t *dest);

    int processWriteCoils(int addr, int status);
    int processWriteMultiColis(int addr, int nb, uint8_t *src);
    int processWriteRegisters(int addr, const uint16_t value);
    int processWriteMultiRegisters(int addr, int nb, uint16_t *src);

    // int processReadWriteRegisters();
    // int processReplyException();

    virtual bool isOpen() const { return false; }

    int m_numberOfRetries;

    CscsModbusClient *mm_func() const;

    void init();    
};

END_NAMESPACE

#endif