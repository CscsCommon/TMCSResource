#ifndef SCSMODBUSRTUSERIALSLAVE_H
#define SCSMODBUSRTUSERIALSLAVE_H

#include "scsmodbusclient.h"

BEGIN_NAMESPACE(Gemini)

class CscsModbusRtuSerialSlavePrivate;

class CscsModbusRtuSerialSlave : public CscsModbusClient
{
friend class CscsModbusRtuSerialSlavePrivate;
public:
    explicit CscsModbusRtuSerialSlave(CscsObject *parent = nullptr);
    ~CscsModbusRtuSerialSlave();

    int interFrameDelay();
    void setInterFrameDelay(int us);

    bool open() override;
    CscsModbusRtuSerialSlavePrivate *d_func() const { return reinterpret_cast<CscsModbusRtuSerialSlavePrivate *>(d); }
protected:
    CscsModbusRtuSerialSlave(CscsModbusRtuSerialSlavePrivate *dd, CscsObject *parent = nullptr);

};

END_NAMESPACE

#endif