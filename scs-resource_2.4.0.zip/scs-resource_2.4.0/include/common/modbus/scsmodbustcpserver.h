#ifndef SCSMODBUSTCPSERVER_H
#define SCSMODBUSTCPSERVER_H

#include "scsmodbusserver.h"
#include <kernel/scssocketnotifier.h>

BEGIN_NAMESPACE(Gemini)

class CscsModbusTcpServerPrivate;

class CscsModbusTcpServer : public CscsModbusServer{
friend class CscsModbusTcpServerPrivate;
public:
    explicit CscsModbusTcpServer(CscsObject *parent = nullptr);
    ~CscsModbusTcpServer();

    bool open() override;

    void setListenSocketNum(int block);
    int listenSocketNum();

    void processRequest();
    void close() override;

    CscsModbusTcpServerPrivate *d_func();

protected:
    CscsModbusTcpServer(CscsModbusTcpServerPrivate *dd, CscsObject *parent = nullptr);

};

END_NAMESPACE

#endif 