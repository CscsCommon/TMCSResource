#ifndef SCSMODBUSDATAUNIT_H
#define SCSMODBUSDATAUNIT_H

#include <kernel/scsmap.h>
#include <kernel/scsvector.h>
#include <kernel/scsvariant.h>

BEGIN_NAMESPACE(Gemini)

class CscsModbusDataUnit
{
public:
    enum RegisterType {
        Invalid,
        DiscreteInputs,
        Coils,
        InputRegisters,
        HoldingRegisters
    };

    enum DataType{
      Uint8,
      Uint16
    };

    CscsModbusDataUnit();

    explicit CscsModbusDataUnit(RegisterType type)
        : CscsModbusDataUnit(type, (int)0, (uint8_t)0)
    {
      if(type == DiscreteInputs || type == Coils)
        m_dataType = Uint8;
      else if(type == InputRegisters || type == HoldingRegisters)
        m_dataType = Uint16;
    }

    CscsModbusDataUnit(RegisterType type, int newStartAddress, uint8_t newValueCount)
        : CscsModbusDataUnit(type, newStartAddress, CscsVector<uint8_t>(newValueCount))
    { m_dataType = Uint8; }

    CscsModbusDataUnit(RegisterType type, int newStartAddress, uint16_t newValueCount)
        : CscsModbusDataUnit(type, newStartAddress, CscsVector<uint16_t>(newValueCount))
    { m_dataType = Uint16; }

    CscsModbusDataUnit(RegisterType type, int newStartAddress, const CscsVector<uint8_t> &newValues)
        : m_type(type)
        , m_startAddress(newStartAddress)
    {
      for(int i = 0; i < newValues.size(); i++)
        m_values.append(CscsVariant(newValues.at(i)));
    }

    CscsModbusDataUnit(RegisterType type, int newStartAddress, const CscsVector<uint16_t> &newValues)
        : m_type(type)
        , m_startAddress(newStartAddress)
    {
      for(int i = 0; i < newValues.size(); i++)
        m_values.append(CscsVariant(newValues.at(i)));
    }

    DataType dataType() const { return m_dataType; }
    void setDataType(DataType type) { if(type != m_dataType) m_dataType = type, m_values.clear(); }

    RegisterType registerType() const { return m_type; }
    void setRegisterType(RegisterType type) { m_type = type; }

    inline int startAddress() const { return m_startAddress; }
    inline void setStartAddress(int newAddress) { m_startAddress = newAddress; }

    inline CscsVector<CscsVariant> values() const { return m_values; }
    inline void setValues(const CscsVector<uint8_t> &newValues)
    {
        for(int i = 0; i < newValues.size(); i++)
          m_values.append(CscsVariant(newValues.at(i)));
    }

   inline void setValues(const CscsVector<uint16_t> &newValues)
    {
        for(int i = 0; i < newValues.size(); i++)
          m_values.append(CscsVariant(newValues.at(i)));
    }    

    inline uint valueCount() const { return m_values.count(); }

    inline void setValue(int index, uint16_t newValue)
    {
        if (m_values.isEmpty() || index >= m_values.size()|| m_dataType != Uint16)
            return;
        m_values[index] = CscsVariant(newValue);
    }

    inline void setValue(int index, uint8_t newValue)
    {
        if (m_values.isEmpty() || index >= m_values.size() || m_dataType != Uint8)
            return;
        m_values[index] = CscsVariant(newValue);
    }

    inline CscsVariant value(int index) const { return m_values.value(index); }

    bool isValid() const { return m_type != Invalid && m_startAddress != -1; }

private:
    DataType    m_dataType;
    RegisterType m_type;
    int m_startAddress;
    CscsVector<CscsVariant> m_values;
};
typedef CscsMap<CscsModbusDataUnit::RegisterType, CscsModbusDataUnit> CscsModbusDataUnitMap;


END_NAMESPACE
#endif