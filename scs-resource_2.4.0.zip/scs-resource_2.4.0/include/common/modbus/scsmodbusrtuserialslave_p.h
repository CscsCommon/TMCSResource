#ifndef SCSMODBUSRTUSERIALSLAVE_P_H
#define SCSMODBUSRTUSERIALSLAVE_P_H

#include <kernel/scsconnection.hpp>
#include <serialport/scsserialport.h>
#include "scsmodbusrtuserialslave.h"

#include "scsmodbusclient_p.h"


BEGIN_NAMESPACE(Gemini)


class CscsModbusRtuSerialSlavePrivate : public CscsModbusClientPrivate
{

public:
    void setupSerialPort()
    {

    }

    CscsModbusRtuSerialSlave *mm_func() const { return reinterpret_cast<CscsModbusRtuSerialSlave *>(mm); }

};

END_NAMESPACE

#endif // QMODBUSRTUSERIALSLAVE_P_H
