#ifndef SCSMODBUSTCPSERVER_P_H
#define SCSMODBUSTCPSERVER_P_H

#include <kernel/scsconnection.hpp>
#include <kernel/scsvector.h>
#include <network/scstcp.h>

#include "scsmodbustcpserver.h"
#include "scsmodbusserver_p.h"

BEGIN_NAMESPACE(Gemini)

class CscsModbusTcpServerPrivate : public CscsModbusServerPrivate
{
public:

    CscsModbusTcpServerPrivate();

    void processNewConnection(int s);
    void processData(int socket);

    void deleteNotifier(int socket);
    void clearAllClient();

    bool modbusCreate();
    CscsModbusTcpServer *mm_func();

    int m_tcpListen_number;
    CscsSocketNotifier *m_listen_notifier;

};

END_NAMESPACE

#endif