#ifndef SCSMODBUSSERVER_H
#define SCSMODBUSSERVER_H

#include <kernel/scsobject.h>
#include <kernel/scsvariant.h>
#include "scsmodbusdataunit.h"
#include "scsmodbusdevice.h"

BEGIN_NAMESPACE(Gemini)

class CscsModbusServerPrivate;
class CscsModbusServer : public CscsModbusDevice
{
friend class CscsModbusServerPrivate;

public:

    explicit CscsModbusServer(CscsObject *parent = nullptr);
    ~CscsModbusServer();

    void setStartAddressAndNum(int start_bits, int nb_bits, int start_input_bits, int nb_input_bits, 
                          int start_registers, int nb_registers, int start_input_registers, int nb_input_registers);
    bool data(CscsModbusDataUnit *newData) const;
    bool setData(const CscsModbusDataUnit &unit);

    bool setData(CscsModbusDataUnit::RegisterType table, int address, uint16_t data);
    bool data(CscsModbusDataUnit::RegisterType table, int address, uint16_t *data) const;

    int socketDescriptor();
    int setSocketDescriptor(int socket);   

    virtual void processRequest() = 0;
    CscsModbusServerPrivate *d_func() const;

protected:
    CscsModbusServer(CscsModbusServerPrivate *dd, CscsObject *parent = nullptr);


};

END_NAMESPACE

#endif