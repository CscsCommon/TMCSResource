#ifndef SCSMODBUSSERIALMASTER_P_H
#define SCSMODBUSSERIALMASTER_P_H

#include <serialport/scsserialport.h>
#include <kernel/scsconnection.hpp>
#include <kernel/scspointer.h>
#include <kernel/scsqueue.h>
#include <kernel/scstimer.h>
#include <painting/scsmath.h>
#include <modbus.h>

#include "scsmodbusserver_p.h"
#include "scsmodbusrtuserialmaster.h"


BEGIN_NAMESPACE(Gemini)

class CscsModbusRtuSerialMasterPrivate : public CscsModbusServerPrivate
{

public:
    CscsModbusRtuSerialMasterPrivate();
   ~CscsModbusRtuSerialMasterPrivate();
    CscsModbusRtuSerialMaster *mm_func() const;

    void setup();
    void processData();
    void scsClearNotifier();
    CscsSocketNotifier *m_port_notifier;

    uint8_t src[MODBUS_MAX_PDU_LENGTH];

};

END_NAMESPACE

#endif 