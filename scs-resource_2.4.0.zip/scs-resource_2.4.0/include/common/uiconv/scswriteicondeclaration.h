#ifndef SCSWRITEICONDECLARATION_H
#define SCSWRITEICONDECLARATION_H
#include "scstreewalker.h"

BEGIN_NAMESPACE(Gemini)

class CscsTextStream;
class CscsUIDriver;
class CscsUic;

struct CscsOption;

class CscsWriteIconDeclaration : public CscsTreeWalker
{
public:
    CscsWriteIconDeclaration(CscsUic *uic);

    void acceptUI(CscsDomUI *node);
    void acceptImages(CscsDomImages *images);
    void acceptImage(CscsDomImage *image);

private:
    CscsUic *uic;
    CscsUIDriver *driver;
    CscsTextStream &output;
    const CscsOption &option;
	
};

END_NAMESPACE

#endif