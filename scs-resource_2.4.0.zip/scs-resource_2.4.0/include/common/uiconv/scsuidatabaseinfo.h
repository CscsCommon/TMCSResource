#ifndef SCSUIDATABASEINFO_H
#define SCSUIDATABASEINFO_H
#include "scstreewalker.h"
#include <kernel/scsstringlist.h>
#include <kernel/scsmap.h>

BEGIN_NAMESPACE(Gemini)

class CscsUIDriver;

class CscsUIDataBaseInfo : public CscsTreeWalker
{
public:
    CscsUIDataBaseInfo(CscsUIDriver *driver);

    void acceptUI(CscsDomUI *node);
    void acceptWidget(CscsDomWidget *node);

    inline CscsStringList connections() const
    { return m_connections; }

    inline CscsStringList cursors(const CscsString &connection) const
    { return m_cursors.value(connection); }

    inline CscsStringList fields(const CscsString &connection) const
    { return m_fields.value(connection); }

private:
    CscsUIDriver *driver;
    CscsStringList m_connections;
    CscsMap<CscsString, CscsStringList> m_cursors;
    CscsMap<CscsString, CscsStringList> m_fields;
};

END_NAMESPACE

#endif