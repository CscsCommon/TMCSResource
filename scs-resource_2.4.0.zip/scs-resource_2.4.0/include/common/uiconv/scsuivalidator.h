#ifndef SCSUIVALIDATOR_H
#define SCSUIVALIDATOR_H
#include "scstreewalker.h"

BEGIN_NAMESPACE(Gemini)

class CscsTextStream;
class CscsUIDriver;
class CscsUic;
struct CscsOption;

struct CscsUIValidator : public CscsTreeWalker
{
    CscsUIValidator(CscsUic *uic);

    void acceptUI(CscsDomUI *node);
    void acceptWidget(CscsDomWidget *node);

    void acceptLayoutItem(CscsDomLayoutItem *node);
    void acceptLayout(CscsDomLayout *node);

    void acceptActionGroup(CscsDomActionGroup *node);
    void acceptAction(CscsDomAction *node);

private:
    CscsUIDriver *driver;
    CscsTextStream &output;
    const CscsOption &option;
    CscsUic *uic;
};

END_NAMESPACE

#endif