#ifndef SCSWRITEINCLUDES_H
#define SCSWRITEINCLUDES_H

#include "scstreewalker.h"
#include <kernel/scsmap.h>
#include <kernel/scsstring.h>

BEGIN_NAMESPACE(Gemini)

class CscsTextStream;
class CscsUIDriver;
class CscsUic;

struct CscsOption;

struct CscsWriteIncludes : public CscsTreeWalker
{
    CscsWriteIncludes(CscsUic *uic);

    void acceptUI(CscsDomUI *node);
    void acceptWidget(CscsDomWidget *node);
    void acceptLayout(CscsDomLayout *node);
    void acceptSpacer(CscsDomSpacer *node);

//
// custom widgets
//
    void acceptCustomWidgets(CscsDomCustomWidgets *node);
    void acceptCustomWidget(CscsDomCustomWidget *node);

//
// include hints
//
    void acceptIncludes(CscsDomIncludes *node);
    void acceptInclude(CscsDomInclude *node);

private:
    void add(const CscsString &className);

private:
    CscsUic *uic;
    CscsUIDriver *driver;
    CscsTextStream &output;
    const CscsOption &option;

    CscsMap<CscsString, bool> m_includes;
    CscsMap<CscsString, bool> m_customWidgets;
    CscsMap<CscsString, CscsString> m_classToHeader;
    CscsMap<CscsString, CscsString> m_oldHeaderToNewHeader;
};

END_NAMESPACE

#endif