#ifndef SCSTEXTTABLE_H
#define SCSTEXTTABLE_H
#include "scstextobject.h"

BEGIN_NAMESPACE(Gemini)

class CscsTextCursor;
class CscsTextTable;
class CscsTextTablePrivate;

class  CscsTextTableCell
{
public:
    CscsTextTableCell() : table(0) {}
    ~CscsTextTableCell() {}
    CscsTextTableCell(const CscsTextTableCell &o) : table(o.table), fragment(o.fragment) {}
    CscsTextTableCell &operator=(const CscsTextTableCell &o)
    { table = o.table; fragment = o.fragment; return *this; }

    void setFormat(const CscsTextCharFormat &format);
    CscsTextCharFormat format() const;

    int row() const;
    int column() const;

    int rowSpan() const;
    int columnSpan() const;

    inline bool isValid() const { return table != 0; }

    CscsTextCursor firstCursorPosition() const;
    CscsTextCursor lastCursorPosition() const;
    int firstPosition() const;
    int lastPosition() const;

    inline bool operator==(const CscsTextTableCell &other) const
    { return table == other.table && fragment == other.fragment; }
    inline bool operator!=(const CscsTextTableCell &other) const
    { return !operator==(other); }

    CscsTextFrame::iterator begin() const;
    CscsTextFrame::iterator end() const;

private:
    friend class CscsTextTable;
    CscsTextTableCell(const CscsTextTable *t, int f)
        : table(t), fragment(f) {}

    const CscsTextTable *table;
    int fragment;
};

class  CscsTextTable : public CscsTextFrame
{
public:
    explicit CscsTextTable(CscsTextDocument *doc);
    ~CscsTextTable();

    void resize(int rows, int cols);
    void insertRows(int pos, int num);
    void insertColumns(int pos, int num);
    void removeRows(int pos, int num);
    void removeColumns(int pos, int num);

    void mergeCells(int row, int col, int numRows, int numCols);
    void mergeCells(const CscsTextCursor &cursor);
    void splitCell(int row, int col, int numRows, int numCols);

    int rows() const;
    int columns() const;

    CscsTextTableCell cellAt(int row, int col) const;
    CscsTextTableCell cellAt(int position) const;
    CscsTextTableCell cellAt(const CscsTextCursor &c) const;

    CscsTextCursor rowStart(const CscsTextCursor &c) const;
    CscsTextCursor rowEnd(const CscsTextCursor &c) const;

    void setFormat(const CscsTextTableFormat &format);
    CscsTextTableFormat format() const { return CscsTextObject::format().toTableFormat(); }

private:
    CscsTextTablePrivate* d_func()const;
    friend class CscsTextTableCell;
    friend class CscsTextTablePrivate;
};

END_NAMESPACE

#endif