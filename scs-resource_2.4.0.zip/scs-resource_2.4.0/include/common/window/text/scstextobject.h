#ifndef SCSTEXTOBJECT_H
#define SCSTEXTOBJECT_H
#include <kernel/scsobject.h>
#include "scstextformat.h"

BEGIN_NAMESPACE(Gemini)

class CscsTextObjectPrivate;
class CscsTextDocument;
class CscsTextDocumentPrivate;
class CscsTextCursor;
class CscsTextBlock;
class CscsTextFragment;
class CscsTextLayout;
class CscsTextList;

class  CscsTextObject : public CscsObject
{

protected:
    explicit CscsTextObject(CscsTextDocument *doc);
    ~CscsTextObject();

    void setFormat(const CscsTextFormat &format);

public:
    CscsTextFormat format() const;
    int formatIndex() const;

    CscsTextDocument *document() const;

    int objectIndex() const;

    CscsTextDocumentPrivate *docHandle() const;

protected:
    CscsTextObject(CscsTextObjectPrivate* dd, CscsTextDocument *doc);

private:
	CscsTextObjectPrivate* d_func()const;
    friend class CscsTextDocumentPrivate;
};

class CscsTextBlockGroupPrivate;
class  CscsTextBlockGroup : public CscsTextObject
{

protected:
    explicit CscsTextBlockGroup(CscsTextDocument *doc);
    ~CscsTextBlockGroup();

    virtual void blockInserted(const CscsTextBlock &block);
    virtual void blockRemoved(const CscsTextBlock &block);
    virtual void blockFormatChanged(const CscsTextBlock &block);

    CscsList<CscsTextBlock> blockList() const;

protected:
    CscsTextBlockGroup(CscsTextBlockGroupPrivate* dd, CscsTextDocument *doc);
private:
    CscsTextBlockGroupPrivate* d_func()const;
    friend class CscsTextDocumentPrivate;
};

class  CscsTextFrameLayoutData {
public:
    virtual ~CscsTextFrameLayoutData();
};

class CscsTextFramePrivate;
class  CscsTextFrame : public CscsTextObject
{

public:
    explicit CscsTextFrame(CscsTextDocument *doc);
    ~CscsTextFrame();

    inline void setFrameFormat(const CscsTextFrameFormat &format);
    CscsTextFrameFormat frameFormat() const { return CscsTextObject::format().toFrameFormat(); }

    CscsTextCursor firstCursorPosition() const;
    CscsTextCursor lastCursorPosition() const;
    int firstPosition() const;
    int lastPosition() const;

    CscsTextFrameLayoutData *layoutData() const;
    void setLayoutData(CscsTextFrameLayoutData *data);

    CscsList<CscsTextFrame *> childFrames() const;
    CscsTextFrame *parentFrame() const;

    class  iterator {
        CscsTextFrame *f;
        int b;
        int e;
        CscsTextFrame *cf;
        int cb;

        friend class CscsTextFrame;
        friend class CscsTextTableCell;
        friend class CscsTextDocumentLayoutPrivate;
        iterator(CscsTextFrame *frame, int block, int begin, int end);
    public:
        iterator();
        iterator(const iterator &o);
        iterator &operator=(const iterator &o);

        CscsTextFrame *parentFrame() const { return f; }

        CscsTextFrame *currentFrame() const;
        CscsTextBlock currentBlock() const;

        bool atEnd() const { return !cf && cb == e; }

        inline bool operator==(const iterator &o) const { return f == o.f && cf == o.cf && cb == o.cb; }
        inline bool operator!=(const iterator &o) const { return f != o.f || cf != o.cf || cb != o.cb; }
        iterator &operator++();
        inline iterator operator++(int) { iterator tmp = *this; operator++(); return tmp; }
        iterator &operator--();
        inline iterator operator--(int) { iterator tmp = *this; operator--(); return tmp; }
    };

    friend class iterator;
    typedef iterator Iterator;

    iterator begin() const;
    iterator end() const;

protected:
    CscsTextFrame(CscsTextFramePrivate* dd, CscsTextDocument *doc);
private:
    friend class CscsTextDocumentPrivate;
    friend class CscsTextFramePrivate;
    CscsTextFramePrivate* d_func()const;
};

inline void CscsTextFrame::setFrameFormat(const CscsTextFrameFormat &aformat)
{ CscsTextObject::setFormat(aformat); }

class  CscsTextBlockUserData {
public:
    virtual ~CscsTextBlockUserData();
};

class  CscsTextBlock
{
    friend class CscsSyntaxHighlighter;
public:
    inline CscsTextBlock(CscsTextDocumentPrivate *priv, int b) : p(priv), n(b) {}
    inline CscsTextBlock() : p(0), n(0) {}
    inline CscsTextBlock(const CscsTextBlock &o) : p(o.p), n(o.n) {}
    inline CscsTextBlock &operator=(const CscsTextBlock &o) { p = o.p; n = o.n; return *this; }

    inline bool isValid() const { return p != 0 && n != 0; }

    inline bool operator==(const CscsTextBlock &o) const { return p == o.p && n == o.n; }
    inline bool operator!=(const CscsTextBlock &o) const { return p != o.p || n != o.n; }
    inline bool operator<(const CscsTextBlock &o) const { return position() < o.position(); }

    int position() const;
    int length() const;
    bool contains(int position) const;

    CscsTextLayout *layout() const;
    void clearLayout();
    CscsTextBlockFormat blockFormat() const;
    int blockFormatIndex() const;
    CscsTextCharFormat charFormat() const;
    int charFormatIndex() const;

    CscsString text() const;

    const CscsTextDocument *document() const;

    CscsTextList *textList() const;

    CscsTextBlockUserData *userData() const;
    void setUserData(CscsTextBlockUserData *data);

    int userState() const;
    void setUserState(int state);

    int revision() const;
    void setRevision(int rev);

    bool isVisible() const;
    void setVisible(bool visible);

    int blockNumber() const;

    class  iterator {
        const CscsTextDocumentPrivate *p;
        int b;
        int e;
        int n;
        friend class CscsTextBlock;
        iterator(const CscsTextDocumentPrivate *priv, int begin, int end, int f) : p(priv), b(begin), e(end), n(f) {}
    public:
        iterator() : p(0), b(0), e(0), n(0) {}
        iterator(const iterator &o) : p(o.p), b(o.b), e(o.e), n(o.n) {}

        CscsTextFragment fragment() const;

        bool atEnd() const { return n == e; }

        inline bool operator==(const iterator &o) const { return p == o.p && n == o.n; }
        inline bool operator!=(const iterator &o) const { return p != o.p || n != o.n; }
        iterator &operator++();
        inline iterator operator++(int) { iterator tmp = *this; operator++(); return tmp; }
        iterator &operator--();
        inline iterator operator--(int) { iterator tmp = *this; operator--(); return tmp; }
    };

    typedef iterator Iterator;

    iterator begin() const;
    iterator end() const;

    CscsTextBlock next() const;
    CscsTextBlock previous() const;

    inline CscsTextDocumentPrivate *docHandle() const { return p; }

private:
    CscsTextDocumentPrivate *p;
    int n;
    friend class CscsTextDocumentPrivate;
    friend class CscsTextLayout;
};


class  CscsTextFragment
{
public:
    inline CscsTextFragment(const CscsTextDocumentPrivate *priv, int f, int fe) : p(priv), n(f), ne(fe) {}
    inline CscsTextFragment() : p(0), n(0), ne(0) {}
    inline CscsTextFragment(const CscsTextFragment &o) : p(o.p), n(o.n), ne(o.ne) {}
    inline CscsTextFragment &operator=(const CscsTextFragment &o) { p = o.p; n = o.n; ne = o.ne; return *this; }

    inline bool isValid() const { return p && n; }

    inline bool operator==(const CscsTextFragment &o) const { return p == o.p && n == o.n; }
    inline bool operator!=(const CscsTextFragment &o) const { return p != o.p || n != o.n; }
    inline bool operator<(const CscsTextFragment &o) const { return position() < o.position(); }

    int position() const;
    int length() const;
    bool contains(int position) const;

    CscsTextCharFormat charFormat() const;
    int charFormatIndex() const;
    CscsString text() const;

private:
    const CscsTextDocumentPrivate *p;
    int n;
    int ne;
};

END_NAMESPACE


#endif