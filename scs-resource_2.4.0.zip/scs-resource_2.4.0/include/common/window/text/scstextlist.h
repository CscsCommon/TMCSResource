#ifndef SCSTEXTLIST_H
#define SCSTEXTLIST_H
#include "scstextobject.h"

BEGIN_NAMESPACE(Gemini)

class CscsTextListPrivate;
class CscsTextCursor;

class  CscsTextList : public CscsTextBlockGroup
{
public:
    explicit CscsTextList(CscsTextDocument *doc);
    ~CscsTextList();

    int count() const;

    inline bool isEmpty() const
    { return count() == 0; }

    CscsTextBlock item(int i) const;

    int itemNumber(const CscsTextBlock &) const;
    CscsString itemText(const CscsTextBlock &) const;

    void removeItem(int i);
    void remove(const CscsTextBlock &);

    void add(const CscsTextBlock &block);

    inline void setFormat(const CscsTextListFormat &format);
    CscsTextListFormat format() const { return CscsTextObject::format().toListFormat(); }

private:
    CscsTextListPrivate* d_func()const;
};

inline void CscsTextList::setFormat(const CscsTextListFormat &aformat)
{ CscsTextObject::setFormat(aformat); }

END_NAMESPACE
#endif