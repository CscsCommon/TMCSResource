#ifndef SCSTEXTDOCUMENT_H
#define SCSTEXTDOCUMENT_H

#include <kernel/scsobject.h>
#include <painting/scssize.h>
#include <painting/scsfont.h>
#include <painting/scsrect.h>
#include "scstextoption.h"

BEGIN_NAMESPACE(Gemini)

class CscsTextFormatCollection;
class CscsTextListFormat;
class CscsRect;
class CscsPainter;
class CscsAbstractTextDocumentLayout;
class CscsPoint;
class CscsTextCursor;
class CscsTextObject;
class CscsTextFormat;
class CscsTextFrame;
class CscsTextBlock;
class CscsCodec;
class CscsUrl;
class CscsVariant;
class CscsRectF;
class CscsTextOption;
class CscsRegExp;
class CscsString;
class CscsTextDocumentPrivate;

template<typename T> class CscsVector;
bool mightBeRichText(const CscsString&);
CscsString escape(const CscsString& plain);
CscsString convertFromPlainText(const CscsString &plain, SCS::WhiteSpaceMode mode = SCS::WhiteSpacePre);

class  CscsAbstractUndoItem
{
public:
    virtual ~CscsAbstractUndoItem() = 0;
    virtual void undo() = 0;
    virtual void redo() = 0;
};

inline CscsAbstractUndoItem::~CscsAbstractUndoItem()
{
}



class  CscsTextDocument : public CscsObject
{

public:
    explicit CscsTextDocument(CscsObject *parent = 0);
    explicit CscsTextDocument(const CscsString &text, CscsObject *parent = 0);
    ~CscsTextDocument();

    CscsTextDocument *clone(CscsObject *parent = 0) const;

    bool isEmpty() const;
    virtual void clear();

    void setUndoRedoEnabled(bool enable);
    bool isUndoRedoEnabled() const;

    bool isUndoAvailable() const;
    bool isRedoAvailable() const;

    int revision() const;

    void setDocumentLayout(CscsAbstractTextDocumentLayout *layout);
    CscsAbstractTextDocumentLayout *documentLayout() const;

    enum MetaInformation {
        DocumentTitle,
        DocumentUrl
    };
    void setMetaInformation(MetaInformation info, const CscsString &);
    CscsString metaInformation(MetaInformation info) const;

    CscsString toPlainText() const;
    void setPlainText(const CscsString &text);

    enum FindFlag
    {
        FindBackward        = 0x00001,
        FindCaseSensitively = 0x00002,
        FindWholeWords      = 0x00004
    };
    SCS_DECLARE_FLAGS(FindFlags, FindFlag)

    CscsTextCursor find(const CscsString &subString, int from = 0, FindFlags options = 0) const;
    CscsTextCursor find(const CscsString &subString, const CscsTextCursor &from, FindFlags options = 0) const;

    CscsTextCursor find(const CscsRegExp &expr, int from = 0, FindFlags options = 0) const;
    CscsTextCursor find(const CscsRegExp &expr, const CscsTextCursor &from, FindFlags options = 0) const;

    CscsTextFrame *frameAt(int pos) const;
    CscsTextFrame *rootFrame() const;

    CscsTextObject *object(int objectIndex) const;
    CscsTextObject *objectForFormat(const CscsTextFormat &) const;

    CscsTextBlock findBlock(int pos) const;
    CscsTextBlock findBlockByNumber(int blockNumber) const;
    CscsTextBlock begin() const;
    CscsTextBlock end() const;

    CscsTextBlock firstBlock() const;
    CscsTextBlock lastBlock() const;

    void setPageSize(const CscsSizeF &size);
    CscsSizeF pageSize() const;

    void setDefaultFont(const CscsFont &font);
    CscsFont defaultFont() const;

    int pageCount() const;

    bool isModified() const;


    enum ResourceType {
        HtmlResource  = 1,
        ImageResource = 2,
        StyleSheetResource = 3,

        UserResource  = 100
    };

    CscsVariant resource(int type, const CscsUrl &name) const;
    void addResource(int type, const CscsUrl &name, const CscsVariant &resource);

    CscsVector<CscsTextFormat> allFormats() const;

    void markContentsDirty(int from, int length);

    void setUseDesignMetrics(bool b);
    bool useDesignMetrics() const;

    void drawContents(CscsPainter *painter, const CscsRectF &rect = CscsRectF());

    void setTextWidth(double width);
    double textWidth() const;

    double idealWidth() const;

    double indentWidth() const;
    void setIndentWidth(double width);

    void adjustSize();
    CscsSizeF size() const;

    int blockCount() const;


    void undo(CscsTextCursor *cursor);
    void redo(CscsTextCursor *cursor);

    int maximumBlockCount() const;
    void setMaximumBlockCount(int maximum);

    CscsTextOption defaultTextOption() const;
    void setDefaultTextOption(const CscsTextOption &option);

SIGNALS:
    void contentsChange(int from, int charsRemoves, int charsAdded){}
    void contentsChanged(){}
    void undoAvailable(bool){}
    void redoAvailable(bool){}
    void undoCommandAdded(){}
    void modificationChanged(bool m){}
    void cursorPositionChanged(const CscsTextCursor &cursor){}
    void blockCountChanged(int newBlockCount){}

    void documentLayoutChanged();

SLOTS:
    void undo();
    void redo();
    void appendUndoItem(CscsAbstractUndoItem *);
    void setModified(bool m = true);

protected:
    virtual CscsTextObject *createObject(const CscsTextFormat &f);
    virtual CscsVariant loadResource(int type, const CscsUrl &name);

    CscsTextDocument(CscsTextDocumentPrivate* dd, CscsObject *parent);
public:
    CscsTextDocumentPrivate *docHandle() const;
private:
    CscsTextDocumentPrivate* d_func()const;
    friend class CscsTextDocumentPrivate;

    BEGIN_PROPERTY(CscsTextDocument,CscsObject)
    META_PROPERTY(bool, undoRedoEnabled, READ, isUndoRedoEnabled, WRITE, setUndoRedoEnabled)
    META_PROPERTY(bool, modified, READ, isModified, WRITE, setModified)
    META_PROPERTY(CscsSizeF, pageSize, READ, pageSize, WRITE, setPageSize)
    META_PROPERTY(CscsFont, defaultFont, READ, defaultFont, WRITE, setDefaultFont)
    META_PROPERTY(bool, useDesignMetrics, READ, useDesignMetrics, WRITE, setUseDesignMetrics)
    META_READ_PROPERTY(CscsSizeF, size, READ, size)
    META_PROPERTY(double, textWidth, READ, textWidth, WRITE, setTextWidth)
    META_READ_PROPERTY(int, blockCount, READ, blockCount)
    META_PROPERTY(double, indentWidth, READ, indentWidth, WRITE, setIndentWidth)
    META_PROPERTY(int, maximumBlockCount, READ, maximumBlockCount, WRITE, setMaximumBlockCount)
    META_PROPERTY(CscsTextOption, defaultTextOption, READ, defaultTextOption, WRITE, setDefaultTextOption)
    END_PROPERTY
};

SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsTextDocument::FindFlags)

END_NAMESPACE

#endif