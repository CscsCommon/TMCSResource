#ifndef SCSITEMEDITORFACTORY_H
#define SCSITEMEDITORFACTORY_H
#include <kernel/scsbytearray.h>
#include <kernel/scshash.h>
#include <kernel/scsvariant.h>

BEGIN_NAMESPACE(Gemini)

class CscsWidget;

class CscsItemEditorCreatorBase
{
public:
    virtual ~CscsItemEditorCreatorBase() {}

    virtual CscsWidget *createWidget(CscsWidget *parent) const = 0;
    virtual CscsByteArray valuePropertyName() const = 0;
};

template <class T>
class CscsItemEditorCreator : public CscsItemEditorCreatorBase
{
public:
    inline CscsItemEditorCreator(const CscsByteArray &valuePropertyName);
    inline CscsWidget *createWidget(CscsWidget *parent) const { return new T(parent); }
    inline CscsByteArray valuePropertyName() const { return propertyName; }

private:
    CscsByteArray propertyName;
};

template <class T>
inline CscsItemEditorCreator<T>::CscsItemEditorCreator(const CscsByteArray &avaluePropertyName)
    : propertyName(avaluePropertyName) {}

class  CscsItemEditorFactory
{
public:
    inline CscsItemEditorFactory() {}
    virtual ~CscsItemEditorFactory();

    virtual CscsWidget *createEditor(CscsVariant::Type type, CscsWidget *parent) const;
    virtual CscsByteArray valuePropertyName(CscsVariant::Type type) const;

    void registerEditor(CscsVariant::Type type, CscsItemEditorCreatorBase *creator);

    static const CscsItemEditorFactory *defaultFactory();
    static void setDefaultFactory(CscsItemEditorFactory *factory);

private:
    CscsHash<CscsVariant::Type, CscsItemEditorCreatorBase *> creatorMap;
};

END_NAMESPACE

#endif