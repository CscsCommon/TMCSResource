#ifndef SCSABSTRACTITEMVIEW_H
#define SCSABSTRACTITEMVIEW_H
#include <window/scsabstractitemmodel.h>
#include <window/scsabstractitemdelegate.h>
#include <window/scsitemselectionmodel.h>
#include <window/widgets/scsabstractscrollarea.h>
BEGIN_NAMESPACE(Gemini)

class CscsEvent;
class CscsAbstractItemViewPrivate;
class CscsStyleOptionViewItem;
class CscsMouseEvent;
class CscsFocusEvent;
class CscsResizeEvent;
class CscsKeyEvent;

class  CscsAbstractItemView : public CscsAbstractScrollArea
{
    

public:
    enum SelectionMode {
        NoSelection,
        SingleSelection,
        MultiSelection,
        ExtendedSelection,
        ContiguousSelection
    };

    enum SelectionBehavior {
        SelectItems,
        SelectRows,
        SelectColumns
    };

    enum ScrollHint {
        EnsureVisible,
        PositionAtTop,
        PositionAtBottom,
        PositionAtCenter
    };

    enum EditTrigger {
        NoEditTriggers = 0,
        CurrentChanged = 1,
        DoubleClicked = 2,
        SelectedClicked = 4,
        EditKeyPressed = 8,
        AnyKeyPressed = 16,
        AllEditTriggers = 31
    };

    SCS_DECLARE_FLAGS(EditTriggers, EditTrigger)

    enum ScrollMode {
        ScrollPerItem,
        ScrollPerPixel
    };
    explicit CscsAbstractItemView(CscsWidget *parent = nullptr);
    ~CscsAbstractItemView();

    virtual void setModel(CscsAbstractItemModel *model);
    CscsAbstractItemModel *model() const;

    virtual void setSelectionModel(CscsItemSelectionModel *selectionModel);
    CscsItemSelectionModel *selectionModel() const;

    void setItemDelegate(CscsAbstractItemDelegate *delegate);
    CscsAbstractItemDelegate *itemDelegate() const;

    void setSelectionMode(CscsAbstractItemView::SelectionMode mode);
    CscsAbstractItemView::SelectionMode selectionMode() const;

    void setSelectionBehavior(CscsAbstractItemView::SelectionBehavior behavior);
    CscsAbstractItemView::SelectionBehavior selectionBehavior() const;

    CscsModelIndex currentIndex() const;
    CscsModelIndex rootIndex() const;

    void setEditTriggers(EditTriggers triggers);
    EditTriggers editTriggers() const;

    void setVerticalScrollMode(ScrollMode mode);
    ScrollMode verticalScrollMode() const;

    void setHorizontalScrollMode(ScrollMode mode);
    ScrollMode horizontalScrollMode() const;

    void setAutoScroll(bool enable);
    bool hasAutoScroll() const;

    void setAutoScrollMargin(int margin);
    int autoScrollMargin() const;

    void setTabKeyNavigation(bool enable);
    bool tabKeyNavigation() const;


    void setAlternatingRowColors(bool enable);
    bool alternatingRowColors() const;
    
    void setIconSize(const CscsSize &size);
    CscsSize iconSize() const;

    void setTextElideMode(SCS::TextElideMode mode);
    SCS::TextElideMode textElideMode() const;

    virtual void keyboardSearch(const std::string &search);

    virtual CscsRect visualRect(const CscsModelIndex &index) const = 0;
    virtual void scrollTo(const CscsModelIndex &index, ScrollHint hint = EnsureVisible) = 0;
    virtual CscsModelIndex indexAt(const CscsPoint &p) const = 0;

    CscsSize sizeHintForIndex(const CscsModelIndex &index) const;
    virtual int sizeHintForRow(int row) const;
    virtual int sizeHintForColumn(int column) const;

    void openPersistentEditor(const CscsModelIndex &index);
    void closePersistentEditor(const CscsModelIndex &index);

    void setIndexWidget(const CscsModelIndex &index, CscsWidget *widget);
    CscsWidget *indexWidget(const CscsModelIndex &index) const;

    void setItemDelegateForRow(int row, CscsAbstractItemDelegate *delegate);
    CscsAbstractItemDelegate *itemDelegateForRow(int row) const;

    void setItemDelegateForColumn(int column, CscsAbstractItemDelegate *delegate);
    CscsAbstractItemDelegate *itemDelegateForColumn(int column) const;

    CscsAbstractItemDelegate *itemDelegate(const CscsModelIndex &index) const;

    using CscsAbstractScrollArea::update;

SLOTS:
    virtual void reset();
    virtual void setRootIndex(const CscsModelIndex &index);
    virtual void doItemsLayout();
    virtual void selectAll();
    void edit(const CscsModelIndex &index);
    void clearSelection();
    void setCurrentIndex(const CscsModelIndex &index);
    void scrollToTop();
    void scrollToBottom();
    void update(const CscsModelIndex &index);

protected:
    virtual void dataChanged(const CscsModelIndex &topLeft, const CscsModelIndex &bottomRight);
    virtual void rowsInserted(const CscsModelIndex &parent, int start, int end);
    virtual void rowsAboutToBeRemoved(const CscsModelIndex &parent, int start, int end);
    virtual void selectionChanged(const CscsItemSelection &selected, const CscsItemSelection &deselected);
    virtual void currentChanged(const CscsModelIndex &current, const CscsModelIndex &previous);
    virtual void updateEditorData();
    virtual void updateEditorGeometries();
    virtual void updateGeometries();
    virtual void verticalScrollbarAction(int action);
    virtual void horizontalScrollbarAction(int action);
    virtual void verticalScrollbarValueChanged(int value);
    virtual void horizontalScrollbarValueChanged(int value);
    virtual void closeEditor(CscsWidget *editor, CscsAbstractItemDelegate::EndEditHint hint);
    virtual void commitData(CscsWidget *editor);
    virtual void editorDestroyed(CscsObject *editor);

SIGNALS:
    void pressed(const CscsModelIndex &index){}
    void clicked(const CscsModelIndex &index){}
    void doubleClicked(const CscsModelIndex &index){}
    
    void activated(const CscsModelIndex &index){}
    void entered(const CscsModelIndex &index){}
    void viewportEntered(){}

protected:
    CscsAbstractItemView(CscsAbstractItemViewPrivate* , CscsWidget *parent = 0);

    void setHorizontalStepsPerItem(int steps);
    int horizontalStepsPerItem() const;
    void setVerticalStepsPerItem(int steps);
    int verticalStepsPerItem() const;

    enum CursorAction { MoveUp, MoveDown, MoveLeft, MoveRight,
                        MoveHome, MoveEnd, MovePageUp, MovePageDown,
                        MoveNext, MovePrevious };
    virtual CscsModelIndex moveCursor(CursorAction cursorAction,
                                   SCS::KeyboardModifiers modifiers) = 0;

    virtual int horizontalOffset() const = 0;
    virtual int verticalOffset() const = 0;

    virtual bool isIndexHidden(const CscsModelIndex &index) const = 0;

    virtual void setSelection(const CscsRect &rect, CscsItemSelectionModel::SelectionFlags command) = 0;
    virtual CscsRegion visualRegionForSelection(const CscsItemSelection &selection) const = 0;
    virtual CscsModelIndexList selectedIndexes() const;

    virtual bool edit(const CscsModelIndex &index, EditTrigger trigger, CscsEvent *event);

    virtual CscsItemSelectionModel::SelectionFlags selectionCommand(const CscsModelIndex &index,
                                                                 const CscsEvent *event = 0) const;
    
    virtual CscsStyleOptionViewItem viewOptions() const;

    enum State {
        NoState,
        DraggingState, //reserve
        DragSelectingState, //reserve
        EditingState,
        ExpandingState,
        CollapsingState,
        AnimatingState
    };

    State state() const;
    void setState(State state);

    void scheduleDelayedItemsLayout();
    void executeDelayedItemsLayout();

    void setDirtyRegion(const CscsRegion &region);
    void scrollDirtyRegion(int dx, int dy);
    CscsPoint dirtyRegionOffset() const;
    
    void startAutoScroll();
    void stopAutoScroll();
    void doAutoScroll();

    bool focusNextPrevChild(bool next);
    bool event(CscsEvent *event);
    bool viewportEvent(CscsEvent *event);
    void mousePressEvent(CscsMouseEvent *event);
    void mouseMoveEvent(CscsMouseEvent *event);
    void mouseReleaseEvent(CscsMouseEvent *event);
    void mouseDoubleClickEvent(CscsMouseEvent *event);
    void focusInEvent(CscsFocusEvent *event);
    void focusOutEvent(CscsFocusEvent *event);
    void keyPressEvent(CscsKeyEvent *event);
    void resizeEvent(CscsResizeEvent *event);
    void timerEvent(CscsTimerEvent *event);

private:
    CscsAbstractItemViewPrivate* d_func()const;
    friend class CscsAbstractItemViewPrivate;
    friend class CscsTreeView;
    friend class CscsTreeViewPrivate;
    BEGIN_PROPERTY(CscsAbstractItemView, CscsAbstractScrollArea)
        META_PROPERTY(bool, autoScroll, READ, hasAutoScroll, WRITE, setAutoScroll)
        META_PROPERTY(int, autoScrollMargin, READ, autoScrollMargin, WRITE, setAutoScrollMargin)
        META_PROPERTY(EditTriggers, editTriggers, READ, editTriggers, WRITE, setEditTriggers)
        META_PROPERTY(bool, tabKeyNavigation, READ, tabKeyNavigation, WRITE, setTabKeyNavigation)
        META_PROPERTY(bool, alternatingRowColors, READ, alternatingRowColors, WRITE, setAlternatingRowColors)
        META_PROPERTY(SelectionMode, selectionMode, READ, selectionMode, WRITE, setSelectionMode)
        META_PROPERTY(SelectionBehavior, selectionBehavior, READ, selectionBehavior, WRITE, setSelectionBehavior)
        META_PROPERTY(CscsSize, iconSize, READ, iconSize, WRITE, setIconSize)
        META_PROPERTY(SCS::TextElideMode, textElideMode, READ, textElideMode, WRITE, setTextElideMode)
        META_PROPERTY(ScrollMode, verticalScrollMode, READ, verticalScrollMode, WRITE, setVerticalScrollMode)
        META_PROPERTY(ScrollMode, horizontalScrollMode, READ, horizontalScrollMode, WRITE, setHorizontalScrollMode)
    END_PROPERTY
};
SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsAbstractItemView::EditTriggers)

END_NAMESPACE

#endif