#ifndef SCSLISTVIEW_H
#define SCSLISTVIEW_H

#include "scsabstractitemview.h"

BEGIN_NAMESPACE(Gemini)

class CscsListViewPrivate;

class WIDGET_EXPORT CscsListView : public CscsAbstractItemView
{


public:
    enum Movement { Static, Free, Snap };
    enum Flow { LeftToRight, TopToBottom };
    enum ResizeMode { Fixed, Adjust };
    enum LayoutMode { SinglePass, Batched };
    enum ViewMode { ListMode, IconMode };

    explicit CscsListView(CscsWidget *parent = 0);
    ~CscsListView();

    void setMovement(Movement movement);
    Movement movement() const;

    void setFlow(Flow flow);
    Flow flow() const;

    void setWrapping(bool enable);
    bool isWrapping() const;

    void setResizeMode(ResizeMode mode);
    ResizeMode resizeMode() const;

    void setLayoutMode(LayoutMode mode);
    LayoutMode layoutMode() const;

    void setSpacing(int space);
    int spacing() const;

    void setBatchSize(int batchSize);
    int batchSize() const;

    void setGridSize(const CscsSize &size);
    CscsSize gridSize() const;

    void setViewMode(ViewMode mode);
    ViewMode viewMode() const;

    void clearPropertyFlags();

    bool isRowHidden(int row) const;
    void setRowHidden(int row, bool hide);

    void setModelColumn(int column);
    int modelColumn() const;

    void setUniformItemSizes(bool enable);
    bool uniformItemSizes() const;

    void setWordWrap(bool on);
    bool wordWrap() const;

    void setSelectionRectVisible(bool show);
    bool isSelectionRectVisible() const;


    CscsRect visualRect(const CscsModelIndex &index) const;
    void scrollTo(const CscsModelIndex &index, ScrollHint hint = EnsureVisible);
    CscsModelIndex indexAt(const CscsPoint &p) const;

    void doItemsLayout();
    void reset();
    void setRootIndex(const CscsModelIndex &index);

SIGNALS:
    void indexesMoved(const CscsModelIndex& index){}

protected:
    CscsListView(CscsListViewPrivate* , CscsWidget *parent = nullptr);

    bool event(CscsEvent* e);

    void scrollContentsBy(int dx, int dy);
 
    void resizeContents(int width, int height);
    CscsSize contentsSize() const;

    void dataChanged(const CscsModelIndex &topLeft, const CscsModelIndex &bottomRight);
    void rowsInserted(const CscsModelIndex &parent, int start, int end);
    void rowsAboutToBeRemoved(const CscsModelIndex &parent, int start, int end);

    void mouseMoveEvent(CscsMouseEvent *e);
    void mouseReleaseEvent(CscsMouseEvent *e);

    void timerEvent(CscsTimerEvent *e);
    void resizeEvent(CscsResizeEvent *e);

    CscsStyleOptionViewItem viewOptions() const;
    void paintEvent(CscsPaintEvent *e);

    int horizontalOffset() const;
    int verticalOffset() const;
    CscsModelIndex moveCursor(CursorAction cursorAction, SCS::KeyboardModifiers modifiers);
    CscsRect rectForIndex(const CscsModelIndex &index) const;
    void setPositionForIndex(const CscsPoint &position, const CscsModelIndex &index);

    void setSelection(const CscsRect &rect, CscsItemSelectionModel::SelectionFlags command);
    CscsRegion visualRegionForSelection(const CscsItemSelection &selection) const;
    CscsModelIndexList selectedIndexes() const;

    void updateGeometries();

    bool isIndexHidden(const CscsModelIndex &index) const;

    void selectionChanged(const CscsItemSelection &selected, const CscsItemSelection &deselected);
    void currentChanged(const CscsModelIndex &current, const CscsModelIndex &previous);

private:
    CscsListViewPrivate* d_func()const;
    int visualIndex(const CscsModelIndex &index) const;
    friend class CscsListViewPrivate;
BEGIN_PROPERTY(CscsListView,CscsAbstractItemView)
    META_PROPERTY(Movement, movement, READ, movement, WRITE, setMovement)
    META_PROPERTY(Flow, flow, READ, flow, WRITE, setFlow)
    META_PROPERTY(bool, isWrapping, READ, isWrapping, WRITE, setWrapping)
    META_PROPERTY(ResizeMode, resizeMode, READ, resizeMode, WRITE, setResizeMode)
    META_PROPERTY(LayoutMode, layoutMode, READ, layoutMode, WRITE, setLayoutMode)
    META_PROPERTY(int, spacing, READ, spacing, WRITE, setSpacing)
    META_PROPERTY(CscsSize, gridSize, READ, gridSize, WRITE, setGridSize)
    META_PROPERTY(ViewMode, viewMode, READ, viewMode, WRITE, setViewMode)
    META_PROPERTY(int, modelColumn, READ, modelColumn, WRITE, setModelColumn)
    META_PROPERTY(bool, uniformItemSizes, READ, uniformItemSizes, WRITE, setUniformItemSizes)
    META_PROPERTY(int, batchSize, READ, batchSize, WRITE, setBatchSize)
    META_PROPERTY(bool, wordWrap, READ, wordWrap, WRITE, setWordWrap)
    META_PROPERTY(bool, selectionRectVisible, READ, isSelectionRectVisible, WRITE, setSelectionRectVisible)
END_PROPERTY

};
END_NAMESPACE
#endif