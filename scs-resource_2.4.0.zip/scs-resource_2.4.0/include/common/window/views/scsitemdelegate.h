#ifndef SCSITEMDELEGATE_H
#define SCSITEMDELEGATE_H
#include <window/scsabstractitemdelegate.h>
#include <kernel/scsstring.h>
#include <painting/scsimage.h>
#include <kernel/scsvariant.h>

BEGIN_NAMESPACE(Gemini)

class CscsItemDelegatePrivate;
class CscsItemEditorFactory;
class CscsPalette;

class  CscsItemDelegate : public CscsAbstractItemDelegate
{
public:
    explicit CscsItemDelegate(CscsObject *parent = nullptr);
    ~CscsItemDelegate();

    // painting
    void paint(CscsPainter *painter,
               const CscsStyleOptionViewItem &option,
               const CscsModelIndex &index) const;
    CscsSize sizeHint(const CscsStyleOptionViewItem &option,
                   const CscsModelIndex &index) const;

    // editing
    CscsWidget *createEditor(CscsWidget *parent,
                          const CscsStyleOptionViewItem &option,
                          const CscsModelIndex &index) const;

    void setEditorData(CscsWidget *editor, const CscsModelIndex &index) const;
    void setModelData(CscsWidget *editor, CscsAbstractItemModel *model, const CscsModelIndex &index) const;

    void updateEditorGeometry(CscsWidget *editor,
                              const CscsStyleOptionViewItem &option,
                              const CscsModelIndex &index) const;

    // editor factory
    CscsItemEditorFactory *itemEditorFactory() const;
    void setItemEditorFactory(CscsItemEditorFactory *factory);

protected:
    virtual void drawBackground(CscsPainter *painter,
                                   const CscsStyleOptionViewItem &option,
                                   const CscsModelIndex &index) const;
    virtual void drawDisplay(CscsPainter *painter, const CscsStyleOptionViewItem &option,
                             const CscsRect &rect, const std::string &text) const;
    virtual void drawDecoration(CscsPainter *painter, const CscsStyleOptionViewItem &option,
                                const CscsRect &rect, const CscsImage &image) const;
    virtual void drawFocus(CscsPainter *painter, const CscsStyleOptionViewItem &option,
                           const CscsRect &rect) const;
    virtual void drawCheck(CscsPainter *painter, const CscsStyleOptionViewItem &option,
                           const CscsRect &rect, SCS::CheckState state) const;

    void doLayout(const CscsStyleOptionViewItem &option,
                  CscsRect *checkRect, CscsRect *iconRect, CscsRect *textRect, bool hint) const;
    CscsImage decoration(const CscsStyleOptionViewItem &option, const CscsVariant &variant) const;
    CscsImage *selected(const CscsImage &image, const CscsPalette &palette, bool enabled) const;
    CscsRect check(const CscsStyleOptionViewItem &option, const CscsRect &bounding,
                const CscsVariant &variant) const;

    bool eventFilter(CscsObject *object, CscsEvent *event);
    bool editorEvent(CscsEvent *event, CscsAbstractItemModel *model,
                     const CscsStyleOptionViewItem &option, const CscsModelIndex &index);

private:
    CscsItemDelegatePrivate* d_func()const;
};

END_NAMESPACE

#endif