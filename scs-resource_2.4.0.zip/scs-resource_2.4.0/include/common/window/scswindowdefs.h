#ifndef SCSWINDOWDEFS_H
#define SCSWINDOWDEFS_H
#include <set>
#include <unordered_set>
#include <unordered_map>
//#include <ext/hash_map>
//using namespace __gnu_cxx;
#include <vector>
#include <kernel/scsnamespace.h>

BEGIN_NAMESPACE(Gemini)

class CscsWidget;

typedef std::unordered_map<int, CscsWidget*> CscsWidgetMapper;
typedef std::unordered_set<CscsWidget*> CscsWidgetSet;
typedef std::vector<CscsWidget*> CscsWidgetVector;
typedef std::list<CscsWidget*> CscsWidgetList;

typedef std::unordered_map<int, CscsWidget*>::iterator CscsWidgetMapperIt;
typedef std::unordered_set<CscsWidget*>::iterator CscsWidgetSetIt;
typedef std::vector<CscsWidget*>::iterator CscsWidgetVectorIt;
typedef std::list<CscsWidget*>::iterator CscsWidgetListIt;

END_NAMESPACE


#endif