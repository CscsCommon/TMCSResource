#ifndef SCSCOMMONSTYLE_H
#define SCSCOMMONSTYLE_H
#include "scsbasestyle.h"

BEGIN_NAMESPACE(Gemini)

class CscsStyleOption;
class CscsStyleOptionToolButton;
class CscsPainter;
class CscsWidget;

class CscsCommonStyle:public CscsBaseStyle{
	public:
		CscsCommonStyle();
		~CscsCommonStyle();

		void drawPrimitive(PrimitiveElement e, const CscsStyleOption* op, CscsPainter* p,
						   const CscsWidget* w=0)const;

		void drawControl(ControlElement element, const CscsStyleOption *op, CscsPainter *p,
                     const CscsWidget *w = 0) const;
    	CscsRect subElementRect(SubElement r, const CscsStyleOption *op, const CscsWidget *w = 0) const;
    	void drawComplexControl(ComplexControl cc, const CscsStyleOptionComplex *opt, CscsPainter *p,
                            const CscsWidget *w = 0) const;
    	SubControl hitTestComplexControl(ComplexControl cc, const CscsStyleOptionComplex* op, const CscsPoint& p, const CscsWidget* w=0)const;
    	CscsRect subControlRect(ComplexControl cc, const CscsStyleOptionComplex *op, SubControl sc,
    	                     const CscsWidget *w = 0) const;
    	CscsSize sizeFromContents(ContentsType ct, const CscsStyleOption *opt,
                           const CscsSize &contentsSize, const CscsWidget *w = 0) const;

    	int pixelMetric(PixelMetric m, const CscsStyleOption *op = 0, const CscsWidget *widget = 0) const;

    	int styleHint(StyleHint sh, const CscsStyleOption *op = 0, const CscsWidget *w = 0,
                  	CscsStyleHintReturn *shret = 0) const;

    	CscsImage standardPixmap(StandardPixmap sp, const CscsStyleOption *op = 0,
                           const CscsWidget *w = 0) const;
      virtual CscsImage generatedIconPixmap(CscsIcon::Mode iconMode, const CscsImage &pixmap,
                                        const CscsStyleOption *opt) const ;

private:
   void drawArrow(const CscsStyleOptionToolButton *toolbutton,
            const CscsRect &rect, CscsPainter *painter, const CscsWidget *widget=0)const;
  void drawSlider(const CscsStyleOptionComplex *opt, CscsPainter *p, const CscsWidget *widget)const;
};

END_NAMESPACE

#endif