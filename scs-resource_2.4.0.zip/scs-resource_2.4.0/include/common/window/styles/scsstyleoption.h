/*
 * Created by J.Wong 2018/11/27
 */
#ifndef SCSSTYLEOPTION_H
#define SCSSTYLEOPTION_H

#include <painting/scsfont.h>
#include <painting/scspainter.h>
#include <painting/scsregion.h>
#include "../scsenum.h"
#include "scspalette.h"
#include "scsbasestyle.h"
#include "../widgets/scsslider.h"
#include "../widgets/scsrubberband.h"
#include "../widgets/scsicon.h"
#include "../widgets/scstabbar.h"
#include "../widgets/scsabstractspinbox.h"
#include "window/scsabstractitemmodel.h"

BEGIN_NAMESPACE(Gemini)

class CscsStyleOption{
	public:
		enum OptionType{
			          Default, 
			          FocusRect, 
			          Button, 
			          Tab, 
			          MenuItem,
                      Frame, 
                      ProgressBar, 
                      ToolBox, 
                      Header, 
                      DockWindow,
                      DockWidget, 
                      ListViewItem, 
                      ViewItem, 
                      TabWidgetFrame,
                      TabBarBase, 
                      RubberBand,
                      Complex = 0xf0000, 
                      Slider, 
                      SpinBox, 
                      ToolButton, 
                      ComboBox,
                      ListView, 
                      TitleBar,
                      GroupBox,
                      CustomBase = 0xf00,
                      ComplexCustomBase = 0xf000000
		};

		enum StyleOptionType{

			Type=Default
		};

		enum StyleOptionVersion{
			Version=1
		};

		int version;
		int type;

		CscsBaseStyle::State state;
		CscsRect rect;
		SCS::LayoutDirection direction;
		CscsPalette palette;
		CscsFont font;

		CscsStyleOption(int version=CscsStyleOption::Version, int type=Default);
		CscsStyleOption(const CscsStyleOption& o);
		CscsStyleOption& operator=(const CscsStyleOption& o);
		~CscsStyleOption();
		void init(const CscsWidget* w);
        inline void initForm(const CscsWidget *w){ init(w); }
};

class CscsStyleOptionFocusRect:public CscsStyleOption{
	public:
		enum StyleOptionType{Type=FocusRect};
		enum StyleOptionVersion{Version=1};
		CscsRgba backgroundColor;
		CscsStyleOptionFocusRect();
		CscsStyleOptionFocusRect(const CscsStyleOptionFocusRect& o):CscsStyleOption(Version,Type){
			*this=o;
		}

	protected:
		CscsStyleOptionFocusRect(int version);
};

class CscsStyleOptionFrame:public CscsStyleOption{
	public:
		enum StyleOptionType{Type=Frame};
		enum StyleOptionVersion{Version=1};

		int lineWidth;
		int midLineWidth;

		CscsStyleOptionFrame();
		CscsStyleOptionFrame(const CscsStyleOptionFrame& o):CscsStyleOption(Version, Type){
			*this=o;
		}
	protected:
		CscsStyleOptionFrame(int version);
};

class  CscsStyleOptionFrameV2 : public CscsStyleOptionFrame
{
public:
    enum StyleOptionVersion { Version = 2 };
    enum FrameFeature {
        None = 0x00,
        Flat = 0x01
    };
    SCS_DECLARE_FLAGS(FrameFeatures, FrameFeature)
    FrameFeatures features;

    CscsStyleOptionFrameV2();
    CscsStyleOptionFrameV2(const CscsStyleOptionFrameV2 &other) : CscsStyleOptionFrame(Version) { *this = other; }
    CscsStyleOptionFrameV2(const CscsStyleOptionFrame &other);
    CscsStyleOptionFrameV2 &operator=(const CscsStyleOptionFrame &other);

protected:
    CscsStyleOptionFrameV2(int version);
};

SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsStyleOptionFrameV2::FrameFeatures)


class  CscsStyleOptionTabWidgetFrame : public CscsStyleOption
{
public:
    enum StyleOptionType { Type = TabWidgetFrame };
    enum StyleOptionVersion { Version = 1 };

    int lineWidth;
    int midLineWidth;
    CscsTabBar::Shape shape;
    CscsSize tabBarSize;
    CscsSize rightCornerWidgetSize;
    CscsSize leftCornerWidgetSize;

    CscsStyleOptionTabWidgetFrame();
    inline CscsStyleOptionTabWidgetFrame(const CscsStyleOptionTabWidgetFrame &other)
        : CscsStyleOption(Version, Type) { *this = other; }

protected:
    CscsStyleOptionTabWidgetFrame(int version);
};


class  CscsStyleOptionHeader : public CscsStyleOption
{
public:
    enum StyleOptionType{ Type = Header };
    enum StyleOptionVersion{ Version = 1 };

    enum SectionPosition { Beginning, Middle, End, OnlyOneSection };
    enum SelectedPosition { NotAdjacent, NextIsSelected, PreviousIsSelected,
                            NextAndPreviousAreSelected };
    enum SortIndicator { None, SortUp, SortDown };

    int section;
    std::string text;
    SCS::Alignment textAlignment;
    CscsIcon icon;
    SCS::Alignment iconAlignment;
    SectionPosition position;
    SelectedPosition selectedPosition;
    SortIndicator sortIndicator;
    SCS::Orientation orientation;
    CscsFont font;

    CscsStyleOptionHeader();
    CscsStyleOptionHeader(const CscsStyleOptionHeader &other) : CscsStyleOption(Version, Type) { *this = other; }

protected:
    CscsStyleOptionHeader(int version);
};

class  CscsStyleOptionButton : public CscsStyleOption
{
public:
    enum StyleOptionType{ Type = Button };
    enum StyleOptionVersion{ Version = 1 };

    enum ButtonFeature { None = 0x00, Flat = 0x01, HasMenu = 0x02, DefaultButton = 0x04,
                         AutoDefaultButton = 0x08 };
    SCS_DECLARE_FLAGS(ButtonFeatures, ButtonFeature)

    ButtonFeatures features;
    std::string text;
    CscsIcon icon;
    CscsSize iconSize;

    CscsStyleOptionButton();
    CscsStyleOptionButton(const CscsStyleOptionButton &other) : CscsStyleOption(Version, Type) { *this = other; }

protected:
    CscsStyleOptionButton(int version);
};

class  CscsStyleOptionTabBarBase : public CscsStyleOption
{
public:
    enum StyleOptionType{ Type = TabBarBase };
    enum StyleOptionVersion{ Version = 1 };

    CscsTabBar::Shape shape;
    CscsRect tabBarRect;
    CscsRect selectedTabRect;

    CscsStyleOptionTabBarBase();
    CscsStyleOptionTabBarBase(const CscsStyleOptionTabBarBase &other) : CscsStyleOption(Version, Type) { *this = other; }

protected:
    CscsStyleOptionTabBarBase(int version);
};

class  CscsStyleOptionTab : public CscsStyleOption
{
public:
    enum StyleOptionType{ Type = Tab };
    enum StyleOptionVersion{ Version = 1 };

    enum TabPosition { Beginning, Middle, End, OnlyOneTab };
    enum SelectedPosition { NotAdjacent, NextIsSelected, PreviousIsSelected };
    enum CornerWidget { NoCornerWidgets = 0x00, LeftCornerWidget = 0x01,
                        RightCornerWidget = 0x02 };
    SCS_DECLARE_FLAGS(CornerWidgets, CornerWidget)

    CscsTabBar::Shape shape;
    std::string text;
    CscsIcon icon;
    int row;
    TabPosition position;
    SelectedPosition selectedPosition;
    CornerWidgets cornerWidgets;

    CscsStyleOptionTab();
    CscsStyleOptionTab(const CscsStyleOptionTab &other) : CscsStyleOption(Version, Type) { *this = other; }

protected:
    CscsStyleOptionTab(int version);
};


class  CscsStyleOptionTabV2 : public CscsStyleOptionTab
{
public:
    enum StyleOptionVersion { Version = 2 };
    CscsSize iconSize;
    CscsStyleOptionTabV2();
    CscsStyleOptionTabV2(const CscsStyleOptionTabV2 &other) : CscsStyleOptionTab(Version) { *this = other; }
    CscsStyleOptionTabV2(const CscsStyleOptionTab &other);
    CscsStyleOptionTabV2 &operator=(const CscsStyleOptionTab &other);

protected:
    CscsStyleOptionTabV2(int version);
};


class CscsStyleOptionProgressBar : public CscsStyleOption
{
public:
    enum StyleOptionType{ Type = ProgressBar };
    enum StyleOptionVersion{ Version = 1 };

    int minimum;
    int maximum;
    int progress;
    std::string text;
    int textAlignment;
    bool textVisible;

    CscsStyleOptionProgressBar();
    CscsStyleOptionProgressBar(const CscsStyleOptionProgressBar &other) : CscsStyleOption(Version, Type) { *this = other; }

protected:
    CscsStyleOptionProgressBar(int version);
};


class  CscsStyleOptionProgressBarV2 : public CscsStyleOptionProgressBar
{
public:
    enum StyleOptionType { Type = ProgressBar };
    enum StyleOptionVersion { Version = 2 };
    SCS::Orientation orientation;
    bool invertedAppearance;
    bool bottomToTop;

    CscsStyleOptionProgressBarV2();
    CscsStyleOptionProgressBarV2(const CscsStyleOptionProgressBar &other);
    CscsStyleOptionProgressBarV2(const CscsStyleOptionProgressBarV2 &other);
    CscsStyleOptionProgressBarV2 &operator=(const CscsStyleOptionProgressBar &other);

protected:
    CscsStyleOptionProgressBarV2(int version);
};

class  CscsStyleOptionMenuItem : public CscsStyleOption
{
public:
    enum StyleOptionType{ Type = MenuItem };
    enum StyleOptionVersion{ Version = 1 };

    enum MenuItemType { Normal, DefaultItem, Separator, SubMenu, Scroller, TearOff, Margin,
                        EmptyArea };
    enum CheckType { NotCheckable, Exclusive, NonExclusive };

    MenuItemType menuItemType;
    CheckType checkType;
    bool checked;
    bool menuHasCheckableItems;
    CscsRect menuRect;
    std::string text;
    CscsIcon icon;
    int maxIconWidth;
    int tabWidth;
    CscsFont font;

    CscsStyleOptionMenuItem();
    CscsStyleOptionMenuItem(const CscsStyleOptionMenuItem &other) : CscsStyleOption(Version, Type) { *this = other; }

protected:
    CscsStyleOptionMenuItem(int version);
};

class  CscsStyleOptionDockWidget : public CscsStyleOption
{
public:
    enum StyleOptionType{ Type = DockWidget };
    enum StyleOptionVersion{ Version = 1 };

    std::string title;
    bool closable;
    bool movable;
    bool floatable;

    CscsStyleOptionDockWidget();
    CscsStyleOptionDockWidget(const CscsStyleOptionDockWidget &other) : CscsStyleOption(Version, Type) { *this = other; }

protected:
    CscsStyleOptionDockWidget(int version);
};


class  CscsStyleOptionDockWidgetV2 : public CscsStyleOptionDockWidget
{
public:
    enum StyleOptionVersion { Version = 2 };

    bool verticalTitleBar;

    CscsStyleOptionDockWidgetV2();
    CscsStyleOptionDockWidgetV2(const CscsStyleOptionDockWidgetV2 &other)
        : CscsStyleOptionDockWidget(Version) { *this = other; }
    CscsStyleOptionDockWidgetV2(const CscsStyleOptionDockWidget &other);
    CscsStyleOptionDockWidgetV2 &operator = (const CscsStyleOptionDockWidget &other);

protected:
    CscsStyleOptionDockWidgetV2(int version);
};

class  CscsStyleOptionViewItem : public CscsStyleOption
{
public:
    enum StyleOptionType{ Type = ViewItem };
    enum StyleOptionVersion{ Version = 1 };

    enum Position { Left, Right, Top, Bottom };

    SCS::Alignment displayAlignment;
    SCS::Alignment decorationAlignment;
    SCS::TextElideMode textElideMode;
    Position decorationPosition;
    CscsSize decorationSize;
    CscsFont font;
    bool showDecorationSelected;

    CscsStyleOptionViewItem();
    CscsStyleOptionViewItem(const CscsStyleOptionViewItem &other) : CscsStyleOption(Version, Type) { *this = other; }

protected:
    CscsStyleOptionViewItem(int version);
};


class  CscsStyleOptionViewItemV2 : public CscsStyleOptionViewItem
{
public:
    enum StyleOptionVersion { Version = 2 };

    enum ViewItemFeature {
        None = 0x00,
        WrapText = 0x01,
        Alternate = 0x02,
        HasCheckIndicator = 0x04,
        HasDisplay = 0x08,
        HasDecoration = 0x10
    };
    SCS_DECLARE_FLAGS(ViewItemFeatures, ViewItemFeature)

    ViewItemFeatures features;

    CscsStyleOptionViewItemV2();
    CscsStyleOptionViewItemV2(const CscsStyleOptionViewItemV2 &other) : CscsStyleOptionViewItem(Version) { *this = other; }
    CscsStyleOptionViewItemV2(const CscsStyleOptionViewItem &other);
    CscsStyleOptionViewItemV2 &operator=(const CscsStyleOptionViewItem &other);

protected:
    CscsStyleOptionViewItemV2(int version);
};

class  CscsStyleOptionViewItemV3 : public CscsStyleOptionViewItemV2
{
public:
    enum StyleOptionVersion { Version = 3 };

    // CscsLocale locale;
    const CscsWidget *widget;

    CscsStyleOptionViewItemV3();
    CscsStyleOptionViewItemV3(const CscsStyleOptionViewItemV3 &other)
        : CscsStyleOptionViewItemV2(Version) { *this = other; }
    CscsStyleOptionViewItemV3(const CscsStyleOptionViewItem &other);
    CscsStyleOptionViewItemV3 &operator = (const CscsStyleOptionViewItem &other);

protected:
    CscsStyleOptionViewItemV3(int version);
};

class CscsStyleOptionViewItemV4 : public CscsStyleOptionViewItemV3
{
public:
    enum StyleOptionVersion { Version = 4 };
    enum ViewItemPosition { Invalid, Beginning, Middle, End, OnlyOne };

    CscsModelIndex index;
    SCS::CheckState checkState;
    CscsIcon icon;
    //std::string text;
    ViewItemPosition viewItemPosition;
    CscsBrush backgroundBrush;

    CscsStyleOptionViewItemV4();
    CscsStyleOptionViewItemV4(const CscsStyleOptionViewItemV4 &other)
        : CscsStyleOptionViewItemV3(Version) { *this = other; }
    CscsStyleOptionViewItemV4(const CscsStyleOptionViewItem &other);
    CscsStyleOptionViewItemV4 &operator = (const CscsStyleOptionViewItem &other);

protected:
    CscsStyleOptionViewItemV4(int version);
};

class CscsStyleOptionToolBox : public CscsStyleOption
{
public:
    enum StyleOptionType{ Type = ToolBox };
    enum StyleOptionVersion{ Version = 1 };

    std::string text;
    CscsIcon icon;


    CscsStyleOptionToolBox();
    CscsStyleOptionToolBox(const CscsStyleOptionToolBox &other) : CscsStyleOption(Version, Type) { *this = other; }

protected:
    CscsStyleOptionToolBox(int version);
};

class  CscsStyleOptionRubberBand : public CscsStyleOption
{
public:
    enum StyleOptionType{ Type = RubberBand };
    enum StyleOptionVersion{ Version = 1 };

    CscsRubberBand::Shape shape;
    bool opaque;

    CscsStyleOptionRubberBand();
    CscsStyleOptionRubberBand(const CscsStyleOptionRubberBand &other) : CscsStyleOption(Version, Type) { *this = other; }

protected:
    CscsStyleOptionRubberBand(int version);
};

class CscsStyleOptionComplex : public CscsStyleOption
{
public:
    enum StyleOptionType{ Type = Complex };
    enum StyleOptionVersion{ Version = 1 };

    CscsBaseStyle::SubControls subControls;
    CscsBaseStyle::SubControls activeSubControls;

    CscsStyleOptionComplex(int version = CscsStyleOptionComplex::Version, int type = Complex);
    CscsStyleOptionComplex(const CscsStyleOptionComplex &other) : CscsStyleOption(Version, Type) { *this = other; }
};



class  CscsStyleOptionSlider : public CscsStyleOptionComplex
{
public:
    enum StyleOptionType{ Type = Slider };
    enum StyleOptionVersion{ Version = 1 };

    SCS::Orientation orientation;
    int minimum;
    int maximum;
    CscsSlider::TickPosition tickPosition;
    int tickInterval;
    bool upsideDown;
    int sliderPosition;
    int sliderValue;
    int singleStep;
    int pageStep;
    double notchTarget;
    bool dialWrapping;

    CscsStyleOptionSlider();
    CscsStyleOptionSlider(const CscsStyleOptionSlider &other) : CscsStyleOptionComplex(Version, Type) { *this = other; }

protected:
    CscsStyleOptionSlider(int version);
};

class  CscsStyleOptionSpinBox : public CscsStyleOptionComplex
{
public:
    enum StyleOptionType{ Type = SpinBox };
    enum StyleOptionVersion{ Version = 1 };

    CscsAbstractSpinBox::ButtonSymbols buttonSymbols;
    CscsAbstractSpinBox::StepEnabled stepEnabled;
    bool frame;

    CscsStyleOptionSpinBox();
    CscsStyleOptionSpinBox(const CscsStyleOptionSpinBox &other) : CscsStyleOptionComplex(Version, Type) { *this = other; }

protected:
    CscsStyleOptionSpinBox(int version);
};

class  CscsStyleOptionToolButton : public CscsStyleOptionComplex
{
public:
    enum StyleOptionType{ Type = ToolButton };
    enum StyleOptionVersion{ Version = 1 };

    enum ToolButtonFeature { None = 0x00, Arrow = 0x01, Menu = 0x04, PopupDelay = 0x08 };
    SCS_DECLARE_FLAGS(ToolButtonFeatures, ToolButtonFeature)

    ToolButtonFeatures features;
    std::string text;
    SCS::ArrowType arrowType;
    SCS::ToolButtonStyle toolButtonStyle;
    CscsPoint pos;
    CscsFont font;
    CscsIcon icon;
    CscsSize iconSize;

    CscsStyleOptionToolButton();
    CscsStyleOptionToolButton(const CscsStyleOptionToolButton &other) : CscsStyleOptionComplex(Version, Type) { *this = other; }

protected:
    CscsStyleOptionToolButton(int version);
};

class  CscsStyleOptionComboBox : public CscsStyleOptionComplex
{
public:
    enum StyleOptionType{ Type = ComboBox };
    enum StyleOptionVersion{ Version = 1 };

    bool editable;
    CscsRect popupRect;
    bool frame;
    std::string currentText;
    CscsIcon currentIcon;
    CscsSize iconSize;

    CscsStyleOptionComboBox();
    CscsStyleOptionComboBox(const CscsStyleOptionComboBox &other) : CscsStyleOptionComplex(Version, Type) { *this = other; }

protected:
    CscsStyleOptionComboBox(int version);
};

class  CscsStyleOptionTitleBar : public CscsStyleOptionComplex
{
public:
    enum StyleOptionType{ Type = TitleBar };
    enum StyleOptionVersion{ Version = 1 };

    std::string text;
    int titleBarState;
    SCS::WindowFlags titleBarFlags;

    CscsStyleOptionTitleBar();
    CscsStyleOptionTitleBar(const CscsStyleOptionTitleBar &other) : CscsStyleOptionComplex(Version, Type) { *this = other; }

protected:
    CscsStyleOptionTitleBar(int version);
};


class  CscsStyleOptionGroupBox : public CscsStyleOptionComplex
{
public:
    enum StyleOptionType { Type = GroupBox };
    enum StyleOptionVersion { Version = 1 };

    CscsStyleOptionFrameV2::FrameFeatures features;
    std::string text;
    SCS::Alignment textAlignment;
    CscsRgba textColor;
    int lineWidth;
    int midLineWidth;

    CscsStyleOptionGroupBox();
    CscsStyleOptionGroupBox(const CscsStyleOptionGroupBox &other) : CscsStyleOptionComplex(Version, Type) { *this = other; }
protected:
    CscsStyleOptionGroupBox(int version);
};

template <typename T>
T scs_styleoption_cast(const CscsStyleOption *opt)
{
    if (opt && opt->version >= static_cast<T>(0)->Version && (opt->type == static_cast<T>(0)->Type
        || int(static_cast<T>(0)->Type) == CscsStyleOption::Default
        || (int(static_cast<T>(0)->Type) == CscsStyleOption::Complex
            && opt->type > CscsStyleOption::Complex)))
        return static_cast<T>(opt);
    return 0;
}

template <typename T>
T scs_styleoption_cast(CscsStyleOption *opt)
{
    if (opt && opt->version >= static_cast<T>(0)->Version && (opt->type == static_cast<T>(0)->Type
        || int(static_cast<T>(0)->Type) == CscsStyleOption::Default
        || (int(static_cast<T>(0)->Type) == CscsStyleOption::Complex
            && opt->type > CscsStyleOption::Complex)))
        return static_cast<T>(opt);
    return 0;
}


class  CscsStyleHintReturn {
public:
    enum HintReturnType {
        Default=0xf000, Mask
    };

    enum { Type = Default };
    enum { Version = 1 };

    CscsStyleHintReturn(int version = CscsStyleOption::Version, int type = Default);
    ~CscsStyleHintReturn();

    int version;
    int type;
};

class  CscsStyleHintReturnMask : public CscsStyleHintReturn {
public:
    enum { Type = Mask };
    enum { Version = 1 };

    CscsStyleHintReturnMask();

    CscsRegion region;
};

template <typename T>
T scs_styleoption_cast(const CscsStyleHintReturn *hint)
{
    if (hint && hint->version <= static_cast<T>(0)->Version &&
        (hint->type == static_cast<T>(0)->Type || int(static_cast<T>(0)->Type) == CscsStyleHintReturn::Default))
        return static_cast<T>(hint);
    return 0;
}

template <typename T>
T scs_styleoption_cast(CscsStyleHintReturn *hint)
{
    if (hint && hint->version <= static_cast<T>(0)->Version &&
        (hint->type == static_cast<T>(0)->Type || int(static_cast<T>(0)->Type) == CscsStyleHintReturn::Default))
        return static_cast<T>(hint);
    return 0;
}

SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsStyleOptionToolButton::ToolButtonFeatures)

SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsStyleOptionButton::ButtonFeatures)

END_NAMESPACE

#endif