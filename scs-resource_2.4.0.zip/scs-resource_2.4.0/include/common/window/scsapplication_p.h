#ifndef SCSAPPLICATION_P_H
#define SCSAPPLICATION_P_H

#include <kernel/scsapplicationplus_p.h>
#include "scswindowdefs.h"
#include "scswindowevent.h"
#include "scsenum.h"
#include "widgets/scscursor.h"
#include <kernel/scsevent.h>
#include <painting/scssize.h>
#include <kernel/scslist.h>
#ifdef D_WIN32
#include <windows.h>
#endif
BEGIN_NAMESPACE(Gemini)

class CscsObject;
class CscsApplication;
class CscsWidget;
class CscsFont;
class CscsPoint;
class CscsPalette;
class CscsBaseStyle;
class CscsFocusFrame;
class CscsTimer;
class CscsDataSensor;
class CscsTranslator;

class CscsApplicationPrivate:public CscsApplicationPlusPrivate{
public:
	CscsApplicationPrivate();
	~CscsApplicationPrivate();
	CscsApplication* mm_func()const;

	void createEventDispatcher();

	static CscsApplicationPrivate* instance(){return self;}

	static void setFocusWidget(CscsWidget* focus, SCS::FocusReason reason);
	static CscsWidget* findChildWidget(const CscsWidget* p, const CscsPoint& pos);
	static CscsWidget* findWidget(const CscsObjectList&, const CscsPoint& ,bool rec);
	static CscsWidget  *widgetAt(int x, int y);
	static void dispatchEnterLeave(CscsWidget* enter, CscsWidget* leave);
	static void setSystemPalette(const CscsPalette &pal);

	static void enterModal(CscsWidget* );
	static void leaveModal(CscsWidget* );
	static void enterModal_sys(CscsWidget* );
	static void leaveModal_sys(CscsWidget* );
	static bool isBlockedByModal(CscsWidget* );
	static bool modalState();
	static bool tryModalHelper(CscsWidget* widget, CscsWidget** rettop=0);
#ifdef D_WIN32
	static void updateApplicationWindow();
#endif
	bool inPopupMode()const;
	void closePopup(CscsWidget* popup);
	void openPopup(CscsWidget* popup);

	void construct();

	bool notify(CscsObject* r, CscsEvent* e);
#ifdef D_WIN32
	bool create();
	void destroy();
#endif
private:
	#ifdef D_WIN32
	static HANDLE appHwnd;
	static CscsImage* appCanvas;

	#endif
	static CscsApplicationPrivate *self;

	static CscsPalette* app_palette;
	static CscsPalette* sys_palette;
	static CscsPalette* set_palette;
	static CscsBaseStyle* app_style;
	static std::string styleSheet;
	static CscsTranslator* app_translator;

	static CscsList<CscsWidget*>* popup_widgets;
	static CscsWidget* main_widget;
	static CscsWidget* focus_widget;
	static CscsWidget* active_window;
	static CscsFocusFrame* focus_frame;
	static int mouse_double_click_time;
	static int keyboard_input_time;
	static int cursor_twinking_time;
	std::list<CscsCursor> cursor_list;

	static SCS::MouseButtons mouse_buttons;
	static SCS::KeyboardModifiers modifier_buttons;


	static CscsFont* app_font;
	static CscsSize app_strut;
	static CscsTimer* app_timer;
	static bool 	app_navi;
	friend class CscsApplication;
	friend class CscsWidgetExtend;
	friend class CscsWindowStorage;
	friend class CscsWindowSystemServer;
};

END_NAMESPACE

#endif