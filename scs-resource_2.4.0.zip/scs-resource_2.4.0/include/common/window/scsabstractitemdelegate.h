#ifndef SCSABSTRACTITEMDELEGATE_H
#define SCSABSTRACTITEMDELEGATE_H

#include <kernel/scsobject.h>
#include "scsenum.h"

BEGIN_NAMESPACE(Gemini)

class CscsPainter;
class CscsModelIndex;
class CscsAbstractItemModel;
class CscsWidget;
class CscsStyleOptionViewItem;
class CscsFont;
class CscsSize;
class CscsEvent;

class  CscsAbstractItemDelegate : public CscsObject
{

public:

    enum EndEditHint {
        NoHint,
        EditNextItem,
        EditPreviousItem,
        SubmitModelCache,
        RevertModelCache
    };

    explicit CscsAbstractItemDelegate(CscsObject *parent = nullptr);
    virtual ~CscsAbstractItemDelegate();

    // painting
    virtual void paint(CscsPainter *painter,
                       const CscsStyleOptionViewItem &option,
                       const CscsModelIndex &index) const = 0;

    virtual CscsSize sizeHint(const CscsStyleOptionViewItem &option,
                           const CscsModelIndex &index) const = 0;

    // editing
    virtual CscsWidget *createEditor(CscsWidget *parent,
                                  const CscsStyleOptionViewItem &option,
                                  const CscsModelIndex &index) const;

    virtual void setEditorData(CscsWidget *editor, const CscsModelIndex &index) const;

    virtual void setModelData(CscsWidget *editor,
                              CscsAbstractItemModel *model,
                              const CscsModelIndex &index) const;

    virtual void updateEditorGeometry(CscsWidget *editor,
                                      const CscsStyleOptionViewItem &option,
                                      const CscsModelIndex &index) const;

    // for non-widget editors
    virtual bool editorEvent(CscsEvent *event,
                             CscsAbstractItemModel *model,
                             const CscsStyleOptionViewItem &option,
                             const CscsModelIndex &index);

    static std::string elidedText(const CscsFont& font, int width,
                              SCS::TextElideMode mode, const std::string &text);
SIGNALS:
    void commitData(CscsWidget *editor){}
    void closeEditor(CscsWidget *editor, CscsAbstractItemDelegate::EndEditHint hint = NoHint){}
    void sizeHintChanged(const CscsModelIndex&){}
protected:
    CscsAbstractItemDelegate(CscsObjectPrivate*, CscsObject *parent = nullptr);
};

END_NAMESPACE

#endif