#ifndef SCSVIRTUALDISPLAY_H
#define SCSVIRTUALDISPLAY_H

#include <string>
#include <kernel/scstypes.h>
#include "scsdisplay.h"

BEGIN_NAMESPACE(Gemini)

class CscsVirtualShared
{
public:
    volatile int lastop;
    volatile int optype;
    volatile int fifocount;   // Accel drivers only
    volatile int fifomax;
    volatile int forecol;     // Foreground colour cacheing
    volatile unsigned int buffer_offset;   // Destination
    volatile int linestep;
    volatile int cliptop;    // Clip rectangle
    volatile int clipleft;
    volatile int clipright;
    volatile int clipbottom;
    volatile unsigned int rop;

};

class CscsVirtualDisplay:public CscsDisplay{
public:
	CscsVirtualDisplay();
	virtual ~CscsVirtualDisplay();

	virtual bool init();
	virtual bool connect(const std::string& display);

	virtual void disconnect();
	virtual void shutdown();
	virtual void save();
	virtual void restore();
	virtual void blank(bool on);
	virtual void setMode(int nw, int nh, int reserved=32);
	virtual uint8* cache(int);
	virtual void uncache(uint8*);
	virtual int sharedRamSize(void* );
	virtual bool useOffscreen() { return false; }
	
	CscsVirtualShared* shared;

protected:
	void deleteEntry(uint8* );

    bool canaccel;
    int dataoffset;
    int cacheStart;

    static void clearCache(CscsDisplay *instance, int);
private:
	void delete_entry(int);
    void insert_entry(int,int,int);
    void setupOffScreen();
    //void createPalette(fb_cmap &cmap, fb_var_screeninfo &vinfo, fb_fix_screeninfo &finfo);

    int fd;
    int startupw;
    int startuph;
    int startupd;
};

extern CscsDisplay* scs_global_display;

CscsDisplay* scs_get_display(const std::string& name);

END_NAMESPACE

#endif