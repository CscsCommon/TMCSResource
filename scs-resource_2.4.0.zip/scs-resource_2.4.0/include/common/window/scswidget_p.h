#ifndef SCSWIDGET_P_H
#define SCSWIDGET_P_H
#include <string>
#include <memory>
#include <kernel/scstypes.h>
#include <kernel/scsobject_p.h>
#include "scsenum.h"
#include <painting/scspoint.h>
#include <painting/scsregion.h>
#include <painting/scsrect.h>
#include "scswidget.h"
#include "scswindowdefs.h"
#include "widgets/scssizepolicy.h"
#ifdef USE_KMS_BACKEND
#include <platforms/scswindowsurface.h>
#endif

BEGIN_NAMESPACE(Gemini)

class CscsBackingStore;
class CscsEvent;
class CscsFont;
class CscsPalette;
class CscsBaseStyle;
class CscsLayout;

struct WinExtra{
	std::string caption; //widget caption
	uint16 incrw, incrh; //increment size
	uint32 frleft, frtop, frright, frbottom;//frame left/top right/bottom
	uint8 opacity;

	SCS::WindowFlags savedFlags;//save flags of widget
	uint16 basew, baseh;//base size
	#ifndef USE_KMS_BACKEND
	CscsBackingStore* backingStore;
	#else
	CscsSurface* backingStore;
	cairo_device_t* backingDevice;
	#endif
	CscsPoint 	backingOffset;
	CscsPoint   painterOffset;
	CscsRegion dirtyRegion;
	bool inPaintTransaction;

	CscsRect normalGeometry;
};

struct WidExtra{
	int32 minw, minh;
	int32 maxw, maxh;
	CscsWidget* focus_proxy;
	CscsCursor* curs;
	WinExtra* topextra;
	CscsRegion mask; //widget mask;
	CscsBaseStyle* style;
	std::string styleSheet;
	CscsSizePolicy size_policy;
	uint explicitMinSize : 2;
    uint autoFillBackground : 1;
};

class CscsWidget;
class CscsWidgetPrivate:public CscsObjectPrivate{
public:
	CscsWidgetPrivate();
	~CscsWidgetPrivate();

	CscsWidget* mm_func()const;

	WidExtra* extraData()const;
	WinExtra* topData()const;

	void init(CscsWidget* topWidget, SCS::WindowFlags f);
	void create(int window, bool initialize, bool destroyOld);
	void createWinExtra();
	void createWidExtra();
	void deleteWidExtra();
	void updateSystemBackground();
	void raise();
	void lower();
	void stackUnder(CscsWidget* );


	void setFont(const CscsFont& f);
	void resolveFont(const CscsFont& f);
	void resolveFont();
	void setPalette(const CscsPalette& pal);
	void resolvePalette();

	void updateFrameStrut() const;
	bool isBackgroundInherited()const;
	void updateInheritedBackground();
	void updatePropagatedBackground(const CscsRegion *reg=0);
	
	void setUpdatesEnabled(bool );
	void composeBackground(const CscsRect& );
	CscsRect clipRect()const;

	bool isFullyOpaque()const;

	void addNavigationWidgets(CscsWidget* w);
	void removeNavigationWidgets(CscsWidget* w);

	enum CloseMode{
		CloseNoEvent,
		CloseWidthEvent,
		CloseWidthSpontaneousEvent
	};

	bool close(CloseMode);

	bool compositeEvent(CscsEvent* e);

	void reparentFocusWidgets(CscsWidget* oldwin);
	static int pointToRect(const CscsPoint& p, const CscsRect& r);
	

	void setWinId(int);
	void showChildren(bool spontaneous);
	void hideChildren(bool spontaneous);

	void setParent(CscsWidget* parent, SCS::WindowFlags f);
	void setGeometry(int x, int y, int w, int h, bool isMoved);
	void show_recursive();
	void show_helper();
	void show();
	void hide_helper();
	void hide();
	void setEnabled(bool enabled);
	void setConstraints();

	void setLayoutDirection_helper(SCS::LayoutDirection dir);
	void resolveLayoutDirection();

	void setWindowTitle_helper(const std::string& caption);
	void setWindowTitle(const std::string& caption);

	CscsRegion requestedRegion()const;
	void requestedWindowRegion(const CscsRegion& r);

	void paintHierarchy(const CscsRegion& r);
	void doPaint(const CscsRegion& r);
	void blendToDisplay(const CscsRegion& r);

	void paintHierarchyOnScreen(const CscsRegion& r);

	void propagatePaletteChange();
	void deactiveWidgetCleanup();
	void paintBackground();

	void setStyle_helper(CscsBaseStyle* newStyle, bool propagate);
	void inheritStyle();
	
	static int instanceCounter;
	static int maxInstances;

	CscsWidgetData data;
	WidExtra* extra;
	CscsWidget* focus_next;
	CscsWidget* focus_child;
	CscsLayout* layout;

	CscsPalette::ColorRole fg_role:8;
	CscsPalette::ColorRole bg_role:8;
	

	int leftMargin, topMargin, rightMargin, bottomMargin;
	
	int hd;
	uint hightAttrs[2];

	bool  designerMode;

	//static CscsWidgetMapper* mapper;
	static CscsWidgetSet* 	mapper;
	static std::list<CscsWidget*> navigations;
	mutable const CscsObject *polished;

friend class CscsWidget;
friend class CscsLayout;
};

END_NAMESPACE
#endif