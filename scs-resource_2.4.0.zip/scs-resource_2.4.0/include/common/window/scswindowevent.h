 /*Created by J.Wong 2018/10/28
 version:    version 1.0,
 dependency: base on  or greater than c++11
 function: type erase
 gcc4.9+
 */

#ifndef SCSWINDOWEVENT_H
#define SCSWINDOWEVENT_H
#include <kernel/scsevent.h>
#include <painting/scsrect.h>
#include <painting/scspoint.h>
#include <painting/scsregion.h>
#include <kernel/scsstring.h>
#include "scsenum.h"


BEGIN_NAMESPACE(Gemini)

namespace SCS{
 	enum MouseButton{
        NoButton=0x00,
        LeftButton=0x01,
        RightButton=0x02,
        MidButton=0x04,
        MouseButtonMask=0xffffffff
    };
    SCS_DECLARE_FLAGS(MouseButtons, MouseButton)

	 enum SCSREL{
			SCSREL_X=0x00,
			SCSREL_Y=0x01,
			SCSREL_WHEEL=0x08
	};
}

SCS_DECLARE_OPERATORS_FOR_FLAGS(SCS::MouseButtons)


class CscsMouseEvent:public CscsEvent{

public:
	CscsMouseEvent(SCSType type, const CscsPoint& pos, SCS::MouseButton button, SCS::MouseButtons buttons,SCS::KeyboardModifiers modifiers)
	:CscsEvent(type),p(pos),g(pos), b(button),s(buttons),m(modifiers){}
	CscsMouseEvent(SCSType type, const CscsPoint &pos, const CscsPoint &globalPos,
                SCS::MouseButton button, SCS::MouseButtons buttons,SCS::KeyboardModifiers modifiers)
	:CscsEvent(type),p(pos),g(globalPos), b(button),s(buttons),m(modifiers){}

	const CscsPoint& pos()const{

		return p;
	}

	int x()const{

		return p.x();
	}

	int y()const{

		return p.y();
	}

	const CscsPoint &globalPos() const{
	 return g;
	}

	int globalX() const { return g.x(); }
    int globalY() const { return g.y(); }

	SCS::MouseButton button()const {
		return b;
	 }

	SCS::MouseButtons buttons() const{

		return  s;
	}

	inline SCS::KeyboardModifiers modifiers() const { return m; }
    inline void setModifiers(SCS::KeyboardModifiers amodifiers) { m = amodifiers; }

protected:
	CscsPoint p, g;
	SCS::MouseButton b;
	SCS::MouseButtons s;
	SCS::KeyboardModifiers m;

};

enum SCSOrientation{

	Horizontal,
	Vertical
};


class CscsWheelEvent:public CscsEvent{

public:
	CscsWheelEvent(const CscsPoint& pos, int delta, int state, SCSOrientation orient=Vertical)
	:CscsEvent(Wheel),p(pos),d(delta),s(state),o(orient){}

	int delta()const {

		return d;
	}

	const CscsPoint& pos()const{

		return p;
	}

	int x() const{return p.x();}
	int y() const{return p.y();}

	SCS::MouseButtons buttons() const{

		return  s;
	}

	SCSOrientation orientation()const {
		return o;
	}

protected:
	CscsPoint p;
	int d;
	SCS::MouseButtons s;
	SCSOrientation o;
};

enum CscsEV{
/*
 * Event types
 */
SCSEV_SYN=0x00,
SCSEV_KEY=0x01,
SCSEV_REL=0x02,
SCSEV_ABS=0x03,
SCSEV_MSC=0x04,
SCSEV_SW=0x05,
SCSEV_LED=0x11,
SCSEV_SND=0x12,
SCSEV_REP=0x14,
SCSEV_FF =0x15,
SCSEV_PWR=0x16,
SCSEV_FF_STATUS=0x17,
SCSEV_MAX=0x1f,
SCSEV_CNT=(SCSEV_MAX+1)

};

namespace SCS{
enum CscsKey{
	Key_Escape=0x1000,
	Key_Tab=0x1001,
	Key_Backtab=0x1002,
	Key_BackTab=Key_Backtab,
	Key_BackSpace=0x1003,
	Key_Backspace=Key_BackSpace,
	Key_Return=0x1004,
	Key_Enter=0x1005,
	Key_Insert=0x1006,
	Key_Delete=0x1007,
	Key_Pause=0x1008,
	Key_Print=0x1009,
	Key_SysReq=0x100a,
	Key_Home=0x1010,
	Key_End=0x1011,
	Key_Left=0x1012,
	Key_Up=0x1013,
	Key_Right=0x1014,
	Key_Down=0x1015,
	Key_Prior=0x1016,
	Key_PageUp=Key_Prior,
	Key_Next=0x1017,
	Key_PageDown=Key_Next,
	Key_Shift=0x1020,
	Key_Ctrl=0x1021,
	Key_Control=0x1021,
	Key_Meta=0x1022,
	Key_Alt=0x1023,
	Key_CapsLock=0x1024,
	Key_NumLock=0x1025,
	Key_ScrollLock=0x1026,
	Key_F1=0x1030,
	Key_F2=0x1031,
	Key_F3=0x1032,
	Key_F4=0x1033,
	Key_F5=0x1034,
	Key_F6=0x1035,
	Key_F7=0x1036,
	Key_F8=0x1037,
	Key_F9=0x1038,
	Key_F10=0x1039,
	Key_F11=0x103a,
	Key_F12=0x103b,
	Key_F13=0x103c,
	Key_F14=0x103d,
	Key_F15=0x103e,
	Key_F16=0x103f,
	Key_F17=0x1040,
	Key_F18=0x1041,
	Key_F19=0x1042,
	Key_F20=0x1043,
	Key_F21=0x1044,
	Key_F22=0x1045,
	Key_F23=0x1046,
	Key_F24=0x1047,
	Key_F25=0x1048,
	Key_F26=0x1049,
	Key_F27=0x104a,
	Key_F28=0x104b,
	Key_F29=0x104c,
	Key_F30=0x104d,
	Key_F31=0x104e,
	Key_F32=0x104f,
	Key_F33=0x1050,
	Key_F34=0x1051,
	Key_F35=0x1052,
	Key_Super_L=0x1053,
	Key_Super_R=0x1054,
	Key_Menu=0x1055,
	Key_Hyper_L=0x1056,
	Key_Hyper_R=0x1057,
	Key_Help=0x1058,
	Key_Direction_L=0x1059,
	Key_Direction_R=0x1060,
	Key_Space=0x20,
	Key_Any=Key_Space,
	Key_Exclam=0x21,
	Key_QuoteDbl=0x22,
	Key_NumberSign=0x23,
	Key_Dollar=0x24,
	Key_Percent=0x25,
	Key_Ampersand=0x26,
	Key_Apostrophe=0x27,
	Key_ParentLeft=0x28,
	Key_ParentRight=0x29,
	Key_Asterisk=0x2a,
	Key_Plus=0x2b,
	Key_Comma=0x2c,
	Key_Minus=0x2d,
	Key_Period=0x2e,
	Key_Slash=0x2f,
	Key_0=0x30,
	Key_1=0x31,
	Key_2=0x32,
	Key_3=0x33,
	Key_4=0x34,
	Key_5=0x35,
	Key_6=0x36,
	Key_7=0x37,
	Key_8=0x38,
	Key_9=0x39,
	Key_Colon=0x3a,
	Key_Semicolon=0x3b,
	Key_Less=0x3c,
	Key_Equal=0x3d,
	Key_Greater=0x3e,
	Key_Question=0x3f,
	Key_At=0x40,
	Key_A=0x41,
	Key_B=0x42,
	Key_C=0x43,
	Key_D=0x44,
	Key_E=0x45,
	Key_F=0x46,
	Key_G=0x47,
	Key_H=0x48,
	Key_I=0x49,
	Key_J=0x4a,
	Key_K=0x4b,
	Key_L=0x4c,
	Key_M=0x4d,
	Key_N=0x4e,
	Key_O=0x4f,
	Key_P=0x50,
	Key_Q=0x51,
	Key_R=0x52,
	Key_S=0x53,
	Key_T=0x54,
	Key_U=0x55,
	Key_V=0x56,
	Key_W=0x57,
	Key_X=0x58,
	Key_Y=0x59,
	Key_Z=0x5a,
	Key_BracketLeft=0x5b,
	Key_Backslash=0x5c,
	Key_BracketRight=0x5d,
	Key_AsciiCircum=0x5e,
	Key_Underscore=0x5f,
	Key_QuoteLeft=0x60,
	Key_BraceLeft=0x7b,
	Key_Bar=0x7c,
	Key_BraceRight=0x7d,
	Key_AsciiTilde=0x7e,


	Key_nobreakspace=0xa0,
	Key_exclamdown=0xa1,
	Key_cent=0xa2,
	Key_sterling=0xa3,
	Key_currency=0xa4,
	Key_yen=0xa5,
	Key_brokenbar=0xa6,
	Key_section=0x0a7,
	Key_diaeresis=0xa8,
	Key_copyright=0xa9,
	Key_ordfeminine=0xaa,
	Key_guillemotleft=0xab,
	Key_notsign=0xac,
	Key_hyphen=0xad,
	Key_rigistered=0xae,
	Key_macron=0xaf,
	Key_degree=0xb0,
	Key_plusminus=0xb1,
	Key_twosuperior=0xb2,
	Key_threesuperior=0xb3,
	Key_acute=0xb4,
	Key_mu=0xb5,
	Key_paragraph=0xb6,
	Key_periodcentered=0xb7,
	Key_cedilla=0xb8,
	Key_onesuperior=0xb9,
	Key_masculine=0xba,

	Key_unknown=0xffff

};

}

class CscsKeyEvent:public CscsEvent{

public:
	CscsKeyEvent(SCSType type, int key, int ascii,int modifiers/*,int state*/,bool autorep=false, int count=1)
	:CscsEvent(type),k(key),m(modifiers)/*,s(state)*/,a(ascii),autor(autorep),c(count){}

	int key()const{

		return k;
	}

	int ascii()const{

		return a;
	}

	SCS::KeyboardModifiers modifiers() const{
		return SCS::KeyboardModifiers(m);
	}

	CscsString text()const{
		return CscsString(CscsChar(a==0xffff?0:a));
	}

	// SCS::MouseButton state()const{

	// 	return SCS::MouseButton(s);
	// }

	bool isAutoRepeat()const {return autor;}

	int count()const {return c; }

protected:
	int k, m/*, s*/;
	ushort a;
	bool autor;
	short c;

};


typedef struct{
	int k;
	int s;
	int m;
	bool autor;
	short c;
}CscsKeyData;

typedef struct{
	int x;
	int y;
	int delta;
	int s;
	int o;
}CscsWheelData;

typedef struct{
 int x;
 int y;
 int delta;
 int bs;
}CscsMouseData;


class CscsFocusEvent:public CscsEvent{
public:

	CscsFocusEvent(SCSType type, SCS::FocusReason reason=SCS::OtherFocusReason);
	~CscsFocusEvent();

	bool getFocus()const;
	bool loseFocus()const;

	SCS::FocusReason reason();
private:
	friend class CscsApplication;
	SCS::FocusReason m_reason;
}; 


class CscsMoveEvent:public CscsEvent{
public:
	CscsMoveEvent(const CscsPoint& pos, const CscsPoint& oldPos);
	~CscsMoveEvent();

	const CscsPoint& pos()const;
	const CscsPoint& oldPos()const;

protected:
	friend class CscsApplication;
	CscsPoint p, oldp;
};

class CscsSwipeEvent:public CscsEvent{
public:
	CscsSwipeEvent(SCSType type,const CscsPoint& pos);
	~CscsSwipeEvent();
	const CscsPoint& pos()const;

protected:
	friend class CscsApplication;
	CscsPoint p;
};


class CscsCloseEvent:public CscsEvent{
public:	
	CscsCloseEvent():CscsEvent(Close){}
	~CscsCloseEvent(){}
};

class CscsHideEvent:public CscsEvent{
public:
	CscsHideEvent():CscsEvent(Hide){}
	~CscsHideEvent(){}
};

class CscsShowEvent:public CscsEvent{
public:
	CscsShowEvent():CscsEvent(Show){}
	~CscsShowEvent(){}
};


class CscsPaintEvent:public CscsEvent{
public:
	CscsPaintEvent(const CscsRegion& r);
	CscsPaintEvent(const CscsRect& r);
	~CscsPaintEvent();
	const CscsRect& rect()const;
	const CscsRegion& region()const;

protected:
	friend class CscsApplication;
	CscsRect m_rect;
	CscsRegion m_region;
	bool m_erased;
};

class CscsResizeEvent:public CscsEvent{
public:
	CscsResizeEvent(const CscsSize& size, const CscsSize& oldSize);
	~CscsResizeEvent();

	const CscsSize& size()const;
	const CscsSize& oldSize()const;

protected:
	friend class CscsApplication;
	CscsSize s, oldS;
};

class CscsUpdateEvent : public CscsPaintEvent
{
public:
    CscsUpdateEvent(const CscsRegion& paintRegion);
    CscsUpdateEvent(const CscsRect &paintRect);
    ~CscsUpdateEvent();
};

#ifdef D_WIN32
class CscsWindowPaintEvent : public CscsPaintEvent
{
public:
    CscsWindowPaintEvent(const CscsRegion& paintRegion);
    CscsWindowPaintEvent(const CscsRect &paintRect);
    ~CscsWindowPaintEvent();
};

#endif


class CscsPaintOnScreenEvent:public CscsPaintEvent{
public:
    CscsPaintOnScreenEvent(const CscsRegion& r);
    CscsPaintOnScreenEvent(const CscsRect&  r);
    ~CscsPaintOnScreenEvent();
};

class CscsRepaintSurfaceEvent:public CscsPaintEvent{
public:
    CscsRepaintSurfaceEvent(int winId, const CscsRegion& r);
    CscsRepaintSurfaceEvent(int winId, const CscsRect&  r);
    ~CscsRepaintSurfaceEvent();
    int winId()const;
private:
	int m_winId;
};

class  CscsWindowStateChangeEvent: public CscsEvent
{
public:
    CscsWindowStateChangeEvent(SCS::WindowStates aOldState);
    ~CscsWindowStateChangeEvent();

    inline SCS::WindowStates oldState() const { return ostate; }

private:
    SCS::WindowStates ostate;
};

END_NAMESPACE

#endif