 /*Created by J.Wong 2018/10/29
 version:    version 1.0,
 dependency: base on  or greater than c++11
 function: type erase
 gcc4.8+
 */
#ifndef SCSWIDGET_H
#define SCSWIDGET_H
#include <kernel/scsobject.h>
#include <kernel/scstypes.h>
#include <kernel/scslist.h>
#include <painting/scsrect.h>
#include <painting/scspaintdevice.h>
#include <painting/scsfont.h>
#include <painting/scsrgba.h>
#include "scsenum.h"
#include "scsplatformscreen.h"
#include "widgets/scscursor.h"
#include "styles/scspalette.h"
#include "widgets/scssizepolicy.h"
#include <config.h>

#ifdef D_DESIGNER_LIB
class CscsWidget;
#endif
BEGIN_NAMESPACE(Gemini)
 
#define CONTAINER_WIDGET
#define DESINER_INVISIBLE
#define SENSOR_WIDGET

class CscsEvent;
class CscsMouseEvent;
class CscsSwipeEvent;
class CscsKeyEvent;
class CscsFocusEvent;
class CscsMoveEvent;
class CscsCloseEvent;
class CscsHideEvent;
class CscsShowEvent;
class CscsPaintEvent;
class CscsResizeEvent;
class CscsWidgetPrivate;
class CscsBaseStyle;
class CscsLayout;
class CscsBackingStore;

#define MAX_WIDGETSIZE 65535

struct  CscsWidgetData{
	int windId;
	uint widgetAttr;
	SCS::WindowFlags winFlags;
	uint winState:4;
	uint focus_policy:4;
	uint isClosing:1;
	uint inShow:1;
	uint inSetWinState:1;
	mutable uint fstruct_dirty:1;
	uint context_menu_policy : 3;
	uint dirty:1;
	uint navi:1;
	uint unUsed:16;
	int allocReginIndex;
	int priv;
	CscsRect cRect;
	mutable CscsPalette pal;
	CscsFont fnt;
	CscsRect wRect;

};



class WIDGET_EXPORT CscsWidget:public CscsObject,public CscsPaintDevice{
	
	CONTAINER_WIDGET
public:
	CscsWidget(CscsWidget* parent=0,SCS::WindowFlags f=0);
	~CscsWidget();

	int  winId()const;
	bool isTopLevel()const;
	bool isWindow()const;
	bool isModal()const;
	bool isEnabled()const;
	bool updateEnables()const;
	bool isActiveWindow()const;
	bool activeWindow();

	bool isDesignerMode()const;
	void setDesignerMode(bool mode);

	bool navigation()const;
	void setNavigation(bool enable);


	const CscsFont& font()const;
	void setFont(const CscsFont& f);

	const CscsPalette& palette()const;
	void setPalette(const CscsPalette& pal);

	void setBackgroundRole(CscsPalette::ColorRole);
	CscsPalette::ColorRole backgroundRole()const;

	void setForegroundRole(CscsPalette::ColorRole);
	CscsPalette::ColorRole foregroundRole()const;

	bool autoFillBackground()const;
	void setAutoFillBackground(bool enabled);


	bool isEnabledTo(CscsWidget* w)const;




	void setUpdateEnables(bool enable);

	CscsWidgetPrivate* d_func()const;

	CscsPlatformScreen* screen()const{
		return scs_screen;
	}


	void setWindowTitle(const std::string& title);
	std::string windowTitle()const;

	CscsWidget* window()const;
	CscsWidget* parentWidget()const;
	void setParent(CscsWidget* parent);
	void setParent(CscsWidget* parent, SCS::WindowFlags f);
	void setWindowFlags(SCS::WindowFlags f);
	SCS::WindowFlags windowFlags()const;

	SCS::WindowType windowType()const;

	static CscsWidget* find(int id);
	inline CscsWidget* childAt(int x, int y)const{
		return childAt(CscsPoint(x,y));
	}
	CscsWidget* childAt(const CscsPoint& p)const;

	bool 		hasFocus()const;
	void 		clearFocus();
	void 		setFocus(SCS::FocusReason reason);

	static void setTabOrder(CscsWidget* first, CscsWidget* second);
	void setFocusProxy(CscsWidget *);
    CscsWidget *focusProxy() const;
    
	CscsWidget* focusWidget()const;
	CscsWidget* nextInFocusChain()const;

	SCS::FocusPolicy focusPolicy()const;
	void setFocusPolicy(SCS::FocusPolicy policy);

	void setAttribute(SCS::WidgetAttribute f, bool on=true);
	bool testAttribute(SCS::WidgetAttribute f)const;

	int handle()const;

	bool isAncestorOf(CscsWidget* w);


	void grabMouse();
	void grabMouse(const CscsCursor& );
	void releaseMouse();

	CscsCursor cursor()const;
	void setCursor(const CscsCursor& );
	void unsetCursor();

	static CscsWidget*  mouseGrabber();

	inline bool hasMouseTracking()const{
		return testAttribute(SCS::WA_MouseTracking);
	}

	inline void setMouseTracking(bool enable){
		setAttribute(SCS::WA_MouseTracking,enable);
	}

	CscsLayout* layout()const;
	void setLayout(CscsLayout *l);
	//add 2018/12/15 for layout
	CscsSizePolicy sizePolicy()const;
	void setSizePolicy(CscsSizePolicy);

	inline void setSizePolicy(CscsSizePolicy::Policy horizontal, CscsSizePolicy::Policy vertical){
		setSizePolicy(CscsSizePolicy(horizontal,vertical));
	}
    virtual int heightForWidth(int) const;
    virtual CscsSize minimumSizeHint() const;

    bool isMinimized()const;
	bool isMaximized()const;
	bool isFullScreen()const;

	SCS::WindowStates windowState()const;
	void setWindowState(SCS::WindowStates state);
	void overrideWindowState(SCS::WindowStates state);

	void showMinimized();
    void showMaximized();
    void showFullScreen();
    void showNormal();
    void scroll(int dx, int dy);
    void scroll(int dx, int dy, const CscsRect& r);

    CscsSize minimumSize() const;
    CscsSize maximumSize() const;
    inline int minimumWidth() const{
    	return minimumSize().width();
    }
    inline int minimumHeight() const{
    	return minimumSize().height();
    }
    inline int maximumWidth() const{
    	return maximumSize().width();
    }
    inline int maximumHeight() const{
    	return maximumSize().height();
    }
    inline void setMinimumSize(const CscsSize& s){
    	setMinimumSize(s.width(), s.height());
    }
    
    inline void setMaximumSize(const CscsSize& s){

    	setMaximumSize(s.width(),s.height());
    }
    void setMinimumWidth(int minw);
    void setMinimumHeight(int minh);
    inline void setMaximumWidth(int maxw){
    	setMaximumSize(maxw, maximumSize().height());
    }
    inline void setMaximumHeight(int maxh){
    	setMaximumSize(maximumSize().width(),maxh);
    }

    void setMinimumSize(int minw, int minh);
    void setMaximumSize(int maxw, int maxh);
    

    CscsSize sizeIncrement() const;
    inline void setSizeIncrement(const CscsSize& s){
    	setSizeIncrement(s.width(),s.height());
    }
    void setSizeIncrement(int w, int h);
    CscsSize baseSize() const;
    void setBaseSize(const CscsSize& s){
    	setBaseSize(s.width(),s.height());
    }

    void setBaseSize(int basew, int baseh);
    void setFixedSize(const CscsSize& s);
    void setFixedSize(int w, int h);
    void setFixedWidth(int w);
    void setFixedHeight(int h);

    virtual void setDataID(uint uid){}
    virtual void setMaxDataID(uint uid){}
    virtual void setMinDataID(uint uid){}

    virtual uint dataID()const { return 0; }
    virtual uint maxDataID()const { return 0;}
    virtual uint minDataID()const { return 0; }
    virtual void setPrivilege(int priv);
    int 	privilege()const;
public:
	CscsPoint  pos()const;
	CscsSize   size()const;
	int x()const;
	int y()const;
	int width()const;
	int height()const;
	CscsSize frameSize() const;
	inline CscsRect rect()const{
		return CscsRect(0,0,data->cRect.width(),data->cRect.height());
	}
	inline void setGeometry(int x, int y, int w, int h){
		setGeometry(CscsRect(x, y, w, h));
	}
	void setGeometry(const CscsRect& r);

	CscsRect& geometry()const{

		return data->cRect;
	}

	CscsRect frameGeometry() const;

	CscsRect childrenRect()const;
	CscsRegion childrenRegion()const;

	CscsRegion mask()const;
	void setMask(const CscsRegion& msk);
	void clearMask();

	CscsPoint mapToGlobal(const CscsPoint& pos);
	CscsPoint mapFromGlobal(const CscsPoint& pos);
	CscsPoint mapToParent(const CscsPoint& pos);
	CscsPoint mapFromParent(const CscsPoint& pos);
	CscsPoint mapTo(const CscsWidget* w, const CscsPoint& pos);
	CscsPoint mapFrom(const CscsWidget* w, const CscsPoint& pos);
	
	void move(int x, int y);
	void move(const CscsPoint& p);
	void resize(int w, int h);
	void resize(const CscsSize& size);
	void adjustSize();
	

	
	
	bool isVisible()const;
	bool isVisibleTo(CscsWidget* w);
	bool isHidden()const;



	CscsRegion visibleRegion()const;

	void updateGeometry();

	virtual CscsSize sizeHint()const;

	CscsBaseStyle* style()const;
	void setStyle(CscsBaseStyle* style);

	void setStyleSheet(const std::string& styleSheet);
	std::string styleSheet()const;
	

	void setContentsMargins(int left, int top, int right, int bottom);
	void getContentsMargins(int& left, int& top, int& right, int& bottom)const;
	CscsRect contentsRect()const;

	void setLayoutDirection(SCS::LayoutDirection dir);
	SCS::LayoutDirection layoutDirection()const;
	void unsetLayoutDirection();
	inline bool isRightToLeft()const{return layoutDirection()==(SCS::RightToLeft);}
	inline bool isLeftToRight()const{return layoutDirection()==(SCS::LeftToRight);}

    CscsImage* backingStore()const;
	void setBackingStore(CscsImage* img);
	void ensurePolished() const;
protected:
	bool event(CscsEvent* e);
	virtual void mousePressEvent(CscsMouseEvent* me);
	virtual void mouseReleaseEvent(CscsMouseEvent* me);
	virtual void mouseDoubleClickEvent(CscsMouseEvent* me);
	virtual void mouseMoveEvent(CscsMouseEvent* me);

	virtual void swipeEvent(CscsSwipeEvent* se);

	virtual void keyPressEvent(CscsKeyEvent* ke);
	virtual void keyReleaseEvent(CscsKeyEvent* ke);

	virtual void focusInEvent(CscsFocusEvent* fe);
	virtual void focusOutEvent(CscsFocusEvent* fe);

	virtual void enterEvent(CscsEvent* e);
	virtual void leaveEvent(CscsEvent* e);

	virtual void moveEvent(CscsMoveEvent* me);
	virtual void closeEvent(CscsCloseEvent* ce);
	virtual void showEvent(CscsShowEvent* se);
	virtual void hideEvent(CscsHideEvent* he);

	virtual void changeEvent(CscsEvent* e);

	virtual void paintEvent(CscsPaintEvent* pe);
	virtual void resizeEvent(CscsResizeEvent* re);

protected:
	CscsWidget(CscsWidgetPrivate* d,CscsWidget* parent,SCS::WindowFlags f);
	void create(int id=0, bool initialize=true, bool destroyOld=true);
	void destroy(bool destroyWindow=true, bool destroySubWindows=true);

	virtual bool focusNextPrevChild(bool next);
	bool focusNextChild(){ return focusNextPrevChild(true);}
	bool focusPrevChild(){ return focusNextPrevChild(false);}
	
	bool   focusByNavigation(uint type);
	void paintBackground();

	bool focusByDirectionL();
	bool focusByDirectionR();
	bool focusByDirectionD();
	bool focusByDirectionU();
	bool focusByDirectionLD();
	bool focusByDirectionUL();
	void focusByDirectionLR();
	void focusByDirectionRR();
	void focusByDirectionDR();
	void focusByDirectionUR();
	bool focusByEnter();
	bool focusByTaborder();

SLOTS:
	void setEnabled(bool enabled);
	void setDisabled(bool enabled){
		setEnabled(!enabled);
	}
	void update();
	void repaint();
	inline 	void setFocus() { setFocus(SCS::OtherFocusReason); }

public:

	void update(int x, int y, int w, int h);
    void update(const CscsRect& r);
    void update(const CscsRegion& r);

	void repaint(int x, int y, int w, int h);
    void repaint(const CscsRect &r);
    void repaint(const CscsRegion &rgn);

	virtual void setVisible(bool visible);
	inline void setHidden(bool hidden){
		setVisible(!hidden);
	}
	inline void show(){
		setVisible(true);
	}
	inline void hide(){
		setVisible(false);
	}

	bool close();
	bool raise();
	bool lower();
	void stackUnder(CscsWidget* w);

	void setToolTipDuration(uint duration);
	void setAcceptDrops(bool accept);
	

private:
	void setBackingStore(cairo_surface_t* surface,cairo_device_t* dev=nullptr);
	CscsWidgetData* data;
	friend class CscsWidgetPrivate;
	friend class CscsApplication;
	friend class CscsStyleSheetStyle;
	friend class CscsWindowSurfaceManager;
	#ifdef D_DESIGNER_LIB
    friend class ::CscsWidget;
    #endif
BEGIN_PROPERTY(CscsWidget,CscsObject)
    META_READ_PROPERTY(bool, modal, READ, isModal)
    META_PROPERTY(bool, enabled, READ, isEnabled, WRITE, setEnabled)
    META_PROPERTY(CscsRect, geometry, READ, geometry, WRITE, setGeometry)
    META_READ_PROPERTY(CscsRect, frameGeometry, READ, frameGeometry)
    META_READ_PROPERTY(int, x, READ, x)
    META_READ_PROPERTY(int, y, READ, y)
    META_PROPERTY(CscsPoint, pos, READ, pos, WRITE, move)
    META_READ_PROPERTY(CscsSize, frameSize, READ, frameSize)
    META_PROPERTY(CscsSize, size, READ, size, WRITE, resize)
    META_READ_PROPERTY(int, width, READ, width)
    META_READ_PROPERTY(int, height, READ, height)
    META_READ_PROPERTY(CscsRect, rect, READ, rect)
    META_READ_PROPERTY(CscsRect, childrenRect, READ, childrenRect)
    META_READ_PROPERTY(CscsRegion, childrenRegion, READ, childrenRegion)
    META_PROPERTY(CscsSizePolicy, sizePolicy, READ, sizePolicy, WRITE, setSizePolicy)
    META_PROPERTY(CscsSize, minimumSize, READ, minimumSize, WRITE, setMinimumSize)
    META_PROPERTY(CscsSize, maximumSize, READ, maximumSize, WRITE, setMaximumSize)
    META_PROPERTY(int, minimumWidth, READ, minimumWidth, WRITE, setMinimumWidth)
    META_PROPERTY(int, minimumHeight, READ, minimumHeight, WRITE, setMinimumHeight)
    META_PROPERTY(int, maximumWidth, READ, maximumWidth, WRITE, setMaximumWidth)
    META_PROPERTY(int, maximumHeight, READ, maximumHeight, WRITE, setMaximumHeight)
    META_PROPERTY(CscsSize, sizeIncrement, READ, sizeIncrement, WRITE, setSizeIncrement)
    META_PROPERTY(CscsSize, baseSize, READ, baseSize, WRITE, setBaseSize)
    META_PROPERTY(CscsPalette, palette, READ, palette, WRITE, setPalette)
    META_PROPERTY(CscsFont, font, READ, font, WRITE, setFont)
    META_PROPERTY(bool, mouseTracking, READ, hasMouseTracking, WRITE, setMouseTracking)
    META_READ_PROPERTY(bool, isActiveWindow, READ, isActiveWindow)
    META_PROPERTY(SCS::FocusPolicy, focusPolicy, READ, focusPolicy, WRITE, setFocusPolicy)
    META_PROPERTY(bool , navigation, READ, navigation, WRITE , setNavigation);
    META_READ_PROPERTY(bool, focus, READ, hasFocus)
    META_PROPERTY(bool, updatesEnabled, READ, updateEnables, WRITE, setUpdateEnables)
    META_PROPERTY(bool, visible, READ, isVisible, WRITE, setVisible)
    META_READ_PROPERTY(bool, minimized, READ, isMinimized)
    META_READ_PROPERTY(bool, maximized, READ, isMaximized)
    META_READ_PROPERTY(bool, fullScreen, READ, isFullScreen)
    META_READ_PROPERTY(CscsSize, sizeHint, READ, sizeHint)
    META_READ_PROPERTY(CscsSize, minimumSizeHint, READ, minimumSizeHint)
    META_PROPERTY(std::string, windowTitle, READ, windowTitle, WRITE, setWindowTitle)
    META_PROPERTY(SCS::LayoutDirection, layoutDirection, READ, layoutDirection, WRITE, setLayoutDirection)
END_PROPERTY

};


inline CscsWidget *scs_widget_cast(CscsObject *o)
{
    if (!o || !o->isWidget()) return 0;
    return static_cast<CscsWidget*>(o);
}

inline const CscsWidget *scs_widget_cast(const CscsObject *o)
{
    if (!o || !o->isWidget()) return 0;
    return static_cast<const CscsWidget*>(o);
}

template <typename T> 
inline T scs_widget_cast(CscsObject* o, const std::string& classname){
	if(!o||!o->isWidget()) return 0;
	if (o->className()==classname||o->inherits(classname.data())){
		return  static_cast<T>(o);
	}
	return 0;
}

template <typename T> 
inline const T scs_widget_cast(const CscsObject* o, const std::string& classname){
	if(!o||!o->isWidget()) return 0;
	if (o->className()==classname||o->inherits(classname.data())){
		return  static_cast<const T>(o);
	}
	return 0;
}

void scs_findchild_helper(const CscsObject *parent, const std::string &name,
                         const std::string& classname, CscsList<void*> *list);

template <typename T>
inline CscsList<T> scsFindChildren(const CscsObject* o, const std::string& classname,const std::string& name=std::string()){
	CscsList<T> list;
	scs_findchild_helper(o,name,classname, reinterpret_cast<CscsList<void *>*>(&list));
	return list;
}


template <typename T>
inline T scsFindChild(const CscsObject* o, const std::string& classname,const std::string& name=std::string()){
	CscsList<T> list;
	scs_findchild_helper(o,name,classname, reinterpret_cast<CscsList<void *>*>(&list));
	if(list.isEmpty()) return nullptr;
	return list[0];
}  

END_NAMESPACE

#endif
