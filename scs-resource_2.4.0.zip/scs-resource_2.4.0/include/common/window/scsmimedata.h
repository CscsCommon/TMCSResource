#ifndef SCSMIMEDATA_H
#define SCSMIMEDATA_H
#include <kernel/scsvariant.h>
#include <kernel/scsobject.h>

BEGIN_NAMESPACE(Gemini)

class CscsMimeDataPrivate;
class CscsStringList;

class  CscsMimeData : public CscsObject
{
public:
    CscsMimeData();
    ~CscsMimeData();

    CscsString text() const;
    void setText(const CscsString &text);
    bool hasText() const;

    CscsVariant imageData() const;
    void setImageData(const CscsVariant &image);
    bool hasImage() const;

    CscsVariant colorData() const;
    void setColorData(const CscsVariant &color);
    bool hasColor() const;

    CscsByteArray data(const CscsString &mimetype) const;
    void setData(const CscsString &mimetype, const CscsByteArray &data);

    virtual bool hasFormat(const CscsString &mimetype) const;
    virtual CscsStringList formats() const;

    void clear();
protected:
    virtual CscsVariant retrieveData(const CscsString &mimetype,
                                      CscsVariant::Type preferredType) const;
private:
    CscsMimeDataPrivate* d_func()const;
    friend class CscsMimeDataPrivate;
};

END_NAMESPACE

#endif