#ifndef SCSCHECKBOX_H
#define SCSCHECKBOX_H
#include "scsabstractbutton.h"

BEGIN_NAMESPACE(Gemini)

class CscsCheckBoxPrivate;

class WIDGET_EXPORT CscsCheckBox : public CscsAbstractButton
{
    
public:
    explicit CscsCheckBox(CscsWidget *parent=0);
    explicit CscsCheckBox(const std::string &text, CscsWidget *parent=0);


    CscsSize sizeHint() const;

    void setTristate(bool y = true);
    bool isTristate() const;

    SCS::CheckState checkState() const;
    void setCheckState(SCS::CheckState state);

SIGNALS:
    void stateChanged(int){}

protected:
    bool hitButton(const CscsPoint &pos) const;
    void checkStateSet();
    void nextCheckState();
    void paintEvent(CscsPaintEvent *);


private:
    CscsCheckBoxPrivate* d_func()const;

BEGIN_PROPERTY(CscsCheckBox,CscsAbstractButton)
    META_PROPERTY(bool, tristate, READ, isTristate, WRITE, setTristate)
END_PROPERTY

};

END_NAMESPACE

#endif