#ifndef SCSSLIDER_H
#define SCSSLIDER_H
#include "scsabstractslider.h"

BEGIN_NAMESPACE(Gemini)

class CscsSliderPrivate;

class WIDGET_EXPORT CscsSlider : public CscsAbstractSlider
{
	friend class CscsSliderPrivate;

public:
    enum TickPosition {
        NoTicks = 0,
        TicksAbove = 1,
        TicksLeft = TicksAbove,
        TicksBelow = 2,
        TicksRight = TicksBelow,
        TicksBothSides = 3
    };

    explicit CscsSlider(CscsWidget *parent = 0);
    explicit CscsSlider(SCS::Orientation orientation, CscsWidget *parent = 0);

    ~CscsSlider();

    CscsSliderPrivate* d_func()const;
    CscsSize sizeHint() const;
    CscsSize minimumSizeHint() const;

    void setTickPosition(TickPosition position);
    TickPosition tickPosition() const;

    void setTickInterval(int ti);
    int tickInterval() const;

    bool event(CscsEvent *event);

protected:
    void paintEvent(CscsPaintEvent *ev);
    void mousePressEvent(CscsMouseEvent *ev);
    void mouseReleaseEvent(CscsMouseEvent *ev);
    void mouseMoveEvent(CscsMouseEvent *ev);

BEGIN_PROPERTY(CscsSlider,CscsAbstractSlider)
    META_PROPERTY(TickPosition, tickPosition, READ, tickPosition, WRITE, setTickPosition)
    META_PROPERTY(int, tickInterval, READ, tickInterval, WRITE, setTickInterval)
END_PROPERTY

};

END_NAMESPACE

#endif