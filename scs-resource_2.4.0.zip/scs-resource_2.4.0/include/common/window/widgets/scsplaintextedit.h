#ifndef SCSPLAINTEXTEDIT_H
#define SCSPLAINTEXTEDIT_H

#include "scsabstractscrollarea.h"
#include <window/text/scstextdocument.h>
#include <window/text/scstextoption.h>
#include <window/text/scstextcursor.h>
#include <window/text/scstextformat.h>
#include <window/text/scsabstracttextdocumentlayout.h>
#include <kernel/scsstring.h>

BEGIN_NAMESPACE(Gemini)

class CscsTextDocument;
class CscsPlainTextEditPrivate;


class WIDGET_EXPORT CscsPlainTextEdit : public CscsAbstractScrollArea
{
    CscsPlainTextEditPrivate* d_func()const;

public:
    enum LineWrapMode {
        NoWrap,
        WidgetWidth
    };

    explicit CscsPlainTextEdit(CscsWidget *parent = 0);
    explicit CscsPlainTextEdit(const std::string &text, CscsWidget *parent = 0);
    virtual ~CscsPlainTextEdit();

    void setDocument(CscsTextDocument *document);
    CscsTextDocument *document() const;

    void setTextCursor(const CscsTextCursor &cursor);
    CscsTextCursor textCursor() const;

    bool isReadOnly() const;
    void setReadOnly(bool ro);

    void setTextInteractionFlags(SCS::TextInteractionFlags flags);
    SCS::TextInteractionFlags textInteractionFlags() const;

    void mergeCurrentCharFormat(const CscsTextCharFormat &modifier);
    void setCurrentCharFormat(const CscsTextCharFormat &format);
    CscsTextCharFormat currentCharFormat() const;

    bool tabChangesFocus() const;
    void setTabChangesFocus(bool b);

    inline void setDocumentTitle(const std::string &title)
    { document()->setMetaInformation(CscsTextDocument::DocumentTitle, CscsString::fromUtf8(title.data())); }
    inline std::string documentTitle() const
    { 
    	CscsString title=document()->metaInformation(CscsTextDocument::DocumentTitle); 
    	if(title.isEmpty()) return std::string();
    	return std::string(title.toUtf8().data());
    }

    inline bool isUndoRedoEnabled() const
    { return document()->isUndoRedoEnabled(); }
    inline void setUndoRedoEnabled(bool enable)
    { document()->setUndoRedoEnabled(enable); }

    inline void setMaximumBlockCount(int maximum)
    { document()->setMaximumBlockCount(maximum); }
    inline int maximumBlockCount() const
    { return document()->maximumBlockCount(); }


    LineWrapMode lineWrapMode() const;
    void setLineWrapMode(LineWrapMode mode);

    CscsTextOption::WrapMode wordWrapMode() const;
    void setWordWrapMode(CscsTextOption::WrapMode policy);

    void setBackgroundVisible(bool visible);
    bool backgroundVisible() const;

    void setCenterOnScroll(bool enabled);
    bool centerOnScroll() const;

    bool find(const std::string &exp, CscsTextDocument::FindFlags options = 0);

    inline std::string toPlainText() const
    { 
    	CscsString text=document()->toPlainText();
    	if(text.isEmpty()) return std::string();
    	return std::string(text.toUtf8().constData());
   	}

    void ensureCursorVisible();

    CscsTextCursor cursorForPosition(const CscsPoint &pos) const;
    CscsRect cursorRect(const CscsTextCursor &cursor) const;
    CscsRect cursorRect() const;

    bool overwriteMode() const;
    void setOverwriteMode(bool overwrite);

    int tabStopWidth() const;
    void setTabStopWidth(int width);

    int cursorWidth() const;
    void setCursorWidth(int width);

    // void setExtraSelections(const CscsList<CscsTextEdit::ExtraSelection> &selections);
    // CscsList<CscsTextEdit::ExtraSelection> extraSelections() const;
    void moveCursor(CscsTextCursor::MoveOperation operation, CscsTextCursor::MoveMode mode = CscsTextCursor::MoveAnchor);
    bool canPaste() const;
    int blockCount() const;

SLOTS:

    void setPlainText(const std::string &text);
    void undo();
    void redo();

    void clear();
    void selectAll();

    void insertPlainText(const std::string &text);

    void appendPlainText(const std::string &text);

    void centerCursor();

SIGNALS:
    void textChanged(){}
    void undoAvailable(bool b){}
    void redoAvailable(bool b){}
    void copyAvailable(bool b){}
    void selectionChanged(){}
    void cursorPositionChanged(){}

    void updateRequest(const CscsRect &rect, int dy){}
    void blockCountChanged(int newBlockCount){}
    void modificationChanged(bool){}

protected:
    virtual bool event(CscsEvent *e);
    virtual void timerEvent(CscsTimerEvent *e);
    virtual void keyPressEvent(CscsKeyEvent *e);
    virtual void keyReleaseEvent(CscsKeyEvent *e);
    virtual void resizeEvent(CscsResizeEvent *e);
    virtual void paintEvent(CscsPaintEvent *e);
    virtual void mousePressEvent(CscsMouseEvent *e);
    virtual void mouseMoveEvent(CscsMouseEvent *e);
    virtual void mouseReleaseEvent(CscsMouseEvent *e);
    virtual void mouseDoubleClickEvent(CscsMouseEvent *e);
    virtual bool focusNextPrevChild(bool next);

    virtual void focusInEvent(CscsFocusEvent *e);
    virtual void focusOutEvent(CscsFocusEvent *e);
    virtual void showEvent(CscsShowEvent *);
    virtual void changeEvent(CscsEvent *e);

    CscsPlainTextEdit(CscsPlainTextEditPrivate* dd, CscsWidget *parent);

    virtual void scrollContentsBy(int dx, int dy);

    CscsTextBlock firstVisibleBlock() const;
    CscsPointF contentOffset() const;
    CscsRectF blockBoundingRect(const CscsTextBlock &block) const;
    CscsRectF blockBoundingGeometry(const CscsTextBlock &block) const;
    CscsAbstractTextDocumentLayout::PaintContext getPaintContext() const;


private:
    friend class CscsPlainTextEditControl;
    friend class CscsPlainTextEditPrivate;
    
    BEGIN_PROPERTY(CscsPlainTextEdit,CscsAbstractScrollArea)
    META_PROPERTY(bool, tabChangesFocus, READ, tabChangesFocus, WRITE, setTabChangesFocus)
    META_PROPERTY(std::string, documentTitle, READ, documentTitle, WRITE, setDocumentTitle)
    META_PROPERTY(bool, undoRedoEnabled, READ, isUndoRedoEnabled, WRITE, setUndoRedoEnabled)
    META_PROPERTY(LineWrapMode, lineWrapMode, READ, lineWrapMode, WRITE, setLineWrapMode)
    META_PROPERTY(CscsTextOption::WrapMode, wordWrapMode, READ, wordWrapMode, WRITE, setWordWrapMode)
    META_PROPERTY(bool, readOnly, READ, isReadOnly, WRITE, setReadOnly)
    META_PROPERTY(std::string, plainText, READ, toPlainText, WRITE, setPlainText)
    META_PROPERTY(bool, overwriteMode, READ, overwriteMode, WRITE, setOverwriteMode)
    META_PROPERTY(int, tabStopWidth, READ, tabStopWidth, WRITE, setTabStopWidth)
    META_PROPERTY(int, cursorWidth, READ, cursorWidth, WRITE, setCursorWidth)
    META_PROPERTY(SCS::TextInteractionFlags, textInteractionFlags, READ ,textInteractionFlags, WRITE, setTextInteractionFlags)
    META_READ_PROPERTY(int, blockCount, READ, blockCount)
    META_PROPERTY(int, maximumBlockCount, READ, maximumBlockCount, WRITE, setMaximumBlockCount)
    META_PROPERTY(bool, backgroundVisible, READ, backgroundVisible, WRITE, setBackgroundVisible)
    META_PROPERTY(bool, centerOnScroll, READ, centerOnScroll, WRITE, setCenterOnScroll)
    END_PROPERTY
};


class CscsPlainTextDocumentLayoutPrivate;
class  CscsPlainTextDocumentLayout : public CscsAbstractTextDocumentLayout
{
    CscsPlainTextDocumentLayoutPrivate* d_func()const;

public:
    CscsPlainTextDocumentLayout(CscsTextDocument *document);
    ~CscsPlainTextDocumentLayout();

    void draw(CscsPainter *, const PaintContext &);
    int hitTest(const CscsPointF &, SCS::HitTestAccuracy ) const;

    int pageCount() const;
    CscsSizeF documentSize() const;

    CscsRectF frameBoundingRect(CscsTextFrame *) const;
    CscsRectF blockBoundingRect(const CscsTextBlock &block) const;

    void ensureBlockLayout(const CscsTextBlock &block) const;

    void setCursorWidth(int width);
    int cursorWidth() const;

    void requestUpdate();

protected:
    void documentChanged(int from, int, int charsAdded);


private:
    void setTextWidth(double newWidth);
    double textWidth() const;
    void layoutBlock(const CscsTextBlock &block);
    double blockWidth(const CscsTextBlock &block);

    CscsPlainTextDocumentLayoutPrivate *priv() const;

    friend class CscsPlainTextEdit;
    friend class CscsPlainTextEditPrivate;

    BEGIN_PROPERTY(CscsPlainTextDocumentLayout, CscsAbstractTextDocumentLayout)
    META_PROPERTY(int, cursorWidth, READ, cursorWidth, WRITE, setCursorWidth);
    END_PROPERTY
};

END_NAMESPACE
#endif