#ifndef SCSWIDGETRESIZEHANDLER_H
#define SCSWIDGETRESIZEHANDLER_H
#include <kernel/scsobject.h>
#include <painting/scspoint.h>
#include <window/scswidget.h>

BEGIN_NAMESPACE(Gemini)

class CscsMouseEvent;
class CscsKeyEvent;

class   CscsWidgetResizeHandler : public CscsObject
{
public:
    enum Action {
        Move        = 0x01,
        Resize        = 0x02,
        Any        = Move|Resize
    };

    explicit CscsWidgetResizeHandler(CscsWidget *parent, CscsWidget *cw = 0);
    void setActive(bool b) { setActive(Any, b); }
    void setActive(Action ac, bool b);
    bool isActive() const { return isActive(Any); }
    bool isActive(Action ac) const;
    void setMovingEnabled(bool b) { movingEnabled = b; }
    bool isMovingEnabled() const { return movingEnabled; }

    bool isButtonDown() const { return buttonDown; }

    void setExtraHeight(int h) { extrahei = h; }
    void setSizeProtection(bool b) { sizeprotect = b; }

    void setFrameWidth(int w) { fw = w; }

    void doResize();
    void doMove();

SIGNALS:
    void activate();

protected:
    bool eventFilter(CscsObject *o, CscsEvent *e);
    void mouseMoveEvent(CscsMouseEvent *e);
    void keyPressEvent(CscsKeyEvent *e);

private:
    enum MousePosition {
        Nowhere,
        TopLeft, BottomRight, BottomLeft, TopRight,
        Top, Bottom, Left, Right,
        Center
    };

    CscsWidget *widget;
    CscsWidget *childWidget;
    CscsPoint moveOffset;
    CscsPoint invertedMoveOffset;
    MousePosition mode;
    int fw;
    int extrahei;
    int range;
    uint buttonDown            :1;
    uint moveResizeMode            :1;
    uint activeForResize    :1;
    uint sizeprotect            :1;
    uint movingEnabled                    :1;
    uint activeForMove            :1;

    void setMouseCursor(MousePosition m);
    bool isMove() const {
        return moveResizeMode && mode == Center;
    }
    bool isResize() const {
        return moveResizeMode && !isMove();
    }
};

END_NAMESPACE

#endif