#ifndef SCSGROUPBOX_H
#define SCSGROUPBOX_H
#include "../scswidget.h"
#include <string>

BEGIN_NAMESPACE(Gemini)

class CscsStyleOptionGroupBox;
class CscsGroupBoxPrivate;
class  WIDGET_EXPORT CscsGroupBox : public CscsWidget
{
    
    CONTAINER_WIDGET
public:
    explicit CscsGroupBox(CscsWidget* parent=0);
    explicit CscsGroupBox(const std::string &title, CscsWidget* parent=0);
    ~CscsGroupBox();

    CscsGroupBoxPrivate* d_func()const;
    std::string title() const;
    void setTitle(const std::string& );

    SCS::Alignment alignment() const;
    void setAlignment(int);

    CscsSize minimumSizeHint() const;

    bool isFlat() const;
    void setFlat(bool b);
    bool isCheckable() const;
    void setCheckable(bool b);
    bool isChecked() const;

SLOTS:
    void setChecked(bool b);

SIGNALS:
    void toggled(bool){}

protected:
    bool event(CscsEvent *);
    void childEvent(CscsChildEvent *);
    void resizeEvent(CscsResizeEvent *);
    void paintEvent(CscsPaintEvent *);
    void focusInEvent(CscsFocusEvent *);
    void changeEvent(CscsEvent *);
    void mousePressEvent(CscsMouseEvent *);
    void mouseMoveEvent(CscsMouseEvent *);
    void mouseReleaseEvent(CscsMouseEvent *);
    void initStyleOption(CscsStyleOptionGroupBox *option) const;
    
friend class CscsGroupBoxPrivate;

BEGIN_PROPERTY(CscsGroupBox,CscsWidget)
    META_PROPERTY(std::string, title, READ, title, WRITE, setTitle)
    META_PROPERTY(SCS::Alignment, alignment, READ, alignment, WRITE, setAlignment)
    META_PROPERTY(bool, flat, READ, isFlat, WRITE, setFlat)
    META_PROPERTY(bool, checkable, READ, isCheckable, WRITE, setCheckable)
    META_PROPERTY(bool, checked, READ, isChecked, WRITE, setChecked)
END_PROPERTY

};

END_NAMESPACE

#endif