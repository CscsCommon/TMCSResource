#ifndef SCSMOVIE_H
#define SCSMOVIE_H
#include <kernel/scsobject.h>
#include <kernel/scsbytearray.h>
#include <kernel/scslist.h>

BEGIN_NAMESPACE(Gemini)
class CscsByteArray;
class CscsRgba;
class CscsDevice;
class CscsImage;
class CscsRect;
class CscsSize;
class CscsMoviePrivate;

class CscsMovie:public CscsObject{
public:
	enum MovieState{
		NotRunning,
		Paused,
		Running
	};

	enum CacheMode{
		CacheNone,
		CacheAll
	};

	CscsMovie(CscsObject* parent=nullptr);
	CscsMovie(CscsDevice* device, const CscsByteArray& format=CscsByteArray(),CscsObject* parent=nullptr);
	CscsMovie(const std::string& fileName, const CscsByteArray& format=CscsByteArray(),CscsObject* parent=nullptr);
	~CscsMovie();
	static CscsList<CscsByteArray> supportFormats();
	void setDevice(CscsDevice* device);
	CscsDevice* device()const;
	void setFileName(const std::string& fileName);
	std::string fileName()const;

	void setFormat(const CscsByteArray& format);
	CscsByteArray format()const;


	MovieState state()const;
	CscsRect frameRect()const;
	CscsImage currentImage()const;

	bool isValid()const;
	bool jumpToFrame(int frameNumber);
	int loopCount()const;
	int frameCount()const;
	int nextFrameDelay()const;
	int currentFrameNumber()const;
	int speed()const;
	CscsSize scaledSize();
	void setScaledSize(const CscsSize& size);

	CacheMode cacheMode()const;
	void setCacheMode(CacheMode mode);

	CscsList<CscsByteArray> supportedFormats();

SIGNALS:
	void started(){}
	void resized(const CscsSize& ){}
	void updated(const CscsRect& ){}
	void stateChanged(CscsMovie::MovieState){}
	void finished(){}
	void frameChanged(int){}

SLOTS:
	void start();
	bool jumpToNextFrame();
	void setPaused(bool paused);
	void stop();
	void setSpeed(int precentSpeed);


private:
	CscsMoviePrivate* d_func()const;	

};

END_NAMESPACE
#endif