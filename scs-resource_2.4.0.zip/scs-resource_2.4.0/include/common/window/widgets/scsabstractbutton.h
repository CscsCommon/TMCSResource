/*
 * Created by J.Wong 2019/04/11
 */
 
#ifndef SCSABSTRACTBUTTON_H
#define SCSABSTRACTBUTTON_H
#include "scsicon.h"
#include "../scswidget.h"

BEGIN_NAMESPACE(Gemini)

class CscsButtonGroup;
class CscsAbstractButtonPrivate;

class  CscsAbstractButton : public CscsWidget
{

public:
    explicit CscsAbstractButton(CscsWidget* parent=0);
    ~CscsAbstractButton();

    void setText(const std::string &text);
    std::string text() const;

	CscsIcon icon() const;
	void setIcon(const CscsIcon &icon);

    CscsSize iconSize() const;

    void setCheckable(bool);
    bool isCheckable() const;

    bool isChecked() const;

    void setDown(bool);
    bool isDown() const;

    void setAutoRepeat(bool);
    bool autoRepeat() const;

	void setAutoRepeatDelay(int);
	int autoRepeatDelay() const;

	void setAutoRepeatInterval(int);
	int autoRepeatInterval() const;

	void setAutoExclusive(bool);
	bool autoExclusive() const;
	
	CscsButtonGroup *group() const;

	virtual void checkStateSet();
	virtual void nextCheckState();

SLOTS:
    void setIconSize(const CscsSize &size);
    void animateClick(int msec = 100);
    void click();
    void toggle();
    void setChecked(bool);

SIGNALS:
    void pressed(){}
    void released(){}
    void clicked(bool checked){}
    void toggled(bool checked){}

protected:
    virtual void paintEvent(CscsPaintEvent *e) = 0;
    virtual bool hitButton(const CscsPoint &pos) const;

    bool event(CscsEvent *e);
    void keyPressEvent(CscsKeyEvent *e);
    void keyReleaseEvent(CscsKeyEvent *e);
    void mousePressEvent(CscsMouseEvent *e);
    void mouseReleaseEvent(CscsMouseEvent *e);
    void mouseMoveEvent(CscsMouseEvent *e);
    void focusInEvent(CscsFocusEvent *e);
    void focusOutEvent(CscsFocusEvent *e);
    void changeEvent(CscsEvent *e);
    void timerEvent(CscsTimerEvent *e);


protected:
    CscsAbstractButton(CscsAbstractButtonPrivate* dd, CscsWidget* parent = 0);

private:
    CscsAbstractButtonPrivate* d_func()const;
    friend class CscsButtonGroup;
    friend class CscsAbstractButtonPrivate;

BEGIN_PROPERTY(CscsAbstractButton, CscsWidget)
    META_PROPERTY(std::string, text, READ, text, WRITE, setText)
    META_PROPERTY(CscsIcon, icon, READ, icon, WRITE, setIcon)
    META_PROPERTY(CscsSize, iconSize, READ, iconSize, WRITE, setIconSize)
    META_PROPERTY(bool, checkable, READ, isCheckable, WRITE, setCheckable)
    META_PROPERTY(bool, checked, READ, isChecked, WRITE, setChecked)
    META_PROPERTY(bool, autoRepeat, READ, autoRepeat, WRITE, setAutoRepeat)
    META_PROPERTY(bool, autoExclusive, READ, autoExclusive, WRITE, setAutoExclusive)
END_PROPERTY

};

END_NAMESPACE

#endif