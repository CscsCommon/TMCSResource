#ifndef SCSSCROLLAREA_H
#define SCSSCROLLAREA_H

#include "scsabstractscrollarea.h"

BEGIN_NAMESPACE(Gemini)

class CscsScrollAreaPrivate;

class WIDGET_EXPORT CscsScrollArea : public CscsAbstractScrollArea
{
    CONTAINER_WIDGET
public:
    explicit CscsScrollArea(CscsWidget* parent=0);
    ~CscsScrollArea();

    CscsWidget *widget() const;
    void setWidget(CscsWidget *w);
    CscsWidget *takeWidget();

    bool widgetResizable() const;
    void setWidgetResizable(bool resizable);

    CscsSize sizeHint() const;
    bool focusNextPrevChild(bool next);

protected:
    bool event(CscsEvent *);
    bool eventFilter(CscsObject *, CscsEvent *);
    void resizeEvent(CscsResizeEvent *);
    void scrollContentsBy(int dx, int dy);
    CscsScrollAreaPrivate *d_func() const;

BEGIN_PROPERTY(CscsScrollArea,CscsAbstractScrollArea)
    META_PROPERTY(bool, widgetResizable, READ, widgetResizable, WRITE, setWidgetResizable)
END_PROPERTY

};

END_NAMESPACE

#endif