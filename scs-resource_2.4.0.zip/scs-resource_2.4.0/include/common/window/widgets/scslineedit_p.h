#ifndef SCSLINEEDITPRIV_H
#define SCSLINEEDITPRIV_H
#include <kernel/scsstring.h>
#include <kernel/scsbasictimer.h>
#include "../styles/scsstyleoption.h"
#include "../scswidget_p.h"
#include "scsvalidator.h"
#include <kernel/scsvector.h>
#include "scslineedit.h"

BEGIN_NAMESPACE(Gemini)

class CscsPainter;

class CscsLineEditPrivate : public CscsWidgetPrivate
{
public:

    CscsLineEditPrivate()
        : cursor(0), cursorTimer(0), frame(1),
          cursorVisible(0), separator(0), readOnly(0),
          dragEnabled(0), contextMenuEnabled(1), alignment(SCS::AlignLeading),
          echoMode(0), textDirty(0), selDirty(0), validInput(1),
          ascent(0), maxLength(32767), hscroll(0), lastCursorPos(-1),validator(0), maskData(0),
          modifiedState(0), undoState(0), selstart(0), selend(0), userInput(false)
        {}
    ~CscsLineEditPrivate()
    {
        delete [] maskData;
    }
   
    CscsLineEdit* mm_func()const;

    void init(const CscsString&);
    void initStyleOption(CscsStyleOptionFrame* opt) const;

    CscsString text;
    CscsString layoutText;
    int cursor;
    int cursorTimer; // -1 for non blinking cursor.
    CscsPoint tripleClick;
    CscsBasicTimer tripleClickTimer;
    uint frame : 1;
    uint cursorVisible : 1;
    uint separator : 1;
    uint readOnly : 1;
    uint dragEnabled : 1;
    uint contextMenuEnabled : 1;
    uint alignment : 8;
    uint echoMode : 2;
    uint textDirty : 1;
    uint selDirty : 1;
    uint validInput : 1;
    int ascent;
    int maxLength;
    int hscroll;
    int lastCursorPos;

    enum { UndoAct, RedoAct, CutAct, CopyAct, PasteAct, ClearAct, SelectAllAct, NCountActs };
    inline void transmitCursorPositionChanged();
    //bool sendMouseEventToInputContext(CscsMouseEvent *e);

    void finishChange(int validateFromState = -1, bool update = false, bool edited = true);

    CscsValidator* validator;
    struct MaskInputData {
        enum Casemode { NoCaseMode, Upper, Lower };
        CscsChar maskChar; // either the separator char or the inputmask
        bool separator;
        Casemode caseMode;
    };
    CscsString inputMask;
    CscsChar blank;
    MaskInputData *maskData;
    inline int nextMaskBlank(int pos) {
        int c = findInMask(pos, true, false);
        separator |= (c != pos);
        return (c != -1 ?  c : maxLength);
    }
    inline int prevMaskBlank(int pos) {
        int c = findInMask(pos, false, false);
        separator |= (c != pos);
        return (c != -1 ? c : 0);
    }

    void setCursorVisible(bool visible);


    // undo/redo handling
    enum CommandType { Separator, Insert, Remove, Delete, RemoveSelection, DeleteSelection };
    struct Command {
        inline Command() {}
        inline Command(CommandType t, int p, CscsChar c) : type(t),uc(c),pos(p) {}
        uint type : 4;
        CscsChar uc;
        int pos;
    };
    int modifiedState;
    int undoState;
    CscsVector<Command> history;
    void addCommand(const Command& cmd);
    void insert(const CscsString& s);
    void del(bool wasBackspace = false);
    void remove(int pos);

    inline void separate() { separator = true; }
    void undo(int until = -1);
    void redo();
    inline bool isUndoAvailable() const { return !readOnly && undoState; }
    inline bool isRedoAvailable() const { return !readOnly && undoState < (int)history.size(); }

    // selection
    int selstart, selend;
    inline bool allSelected() const { return !text.isEmpty() && selstart == 0 && selend == (int)text.length(); }
    inline bool hasSelectedText() const { return !text.isEmpty() && selend > selstart; }
    inline void deselect() { selDirty |= (selend > selstart); selstart = selend = 0; }
    void removeSelectedText();
    inline bool inSelection(int x) const
    { if (selstart >= selend) return false;
    int pos = xToPos(x, CscsLineEdit::CursorOnCharacter);  return pos >= selstart && pos < selend; }

    // masking
    void parseInputMask(const CscsString &maskFields);
    bool isValidInput(CscsChar key, CscsChar mask) const;
    bool hasAcceptableInput(const CscsString &text) const;
    CscsString maskString(uint pos, const CscsString &str, bool clear = false) const;
    CscsString clearString(uint pos, uint len) const;
    CscsString stripString(const CscsString &str) const;
    int findInMask(int pos, bool forward, bool findSeparator, CscsChar searchChar = CscsChar()) const;

    // input methods
    //bool composeMode() const { return !textLayout.preeditAreaText().isEmpty(); }

    // complex text layout
    //CscsTextLayout textLayout;
    void updateTextLayout();
    void moveCursor(int pos, bool mark = false);
    void setText(const CscsString& txt, int pos = -1, bool edited = true);
    int xToPosInternal( int x, CscsLineEdit::CursorPosition ) const;
    int xToPos(int x, CscsLineEdit::CursorPosition = CscsLineEdit::CursorBetweenCharacters) const;
    CscsRect cursorRect() const;

    void clipboardChanged();
    bool userInput;

    int xToCursor(CscsPainter* p,int x, CscsLineEdit::CursorPosition=(CscsLineEdit::CursorBetweenCharacters))const;
    int cursorToX(CscsPainter* p,int cursor, CscsLineEdit::CursorPosition=(CscsLineEdit::CursorBetweenCharacters))const;

    int nextCursorPosition(int oldPos, CscsLineEdit::CursorMode mode=(CscsLineEdit::SkipCharacters))const;
    int previousCursorPosition(int oldPos, CscsLineEdit::CursorMode mode=(CscsLineEdit::SkipCharacters))const;
    bool atWordSeparator(int position) const;
    void drawCursor(CscsPainter* p, const CscsPointF& pos,int cursorPosition);

};

END_NAMESPACE

#endif