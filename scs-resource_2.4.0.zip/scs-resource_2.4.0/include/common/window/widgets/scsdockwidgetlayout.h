#ifndef SCSDOCKWIDGETLAYOUT_H
#define SCSDOCKWIDGETLAYOUT_H
#include "scslayout.h"
#include <kernel/scslist.h>
#include <kernel/file/scstextstream.h>

BEGIN_NAMESPACE(Gemini)

class CscsDockWidget;
class CscsDockWidgetSeparator;

struct CscsDockWidgetLayoutInfo
{
    CscsLayoutItem *item;

    int cur_pos;
    int cur_size;
    int min_size;
    int max_size;

    uint is_sep     : 1;
    uint is_dropped : 1;
    uint reserved   : 13;

    inline CscsDockWidgetLayoutInfo(CscsLayoutItem *i)
	: item(i), cur_pos(-1), cur_size(-1), min_size(1), max_size(-1),
	  is_sep(0), is_dropped(0), reserved(0)
    { }
};

class CscsDockWidgetLayout : public CscsLayout
{
public:
    SCS::DockWidgetArea area;
    SCS::Orientation orientation;
    CscsList<CscsDockWidgetLayoutInfo> layout_info;
    CscsList<CscsDockWidgetLayoutInfo> *save_layout_info;
    mutable CscsSize minSize;
    mutable CscsSize szHint;

    CscsDockWidgetLayout(SCS::DockWidgetArea a, SCS::Orientation o);
    ~CscsDockWidgetLayout();

    enum { // sentinel values used to validate state data
        Marker = 0xfc,
        WidgetMarker = 0xfb
    };
    void saveState(CscsTextStream &stream) const;
    bool restoreState(CscsTextStream &stream);

    // CscsLayout interface
    void addItem(CscsLayoutItem *layoutitem);
    void setGeometry(const CscsRect &rect);
    CscsLayoutItem *itemAt(int index) const;
    CscsLayoutItem *takeAt(int index);
    int count() const;
    CscsSize sizeHint() const;
    CscsSize minimumSize() const;
    void invalidate();
    bool isEmpty() const;

    CscsInternal::RelayoutType relayout_type;
    void relayout(CscsInternal::RelayoutType type = CscsInternal::RelayoutNormal);

    void setOrientation(SCS::Orientation o);
    CscsDockWidgetLayoutInfo &insert(int index, CscsLayoutItem *layoutitem);

    void dump();

    void saveLayoutInfo();
    void resetLayoutInfo();
    void discardLayoutInfo();

    CscsPoint constrain(CscsDockWidgetSeparator *sep, int delta);

    struct Location {
        int index;
        SCS::DockWidgetArea area;
    };
    Location locate(const CscsPoint &mouse) const;
    CscsRect place(CscsDockWidget *dockwidget, const CscsRect &r, const CscsPoint &mouse);
    void drop(CscsDockWidget *dockwidget, const CscsRect &r, const CscsPoint &mouse);

    void extend(CscsDockWidget *dockwidget, SCS::Orientation direction);
    void split(CscsDockWidget *existing, CscsDockWidget *with, SCS::DockWidgetArea area);

SIGNALS:
    void emptied();

SLOTS:
    void maybeDelete();
};

static inline int pick(SCS::Orientation o, const CscsPoint &p)
{ return o == SCS::Horizontal ? p.x() : p.y(); }
static inline int pick(SCS::Orientation o, const CscsSize &s)
{ return o == SCS::Horizontal ? s.width() : s.height(); }
static inline int pick_perp(SCS::Orientation o, const CscsPoint &p)
{ return o == SCS::Vertical ? p.x() : p.y(); }
static inline int pick_perp(SCS::Orientation o, const CscsSize &s)
{ return o == SCS::Vertical ? s.width() : s.height(); }

END_NAMESPACE

#endif