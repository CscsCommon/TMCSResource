#ifndef SCSPROGRESSBAR_H
#define SCSPROGRESSBAR_H

#include "scsframe.h"

BEGIN_NAMESPACE(Gemini)

class CscsProgressBarPrivate;
class CscsStyleOptionProgressBar;

class  WIDGET_EXPORT CscsProgressBar : public CscsWidget
{

public:
    explicit CscsProgressBar(CscsWidget *parent = 0);
     ~CscsProgressBar(){}
    enum Direction { TopToBottom, BottomToTop };

    int minimum() const;
    int maximum() const;

    void setRange(int minimum, int maximum);
    int value() const;

    virtual std::string text() const;
    void setTextVisible(bool visible);
    bool isTextVisible() const;

    SCS::Alignment alignment() const;
    void setAlignment(SCS::Alignment alignment);

    CscsSize sizeHint() const;
    CscsSize minimumSizeHint() const;

    SCS::Orientation orientation() const;

    void setInvertedAppearance(bool invert);
    bool invertedAppearance();
    void setTextDirection(CscsProgressBar::Direction textDirection);
    CscsProgressBar::Direction textDirection();

SLOTS:
    void reset();
    void setMinimum(int minimum);
    void setMaximum(int maximum);
    void setValue(int value);
    void setOrientation(SCS::Orientation);

SIGNALS:
    void valueChanged(int value){}

protected:
    void paintEvent(CscsPaintEvent *);

private:
	CscsProgressBarPrivate* d_func()const;

BEGIN_PROPERTY(CscsProgressBar,CscsWidget)
    META_PROPERTY(int, minimum, READ, minimum, WRITE, setMinimum)
    META_PROPERTY(int, maximum, READ, maximum, WRITE, setMaximum)
    META_READ_PROPERTY(std::string, text, READ, text)
    META_PROPERTY(int, value, READ, value, WRITE, setValue)
    META_PROPERTY(SCS::Alignment, alignment, READ, alignment, WRITE, setAlignment)
    META_PROPERTY(bool, textVisible, READ, isTextVisible, WRITE, setTextVisible)
    META_PROPERTY(Direction, textDirection, READ, textDirection, WRITE, setTextDirection)
    META_PROPERTY(SCS::Orientation, orientation, READ, orientation, WRITE, setOrientation)
    META_PROPERTY(bool, invertedAppearance, READ, invertedAppearance, WRITE, setInvertedAppearance)
END_PROPERTY

};
END_NAMESPACE

#endif