#ifndef SCSTABWIDGET_H
#define SCSTABWIDGET_H
#include <window/scswidget.h>
#include "scsicon.h"

BEGIN_NAMESPACE(Gemini)

class CscsTabBar;
class CscsTabWidgetPrivate;
class WIDGET_EXPORT CscsTabWidget:public CscsWidget{

    CONTAINER_WIDGET
public:
	explicit CscsTabWidget(CscsWidget *parent = 0);
    ~CscsTabWidget();

    int addTab(CscsWidget *widget, const std::string &);
    int addTab(CscsWidget *widget, const CscsIcon& icon, const std::string &label);

    int insertTab(int index, CscsWidget *widget, const std::string &);
    int insertTab(int index, CscsWidget *widget, const CscsIcon& icon, const std::string &label);

    void removeTab(int index);

    bool isTabEnabled(int index) const;
    void setTabEnabled(int index, bool);

    std::string tabText(int index) const;
    void setTabText(int index, const std::string &);

    CscsIcon tabIcon(int index) const;
    void setTabIcon(int index, const CscsIcon & icon);


    int currentIndex() const;
    CscsWidget *currentWidget() const;
    CscsWidget *widget(int index) const;
    int indexOf(CscsWidget *widget) const;
    int count() const;

    enum TabPosition { North, South, West, East
    };

    TabPosition tabPosition() const;
    void setTabPosition(TabPosition);

    enum TabShape { Rounded, Triangular };
    TabShape tabShape() const;
    void setTabShape(TabShape s);

    CscsSize sizeHint() const;
    CscsSize minimumSizeHint() const;

    void setCornerWidget(CscsWidget * w, SCS::Corner corner = SCS::TopRightCorner);
    CscsWidget * cornerWidget(SCS::Corner corner = SCS::TopRightCorner) const;

SLOTS:
    void setCurrentIndex(int index);
    void setCurrentWidget(CscsWidget *widget);

SIGNALS:
    void currentChanged(int index){}

protected:
    virtual void tabInserted(int index);
    virtual void tabRemoved(int index);

    void showEvent(CscsShowEvent *);
    void resizeEvent(CscsResizeEvent *);
    void keyPressEvent(CscsKeyEvent *);
    void paintEvent(CscsPaintEvent *);
    void setTabBar(CscsTabBar *);
    CscsTabBar* tabBar() const;
    void changeEvent(CscsEvent *);

private:
    CscsTabWidgetPrivate* d_func()const;
    void setUpLayout(bool = false);
    friend class CscsTabWidgetPrivate;

BEGIN_PROPERTY(CscsTabWidget,CscsWidget)
    META_PROPERTY(TabPosition, tabPosition, READ, tabPosition, WRITE, setTabPosition)
    META_PROPERTY(TabShape, tabShape, READ, tabShape, WRITE, setTabShape)
    META_PROPERTY(int, currentIndex, READ, currentIndex, WRITE, setCurrentIndex)
    META_READ_PROPERTY(int, count, READ, count)
END_PROPERTY

};

END_NAMESPACE

#endif