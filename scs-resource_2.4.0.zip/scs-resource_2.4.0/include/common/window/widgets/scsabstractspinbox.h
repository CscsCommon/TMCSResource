#ifndef SCSABSTRACTSPINBOX_H
#define SCSABSTRACTSPINBOX_H
#include "../scswidget.h"
#include "scsvalidator.h"

BEGIN_NAMESPACE(Gemini)

class CscsLineEdit;

class CscsAbstractSpinBoxPrivate;
class  CscsAbstractSpinBox : public CscsWidget
{

public:
    explicit CscsAbstractSpinBox(CscsWidget *parent = 0);
    ~CscsAbstractSpinBox();

    enum StepEnabledFlag { StepNone = 0x00, StepUpEnabled = 0x01,
                           StepDownEnabled = 0x02 };
    SCS_DECLARE_FLAGS(StepEnabled, StepEnabledFlag)

    enum ButtonSymbols { NoArrows,UpDownArrows, PlusMinus };

    ButtonSymbols buttonSymbols() const;
    void setButtonSymbols(ButtonSymbols bs);

    std::string text() const;

    std::string specialValueText() const;
    void setSpecialValueText(const std::string &s);

    bool wrapping() const;
    void setWrapping(bool w);

    void setReadOnly(bool r);
    bool isReadOnly() const;

    void setAlignment(SCS::Alignment flag);
    SCS::Alignment alignment() const;

    void setFrame(bool);
    bool hasFrame() const;

    CscsSize sizeHint() const;
    CscsSize minimumSizeHint() const;

    void interpretText();
    bool event(CscsEvent *event);

    virtual CscsValidator::State validate(std::string &input, int &pos) const;
    virtual void fixup(std::string &input) const;

    virtual void stepBy(int steps);
SLOTS:
    void stepUp();
    void stepDown();
    void selectAll();
    virtual void clear();

protected:
    void resizeEvent(CscsResizeEvent *e);
    void keyPressEvent(CscsKeyEvent *e);
    void keyReleaseEvent(CscsKeyEvent *e);
    void focusInEvent(CscsFocusEvent *e);
    void focusOutEvent(CscsFocusEvent *e);
    void changeEvent(CscsEvent *e);
    void closeEvent(CscsCloseEvent *e);
    void hideEvent(CscsHideEvent *e);
    void mousePressEvent(CscsMouseEvent *e);
    void mouseReleaseEvent(CscsMouseEvent *e);
    void mouseMoveEvent(CscsMouseEvent *e);
    void timerEvent(CscsTimerEvent *e);
    void paintEvent(CscsPaintEvent *e);
    void showEvent(CscsShowEvent *e);

    CscsLineEdit *lineEdit() const;
    void setLineEdit(CscsLineEdit *e);

    virtual StepEnabled stepEnabled() const;
SIGNALS:
    void editingFinished(){}
protected:
    CscsAbstractSpinBox(CscsAbstractSpinBoxPrivate* dd, CscsWidget *parent = 0);

private:
    CscsAbstractSpinBoxPrivate* d_func()const;
    friend class CscsAbstractSpinBoxPrivate;

BEGIN_PROPERTY(CscsAbstractSpinBox,CscsWidget)
    META_PROPERTY(bool, wrapping, READ, wrapping, WRITE, setWrapping)
    META_PROPERTY(bool, frame, READ, hasFrame, WRITE, setFrame)
    META_PROPERTY(SCS::Alignment, alignment, READ, alignment, WRITE, setAlignment)
    META_PROPERTY(bool, readOnly, READ, isReadOnly, WRITE, setReadOnly)
    META_PROPERTY(ButtonSymbols, buttonSymbols, READ, buttonSymbols, WRITE, setButtonSymbols)
    META_PROPERTY(std::string, specialValueText, READ, specialValueText, WRITE, setSpecialValueText)
    META_READ_PROPERTY(std::string, text, READ, text)
END_PROPERTY

};
SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsAbstractSpinBox::StepEnabled)

END_NAMESPACE

#endif