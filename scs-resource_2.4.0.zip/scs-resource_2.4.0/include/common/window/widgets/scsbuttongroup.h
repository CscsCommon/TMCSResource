#ifndef SCSBUTTONGROUP_H
#define SCSBUTTONGROUP_H
#include <kernel/scsobject.h>
#include <kernel/scslist.h>

BEGIN_NAMESPACE(Gemini)

class CscsAbstractButton;
class CscsAbstractButtonPrivate;
class CscsButtonGroupPrivate;

class  WIDGET_EXPORT CscsButtonGroup : public CscsObject
{
    
public:
    explicit CscsButtonGroup(CscsObject *parent = 0);
    ~CscsButtonGroup();

    void setExclusive(bool);
    bool exclusive() const;

    void addButton(CscsAbstractButton*);
    void removeButton(CscsAbstractButton*);

    CscsList<CscsAbstractButton*> buttons() const;

    CscsAbstractButton* checkedButton() const;


SIGNALS:
    void buttonClicked(CscsAbstractButton*){}


private:
    CscsButtonGroupPrivate* d_func()const;
    friend class CscsAbstractButton;
    friend class CscsAbstractButtonPrivate;

BEGIN_PROPERTY(CscsButtonGroup, CscsObject)
    META_PROPERTY(bool, exclusive, READ, exclusive, WRITE, setExclusive)
END_PROPERTY

};

END_NAMESPACE

#endif