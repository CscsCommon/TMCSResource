#ifndef SCSDIALOGBUTTONBOX_H
#define SCSDIALOGBUTTONBOX_H
#include "../scswidget.h"
#include <kernel/scsflags.h>

BEGIN_NAMESPACE(Gemini)

class CscsAbstractButton;
class CscsPushButton;
class CscsDialogButtonBoxPrivate;

class WIDGET_EXPORT CscsDialogButtonBox:public CscsWidget{

public:
	enum ButtonRole{
		InvalidRole=-1,
		AcceptRole,
		RejectRole,
		DestructiveRole,
		ActionRole,
		HelpRole,
		YesRole,
		NoRole,
		ResetRole,
		ApplyRole,
		NRoles
	};
	enum StandardButton {
     NoButton           = 0x00000000,
     Ok                 = 0x00000400,
     Save               = 0x00000800,
     SaveAll            = 0x00001000,
     Open               = 0x00002000,
     Yes                = 0x00004000,
     YesToAll           = 0x00008000,
     No                 = 0x00010000,
     NoToAll            = 0x00020000,
     Abort              = 0x00040000,
     Retry              = 0x00080000,
     Ignore             = 0x00100000,
     Close              = 0x00200000,
     Cancel             = 0x00400000,
     Discard            = 0x00800000,
     Help               = 0x01000000,
     Apply              = 0x02000000,
     Reset              = 0x04000000,
     RestoreDefaults    = 0x08000000,
     FirstButton        = Ok,
     LastButton         = RestoreDefaults
    };
    SCS_DECLARE_FLAGS(StandardButtons, StandardButton)

    enum ButtonLayout {
        WinLayout,
        MacLayout,
        KdeLayout,
        GnomeLayout
    };

    CscsDialogButtonBox(CscsWidget *parent = nullptr);
    CscsDialogButtonBox(SCS::Orientation orientation, CscsWidget *parent = nullptr);
    explicit CscsDialogButtonBox(StandardButtons buttons, CscsWidget *parent = nullptr);
    CscsDialogButtonBox(StandardButtons buttons, SCS::Orientation orientation,
                     CscsWidget *parent = nullptr);
    ~CscsDialogButtonBox();

    void setOrientation(SCS::Orientation orientation);
    SCS::Orientation orientation() const;

    void addButton(CscsAbstractButton *button, ButtonRole role);
    CscsPushButton *addButton(const std::string &text, ButtonRole role);
    CscsPushButton *addButton(StandardButton button);
    void removeButton(CscsAbstractButton *button);
    void clear();

    CscsList<CscsAbstractButton *> buttons() const;
    ButtonRole buttonRole(CscsAbstractButton *button) const;

    void setStandardButtons(StandardButtons buttons);
    StandardButtons standardButtons() const;
    StandardButton standardButton(CscsAbstractButton *button) const;
    CscsPushButton *button(StandardButton which) const;

    void setCenterButtons(bool center);
    bool centerButtons() const;

SIGNALS:
    void clicked(CscsAbstractButton *button){}
    void accepted(){}
    void helpRequested(){}
    void rejected(){}

protected:
    void changeEvent(CscsEvent *event) ;
    bool event(CscsEvent *event) ;
private:
	CscsDialogButtonBoxPrivate* d_func()const;
    
BEGIN_PROPERTY(CscsDialogButtonBox,CscsWidget)
    META_PROPERTY(SCS::Orientation, orientation, READ, orientation, WRITE, setOrientation)
    META_PROPERTY(StandardButtons, standardButtons, READ, standardButtons, WRITE, setStandardButtons)
    META_PROPERTY(bool, centerButtons, READ, centerButtons, WRITE, setCenterButtons)
END_PROPERTY

};
SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsDialogButtonBox::StandardButtons)

END_NAMESPACE

#endif