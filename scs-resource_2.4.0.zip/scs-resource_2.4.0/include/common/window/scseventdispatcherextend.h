#ifndef SCSEVENTDISPATCHEREXTEND_H
#define SCSEVENTDISPATCHEREXTEND_H
#include <kernel/scseventdispatcher.h>
#include <list>

BEGIN_NAMESPACE(Gemini)

class CscsEventData;
class CscsEventDispatcherExtend;
class CscsEventDispatcherExtendPrivate:public CscsEventDispatcherPrivate{
public:
	CscsEventDispatcherExtendPrivate(){}
	CscsEventDispatcherExtend* mm_func()const;
	std::list<CscsEventData*> queuedUserEvents;
};


class CscsEventDispatcherExtend:public CscsEventDispatcher{
public:
	CscsEventDispatcherExtend(CscsObject* parent=0);
	~CscsEventDispatcherExtend();

	CscsEventDispatcherExtendPrivate* d_func()const{

		return reinterpret_cast<CscsEventDispatcherExtendPrivate*>(d);
	}

	bool processEvents(CscsEventLoop::EventProcess filter);
	bool hasPendingEvents();
	void flush();

	void startingUp();
	void closingDown();
protected:
	int select(int nfds, fd_set* readfds, fd_set* writefds, fd_set* exceptfds, timeval* timeout);

};

END_NAMESPACE

#endif