#ifndef SCSPLOTMATRIXRASTERDATA_H
#define SCSPLOTMATRIXRASTERDATA_H
#include "scsplotrasterdata.h"
#include <kernel/scsvector.h>
#include <window/scsenum.h>

BEGIN_NAMESPACE(Gemini)

class CscsPlotMatrixRasterData: public CscsPlotRasterData
{
public:
    enum ResampleMode
    {
        NearestNeighbour,
        BilinearInterpolation
    };

    CscsPlotMatrixRasterData();
    virtual ~CscsPlotMatrixRasterData();

    void setResampleMode(ResampleMode mode);
    ResampleMode resampleMode() const;

    virtual void setInterval( SCS::Axis, const CscsPlotInterval & );

    void setValueMatrix( const CscsVector<double> &values, int numColumns );
    const CscsVector<double> valueMatrix() const;

    void setValue( int row, int col, double value );

    int numColumns() const;
    int numRows() const;

    virtual CscsRectF pixelHint( const CscsRectF & ) const;

    virtual double value( double x, double y ) const;

private:
    void update();

    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE

#endif