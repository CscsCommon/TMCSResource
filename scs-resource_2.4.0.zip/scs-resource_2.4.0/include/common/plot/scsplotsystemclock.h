#ifndef SCSPLOTSYSTEMCLOCK_H
#define SCSPLOTSYSTEMCLOCK_H
#include <kernel/scsnamespace.h>

BEGIN_NAMESPACE(Gemini)

class  CscsPlotSystemClock
{
public:
    CscsPlotSystemClock();
    virtual ~CscsPlotSystemClock();

    bool isNull() const;

    void start();
    double restart();
    double elapsed() const;

private:
    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE

#endif