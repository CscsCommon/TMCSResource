#ifndef SCSPLOTABSTRACTSLIDER_H
#define SCSPLOTABSTRACTSLIDER_H
#include "scsplotabstractscale.h"

BEGIN_NAMESPACE(Gemini)

class   CscsPlotAbstractSlider: public CscsPlotAbstractScale
{

public:
    explicit CscsPlotAbstractSlider( CscsWidget *parent = nullptr );
    virtual ~CscsPlotAbstractSlider();

    void setValid( bool );
    bool isValid() const;

    double value() const;

    void setWrapping( bool );
    bool wrapping() const;

    void setTotalSteps( uint );
    uint totalSteps() const;

    void setSingleSteps( uint );
    uint singleSteps() const;

    void setPageSteps( uint );
    uint pageSteps() const;

    void setStepAlignment( bool ); 
    bool stepAlignment() const;

    void setTracking( bool );
    bool isTracking() const;

    void setReadOnly( bool );
    bool isReadOnly() const;

    void setInvertedControls( bool );
    bool invertedControls() const;

SLOTS:
    void setValue(double val );

SIGNALS:
    void valueChanged(double value ){}
    void sliderPressed(){}
    void sliderReleased(){}
    void sliderMoved(double value ){}

protected:
    virtual void mousePressEvent( CscsMouseEvent * );
    virtual void mouseReleaseEvent( CscsMouseEvent * );
    virtual void mouseMoveEvent( CscsMouseEvent * );
    virtual void keyPressEvent( CscsKeyEvent * );

    virtual bool isScrollPosition( const CscsPoint &pos ) const = 0;

    virtual double scrolledTo( const CscsPoint &pos ) const = 0;

    void incrementValue( int numSteps );

    virtual void scaleChange();

protected:
    virtual void sliderChange();

    double incrementedValue( 
        double value, int stepCount ) const;

private:
    double alignedValue( double ) const;
    double boundedValue( double ) const;

    class PrivateData;
    PrivateData *d_data;

BEGIN_PROPERTY(CscsPlotAbstractSlider,CscsPlotAbstractScale)
    META_PROPERTY( double, value, READ, value, WRITE, setValue )
    META_PROPERTY( uint, totalSteps, READ, totalSteps, WRITE, setTotalSteps )
    META_PROPERTY( uint, singleSteps, READ, singleSteps, WRITE, setSingleSteps )
    META_PROPERTY( uint, pageSteps, READ, pageSteps, WRITE, setPageSteps )
    META_PROPERTY( bool, stepAlignment, READ, stepAlignment, WRITE, setStepAlignment )
    META_PROPERTY( bool, readOnly, READ, isReadOnly, WRITE, setReadOnly )
    META_PROPERTY( bool, tracking, READ, isTracking, WRITE, setTracking )
    META_PROPERTY( bool, wrapping, READ, wrapping, WRITE, setWrapping )
    META_PROPERTY( bool, invertedControls, READ, invertedControls, WRITE, setInvertedControls )
END_PROPERTY
};

END_NAMESPACE

#endif