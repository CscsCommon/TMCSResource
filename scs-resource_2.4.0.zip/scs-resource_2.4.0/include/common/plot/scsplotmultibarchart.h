#ifndef SCSPLOTMULTIBARCHART_H
#define SCSPLOTMULTIBARCHART_H

#include "scsplotabstractbarchart.h"
#include "scsplotseriesdata.h"
#include <painting/scsimage.h>

BEGIN_NAMESPACE(Gemini)

class CscsPlotColumnRect;
class CscsPlotColumnSymbol;


class  CscsPlotMultiBarChart:
    public CscsPlotAbstractBarChart, public CscsPlotSeriesStore<CscsPlotSetSample>
{
public:
    enum ChartStyle
    {
        Grouped,
        Stacked
    };

    explicit CscsPlotMultiBarChart( const std::string &title = std::string() );
    explicit CscsPlotMultiBarChart( const CscsPlotText &title );

    virtual ~CscsPlotMultiBarChart();

    virtual int rtti() const;

    void setBarTitles( const CscsList<CscsPlotText> & );
    CscsList<CscsPlotText> barTitles() const;

    void setSamples( const CscsVector<CscsPlotSetSample> & );
    void setSamples( const CscsVector< CscsVector<double> > & );
    void setSamples( CscsPlotSeriesData<CscsPlotSetSample> * );

    void setStyle( ChartStyle style );
    ChartStyle style() const;

    void setSymbol( int valueIndex, CscsPlotColumnSymbol * );
    const CscsPlotColumnSymbol *symbol( int valueIndex ) const;

    void resetSymbolMap();

    virtual void drawSeries( CscsPainter *painter,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect, int from, int to ) const;

    virtual CscsRectF boundingRect() const;

    virtual CscsList<CscsPlotLegendData> legendData() const;

    virtual CscsImage legendIcon( int index, const CscsSizeF& ) const;

protected:
    CscsPlotColumnSymbol *symbol( int valueIndex );

    virtual CscsPlotColumnSymbol *specialSymbol(
        int sampleIndex, int valueIndex ) const;

    virtual void drawSample( CscsPainter *painter,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect, const CscsPlotInterval &boundingInterval,
        int index, const CscsPlotSetSample& sample ) const;

    virtual void drawBar( CscsPainter *, int sampleIndex,
        int valueIndex, const CscsPlotColumnRect & ) const;

    void drawStackedBars( CscsPainter *painter,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect, int index,
        double sampleWidth, const CscsPlotSetSample& sample ) const;

    void drawGroupedBars( CscsPainter *painter,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect, int index,
        double sampleWidth, const CscsPlotSetSample& sample ) const;

private:
    void init();

    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE

#endif