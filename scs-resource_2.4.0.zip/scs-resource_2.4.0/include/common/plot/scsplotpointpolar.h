#ifndef SCSPLOTPOINTPOLAR_H
#define SCSPLOTPOINTPOLAR_H
#include "scsplotmath.h"
#include <painting/scspoint.h>

BEGIN_NAMESPACE(Gemini)

/*!
 * 极坐标点
 */

class  CscsPlotPointPolar
{
public:
    CscsPlotPointPolar();
    CscsPlotPointPolar( double azimuth, double radius );
    CscsPlotPointPolar( const CscsPlotPointPolar & );
    CscsPlotPointPolar( const CscsPointF & );

    void setPoint( const CscsPointF & );
    CscsPointF toPoint() const;

    bool isValid() const;
    bool isNull() const;

    double radius() const;
    double azimuth() const;

    double &rRadius();
    double &rAzimuth();

    void setRadius( double );
    void setAzimuth( double );

    bool operator==( const CscsPlotPointPolar & ) const;
    bool operator!=( const CscsPlotPointPolar & ) const;

    CscsPlotPointPolar normalized() const;

private:
    double d_azimuth;
    double d_radius;
};


inline CscsPlotPointPolar::CscsPlotPointPolar():
    d_azimuth( 0.0 ),
    d_radius( 0.0 )
{
}


inline CscsPlotPointPolar::CscsPlotPointPolar( double azimuth, double radius ):
    d_azimuth( azimuth ),
    d_radius( radius )
{
}


inline CscsPlotPointPolar::CscsPlotPointPolar( const CscsPlotPointPolar &other ):
    d_azimuth( other.d_azimuth ),
    d_radius( other.d_radius )
{
}


inline bool CscsPlotPointPolar::isValid() const
{
    return d_radius >= 0.0;
}


inline bool CscsPlotPointPolar::isNull() const
{
    return d_radius == 0.0;
}


inline double CscsPlotPointPolar::radius() const
{
    return d_radius;
}


inline double CscsPlotPointPolar::azimuth() const
{
    return d_azimuth;
}


inline double &CscsPlotPointPolar::rRadius()
{
    return d_radius;
}


inline double &CscsPlotPointPolar::rAzimuth()
{
    return d_azimuth;
}


inline void CscsPlotPointPolar::setRadius( double radius )
{
    d_radius = radius;
}


inline void CscsPlotPointPolar::setAzimuth( double azimuth )
{
    d_azimuth = azimuth;
}


inline CscsPoint plotPolar2Pos( const CscsPoint &pole,
    double radius, double angle )
{
    const double x = pole.x() + radius * scsCos( angle );
    const double y = pole.y() - radius * scsSin( angle );

    return CscsPoint(scsRound( x ), scsRound( y ));
}

inline CscsPoint plotDegree2Pos( const CscsPoint &pole,
    double radius, double angle )
{
    return plotPolar2Pos( pole, radius, angle / 180.0 * M_PI );
}

inline CscsPointF plotPolar2Pos( const CscsPointF &pole,
    double radius, double angle )
{
    const double x = pole.x() + radius * scsCos( angle );
    const double y = pole.y() - radius * scsSin( angle );

    return CscsPointF( x, y);
}

inline CscsPointF plotDegree2Pos( const CscsPointF &pole,
    double radius, double angle )
{
    return plotPolar2Pos( pole, radius, angle / 180.0 * M_PI );
}

inline CscsPointF plotFastPolar2Pos( const CscsPointF &pole,
    double radius, double angle )
{

    const double x = pole.x() + radius * plotFastCos( angle );
    const double y = pole.y() - radius * plotFastSin( angle );
    return CscsPointF( x, y);
}

inline CscsPointF plotFastDegree2Pos( const CscsPointF &pole,
    double radius, double angle )
{
    return plotFastPolar2Pos( pole, radius, angle / 180.0 * M_PI );
}

inline CscsPlotPointPolar plotFastPos2Polar( const CscsPointF &pos )
{
    return CscsPlotPointPolar( plotFastAtan2( pos.y(), pos.x() ),
        scsSqrt( plotSqr( pos.x() ) + plotSqr( pos.y() ) ) );
}

END_NAMESPACE

#endif