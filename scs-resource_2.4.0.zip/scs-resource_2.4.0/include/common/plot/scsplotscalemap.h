#ifndef SCSPLOTSCALEMAP_H
#define SCSPLOTSCALEMAP_H

#include "scsplottransform.h"
#include <painting/scsrect.h>

BEGIN_NAMESPACE(Gemini)

class  CscsPlotScaleMap
{
public:
    CscsPlotScaleMap();
    CscsPlotScaleMap( const CscsPlotScaleMap& );

    ~CscsPlotScaleMap();

    CscsPlotScaleMap &operator=( const CscsPlotScaleMap & );

    void setTransformation( CscsPlotTransform * );
    const CscsPlotTransform *transformation() const;

    void setPaintInterval( double p1, double p2 );
    void setScaleInterval( double s1, double s2 );

    double transform( double s ) const;
    double invTransform( double p ) const;

    double p1() const;
    double p2() const;

    double s1() const;
    double s2() const;

    double pDist() const;
    double sDist() const;

    static CscsRectF transform( const CscsPlotScaleMap &,
        const CscsPlotScaleMap &, const CscsRectF & );
    static CscsRectF invTransform( const CscsPlotScaleMap &,
        const CscsPlotScaleMap &, const CscsRectF & );

    static CscsPointF transform( const CscsPlotScaleMap &,
        const CscsPlotScaleMap &, const CscsPointF & );
    static CscsPointF invTransform( const CscsPlotScaleMap &,
        const CscsPlotScaleMap &, const CscsPointF & );

    bool isInverting() const;

private:
    void updateFactor();

    double d_s1, d_s2;     // scale interval boundaries
    double d_p1, d_p2;     // paint device interval boundaries

    double d_cnv;       // conversion factor
    double d_ts1;

    CscsPlotTransform *d_transform;
};


inline double CscsPlotScaleMap::s1() const
{
    return d_s1;
}


inline double CscsPlotScaleMap::s2() const
{
    return d_s2;
}


inline double CscsPlotScaleMap::p1() const
{
    return d_p1;
}


inline double CscsPlotScaleMap::p2() const
{
    return d_p2;
}


inline double CscsPlotScaleMap::pDist() const
{
    return scsAbs( d_p2 - d_p1 );
}


inline double CscsPlotScaleMap::sDist() const
{
    return scsAbs( d_s2 - d_s1 );
}


inline double CscsPlotScaleMap::transform( double s ) const
{
    if ( d_transform )
        s = d_transform->transform( s );
    return d_p1 + ( s - d_ts1 ) * d_cnv;
}


inline double CscsPlotScaleMap::invTransform( double p ) const
{
    double s = d_ts1 + ( p - d_p1 ) / d_cnv;
    if ( d_transform )
        s = d_transform->invTransform( s );

    return s;
}

inline bool CscsPlotScaleMap::isInverting() const
{
    return ( ( d_p1 < d_p2 ) != ( d_s1 < d_s2 ) );
}

END_NAMESPACE

#endif