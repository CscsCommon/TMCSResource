#ifndef SCSPLOTDATESCALEENGINE_H
#define SCSPLOTDATESCALEENGINE_H
#include "scsplotdate.h"
#include "scsplotscaleengine.h"

BEGIN_NAMESPACE(Gemini)

class  CscsPlotDateScaleEngine: public CscsPlotLinearScaleEngine
{
	
public:
    CscsPlotDateScaleEngine( CscsDateTime::TimeSpec = CscsDateTime::LocalTime );
    virtual ~CscsPlotDateScaleEngine();

    void setTimeSpec( CscsDateTime::TimeSpec );
    CscsDateTime::TimeSpec timeSpec() const;

    void setUtcOffset( int seconds );
    int utcOffset() const;

    void setWeek0Type( CscsPlotDate::Week0Type );
    CscsPlotDate::Week0Type week0Type() const;
    
    void setMaxWeeks( int );
    int maxWeeks() const;

    virtual void autoScale( int maxNumSteps,
        double &x1, double &x2, double &stepSize ) const;

    virtual CscsPlotScaleDiv divideScale( 
        double x1, double x2,
        int maxMajorSteps, int maxMinorSteps,
        double stepSize = 0.0 ) const;

    virtual CscsPlotDate::IntervalType intervalType( 
        const CscsDateTime &, const CscsDateTime &, int maxSteps ) const;

    CscsDateTime toDateTime( double ) const;

protected:
    virtual CscsDateTime alignDate( const CscsDateTime &, double stepSize,
        CscsPlotDate::IntervalType, bool up ) const;

private:
    CscsPlotScaleDiv buildScaleDiv( const CscsDateTime &, const CscsDateTime &,
        int maxMajorSteps, int maxMinorSteps, 
        CscsPlotDate::IntervalType ) const;

private:
    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE

#endif