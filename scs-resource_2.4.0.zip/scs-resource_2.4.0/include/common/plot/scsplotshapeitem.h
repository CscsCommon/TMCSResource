#ifndef SCSPLOTSHAPEITEM_H
#define SCSPLOTSHAPEITEM_H
#include "scsplotitem.h"
#include <painting/scspath.h>
#include <painting/scspen.h>

BEGIN_NAMESPACE(Gemini)

class  CscsPlotShapeItem: public CscsPlotItem
{
public:
    enum PaintAttribute
    {
        ClipPolygons = 0x01,
    };
    typedef CscsFlags<PaintAttribute> PaintAttributes;
    enum LegendMode
    {
        LegendShape,
        LegendColor
    };

    explicit CscsPlotShapeItem( const std::string &title = std::string() );
    explicit CscsPlotShapeItem( const CscsPlotText &title );

    virtual ~CscsPlotShapeItem();

    void setPaintAttribute( PaintAttribute, bool on = true );
    bool testPaintAttribute( PaintAttribute ) const;

    void setLegendMode( LegendMode );
    LegendMode legendMode() const;

    void setRect( const CscsRectF & );
    void setPolygon( const CscsPolygonF & );

    void setShape( const CscsPath & );
    CscsPath shape() const;

    void setPen( const CscsRgba &, double width = 0.0, CscsPen::PenType = CscsPen::SolidPen );
    void setPen( const CscsPen & );
    CscsPen pen() const;

    void setBrush( const CscsBrush & );
    CscsBrush brush() const;

    void setRenderTolerance( double );
    double renderTolerance() const;

    virtual CscsRectF boundingRect() const;

    virtual void draw( CscsPainter *,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect ) const;

    virtual CscsImage legendIcon( int index, const CscsSizeF & ) const;

    virtual int rtti() const;

private:
    void init();

    class PrivateData;
    PrivateData *d_data;
};
END_NAMESPACE

#endif