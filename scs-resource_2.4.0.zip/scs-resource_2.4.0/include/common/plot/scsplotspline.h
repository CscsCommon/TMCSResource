#ifndef SCSPLOTSPLINE_H
#define SCSPLOTSPLINE_H
#include <painting/scspolygon.h>
#include <kernel/scsvector.h>

BEGIN_NAMESPACE(Gemini)

class  CscsPlotSpline
{
public:
    enum SplineType
    {
        Natural,
        Periodic
    };

    CscsPlotSpline();
    CscsPlotSpline( const CscsPlotSpline & );

    ~CscsPlotSpline();

    CscsPlotSpline &operator=( const CscsPlotSpline & );

    void setSplineType( SplineType );
    SplineType splineType() const;

    bool setPoints( const CscsPolygonF& points );
    CscsPolygonF points() const;

    void reset();

    bool isValid() const;
    double value( double x ) const;

    const CscsVector<double> &coefficientsA() const;
    const CscsVector<double> &coefficientsB() const;
    const CscsVector<double> &coefficientsC() const;

protected:
    bool buildNaturalSpline( const CscsPolygonF & );
    bool buildPeriodicSpline( const CscsPolygonF & );

private:
    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE

#endif