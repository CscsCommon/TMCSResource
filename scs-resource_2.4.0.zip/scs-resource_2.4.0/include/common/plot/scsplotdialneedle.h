#ifndef SCSPLOTDIALNEEDLE_H
#define SCSPLOTDIALNEEDLE_H
#include <window/styles/scspalette.h>

BEGIN_NAMESPACE(Gemini)

class CscsPointF;
class CscsPainter;


class  CscsPlotDialNeedle
{
public:
    CscsPlotDialNeedle();
    virtual ~CscsPlotDialNeedle();

    virtual void setPalette( const CscsPalette & );
    const CscsPalette &palette() const;

    virtual void draw( CscsPainter *painter, const CscsPointF &center,
        double length, double direction, 
        CscsPalette::ColorGroup = CscsPalette::Active ) const;

protected:
    virtual void drawNeedle( CscsPainter *painter, 
        double length, CscsPalette::ColorGroup colorGroup ) const = 0;

    virtual void drawKnob( CscsPainter *, double width, 
        const CscsBrush &, bool sunken ) const;

private:
    CscsPalette d_palette;
};

class  CscsPlotDialSimpleNeedle: public CscsPlotDialNeedle
{
public:
    enum Style
    {
        Arrow,
        Ray
    };

    CscsPlotDialSimpleNeedle( Style, bool hasKnob = true,
        const CscsRgba &mid = CscsRgba(240,240,240,255), const CscsRgba &base = CscsRgba(168,168,168,255));

    void setWidth( double width );
    double width() const;

protected:
    virtual void drawNeedle( CscsPainter *, double length,
        CscsPalette::ColorGroup ) const;

private:
    Style d_style;
    bool d_hasKnob;
    double d_width;
};


class  CscsPlotCompassMagnetNeedle: public CscsPlotDialNeedle
{
public:
    enum Style
    {
        TriangleStyle,
        ThinStyle
    };

    CscsPlotCompassMagnetNeedle( Style = TriangleStyle,
        const CscsRgba &light = CscsRgba(255,255,255,255), const CscsRgba &dark = CscsRgba(255,0,0,255));

protected:
    virtual void drawNeedle( CscsPainter *, 
        double length, CscsPalette::ColorGroup ) const;

private:
    Style d_style;
};



class  CscsPlotCompassWindArrow: public CscsPlotDialNeedle
{
public:
    enum Style
    {
        Style1,
        Style2
    };

    CscsPlotCompassWindArrow( Style, const CscsRgba &light =CscsRgba(255,255,255,255),
        const CscsRgba &dark = CscsRgba(240,240,240,255));

protected:
    virtual void drawNeedle( CscsPainter *, 
        double length, CscsPalette::ColorGroup ) const;

private:
    Style d_style;
};

END_NAMESPACE

#endif