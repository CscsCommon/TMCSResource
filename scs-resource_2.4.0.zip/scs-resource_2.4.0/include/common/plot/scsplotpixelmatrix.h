#ifndef SCSPLOTPIXELMATRIX_H
#define SCSPLOTPIXELMATRIX_H

#include <painting/scsrect.h>
#include <kernel/scsbitarray.h>

BEGIN_NAMESPACE(Gemini)

class  CscsPlotPixelMatrix: public CscsBitArray
{
public:
    CscsPlotPixelMatrix( const CscsRect& rect );
    ~CscsPlotPixelMatrix();

    void setRect( const CscsRect& rect );
    CscsRect rect() const;

    bool testPixel( int x, int y ) const;
    bool testAndSetPixel( int x, int y, bool on );

    int index( int x, int y ) const;

private:
    CscsRect d_rect;
};

inline bool CscsPlotPixelMatrix::testPixel( int x, int y ) const
{
    const int idx = index( x, y );
    return ( idx >= 0 ) ? testBit( idx ) : true;
}

inline bool CscsPlotPixelMatrix::testAndSetPixel( int x, int y, bool on )
{
    const int idx = index( x, y );
    if ( idx < 0 )
        return true;

    const bool onBefore = testBit( idx );
    setBit( idx, on );

    return onBefore;
}

inline int CscsPlotPixelMatrix::index( int x, int y ) const
{
    const int dx = x - d_rect.x();
    if ( dx < 0 || dx >= d_rect.width() )
        return -1;

    const int dy = y - d_rect.y();
    if ( dy < 0 || dy >= d_rect.height() )
        return -1;

    return dy * d_rect.width() + dx;
}

END_NAMESPACE

#endif