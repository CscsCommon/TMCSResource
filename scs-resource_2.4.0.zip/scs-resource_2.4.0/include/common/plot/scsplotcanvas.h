#ifndef SCSPLOTCANVAS_H
#define SCSPLOTCANVAS_H
#include <window/widgets/scsframe.h>
#include <painting/scspath.h>

BEGIN_NAMESPACE(Gemini)

class CscsPlot;
class CscsImage;


class   CscsPlotCanvas : public CscsFrame
{

public:
    enum PaintAttribute
    {

        BackingStore = 1,
        Opaque       = 2,
        HackStyledBackground = 4,
        ImmediatePaint = 8
    };
    typedef CscsFlags<PaintAttribute> PaintAttributes;


    enum FocusIndicator
    {
        NoFocusIndicator,
        CanvasFocusIndicator,
        ItemFocusIndicator
    };

    explicit CscsPlotCanvas( CscsPlot * = nullptr );
    virtual ~CscsPlotCanvas();

    CscsPlot *plot();
    const CscsPlot *plot() const;

    void setFocusIndicator( FocusIndicator );
    FocusIndicator focusIndicator() const;

    void setBorderRadius( double );
    double borderRadius() const;

    void setPaintAttribute( PaintAttribute, bool on = true );
    bool testPaintAttribute( PaintAttribute ) const;

    const CscsImage *backingStore() const;
    void invalidateBackingStore();

    virtual bool event( CscsEvent * );

    CscsPath borderPath( const CscsRect & ) const;

SLOTS:
    void replot();

protected:
    virtual void paintEvent( CscsPaintEvent * );
    virtual void resizeEvent( CscsResizeEvent * );

    virtual void drawFocusIndicator( CscsPainter * );
    virtual void drawBorder( CscsPainter * );

    void updateStyleSheetInfo();

private:
    void drawCanvas( CscsPainter *, bool withBackground );

    class PrivateData;
    PrivateData *d_data;

BEGIN_PROPERTY(CscsPlotCanvas,CscsFrame)
    META_PROPERTY( double, borderRadius, READ, borderRadius, WRITE, setBorderRadius)
END_PROPERTY

};

SCS_DECLARE_OPERATORS_FOR_FLAGS( CscsPlotCanvas::PaintAttributes )

END_NAMESPACE

#endif