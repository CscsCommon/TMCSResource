#ifndef SCSPLOTSCALEENGINE_H
#define SCSPLOTSCALEENGINE_H
#include "scsplotscalediv.h"
#include "scsplotinterval.h"
#include <kernel/scsflags.h>

BEGIN_NAMESPACE(Gemini)

class CscsPlotTransform;

class  CscsPlotScaleArithmetic
{
public:
    static double ceilEps( double value, double intervalSize );
    static double floorEps( double value, double intervalSize );

    static double divideEps( double interval, double steps );

    static double divideInterval( double interval, 
        int numSteps, uint base );
};


class  CscsPlotScaleEngine
{
public:

    enum Attribute
    {
        NoAttribute = 0x00,
        IncludeReference = 0x01,
        Symmetric = 0x02,
        Floating = 0x04,
        Inverted = 0x08
    };
    typedef CscsFlags<Attribute> Attributes;

    explicit CscsPlotScaleEngine( uint base = 10 );
    virtual ~CscsPlotScaleEngine();

    void setBase( uint base );
    uint base() const;

    void setAttribute( Attribute, bool on = true );
    bool testAttribute( Attribute ) const;

    void setAttributes( Attributes );
    Attributes attributes() const;

    void setReference( double reference );
    double reference() const;

    void setMargins( double lower, double upper );
    double lowerMargin() const;
    double upperMargin() const;

    virtual void autoScale( int maxNumSteps,
        double &x1, double &x2, double &stepSize ) const = 0;
    virtual CscsPlotScaleDiv divideScale( double x1, double x2,
        int maxMajorSteps, int maxMinorSteps,
        double stepSize = 0.0 ) const = 0;

    void setTransformation( CscsPlotTransform * );
    CscsPlotTransform *transformation() const;

protected:
    bool contains( const CscsPlotInterval &, double val ) const;
    CscsList<double> strip( const CscsList<double>&, const CscsPlotInterval & ) const;

    double divideInterval( double interval, int numSteps ) const;

    CscsPlotInterval buildInterval( double v ) const;

private:
    class PrivateData;
    PrivateData *d_data;
};

class  CscsPlotLinearScaleEngine: public CscsPlotScaleEngine
{
public:
    CscsPlotLinearScaleEngine( uint base = 10 );
    virtual ~CscsPlotLinearScaleEngine();

    virtual void autoScale( int maxSteps,
        double &x1, double &x2, double &stepSize ) const;

    virtual CscsPlotScaleDiv divideScale( double x1, double x2,
        int numMajorSteps, int numMinorSteps,
                                     double stepSize = 0.0 ) const;


protected:
    CscsPlotInterval align( const CscsPlotInterval&, double stepSize ) const;

    void buildTicks(
        const CscsPlotInterval &, double stepSize, int maxMinSteps,
        CscsList<double> ticks[CscsPlotScaleDiv::NTickTypes] ) const;

    CscsList<double> buildMajorTicks(
        const CscsPlotInterval &interval, double stepSize ) const;

    void buildMinorTicks( const CscsList<double>& majorTicks,
        int maxMinorSteps, double stepSize,
        CscsList<double> &minorTicks, CscsList<double> &mediumTicks ) const;
};


class  CscsPlotLogScaleEngine: public CscsPlotScaleEngine
{
public:
    CscsPlotLogScaleEngine( uint base = 10 );
    virtual ~CscsPlotLogScaleEngine();

    virtual void autoScale( int maxSteps,
        double &x1, double &x2, double &stepSize ) const;

    virtual CscsPlotScaleDiv divideScale( double x1, double x2,
        int numMajorSteps, int numMinorSteps,
        double stepSize = 0.0 ) const;

protected:
    CscsPlotInterval align( const CscsPlotInterval&, double stepSize ) const;

    void buildTicks(
        const CscsPlotInterval &, double stepSize, int maxMinSteps,
        CscsList<double> ticks[CscsPlotScaleDiv::NTickTypes] ) const;

    CscsList<double> buildMajorTicks(
        const CscsPlotInterval &interval, double stepSize ) const;

    void buildMinorTicks( const CscsList<double>& majorTicks,
        int maxMinorSteps, double stepSize,
        CscsList<double> &minorTicks, CscsList<double> &mediumTicks ) const;
};

SCS_DECLARE_OPERATORS_FOR_FLAGS( CscsPlotScaleEngine::Attributes)

END_NAMESPACE


#endif