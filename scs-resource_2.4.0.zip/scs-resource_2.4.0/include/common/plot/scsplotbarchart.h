#ifndef SCSPLOTBARCHART_H
#define SCSPLOTBARCHART_H
#include "scsplotabstractbarchart.h"
#include "scsplotseriesdata.h"
#include <painting/scsimage.h>

BEGIN_NAMESPACE(Gemini)

class CscsPlotColumnRect;
class CscsPlotColumnSymbol;

class  CscsPlotBarChart:public CscsPlotAbstractBarChart,
					   public CscsPlotSeriesStore<CscsPointF>
{
public:
    enum LegendMode
    {
        LegendChartTitle,
        LegendBarTitles
    };

    explicit CscsPlotBarChart( const std::string &title = std::string() );
    explicit CscsPlotBarChart( const CscsPlotText &title );

    virtual ~CscsPlotBarChart();

    virtual int rtti() const;

    void setSamples( const CscsVector<CscsPointF> & );
    void setSamples( const CscsVector<double> & );
    void setSamples( CscsPlotSeriesData<CscsPointF> * );

    void setSymbol( CscsPlotColumnSymbol * );
    const CscsPlotColumnSymbol *symbol() const;

    void setLegendMode( LegendMode );
    LegendMode legendMode() const;

    virtual void drawSeries( CscsPainter *painter,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect, int from, int to ) const;

    virtual CscsRectF boundingRect() const;

    virtual CscsPlotColumnSymbol *specialSymbol(
        int sampleIndex, const CscsPointF& ) const;

    virtual CscsPlotText barTitle( int sampleIndex ) const;

protected:
    virtual void drawSample( CscsPainter *painter,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect, const CscsPlotInterval &boundingInterval,
        int index, const CscsPointF& sample ) const;

    virtual void drawBar( CscsPainter *,
        int sampleIndex, const CscsPointF& sample,
        const CscsPlotColumnRect & ) const;

    CscsList<CscsPlotLegendData> legendData() const;
    CscsImage legendIcon( int index, const CscsSizeF & ) const;

private:
    void init();

    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE

#endif