#ifndef SCSPLOTMATH_H
#define SCSPLOTMATH_H

#include <painting/scsmath.h>
#include <limits>
#include <assert.h>

BEGIN_NAMESPACE(Gemini)

#ifndef M_PI_2
#define M_PI_2 (1.57079632679489661923)
#endif

#ifndef LOG_MIN
#define LOG_MIN 1.0e-100
#endif

#ifndef LOG_MAX
#define LOG_MAX 1.0e100
#endif

inline double plotQNan()
{
    assert(std::numeric_limits<double>::has_quiet_NaN);
    return std::numeric_limits<double>::quiet_NaN();
}

double plotGetMin( const double *array, int size );
double plotGetMax( const double *array, int size );

double plotNormalizeRadians( double radians );
double plotNormalizeDegrees( double degrees );

inline int plotFuzzyCompare( double value1, double value2, double intervalSize )
{
    const double eps = scsAbs( 1.0e-6 * intervalSize );

    if ( value2 - value1 > eps )
        return -1;

    if ( value1 - value2 > eps )
        return 1;

    return 0;
}


inline bool plotFuzzyGreaterOrEqual( double d1, double d2 )
{
    return ( d1 >= d2 ) || scsFuzzyCompare( d1, d2 );
}

inline bool plotFuzzyLessOrEqual( double d1, double d2 )
{
    return ( d1 <= d2 ) || scsFuzzyCompare( d1, d2 );
}

//! Return the sign
inline int plotSign( double x )
{
    if ( x > 0.0 )
        return 1;
    else if ( x < 0.0 )
        return ( -1 );
    else
        return 0;
}

//! Return the square of a number
inline double plotSqr( double x )
{
    return x * x;
}

//! Approximation of arc tangent ( error below 0,005 radians )
inline double plotFastAtan( double x )
{
    if ( x < -1.0 )
        return -M_PI_2 - x / ( x * x + 0.28 );

    if ( x > 1.0 )
        return M_PI_2 - x / ( x * x + 0.28 );

    return x / ( 1.0 + x * x * 0.28 );
}

//! Approximation of arc tangent ( error below 0,005 radians )
inline double plotFastAtan2( double y, double x )
{
    if ( x > 0 )
        return plotFastAtan( y / x );

    if ( x < 0 )
    {
        const double d = plotFastAtan( y / x );
        return ( y >= 0 ) ? d + M_PI : d - M_PI;
    }

    if ( y < 0.0 )
        return -M_PI_2;

    if ( y > 0.0 )
        return M_PI_2;

    return 0.0;
}

//! Translate degrees into radians
inline double plotRadians( double degrees )
{
    return degrees * M_PI / 180.0;
}

//! Translate radians into degrees
inline double plotDegrees( double degrees )
{
    return degrees * 180.0 / M_PI;
}

#define SCS_SINE_TABLE_SIZE 256
extern const double scs_sine_table[SCS_SINE_TABLE_SIZE];

inline double plotFastSin(double x)
{
    int si = int(x * (0.5 * SCS_SINE_TABLE_SIZE / M_PI)); // Would be more accurate with qRound, but slower.
    double d = x - si * (2.0 * M_PI / SCS_SINE_TABLE_SIZE);
    int ci = si + SCS_SINE_TABLE_SIZE / 4;
    si &= SCS_SINE_TABLE_SIZE - 1;
    ci &= SCS_SINE_TABLE_SIZE - 1;
    return scs_sine_table[si] + (scs_sine_table[ci] - 0.5 * scs_sine_table[si] * d) * d;
}

inline double plotFastCos(double x)
{
    int ci = int(x * (0.5 * SCS_SINE_TABLE_SIZE / M_PI)); // Would be more accurate with qRound, but slower.
    double d = x - ci * (2.0 * M_PI / SCS_SINE_TABLE_SIZE);
    int si = ci + SCS_SINE_TABLE_SIZE / 4;
    si &= SCS_SINE_TABLE_SIZE - 1;
    ci &= SCS_SINE_TABLE_SIZE - 1;
    return scs_sine_table[si] - (scs_sine_table[ci] + 0.5 * scs_sine_table[si] * d) * d;
}

END_NAMESPACE
#endif