#ifndef SCSPLOTWIDGETOVERLAY_H
#define SCSPLOTWIDGETOVERLAY_H
#include <window/scswidget.h>
#include <painting/scsregion.h>

BEGIN_NAMESPACE(Gemini)

class CscsPainter;

class  CscsPlotWidgetOverlay: public CscsWidget
{
public:

    enum MaskMode
    {
        NoMask,
        MaskHint,
        AlphaMask
    };

    enum RenderMode
    {
        AutoRenderMode,
        CopyAlphaMask,
        DrawOverlay
    };

    CscsPlotWidgetOverlay( CscsWidget* );
    virtual ~CscsPlotWidgetOverlay();

    void setMaskMode( MaskMode );
    MaskMode maskMode() const;

    void setRenderMode( RenderMode );
    RenderMode renderMode() const;

    void updateOverlay();

    virtual bool eventFilter( CscsObject *, CscsEvent *);

protected:
    virtual void paintEvent( CscsPaintEvent* event );
    virtual void resizeEvent( CscsResizeEvent* event );

    virtual CscsRegion maskHint() const;
    virtual void drawOverlay( CscsPainter *painter ) const = 0;

private:
    void updateMask();
    void draw( CscsPainter * ) const;

private:
    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE

#endif