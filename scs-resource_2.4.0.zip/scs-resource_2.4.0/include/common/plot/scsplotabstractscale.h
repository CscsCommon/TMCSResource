#ifndef SCSPLOTABSTRACTSCALE_H
#define SCSPLOTABSTRACTSCALE_H
#include <window/scswidget.h>

BEGIN_NAMESPACE(Gemini)

class CscsPlotScaleEngine;
class CscsPlotAbstractScaleDraw;
class CscsPlotScaleDiv;
class CscsPlotScaleMap;
class CscsPlotInterval;

class   CscsPlotAbstractScale: public CscsWidget
{

public:
    CscsPlotAbstractScale( CscsWidget *parent = nullptr );
    virtual ~CscsPlotAbstractScale();

    void setScale( double lowerBound, double upperBound );
    void setScale( const CscsPlotInterval & );
    void setScale( const CscsPlotScaleDiv & );

    const CscsPlotScaleDiv& scaleDiv() const;

    void setLowerBound( double value );
    double lowerBound() const;

    void setUpperBound( double value );
    double upperBound() const;

    void setScaleStepSize( double stepSize );
    double scaleStepSize() const;

    void setScaleMaxMajor( int ticks );
    int scaleMaxMinor() const;

    void setScaleMaxMinor( int ticks );
    int scaleMaxMajor() const;

    void setScaleEngine( CscsPlotScaleEngine * );
    const CscsPlotScaleEngine *scaleEngine() const;
    CscsPlotScaleEngine *scaleEngine();

    int transform( double ) const;
    double invTransform( int ) const;

    bool isInverted() const;

    double minimum() const;
    double maximum() const;

    const CscsPlotScaleMap &scaleMap() const;

protected:
    void rescale( double lowerBound, 
        double upperBound, double stepSize );

    void setAbstractScaleDraw( CscsPlotAbstractScaleDraw * );

    const CscsPlotAbstractScaleDraw *abstractScaleDraw() const;
    CscsPlotAbstractScaleDraw *abstractScaleDraw();

    virtual void scaleChange();

private:
    void updateScaleDraw();

    class PrivateData;
    PrivateData *d_data;

BEGIN_PROPERTY(CscsPlotAbstractScale,CscsWidget)
    META_PROPERTY( double, lowerBound, READ, lowerBound, WRITE, setLowerBound )
    META_PROPERTY( double, upperBound, READ, upperBound, WRITE, setUpperBound )
    META_PROPERTY( int, scaleMaxMajor, READ, scaleMaxMajor, WRITE, setScaleMaxMajor )
    META_PROPERTY( int, scaleMaxMinor, READ, scaleMaxMinor, WRITE, setScaleMaxMinor )
    META_PROPERTY( double, scaleStepSize, READ, scaleStepSize, WRITE, setScaleStepSize )
END_PROPERTY

};

END_NAMESPACE

#endif