#ifndef SCSPLOTEVENTPATTERN_H
#define SCSPLOTEVENTPATTERN_H
#include <kernel/scsvector.h>
#include <window/scswindowevent.h>

BEGIN_NAMESPACE(Gemini)

class  CscsPlotEventPattern
{
public:
    enum MousePatternCode
    {
        MouseSelect1,
        MouseSelect2,
        MouseSelect3,
        MouseSelect4,
        MouseSelect5,
        MouseSelect6,
        MousePatternCount
    };

    enum KeyPatternCode
    {
        KeySelect1,
        KeySelect2,
        KeyAbort,
        KeyLeft,
        KeyRight,
        KeyUp,
        KeyDown,
        KeyRedo,
        KeyUndo,
        KeyHome,
        KeyPatternCount
    };
    class MousePattern
    {
    public:
        MousePattern( SCS::MouseButton btn = SCS::NoButton, 
                SCS::KeyboardModifiers modifierCodes = SCS::NoModifier ):
            button( btn ),
            modifiers( modifierCodes )
        {
        }

        SCS::MouseButton button;
        SCS::KeyboardModifiers modifiers;
    };

    class KeyPattern
    {
    public:
        KeyPattern( int keyCode = SCS::Key_unknown, 
                SCS::KeyboardModifiers modifierCodes = SCS::NoModifier ):
            key( keyCode ),
            modifiers( modifierCodes )
        {
        }

        int key;
        SCS::KeyboardModifiers modifiers;
    };

    CscsPlotEventPattern();
    virtual ~CscsPlotEventPattern();

    void initMousePattern( int numButtons );
    void initKeyPattern();

    void setMousePattern( MousePatternCode, SCS::MouseButton button, 
        SCS::KeyboardModifiers = SCS::NoModifier );

    void setKeyPattern( KeyPatternCode, int keyCode, 
        SCS::KeyboardModifiers modifierCodes = SCS::NoModifier );

    void setMousePattern( const CscsVector<MousePattern> & );
    void setKeyPattern( const CscsVector<KeyPattern> & );

    const CscsVector<MousePattern> &mousePattern() const;
    const CscsVector<KeyPattern> &keyPattern() const;

    CscsVector<MousePattern> &mousePattern();
    CscsVector<KeyPattern> &keyPattern();

    bool mouseMatch( MousePatternCode, const CscsMouseEvent * ) const;
    bool keyMatch( KeyPatternCode, const CscsKeyEvent * ) const;

protected:
    virtual bool mouseMatch( const MousePattern &, const CscsMouseEvent * ) const;
    virtual bool keyMatch( const KeyPattern &, const CscsKeyEvent * ) const;

private:
    CscsVector<MousePattern> d_mousePattern;
    CscsVector<KeyPattern> d_keyPattern;
};

//! Compare operator
inline bool operator==( CscsPlotEventPattern::MousePattern b1,
    CscsPlotEventPattern::MousePattern  b2 )
{
    return b1.button == b2.button && b1.modifiers == b2.modifiers;
}

//! Compare operator
inline bool operator==( CscsPlotEventPattern::KeyPattern b1,
   CscsPlotEventPattern::KeyPattern  b2 )
{
    return b1.key == b2.key && b1.modifiers == b2.modifiers;
}

END_NAMESPACE
#endif