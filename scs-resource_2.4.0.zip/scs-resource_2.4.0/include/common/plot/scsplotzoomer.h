#ifndef SCSPLOTZOOMER_H
#define SCSPLOTZOOMER_H
#include "scsplotpicker.h"
#include <kernel/scsstack.h>

BEGIN_NAMESPACE(Gemini)

class  CscsPlotZoomer: public CscsPlotPicker
{
    
public:
    explicit CscsPlotZoomer( CscsWidget *, bool doReplot = true );
    explicit CscsPlotZoomer( int xAxis, int yAxis,
                            CscsWidget *, bool doReplot = true );

    virtual ~CscsPlotZoomer();

    virtual void setZoomBase( bool doReplot = true );
    virtual void setZoomBase( const CscsRectF & );

    CscsRectF zoomBase() const;
    CscsRectF zoomRect() const;

    virtual void setAxis( int xAxis, int yAxis );

    void setMaxStackDepth( int );
    int maxStackDepth() const;

    const CscsStack<CscsRectF> &zoomStack() const;
    void setZoomStack( const CscsStack<CscsRectF> &,
        int zoomRectIndex = -1 );

    uint zoomRectIndex() const;

SLOTS:
    void moveBy( double dx, double dy );
    virtual void moveTo( const CscsPointF & );

    virtual void zoom( const CscsRectF & );
    virtual void zoom( int offset );

SIGNALS:
    void zoomed( const CscsRectF &rect ){}

protected:
    virtual void rescale();

    virtual CscsSizeF minZoomSize() const;

    virtual void widgetMouseReleaseEvent( CscsMouseEvent * );
    virtual void widgetKeyPressEvent( CscsKeyEvent * );

    virtual void begin();
    virtual bool end( bool ok = true );
    virtual bool accept( CscsPolygon & ) const;

private:
    void init( bool doReplot );

    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE

#endif