#ifndef SCSPLOTTEXTLABEL_H
#define SCSPLOTTEXTLABEL_H
#include "scsplottext.h"
#include <window/widgets/scsframe.h>
#include <string>

BEGIN_NAMESPACE(Gemini)

class CscsPaintEvent;
class CscsPainter;

class  WIDGET_EXPORT CscsPlotTextLabel : public CscsFrame
{

public:
    explicit CscsPlotTextLabel( CscsWidget *parent = NULL );
    explicit CscsPlotTextLabel( const CscsPlotText&, CscsWidget *parent = NULL );
    virtual ~CscsPlotTextLabel();

    void setPlainText( const std::string& );
    std::string plainText() const;

SLOTS:
    void setText( const std::string &,
        CscsPlotText::TextFormat textFormat = CscsPlotText::AutoText );
    virtual void setText( const CscsPlotText & );

    void clear();

public:
    const CscsPlotText &text() const;

    int indent() const;
    void setIndent( int );

    int margin() const;
    void setMargin( int );

    virtual CscsSize sizeHint() const;
    virtual CscsSize minimumSizeHint() const;
    virtual int heightForWidth( int ) const;

    CscsRect textRect() const;

    virtual void drawText( CscsPainter *, const CscsRectF & );

protected:
    virtual void paintEvent( CscsPaintEvent *e );
    virtual void drawContents( CscsPainter * );

private:
    void init();
    int defaultIndent() const;

    class PrivateData;
    PrivateData *d_data;

BEGIN_PROPERTY(CscsPlotTextLabel, CscsFrame)
    META_PROPERTY( int, indent, READ, indent, WRITE, setIndent )
    META_PROPERTY( int, margin, READ, margin, WRITE, setMargin )
    META_PROPERTY( std::string, plainText, READ, plainText, WRITE, setPlainText)
END_PROPERTY

};
END_NAMESPACE

#endif