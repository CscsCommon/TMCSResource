#ifndef SCSPLOTPICKERMACHINE_H
#define SCSPLOTPICKERMACHINE_H
#include <kernel/scslist.h>

BEGIN_NAMESPACE(Gemini)

class CscsEvent;
class CscsPlotEventPattern;

class  CscsPlotPickerMachine
{
public:
    enum SelectionType
    {
        NoSelection = -1,
        PointSelection,
        RectSelection,
        PolygonSelection
    };

    //! Commands - the output of a state machine
    enum Command
    {
        Begin,
        Append,
        Move,
        Remove,
        End
    };

    CscsPlotPickerMachine( SelectionType );
    virtual ~CscsPlotPickerMachine();

    virtual CscsList<Command> transition(
        const CscsPlotEventPattern &, const CscsEvent * ) = 0;
    void reset();

    int state() const;
    void setState( int );

    SelectionType selectionType() const;

private:
    const SelectionType d_selectionType;
    int d_state;
};


class  CscsPlotPickerTrackerMachine: public CscsPlotPickerMachine
{
public:
    CscsPlotPickerTrackerMachine();

    virtual CscsList<Command> transition(
        const CscsPlotEventPattern &, const CscsEvent * );
};


class  CscsPlotPickerClickPointMachine: public CscsPlotPickerMachine
{
public:
    CscsPlotPickerClickPointMachine();

    virtual CscsList<Command> transition(
        const CscsPlotEventPattern &, const CscsEvent * );
};

class  CscsPlotPickerDragPointMachine: public CscsPlotPickerMachine
{
public:
    CscsPlotPickerDragPointMachine();

    virtual CscsList<Command> transition(
        const CscsPlotEventPattern &, const CscsEvent * );
};


class  CscsPlotPickerClickRectMachine: public CscsPlotPickerMachine
{
public:
    CscsPlotPickerClickRectMachine();

    virtual CscsList<Command> transition(
        const CscsPlotEventPattern &, const CscsEvent * );
};


class  CscsPlotPickerDragRectMachine: public CscsPlotPickerMachine
{
public:
    CscsPlotPickerDragRectMachine();

    virtual CscsList<Command> transition(
        const CscsPlotEventPattern &, const CscsEvent * );
};
             
                    
class  CscsPlotPickerDragLineMachine: public CscsPlotPickerMachine
{
public:
    CscsPlotPickerDragLineMachine();

    virtual CscsList<Command> transition(
        const CscsPlotEventPattern &, const CscsEvent * );
};


class  CscsPlotPickerPolygonMachine: public CscsPlotPickerMachine
{
public:
    CscsPlotPickerPolygonMachine();

    virtual CscsList<Command> transition(
        const CscsPlotEventPattern &, const CscsEvent * );
};

END_NAMESPACE

#endif