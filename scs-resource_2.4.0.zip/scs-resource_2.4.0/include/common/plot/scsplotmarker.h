#ifndef SCSPLOTMARKER_H
#define SCSPLOTMARKER_H
#include <painting/scspen.h>
#include <painting/scsfont.h>
#include <painting/scsbrush.h>
#include <painting/scsimage.h>
#include <window/scsenum.h>
#include "scsplotitem.h"
#include "scsplotsymbol.h"

BEGIN_NAMESPACE(Gemini)

class CscsRectF;
class CscsPlotText;

class  CscsPlotMarker: public CscsPlotItem
{
public:
    enum LineStyle
    {
        NoLine,
        HLine,
        VLine,
        Cross
    };

    explicit CscsPlotMarker( const std::string &title = std::string() );
    explicit CscsPlotMarker( const CscsPlotText &title );

    virtual ~CscsPlotMarker();

    virtual int rtti() const;

    double xValue() const;
    double yValue() const;
    CscsPointF value() const;

    void setXValue( double );
    void setYValue( double );
    void setValue( double, double );
    void setValue( const CscsPointF & );

    void setLineStyle( LineStyle );
    LineStyle lineStyle() const;

    void setLinePen( const CscsRgba &, double width = 0.0, CscsPen::PenType = CscsPen::SolidPen );
    void setLinePen( const CscsPen & );
    const CscsPen &linePen() const;

    void setSymbol( const CscsPlotSymbol * );
    const CscsPlotSymbol *symbol() const;

    void setLabel( const CscsPlotText& );
    CscsPlotText label() const;

    void setLabelAlignment( SCS::Alignment );
    SCS::Alignment labelAlignment() const;

    void setLabelOrientation( SCS::Orientation );
    SCS::Orientation labelOrientation() const;

    void setSpacing( int );
    int spacing() const;

    virtual void draw( CscsPainter *,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF & ) const;

    virtual CscsRectF boundingRect() const;

    virtual CscsImage legendIcon( int index, const CscsSizeF & ) const;

protected:
    virtual void drawLines( CscsPainter *,
        const CscsRectF &, const CscsPointF & ) const;

    virtual void drawLabel( CscsPainter *,
        const CscsRectF &, const CscsPointF & ) const;

private:

    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE
#endif