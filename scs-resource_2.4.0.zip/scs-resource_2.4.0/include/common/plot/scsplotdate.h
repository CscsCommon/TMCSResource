#ifndef SCSPLOTDATE_H
#define SCSPLOTDATE_H
#include <kernel/scstime.h>
#include <kernel/scsstring.h>

BEGIN_NAMESPACE(Gemini)

class  CscsPlotDate
{
public:

    enum Week0Type
    {
        FirstThursday,
        FirstDay
    };

    enum IntervalType
    {
        Millisecond,
        Second,
        Minute,
        Hour,
        Day,
        Week,
        Month,
        Year
    };

    enum
    {
        //! The Julian day of "The Epoch"
        JulianDayForEpoch = 2440588
    };

    static CscsDate minDate();
    static CscsDate maxDate();

    static CscsDateTime toDateTime( double value, 
        CscsDateTime::TimeSpec = CscsDateTime::UTC );

    static double toDouble( const CscsDateTime & );

    static CscsDateTime ceil( const CscsDateTime &, IntervalType );
    static CscsDateTime floor( const CscsDateTime &, IntervalType );

    static CscsDate dateOfWeek0( int year, Week0Type );
    static int weekNumber( const CscsDate &, Week0Type );

    static int utcOffset( const CscsDateTime & );

    static CscsString toString( const CscsDateTime &, 
        const CscsString & format, Week0Type );
};

END_NAMESPACE

#endif