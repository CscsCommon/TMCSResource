#ifndef SCSPLOTDIAL_H
#define SCSPLOTDIAL_H
#include "scsplotabstractslider.h"
#include "scsplotabstractscaledraw.h"
#include <window/widgets/scsframe.h>
#include <window/styles/scspalette.h>

BEGIN_NAMESPACE(Gemini)

class CscsPlotDialNeedle;
class CscsPlotRoundScaleDraw;

class  WIDGET_EXPORT CscsPlotDial: public CscsPlotAbstractSlider
{

public:
    enum Shadow
    {
        Plain = CscsFrame::Plain,
        Raised = CscsFrame::Raised,
        Sunken = CscsFrame::Sunken
    };

    enum Mode
    {
        RotateNeedle,
        RotateScale
    };

    explicit CscsPlotDial( CscsWidget *parent = nullptr );
    virtual ~CscsPlotDial();

    void setFrameShadow( Shadow );
    Shadow frameShadow() const;

    void setLineWidth( int );
    int lineWidth() const;

    void setMode( Mode );
    Mode mode() const;

    void setScaleArc( double min, double max );

    void setMinScaleArc( double min );
    double minScaleArc() const;

    void setMaxScaleArc( double min );
    double maxScaleArc() const;

    virtual void setOrigin( double );
    double origin() const;

    void setNeedle( CscsPlotDialNeedle * );
    const CscsPlotDialNeedle *needle() const;
    CscsPlotDialNeedle *needle();

    CscsRect boundingRect() const;
    CscsRect innerRect() const;

    virtual CscsRect scaleInnerRect() const;

    virtual CscsSize sizeHint() const;
    virtual CscsSize minimumSizeHint() const;

    void setScaleDraw( CscsPlotRoundScaleDraw * );

    CscsPlotRoundScaleDraw *scaleDraw();
    const CscsPlotRoundScaleDraw *scaleDraw() const;

protected:
    virtual void paintEvent( CscsPaintEvent * );
    virtual void changeEvent( CscsEvent * );

    virtual void drawFrame( CscsPainter *p );
    virtual void drawContents( CscsPainter * ) const;
    virtual void drawFocusIndicator( CscsPainter * ) const;

    void invalidateCache();

    virtual void drawScale( CscsPainter *, 
        const CscsPointF &center, double radius ) const;

    virtual void drawScaleContents( CscsPainter *painter, 
        const CscsPointF &center, double radius ) const;

    virtual void drawNeedle( CscsPainter *, const CscsPointF &,
        double radius, double direction, CscsPalette::ColorGroup ) const;

    virtual double scrolledTo( const CscsPoint & ) const;
    virtual bool isScrollPosition( const CscsPoint & ) const;

    virtual void sliderChange();
    virtual void scaleChange();

private:
    void setAngleRange( double angle, double span );
    void drawNeedle( CscsPainter * ) const;

    class PrivateData;
    PrivateData *d_data;

BEGIN_PROPERTY(CscsPlotDial,CscsPlotAbstractSlider)
    META_PROPERTY( int, lineWidth, READ, lineWidth, WRITE, setLineWidth )
    META_PROPERTY( Shadow, frameShadow, READ, frameShadow, WRITE, setFrameShadow )
    META_PROPERTY( Mode, mode, READ, mode, WRITE, setMode )
    META_PROPERTY( double, origin, READ, origin, WRITE, setOrigin )
    META_PROPERTY( double, minScaleArc, READ, minScaleArc, WRITE, setMinScaleArc)
    META_PROPERTY( double, maxScaleArc, READ, maxScaleArc, WRITE, setMaxScaleArc )
END_PROPERTY
};

END_NAMESPACE

#endif