#ifndef SCSPLOTRENDERER_H
#define SCSPLOTRENDERER_H
#include <kernel/scsobject.h>
#include <painting/scssize.h>
#include <kernel/scsflags.h>

BEGIN_NAMESPACE(Gemini)

class CscsPlot;
class CscsPlotScaleMap;
class CscsRectF;
class CscsPainter;
class CscsPaintDevice;

class  CscsPlotRenderer: public CscsObject
{

public:
    enum DiscardFlag
    {
        DiscardNone             = 0x00,
        DiscardBackground       = 0x01,
        DiscardTitle            = 0x02,
        DiscardLegend           = 0x04,
        DiscardCanvasBackground = 0x08,
        DiscardFooter           = 0x10,
        DiscardCanvasFrame           = 0x20

    };
    typedef CscsFlags<DiscardFlag> DiscardFlags;

    enum LayoutFlag
    {
        DefaultLayout   = 0x00,
        FrameWithScales = 0x01
    };

    typedef CscsFlags<LayoutFlag> LayoutFlags;

    explicit CscsPlotRenderer( CscsObject * = nullptr );
    virtual ~CscsPlotRenderer();

    void setDiscardFlag( DiscardFlag flag, bool on = true );
    bool testDiscardFlag( DiscardFlag flag ) const;

    void setDiscardFlags( DiscardFlags flags );
    DiscardFlags discardFlags() const;

    void setLayoutFlag( LayoutFlag flag, bool on = true );
    bool testLayoutFlag( LayoutFlag flag ) const;

    void setLayoutFlags( LayoutFlags flags );
    LayoutFlags layoutFlags() const;

    void renderTo( CscsPlot *, CscsPaintDevice & ) const;

    virtual void render( CscsPlot *,
        CscsPainter *, const CscsRectF &plotRect ) const;

    virtual void renderTitle( const CscsPlot *,
        CscsPainter *, const CscsRectF &titleRect ) const;

    virtual void renderFooter( const CscsPlot *,
        CscsPainter *, const CscsRectF &footerRect ) const;

    virtual void renderScale( const CscsPlot *, CscsPainter *,
        int axisId, int startDist, int endDist,
        int baseDist, const CscsRectF &scaleRect ) const;

    virtual void renderCanvas( const CscsPlot *,
        CscsPainter *, const CscsRectF &canvasRect,
        const CscsPlotScaleMap* maps ) const;

    virtual void renderLegend(
        const CscsPlot *, CscsPainter *, const CscsRectF &legendRect ) const;

private:
    void buildCanvasMaps( const CscsPlot *,
        const CscsRectF &, CscsPlotScaleMap maps[] ) const;

    bool updateCanvasMargins( CscsPlot *,
        const CscsRectF &, const CscsPlotScaleMap maps[] ) const;

private:
    class PrivateData;
    PrivateData *d_data;
};

SCS_DECLARE_OPERATORS_FOR_FLAGS( CscsPlotRenderer::DiscardFlags )
SCS_DECLARE_OPERATORS_FOR_FLAGS( CscsPlotRenderer::LayoutFlags )


END_NAMESPACE

#endif