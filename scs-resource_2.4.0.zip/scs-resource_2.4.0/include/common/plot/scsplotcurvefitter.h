#ifndef SCSPLOTCURVEFITTER_H
#define SCSPLOTCURVEFITTER_H
#include <painting/scspolygon.h>
#include <painting/scsrect.h>

BEGIN_NAMESPACE(Gemini)

class CscsPlotSpline;
class  CscsPlotCurveFitter
{
public:
    virtual ~CscsPlotCurveFitter();
    virtual CscsPolygonF fitCurve( const CscsPolygonF &polygon ) const = 0;

protected:
    CscsPlotCurveFitter();

private:
    CscsPlotCurveFitter( const CscsPlotCurveFitter & );
    CscsPlotCurveFitter &operator=( const CscsPlotCurveFitter & );
};

class  CscsPlotSplineCurveFitter: public CscsPlotCurveFitter
{
public:
    enum FitMode
    {
        Auto,
        Spline,
        ParametricSpline
    };

    CscsPlotSplineCurveFitter();
    virtual ~CscsPlotSplineCurveFitter();

    void setFitMode( FitMode );
    FitMode fitMode() const;

    void setSpline( const CscsPlotSpline& );
    const CscsPlotSpline &spline() const;
    CscsPlotSpline &spline();

    void setSplineSize( int size );
    int splineSize() const;

    virtual CscsPolygonF fitCurve( const CscsPolygonF & ) const;

private:
    CscsPolygonF fitSpline( const CscsPolygonF & ) const;
    CscsPolygonF fitParametric( const CscsPolygonF & ) const;

    class PrivateData;
    PrivateData *d_data;
};

class  CscsPlotWeedingCurveFitter: public CscsPlotCurveFitter
{
public:
    CscsPlotWeedingCurveFitter( double tolerance = 1.0 );
    virtual ~CscsPlotWeedingCurveFitter();

    void setTolerance( double );
    double tolerance() const;

    void setChunkSize( uint );
    uint chunkSize() const;

    virtual CscsPolygonF fitCurve( const CscsPolygonF & ) const;

private:
    virtual CscsPolygonF simplify( const CscsPolygonF & ) const;

    class Line;

    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE

#endif