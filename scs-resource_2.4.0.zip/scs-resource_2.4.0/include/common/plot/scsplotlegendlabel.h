#ifndef SCSPLOTLEGENDLABEL_H
#define SCSPLOTLEGENDLABEL_H
#include "scsplotlegenddata.h"
#include "scsplottext.h"
#include "scsplottextlabel.h"
#include <painting/scsimage.h>

BEGIN_NAMESPACE(Gemini)

class  WIDGET_EXPORT CscsPlotLegendLabel: public CscsPlotTextLabel
{
public:
    explicit CscsPlotLegendLabel( CscsWidget *parent = nullptr );
    virtual ~CscsPlotLegendLabel();

    void setData( const CscsPlotLegendData & );
    const CscsPlotLegendData &data() const;

    void setItemMode( CscsPlotLegendData::Mode );
    CscsPlotLegendData::Mode itemMode() const;

    void setSpacing( int spacing );
    int spacing() const;

    virtual void setText( const CscsPlotText & );

    void setIcon( const CscsImage & );
    CscsImage icon() const;

    virtual CscsSize sizeHint() const;

    bool isChecked() const;

SLOTS:
    void setChecked( bool on );

SIGNALS:
    void clicked(){}
    void pressed(){}
    void released(){}
    void checked( bool ){}

protected:
    void setDown( bool );
    bool isDown() const;

    virtual void paintEvent( CscsPaintEvent * );
    virtual void mousePressEvent( CscsMouseEvent * );
    virtual void mouseReleaseEvent( CscsMouseEvent * );
    virtual void keyPressEvent( CscsKeyEvent * );
    virtual void keyReleaseEvent( CscsKeyEvent * );

private:
    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE
#endif