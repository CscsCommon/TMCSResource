#ifndef SCSPLOTZONEITEM_H
#define SCSPLOTZONEITEM_H
#include "scsplotitem.h"
#include "scsplotinterval.h"
#include <window/scsenum.h>
#include <painting/scspen.h>

BEGIN_NAMESPACE(Gemini)

class CscsBrush;

class  CscsPlotZoneItem:
    public CscsPlotItem
{
public:
    explicit CscsPlotZoneItem();
    virtual ~CscsPlotZoneItem();

    virtual int rtti() const;

    void setOrientation( SCS::Orientation );
    SCS::Orientation orientation();

    void setInterval( double min, double max );
    void setInterval( const CscsPlotInterval & );
    CscsPlotInterval interval() const;

    void setPen( const CscsRgba &, double width = 0.0, CscsPen::PenType = CscsPen::SolidPen );
    void setPen( const CscsPen & );
    const CscsPen &pen() const;

    void setBrush( const CscsBrush & );
    const CscsBrush &brush() const;

    virtual void draw( CscsPainter *,
        const CscsPlotScaleMap &, const CscsPlotScaleMap &,
        const CscsRectF &) const;

    virtual CscsRectF boundingRect() const;

private:
    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE

#endif