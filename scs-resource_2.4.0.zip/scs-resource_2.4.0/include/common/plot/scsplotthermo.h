#ifndef SCSPLOTTHERMO_H
#define SCSPLOTTHERMO_H
#include "scsplotabstractscale.h"
#include "scsplotinterval.h"

BEGIN_NAMESPACE(Gemini)

class CscsPlotScaleDraw;
class CscsPlotScaleMap;
class CscsBrush;
class CscsPainter;
class CscsPlotColorMap;

class  WIDGET_EXPORT CscsPlotThermo: public CscsPlotAbstractScale
{

public:
    enum ScalePosition
    {
        NoScale,
        LeadingScale,
        TrailingScale
    };

    enum OriginMode
    {
        OriginMinimum,
        OriginMaximum,
        OriginCustom
    };

    explicit CscsPlotThermo( CscsWidget *parent = nullptr );
    virtual ~CscsPlotThermo();

    void setOrientation( SCS::Orientation );
    SCS::Orientation orientation() const;

    void setScalePosition( ScalePosition );
    ScalePosition scalePosition() const;

    void setSpacing( int );
    int spacing() const;

    void setBorderWidth( int w );
    int borderWidth() const;

    void setOriginMode( OriginMode );
    OriginMode originMode() const;

    void setOrigin( double );
    double origin() const;

    void setFillBrush( const CscsBrush &b );
    CscsBrush fillBrush() const;

    void setAlarmBrush( const CscsBrush &b );
    CscsBrush alarmBrush() const;

    void setAlarmLevel( double v );
    double alarmLevel() const;

    void setAlarmEnabled( bool tf );
    bool alarmEnabled() const;

    void setColorMap( CscsPlotColorMap * );
    CscsPlotColorMap *colorMap();
    const CscsPlotColorMap *colorMap() const;

    void setPipeWidth( int w );
    int pipeWidth() const;

    void setRangeFlags( CscsPlotInterval::BorderFlags );
    CscsPlotInterval::BorderFlags rangeFlags() const;

    double value() const;

    virtual CscsSize sizeHint() const;
    virtual CscsSize minimumSizeHint() const;

    void setScaleDraw( CscsPlotScaleDraw * );
    const CscsPlotScaleDraw *scaleDraw() const;

SLOTS:
    virtual void setValue( double val );

protected:
    virtual void drawLiquid( CscsPainter *, const CscsRect & ) const;
    virtual void scaleChange();

    virtual void paintEvent( CscsPaintEvent * );
    virtual void resizeEvent( CscsResizeEvent * );
    virtual void changeEvent( CscsEvent * );

    CscsPlotScaleDraw *scaleDraw();

    CscsRect pipeRect() const;
    CscsRect fillRect( const CscsRect & ) const;
    CscsRect alarmRect( const CscsRect & ) const;

private:
    void layoutThermo( bool );

    class PrivateData;
    PrivateData *d_data;


BEGIN_PROPERTY(CscsPlotThermo, CscsPlotAbstractScale)
    META_PROPERTY( SCS::Orientation, orientation,
         READ, orientation, WRITE, setOrientation )
    META_PROPERTY( ScalePosition, scalePosition, 
        READ, scalePosition, WRITE, setScalePosition )
    META_PROPERTY( OriginMode, originMode, READ, originMode, WRITE, setOriginMode )
    META_PROPERTY( bool, alarmEnabled, READ, alarmEnabled, WRITE, setAlarmEnabled )
    META_PROPERTY( double, alarmLevel, READ, alarmLevel, WRITE, setAlarmLevel )
    META_PROPERTY( double, origin, READ, origin, WRITE, setOrigin )
    META_PROPERTY( int, spacing, READ, spacing, WRITE, setSpacing )
    META_PROPERTY( int, borderWidth, READ, borderWidth, WRITE, setBorderWidth )
    META_PROPERTY( int, pipeWidth, READ, pipeWidth, WRITE, setPipeWidth )
    META_PROPERTY( double, value, READ, value, WRITE, setValue )
END_PROPERTY

};

END_NAMESPACE

#endif