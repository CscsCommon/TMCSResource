#ifndef SCSPLOTLEGENDITEM_H
#define SCSPLOTLEGENDITEM_H
#include "scsplotitem.h"
#include "scsplotlegenddata.h"
#include <window/scsenum.h>

BEGIN_NAMESPACE(Gemini)

class CscsFont;
class  CscsPlotLegendItem: public CscsPlotItem
{
public:
    enum BackgroundMode
    {
        LegendBackground,
        ItemBackground
    };

    explicit CscsPlotLegendItem();
    virtual ~CscsPlotLegendItem();

    virtual int rtti() const;

    void setAlignment( SCS::Alignment );
    SCS::Alignment alignment() const;

    void setMaxColumns( uint );
    uint maxColumns() const;

    void setMargin( int );
    int margin() const;

    void setSpacing( int );
    int spacing() const;

    void setItemMargin( int );
    int itemMargin() const;

    void setItemSpacing( int );
    int itemSpacing() const;

    void setFont( const CscsFont& );
    CscsFont font() const;

    void setBorderDistance( int );
    int borderDistance() const;

    void setBorderRadius( double );
    double borderRadius() const;

    void setBorderPen( const CscsPen & );
    CscsPen borderPen() const;

    void setBackgroundBrush( const CscsBrush & );
    CscsBrush backgroundBrush() const;

    void setBackgroundMode( BackgroundMode );
    BackgroundMode backgroundMode() const;

    void setTextPen( const CscsPen & );
    CscsPen textPen() const;

    virtual void draw( CscsPainter *,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect ) const;

    void clearLegend();

    virtual void updateLegend( const CscsPlotItem *,
        const CscsList<CscsPlotLegendData> & );

    virtual CscsRect geometry( const CscsRectF &canvasRect ) const;

    virtual CscsSize minimumSize( const CscsPlotLegendData & ) const;
    virtual int heightForWidth( const CscsPlotLegendData &, int width ) const;

    CscsList< const CscsPlotItem * > plotItems() const;
    CscsList< CscsRect > legendGeometries( const CscsPlotItem * ) const;

protected:
    virtual void drawLegendData( CscsPainter *painter,
        const CscsPlotItem *, const CscsPlotLegendData &, const CscsRectF & ) const;

    virtual void drawBackground( CscsPainter *, const CscsRectF &rect ) const;

private:
    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE

#endif