#ifndef SCSPLOTABSTRACTBARCHART_H
#define SCSPLOTABSTRACTBARCHART_H
#include "scsplotseriesitem.h"
#include "scsplotseriesdata.h"

BEGIN_NAMESPACE(Gemini)

class  CscsPlotAbstractBarChart: public CscsPlotSeriesItem
{
public:
    enum LayoutPolicy
    {
        AutoAdjustSamples,
        ScaleSamplesToAxes,
        ScaleSampleToCanvas,
        FixedSampleSize
    };

    explicit CscsPlotAbstractBarChart( const CscsPlotText &title );
    virtual ~CscsPlotAbstractBarChart();

    void setLayoutPolicy( LayoutPolicy );
    LayoutPolicy layoutPolicy() const;

    void setLayoutHint( double );
    double layoutHint() const;

    void setSpacing( int );
    int spacing() const;

    void setMargin( int );
    int margin() const;

    void setBaseline( double );
    double baseline() const;

    virtual void getCanvasMarginHint(
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect,
        double &left, double &top, double &right, double &bottom) const;


protected:
    double sampleWidth( const CscsPlotScaleMap &map,
        double canvasSize, double boundingSize,
        double value ) const;

private:
    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE

#endif