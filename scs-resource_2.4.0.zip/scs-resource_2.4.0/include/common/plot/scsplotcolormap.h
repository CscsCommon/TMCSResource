#ifndef SCSPLOTCOLORMAP_H
#define SCSPLOTCOLORMAP_H
#include "scsplotinterval.h"
#include <painting/scsrgba.h>
#include <kernel/scsvector.h>

BEGIN_NAMESPACE(Gemini)

class  CscsPlotColorMap
{
public:
    enum Format
    {
        RGB
    };

    CscsPlotColorMap(Format = CscsPlotColorMap::RGB);
    virtual ~CscsPlotColorMap();

    Format format() const;
    virtual uint rgb( const CscsPlotInterval &interval,
        double value ) const = 0;

    virtual unsigned char colorIndex(
        const CscsPlotInterval &interval, double value) const = 0;

    CscsRgba color( const CscsPlotInterval &, double value ) const;
    virtual CscsVector<uint> colorTable( const CscsPlotInterval & ) const;

private:
    Format d_format;
};


class  CscsPlotLinearColorMap: public CscsPlotColorMap
{
public:

    enum Mode
    {
        FixedColors,
        ScaledColors
    };

    CscsPlotLinearColorMap( CscsPlotColorMap::Format = CscsPlotColorMap::RGB );
    CscsPlotLinearColorMap( const CscsRgba &color1, const CscsRgba &color2,
        CscsPlotColorMap::Format = CscsPlotColorMap::RGB );

    virtual ~CscsPlotLinearColorMap();

    void setMode( Mode );
    Mode mode() const;

    void setColorInterval( const CscsRgba &color1, const CscsRgba &color2 );
    void addColorStop( double value, const CscsRgba& );
    CscsVector<double> colorStops() const;

    CscsRgba color1() const;
    CscsRgba color2() const;

    virtual uint rgb( const CscsPlotInterval &, double value ) const;
    virtual unsigned char colorIndex(
        const CscsPlotInterval &, double value ) const;

    class ColorStops;

private:
    // Disabled copy constructor and operator=
    CscsPlotLinearColorMap( const CscsPlotLinearColorMap & );
    CscsPlotLinearColorMap &operator=( const CscsPlotLinearColorMap & );

    class PrivateData;
    PrivateData *d_data;
};

class CscsPlotAlphaColorMap: public CscsPlotColorMap
{
public:
    CscsPlotAlphaColorMap( const CscsRgba & = CscsRgba(240,240,240,255));
    virtual ~CscsPlotAlphaColorMap();

    void setColor( const CscsRgba & );
    CscsRgba color() const;

    virtual uint rgb( const CscsPlotInterval &, double value ) const;

private:
    CscsPlotAlphaColorMap( const CscsPlotAlphaColorMap & );
    CscsPlotAlphaColorMap &operator=( const CscsPlotAlphaColorMap & );

    virtual unsigned char colorIndex(
        const CscsPlotInterval &, double value ) const;

    class PrivateData;
    PrivateData *d_data;
};

inline CscsRgba CscsPlotColorMap::color(
    const CscsPlotInterval &interval, double value ) const
{
    if ( d_format == RGB )
    {
        return CscsRgba(rgb(interval, value));
    }
    else
    {
        const unsigned int index = colorIndex( interval, value );

        const CscsVector<uint> rgbTable = colorTable( interval );
        return rgbTable[index]; // slow
    }
}

inline CscsPlotColorMap::Format CscsPlotColorMap::format() const
{
    return d_format;
}

END_NAMESPACE
#endif