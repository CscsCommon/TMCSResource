#ifndef SCSDATASENSOREVENT_H
#define SCSDATASENSOREVENT_H
#include <kernel/scsevent.h>
#include <kernel/scsvariant.h>

BEGIN_NAMESPACE(Gemini)

class CscsByteArray;
class CscsDataSensorEvent:public CscsEvent{
public:
	enum SensorType
	{
		UnKnown,
		Bool,
		Int,
		UInt,
		Double,
		Int64,
		UInt64,
		String,
		ByteArray,
		JustNotify,
		Any,
		UserType=128,
		MaxType=255
	};

	enum DataMerge{
		Disable,
		Enable
	};

	CscsDataSensorEvent(int uid, SensorType type, DataMerge merge);
	~CscsDataSensorEvent();

	SensorType sensorType()const;
	DataMerge dataMerge()const;
	int 	 uid()const;

private:
	int id;
	SensorType type;
	DataMerge merge;
};


class CscsUIntDataSensorEvent:public CscsDataSensorEvent{
	public:
		CscsUIntDataSensorEvent(int id, uint value, CscsDataSensorEvent::DataMerge merge=CscsDataSensorEvent::Enable);
		~CscsUIntDataSensorEvent();
		uint value()const;

	private:
		uint data;
};

class CscsUInt64DataSensorEvent:public CscsDataSensorEvent{
	public:
		CscsUInt64DataSensorEvent(int id, uint64 value, CscsDataSensorEvent::DataMerge merge=CscsDataSensorEvent::Enable);
		~CscsUInt64DataSensorEvent();
		uint64 value()const;

	private:
		uint64 data;
};

class CscsInt64DataSensorEvent:public CscsDataSensorEvent{
	public:
		CscsInt64DataSensorEvent(int id, int64 value, CscsDataSensorEvent::DataMerge merge=CscsDataSensorEvent::Enable);
		~CscsInt64DataSensorEvent();
		int64 value()const;

	private:
		int64 data;
};

class CscsIntDataSensorEvent:public CscsDataSensorEvent{
	public:
		CscsIntDataSensorEvent(int id, int value, CscsDataSensorEvent::DataMerge merge=CscsDataSensorEvent::Enable);
		~CscsIntDataSensorEvent();
		int value()const;

	private:
		int data;
};

class CscsDoubleDataSensorEvent:public CscsDataSensorEvent{
	public:
		CscsDoubleDataSensorEvent(int uid, double value, CscsDataSensorEvent::DataMerge merge=CscsDataSensorEvent::Enable);
		double value()const;
	private:
		double data;
};

class CscsByteArrayDataSensorEvent:public CscsDataSensorEvent{
	public:
		CscsByteArrayDataSensorEvent(int uid, const CscsByteArray& data, CscsDataSensorEvent::DataMerge merge=CscsDataSensorEvent::Enable);
		~CscsByteArrayDataSensorEvent();
		CscsByteArray value()const;
	private:
		CscsByteArray data;
};

class CscsBoolDataSensorEvent:public CscsDataSensorEvent{
	public:
		CscsBoolDataSensorEvent(int uid, bool on, CscsDataSensorEvent::DataMerge merge=CscsDataSensorEvent::Enable);
		~CscsBoolDataSensorEvent();
		bool value()const;
	private:
		bool data;
};

class CscsAnyDataSensorEvent:public CscsDataSensorEvent{
	public:
		CscsAnyDataSensorEvent(int uid, const CscsVariant& value,CscsDataSensorEvent::SensorType type, CscsDataSensorEvent::DataMerge merge=CscsDataSensorEvent::Enable);
		~CscsAnyDataSensorEvent();
		CscsVariant value()const;
	private:
		CscsVariant data;
};

END_NAMESPACE

#endif
