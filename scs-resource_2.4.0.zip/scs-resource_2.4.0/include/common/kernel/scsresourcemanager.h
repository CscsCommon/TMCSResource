/*
 * Created by J.Wong 2020/04/11 
 */

#ifndef SCS_RESOURCEMANAGER_H
#define SCS_RESOURCEMANAGER_H
#include "scsobject.h"

BEGIN_NAMESPACE(Gemini)

class CscsResourceEvent;
class CscsEvent;

class CscsResourceManager:public CscsObject{
public:
	static CscsResourceManager* instance(){
		static CscsResourceManager manager;
		return &manager;
	}

protected:
	bool event(CscsEvent* e);
	virtual void resourceEvent(CscsResourceEvent* e);
private:
	CscsResourceManager(CscsObject* parent=nullptr)
	:CscsObject(parent)
	{

	}
};

END_NAMESPACE

#endif