#ifndef SCSWINMESSAGE_H
#define SCSWINMESSAGE_H
#include "scsobject.h"
#include <set>

BEGIN_NAMESPACE(Gemini)

class CscsCustomEvent;
class CscsTimerEvent;

class CscsWinMessage:public CscsObject{
public:
	static CscsWinMessage* instance();
	static void polish(uint message, uint16 wParam, uint32 lParam);
	static void addSubscriber(CscsObject* sub);
	static void removeSubscriber(CscsObject* sub);
protected:
	void customEvent(CscsCustomEvent* ev);
	void timerEvent(CscsTimerEvent* ev);
private:
	CscsWinMessage(CscsObject* parent=nullptr);
	virtual ~CscsWinMessage();
	static std::set<CscsObject*> subsribers;

	static int timerId;
};
END_NAMESPACE

#endif