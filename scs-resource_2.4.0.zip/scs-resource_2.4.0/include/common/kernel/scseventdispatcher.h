#ifndef SCSEVENTDISPATCHER_H
#define SCSEVENTDISPATCHER_H
#include "scsabstracteventdispatcher.h"
#include "scsabstracteventdispatcher_p.h"
#include <atomic>
#include <sys/types.h>
#include <sys/time.h>
#include <config.h>

BEGIN_NAMESPACE(Gemini)

struct CscsSockNot{

	CscsSocketNotifier* obj;
	int fd;
	fd_set* queue;

};

typedef CscsList<CscsSockNot*> CscsSockList;
typedef CscsList<CscsSockNot*>::iterator CscsSockListIter;


class CscsSocketNotType{
public:
    CscsSocketNotType();
    ~CscsSocketNotType();

   	CscsSockList list;
    fd_set select_fds;
    fd_set enabled_fds;
    fd_set pending_fds;
};

class CscsEventDispatcherPrivate;

class CscsEventDispatcher:public CscsAbstractEventDispatcher{

public:
	CscsEventDispatcher(CscsObject* parent=0);
	~CscsEventDispatcher();

	bool processEvents(CscsEventLoop::EventProcess filter);
    bool hasPendingEvents();

    void registerSocketNotifier(CscsSocketNotifier *notifier);
    void unregisterSocketNotifier(CscsSocketNotifier *notifier);
	int registerTimer(int interval, CscsObject *object);
    void registerTimer(int timerId, int interval, CscsObject *object);
    bool unregisterTimer(int timerId);
    bool unregisterTimers(CscsObject *object);
    std::vector<TimerInfo> registeredTimers(CscsObject *object) const;

    void wakeUp();
    void interrupt();
    void flush();

    CscsEventDispatcherPrivate* d_func()const;

protected:
    CscsEventDispatcher(CscsEventDispatcherPrivate* d, CscsObject* parent);
    void setSocketNotifierPending(CscsSocketNotifier *notifier);

    int activateTimers();
    int activateSocketNotifiers();

    virtual int select(int nfds,
                       fd_set *readfds, fd_set *writefds, fd_set *exceptfds,
                       timeval *timeout);

private:
	friend class CscsEventDispatcherPrivate;
};


struct  CscsTimerInfo;

class  CscsEventDispatcherPrivate : public CscsAbstractEventDispatcherPrivate
{


public:
    CscsEventDispatcherPrivate();
    ~CscsEventDispatcherPrivate();

    int processEventsFromSelect(CscsEventLoop::EventProcess filter, timeval *timeout);

    bool mainThread;
    int thread_pipe[2];

    CscsEventDispatcher* mm_func()const{
    	return reinterpret_cast<CscsEventDispatcher*> (mm);
    }

    // watch if time is turned back
    timeval watchtime;

    // highest fd for all socket notifiers
    int sn_highest;
    // 3 socket notifier types - read, write and exception
    CscsSocketNotType sn_vec[3];

    std::list<CscsTimerInfo*> timerList;
    bool timerWait(timeval &);
    void timerInsert(CscsTimerInfo *);
    void timerRepair(const timeval &);

    // pending socket notifiers list
    CscsSockList sn_pending_list;

    std::atomic<int> wakeUps;
    bool interrupt;

};

END_NAMESPACE


#endif