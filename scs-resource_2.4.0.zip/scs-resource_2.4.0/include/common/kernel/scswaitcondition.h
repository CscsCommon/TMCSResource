#ifndef SCSWAITCONDITION_H
#define SCSWAITCONDITION_H
#include <limits>
#include "scsnocopy.hpp"

BEGIN_NAMESPACE(Gemini)

class CscsWaitConditionPrivate;
class CscsMutex;
class CscsWriteReadLock;

class  CscsWaitCondition:public CscsNoCopyable
{

public:
    CscsWaitCondition();
    ~CscsWaitCondition();

    bool wait(CscsMutex *mutex, unsigned long time = std::numeric_limits<unsigned long>::max());
    bool wait(CscsWriteReadLock *writeReadLock, unsigned long time = std::numeric_limits<unsigned long>::max());

    void wakeOne();
    void wakeAll();

private:
    CscsWaitConditionPrivate * d;
};

END_NAMESPACE
#endif