#ifndef SCSRINGBUFFER_H
#define SCSRINGBUFFER_H

#include <vector>
#include "scstypes.h"
#include "scsbytearray.h"

BEGIN_NAMESPACE(Gemini)

class CscsRingBuffer{
public:
  CscsRingBuffer(int growth=4096);

  int nextDataBlockSize()const;
  char* readPointer()const;
  void free(int bytes);
  char* reserve(int bytes);
  void truncate(int bytes);
  void chop(int bytes);
  bool empty()const;

  int getChar();
  void putChar(char c);
  void ungetChar(char c);

  int size()const;
  void clear();
  int indexOf(char c)const;
  int readLine(char* data, int maxLength);
  bool canReadLine()const;

  void append(const char* data, int size);

  inline int skip(int length) {
        return read(0, length);
  }

  inline bool isEmpty() const {
        return tailBuffer == 0 && tail == 0;
  }

  inline int read(char *data, int maxLength) {
        int bytesToRead = std::min(size(), maxLength);
        int readSoFar = 0;
        while (readSoFar < bytesToRead) {
            const char *ptr = readPointer();
            int bytesToReadFromThisBlock = std::min(bytesToRead - readSoFar, nextDataBlockSize());
            if (data)
                memcpy(data + readSoFar, ptr, bytesToReadFromThisBlock);
            readSoFar += bytesToReadFromThisBlock;
            free(bytesToReadFromThisBlock);
        }
        return readSoFar;
    }

    inline CscsByteArray read(int maxLength) {
        CscsByteArray tmp;
        tmp.resize(std::min(maxLength, size()));
        read(tmp.data(), tmp.size());
        return tmp;
    }


     inline CscsByteArray readAll() {
        return read(size());
    }

    inline CscsByteArray peek(int maxLength) const {
        int bytesToRead = std::min(size(), maxLength);
        if(maxLength <= 0)
            return CscsByteArray();
        CscsByteArray ret;
        ret.resize(bytesToRead);
        int readSoFar = 0;
        for (size_t i = 0; readSoFar < bytesToRead && i < buffers.size(); ++i) {
            int start = 0;
            int end = buffers.at(i).size();
            if (i == size_t(0))
                start = head;
            if (i == size_t(tailBuffer))
                end = tail;
            const int len = std::min(ret.size()-readSoFar, end-start);
            memcpy(ret.data()+readSoFar, buffers.at(i).data()+start, len);
            readSoFar += len;
        }
        assert(readSoFar == ret.size());
        return ret;
    }
private:
  std::vector<bytearray> buffers;
  int head, tail;
  int tailBuffer;
  int basicBlockSize;
  int bufferSize;
};

END_NAMESPACE

#endif
