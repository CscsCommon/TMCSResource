#ifndef SCSREGEXP_H
#define SCSREGEXP_H
#include "scsstringlist.h"

BEGIN_NAMESPACE(Gemini)

struct CscsRegExpPrivate;
class CscsStringList;

class  CscsRegExp
{
public:
    enum PatternSyntax { RegExp, Wildcard };
    enum CaretMode { CaretAtZero, CaretAtOffset, CaretWontMatch };
    CscsRegExp();
    explicit CscsRegExp(const CscsString &pattern, CscsString::CaseSensitivity cs = CscsString::CaseSensitive,
		     PatternSyntax syntax = RegExp);
    CscsRegExp(const CscsRegExp &rx);
    ~CscsRegExp();
    CscsRegExp &operator=(const CscsRegExp &rx);

    bool operator==(const CscsRegExp &rx) const;
    inline bool operator!=(const CscsRegExp &rx) const { return !operator==(rx); }

    bool isEmpty() const;
    bool isValid() const;
    CscsString pattern() const;
    void setPattern(const CscsString &pattern);
    CscsString::CaseSensitivity caseSensitivity() const;
    void setCaseSensitivity(CscsString::CaseSensitivity cs);

    PatternSyntax patternSyntax() const;
    void setPatternSyntax(PatternSyntax syntax);

    bool isMinimal() const;
    void setMinimal(bool minimal);


    bool exactMatch(const CscsString &str) const;

    int indexIn(const CscsString &str, int offset = 0, CaretMode caretMode = CaretAtZero) const;
    int lastIndexIn(const CscsString &str, int offset = -1, CaretMode caretMode = CaretAtZero) const;

    int matchedLength() const;
    int numCaptures() const;
    CscsStringList capturedTexts();
    CscsString cap(int nth = 0);
    int pos(int nth = 0);
    CscsString errorString();

    static CscsString escape(const CscsString &str);


private:
    CscsRegExpPrivate *priv;
};
SCS_DECLARE_TYPENAME_INFO(CscsRegExp,SCS_MOVABLE_TYPE)

END_NAMESPACE

#endif