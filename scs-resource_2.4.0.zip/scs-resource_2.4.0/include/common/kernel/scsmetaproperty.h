#ifndef SCSMETAPROPERTY_H
#define SCSMETAPROPERTY_H
#include "scsvariant.h"
#include "scsbytearray.h"
#include <typeinfo>
BEGIN_NAMESPACE(Gemini)

class CscsObject;

struct CscsHeritsObject{
    CscsHeritsObject():clsName(nullptr),superCls(nullptr){

    }
    const char* clsName;
    
    CscsHeritsObject* superCls;
    
    CscsHeritsObject* superClass()const{
        return superCls;
    };

    std::string className()const{
        return clsName;
    }
    friend class CscsObject;
};
struct CscsMetaProperty{

	int propertyOffset()const;
	int propertyCount()const;
	int indexOfProperty(const char* name)const;

	enum Call{
		ReadProperty,
		WriteProperty,
        CheckProperty,
        CheckMetaType
	};

    struct { // private data
     	const CscsMetaProperty *superdata;
     	const CscsByteArray *stringdata;
     	const uint *data;
        typedef void (*StaticMetacallFunction)(CscsObject *, CscsMetaProperty::Call, int, void **);
        StaticMetacallFunction static_metacall;
    }d;
};





#define BEGIN_SUPERCLASS_PROPERTY(ClassName) \
public: \
    virtual bool scs_metacall(CscsMetaProperty::Call _c, const char* _id, void ** _a){ \
        return scs_static_metacall(this,_c,_id,_a); \
    } \
    \
private: \
    static bool scs_static_metacall(CscsObject * _o, CscsMetaProperty::Call _c, const char* _id, void ** _a){ \
        ClassName * _t=static_cast<ClassName *>(_o); \
        if(_a==nullptr) return false; \
        void* _v=_a[0]; \
        if(_t==nullptr||_id==nullptr|| _a==nullptr) return false; \



#define BEGIN_PROPERTY(ClassName,SuperClassName) \
public: \
    virtual bool scs_metacall(CscsMetaProperty::Call _c, const char* _id, void ** _a){ \
        if(!scs_static_metacall(this,_c,_id,_a)) \
        { \
                return SuperClassName::scs_metacall(_c,_id,_a); \
        } \
        return true; \
    } \
    \
private: \
    static bool scs_static_metacall(CscsObject * _o, CscsMetaProperty::Call _c, const char* _id, void ** _a){ \
        ClassName * _t=static_cast<ClassName *>(_o); \
        if(_a==nullptr) return false; \
        void* _v=_a[0]; \
        if(_t==nullptr||_id==nullptr|| _a==nullptr) return false; \


#define END_PROPERTY \
    	\
        return false; \
    } \



#define META_PROPERTY(TYPE, PROPERTY, READ, READMETHOD, WRITE, WRITEMETHOD) \
    if(_c==CscsMetaProperty::ReadProperty) \
    { \
        if(strcmp(_id,#PROPERTY)==0){ \
            *reinterpret_cast<TYPE *>(_v)=_t->READMETHOD(); return true; \
        } \
    } \
    else if(_c==CscsMetaProperty::WriteProperty){ \
        if(strcmp(_id,#PROPERTY)==0){ \
           _t->WRITEMETHOD(*reinterpret_cast<TYPE *>(_v)); return true; \
        } \
    } \
    \
    else if(_c==CscsMetaProperty::CheckProperty) \
    { \
      if(strcmp(_id,#PROPERTY)==0){ \
        return true; \
      } \
    } \
    \
    else if(_c==CscsMetaProperty::CheckMetaType) \
    { \
      if(strcmp(_id,#PROPERTY)==0){ \
        *reinterpret_cast<std::string *>(_v)=#TYPE; \
        return true; \
      } \
    } \



#define META_READ_PROPERTY(TYPE, PROPERTY, READ, READMETHOD) \
    if(_c==CscsMetaProperty::ReadProperty) \
    { \
        if(strcmp(_id,#PROPERTY)==0){ \
            *reinterpret_cast<TYPE *>(_v)=_t->READMETHOD(); return true; \
        } \
    } \
    \
    else if(_c==CscsMetaProperty::CheckProperty) \
    { \
      if(strcmp(_id,#PROPERTY)==0){ \
        return true; \
      } \
    } \
    \
    else if(_c==CscsMetaProperty::CheckMetaType) \
    { \
      if(strcmp(_id,#PROPERTY)==0){ \
        *reinterpret_cast<std::string *>(_v)=#TYPE; \
        return true; \
      } \
    } \



#define META_WRITE_PROPERTY(TYPE, PROPERTY, WRITE, WRITEMETHOD) \
    if(_c==CscsMetaProperty::WriteProperty){ \
            if(strcmp(_id,#PROPERTY)==0){ \
               _t->WRITEMETHOD(*reinterpret_cast<TYPE *>(_v)); return true; \
            } \
        } \
    \
    else if(_c==CscsMetaProperty::CheckProperty) \
    { \
      if(strcmp(_id,#PROPERTY)==0){ \
        return true; \
      } \
    } \
    \
    else if(_c==CscsMetaProperty::CheckMetaType) \
    { \
      if(strcmp(_id,#PROPERTY)==0){ \
        *reinterpret_cast<std::string *>(_v)=#TYPE; \
        return true; \
      } \
    } \

END_NAMESPACE

#endif