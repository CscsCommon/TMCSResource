/*
 Created by J.Wong 2018/08/08
 version:    version 1.0, 
 dependency: base on  or greater than c++11
 function: connections
 gcc:4.9+
 */


#pragma once
#include "scsmessagebus.hpp"
#include "scsnocopy.hpp"
#include "scssender.hpp"
#include "scsobject.h"
#include "scshash.h"
#include "scslist.h"

BEGIN_NAMESPACE(Gemini)
/*! \class CscsConnection scsconnection.hpp "kernel/scsconnection.hpp"
 *  \brief 		信号和槽绑定类.
 * 	\brief		CscsConnection类：实现信号和槽函数绑定接和解除绑定.
 * 	\author 	J.Wong
 *	\date  		2018/08/08
 * 	\version 	1.0
 * 	
 */
static std::string strip;
static const  std::string& topic_strip(const char* topic){
	strip.clear();
	if(!topic) return strip;
	strip.reserve(1024);
	while(*topic){
		if(*topic!=' '&&*topic!=')'&&*topic!='(') strip+=*topic;
		++topic;
	}
	strip.shrink_to_fit();
	// std::cout<<"strip: "<<strip<<std::endl;
	return strip;
}

struct CscsConnection:public CscsNoCopyable
{
	/*! \fn	static long long  connection(CscsObject* sender, const std::string& messageTopic ,CscsObject* receiver, F&& f, long long iid) 
	*  \brief  连接函数.
	*  \param  sender 发送者.
	*  \param  messageTopic 字串化发送信号.如信号为clicked(bool v),则传入字串化为"clicked(bool)"
	*  \param  receiver 接收者
	*  \param  f 接收者处理函数(槽函数) ，此函数必须为lamda表达式
	*  \param  iid 处理函数唯一标识
	*  \return 成功绑定返回ID,失败返回-1.
	*  \details 示例: \n
	* 	CscsPushButton* button=new CscsPushButton(this); \n
	* 	CscsRadioButton* radio=new CscsRadioButton(this); \n
	*	CscsConnection::connection(button,"pressed()",radio,[&](){radio->click();},IID_GEN(radio,"CscsRadioButton::click()"));
	*  
	*/
	template<typename F>
	static long long   connection(CscsObject* sender, const std::string& messageTopic ,CscsObject* receiver, F&& f, long long iid=-1){
		// CscsString topic=CscsString::fromStdString(messageTopic);
		// topic.remove(CscsChar(' '),CscsString::CaseInsensitive);
		// topic.remove(CscsChar('('),CscsString::CaseInsensitive);
		// topic.remove(CscsChar(')'),CscsString::CaseInsensitive);

		const std::string& topic=topic_strip(messageTopic.c_str());
		if(sender&&sender->sender().messageBus()){
			// std::string stdTopic=topic.toStdString();
			long long retIID=sender->sender().messageBus()->attach(std::move(f),topic, iid);
			//添加接收对象
			if(!sender->receivers.contains(receiver)){
				sender->receivers.append(receiver);
			}
			//添加发送对象
			if(receiver){
				if(!receiver->senders.contains(sender)){
					receiver->senders.append(sender);
				}
				MessageData data;
				auto func=to_function(std::forward<F>(f));
				data.mesgType+=topic;
				data.mesgType+=typeid(func).name();
				//std::cout<<"mesageType: "<<data.mesgType<<std::endl;
				data.iid=retIID;
				receiver->messages.append(data);
			}

			// if(receiver)
		 	// 		sender->m_receivers.insert(std::pair<std::string, CscsObject*>(stdTopic,receiver));
		 	return retIID;
		}
		 return -1;
	}

	template<typename R,typename...Args,typename C, typename... DArgs, typename P>
	static long long connection(CscsObject* sender, P&& p, R(C::*f)(DArgs...),
								const std::string& messageTopic="", long long iid=-1,CscsObject* receiver=0){
		// CscsString topic=CscsString::fromStdString(messageTopic);
		// topic.remove(CscsChar(' '),CscsString::CaseInsensitive);
		// topic.remove(CscsChar('('),CscsString::CaseInsensitive);
		// topic.remove(CscsChar(')'),CscsString::CaseInsensitive);
		const std::string& topic=topic_strip(messageTopic.c_str());
		if(sender&&sender->sender().messageBus()){
		 	// std::string stdTopic=topic.toStdString();
			// if(receiver)
		 // 		sender->m_receivers.insert(std::pair<std::string, CscsObject*>(stdTopic,receiver));
		 	return sender->sender().messageBus()->attach<R,Args...>(f,p, topic, iid);
		}
		 return -1;
		
	}

	template<typename R, typename... Args, typename F,
    	class=typename std::enable_if<!std::is_member_function_pointer<F>::value>::type>
	static long long connection(CscsObject* sender,const std::string& messageTopic, CscsObject* receiver,F&& f, long long iid=-1){
		// CscsString topic=CscsString::fromStdString(messageTopic);
		// topic.remove(CscsChar(' '),CscsString::CaseInsensitive);
		// topic.remove(CscsChar('('),CscsString::CaseInsensitive);
		// topic.remove(CscsChar(')'),CscsString::CaseInsensitive);
		const std::string& topic=topic_strip(messageTopic.c_str());
		if(sender&&sender->sender().messageBus()){
		 	// std::string stdTopic=topic.toStdString();
			// if(receiver)
		 // 		sender->m_receivers.insert(std::pair<std::string, CscsObject*>(stdTopic,receiver));
		 	return sender->sender().messageBus()->attach<R,Args...>(f, topic, iid);
		}
		 return -1;
	}

	template<typename R, typename...Args>
	static void disconnection(CscsObject* sender, const std::string& messageTopic="",CscsObject* receiver=0){
		// CscsString topic=CscsString::fromStdString(messageTopic);
		// topic.remove(CscsChar(' '),CscsString::CaseInsensitive);
		// topic.remove(CscsChar('('),CscsString::CaseInsensitive);
		// topic.remove(CscsChar(')'),CscsString::CaseInsensitive);
		const std::string& topic=topic_strip(messageTopic.c_str());
		if(sender&&sender->sender().messageBus()){
			// std::string stdTopic=topic.toStdString();
		 	sender->sender().messageBus()->detach<R,Args...>(topic);
		}
	}


	template<typename R, typename...Args>
	static void disconnection(CscsObject* sender, const std::string& messageTopic,CscsObject* receiver,long long iid){
		//CscsString topic=CscsString::fromStdString(messageTopic);
		// topic.remove(CscsChar(' '),CscsString::CaseInsensitive);
		// topic.remove(CscsChar('('),CscsString::CaseInsensitive);
		// topic.remove(CscsChar(')'),CscsString::CaseInsensitive);
		const std::string& topic=topic_strip(messageTopic.c_str());
		if(sender&&sender->sender().messageBus()){
			// std::string stdTopic=topic.toStdString();
		 	sender->sender().messageBus()->detach<R,Args...>(iid,topic);
		}
	}
	/*! \fn	static void disconnection(CscsObject* obj) 
	*  \brief  解除函数.
	*  \param  obj 解除对象.
	*/
	static void disconnection(CscsObject* obj){
		if(obj){
			//disconnect sender
			for(int i=0; i<obj->senders.size();++i){
				for(int j=0;j<obj->messages.size();++j){
					const std::string& msgType=obj->messages[j].mesgType;
					long long iid=obj->messages[j].iid;
					CscsObject* sender=obj->senders[i];
					if(sender){
						sender->sender().messageBus()->detachX(iid,msgType);
					}
				}
				//printf("i=%d\n", i);
				obj->senders[i]->receivers.removeAll(obj);
				obj->senders[i]->senders.removeAll(obj);
			}
			//disconnect receiver
			for(int i=0; i<obj->receivers.size();++i){
				if(obj->receivers[i]){
					obj->receivers[i]->senders.removeAll(obj);
					obj->receivers[i]->receivers.removeAll(obj);
				}
			}
			obj->receivers.clear();
			obj->senders.clear();
		}
	}
};

END_NAMESPACE