 /*Created by J.Wong 2018/9/26
 version:    version 1.0,
 dependency: base on  or greater than c++11
 function: type erase
 gcc4.9+
 */
#ifndef CSCSANY_H
#define CSCSANY_H

#include <memory>
#include <typeindex>
#include <iostream>
#include "scsnamespace.h"

BEGIN_NAMESPACE(Gemini)

class CscsAny{
public:
	CscsAny(void):m_tpIndex(std::type_index(typeid(void))){}
	CscsAny(const CscsAny& that):m_ptr(that.clone()),m_tpIndex(that.m_tpIndex),m_iid(that.m_iid){}//needed limit const otherwise error in map conductor
	CscsAny(CscsAny&& that):m_ptr(std::move(that.m_ptr)),m_tpIndex(that.m_tpIndex),m_iid(that.m_iid){}
	/*
	create a smart ptr, and we get original type
	through removing cv and reference identifier
	so we can use std::decay method
	*/
	template<typename U, class= typename std::enable_if<!std::is_same<typename std::decay<U>::type,CscsAny>::value,U>::type>
	 CscsAny(U&& value):m_ptr(new  Derived<typename std::decay<U>::type>(std::forward<U>(value)))
	 				,m_tpIndex(std::type_index(typeid(typename std::decay<U>::type))),m_iid(-1){}

	bool isNull()const{
	 	return !bool(m_ptr);
	 }

	long long iid()const{
	 	return m_iid;
	 }

	void setIID(long long iid){
	 	m_iid=iid;
	 }

	 friend bool operator==(const CscsAny& a1, const CscsAny& a2){
	 	if(a1.m_tpIndex!=a2.m_tpIndex){
	 		return false;
	 	}
	 	return true;
	 }


	template<class U> bool is()const{

	 	return m_tpIndex==std::type_index(typeid(U));
	}

	//convert to U type
	template<class U>
	U& anyCast()const{
		if(!is<U>()){
			std::cout<<"can not cast "<<typeid(U).name()<<" to "<<m_tpIndex.name() <<std::endl;
			throw std::bad_cast();
		}
		auto derived=dynamic_cast<Derived<U>*>(m_ptr.get());
		return derived->m_value;
	}

	CscsAny& operator=(const CscsAny& a){
		if(m_ptr==a.m_ptr)
			return *this;
		m_ptr=a.clone();
		m_tpIndex=a.m_tpIndex;
		m_iid=a.m_iid;
		return *this;
	}


private:
	struct Base;
	typedef std::unique_ptr<Base> BasePtr;
	struct Base{
		virtual ~Base(){}
		virtual BasePtr clone()const=0;
	};

	template <typename T>
	struct Derived:Base{
		template <typename U>
		Derived(U&& value):m_value(std::forward<U>(value)){}
		BasePtr clone()const{
			return BasePtr(new Derived<T>(m_value));
		}
		T m_value;
	};

	BasePtr clone()const{
		if(m_ptr!=nullptr)
			return m_ptr->clone();
		return nullptr;
	}

	BasePtr m_ptr;

	std::type_index m_tpIndex;

	long long m_iid;
};

END_NAMESPACE

#endif
