 /*Created by J.Wong 2018/09/19
 version:    version 1.0,
 dependency: base on  or greater than c++11
 function: type erase
 gcc4.8+
 */
#ifndef CSCSOBJECT_H
#define CSCSOBJECT_H

#include "scsnocopy.hpp"
#include "scsutils.h"
#include "scsmetaproperty.h"
#include "scssender.hpp"
#include <stdlib.h>
#include <string.h>
#include <string>
#include <list>
#include <map>
#include "scsvariant.h"

#ifdef D_WIN32
#include <windows.h>
#endif

#ifdef D_DESIGNER_LIB
class CscsObjectLayer;
#endif
BEGIN_NAMESPACE(Gemini)

#define IID_GEN(value,CONST_STRINGS)	\
  ({const char* a=CONST_STRINGS; \
 (reinterpret_cast<long long>(a)|reinterpret_cast<long long>(value)<<32);})

class CscsObject;

typedef CscsList<CscsObject* > CscsObjectList;
typedef CscsList<CscsObject* >::iterator CscsObjectListIt;


class CscsEvent;
class CscsChildEvent;
class CscsTimerEvent;
class CscsCustomEvent;
class CscsThread;
class CscsApplicationPlusPrivate;
class CscsWriteReadLock;
class CscsObjectPrivate;
class CscsDataSensorEvent;
struct MessageData{
	std::string mesgType;
	long long iid;
};

typedef  CscsList<MessageData> Messages;
typedef CscsList<CscsObject*> Senders;
typedef CscsList<CscsObject*> Receivers;

class CscsObject:public CscsNoCopyable
{

public:

	CscsObject(CscsObject* parent=0);

	virtual ~CscsObject();

	virtual void setName(const std::string& name);
	std::string	name()const;



	static CscsMessageBus*	installMessageBus(int id);
	static void		removeMessageBus(int id);
	static void		setMessageBusInvalid(int id);
	static void 	invokeMethod(const CscsObject* obj, const char* method, const CscsVariant& param);

	const 	CscsObjectList& children()const;
	virtual bool event(CscsEvent* e);
	virtual bool eventFilter(CscsObject *, CscsEvent *);

	void installEventFilter(CscsObject*);
	void removeEventFilter(CscsObject* );

	//属性系统方法
	void setProperty(const std::string& varName, void* data);
	bool property(const std::string& varName,void** data);
	
	CscsVariant property(const std::string& varName);
	void setProperty(const std::string& varName, const CscsVariant& data);

	bool findProperty(const std::string& varName);



	//动态属性方法
	void setDynamicProperty(const std::string& varName, const CscsVariant& value);
	CscsVariant dynamicProperty(const std::string& varName)const;
	bool findDynamicProperty(const std::string& varName);

	int		startTimer(int interval);
	int 	killTimer(int id);

	//bool 	className(const char* ) const;
	std::string className()const;
	bool 	inherits(const char* )const;
	CscsHeritsObject* heritsObject()const;

	bool 	isWidget()const;

	CscsThread* thread()const;

	void 		moveToThread(CscsThread* thread);

	void 		setParent(CscsObject* parent);
	CscsObject* parent()const;

	CscsObjectPrivate* d_func()const;


	const CscsObject* receiveFrom()const{
		return m_receiveFrom;
	}
	bool blockSignals(bool blocked){
		bool ret=m_signalsBlocked;
		m_signalsBlocked=blocked;
		return ret;
	}

	bool signalsBlocked()const{
		return m_signalsBlocked;
	}

	void deleteLater();

	template<typename R, typename...Args>
	inline void transmit(Args... args, const std::string& messageTopic){
			CscsString topic=CscsString::fromStdString(messageTopic);
			topic.remove(CscsChar(' '),CscsString::CaseInsensitive);
			topic.remove(CscsChar('('),CscsString::CaseInsensitive);
			topic.remove(CscsChar(')'),CscsString::CaseInsensitive);
			if(m_signalsBlocked&&topic!="destroyedCscsObject*") return ;
			for(int i=0; i<receivers.size();++i){
				if(receivers[i])
					receivers[i]->setSenderFrom(this);
			}
			bool res=sender().transmit<R, Args...>(std::forward<Args>(args)...,messageTopic);
			//clear sender signal object;
			if(res){
				for(int i=0; i<receivers.size();++i){
					if(receivers[i])
						receivers[i]->setSenderFrom(0);
				}
			}

	}


#ifdef D_WIN32	
	CscsSender& sender(){
		
		return m_sender;
	} 
	HWND handle()const;
	void setHandle(HWND hwnd);
#endif
//signals
SIGNALS:
	void destroyed(CscsObject* obj){}
protected:
	CscsObject(CscsObjectPrivate* dd,CscsObject* parent=0);
	virtual void timerEvent(CscsTimerEvent* e);
	virtual void childEvent(CscsChildEvent* e);
	virtual void customEvent(CscsCustomEvent* e);
	virtual void dataSensorEvent(CscsDataSensorEvent* e);
	virtual bool winProc(uint message, uint16 wParam, uint32 lParam) { return false;};

protected:
	CscsObjectPrivate* d;
	const char* classname; //類名
	void 	storeherits(const char* name);
	CscsSender m_sender;
private:
	//CscsMessageBus m_bus;
	Senders senders;
	Receivers receivers;
	Messages messages;

	CscsList<CscsHeritsObject*> heritsVec;
	bool m_signalsBlocked;
	
	inline void setSenderFrom(CscsObject* sender){
		m_receiveFrom=sender;
	}

	void reregisterTimers(void* pointer);

#ifdef D_UNIX
	CscsSender& sender(){
		
		return m_sender;
	} 
#endif

	CscsObject* m_receiveFrom;
	
	friend class CscsThreadInfo;
	friend class CscsApplicationPlusPrivate;
	friend class CscsApplicationPlus;
	friend class CscsObjectPrivate;
	friend class CscsSender;
	friend class CscsConnection;
	friend class CscsDataSensor;
	friend class CscsWinMessage;

	#ifdef D_DESIGNER_LIB
    friend class ::CscsObjectLayer;
    #endif
BEGIN_SUPERCLASS_PROPERTY(CscsObject)
META_WRITE_PROPERTY(void*,reregisterTimers, WRITE, reregisterTimers)
END_PROPERTY
};

class  CscsBoolBlocker
{
public:
    inline CscsBoolBlocker(bool &b):block(b), reset(b){block = true;}
    inline ~CscsBoolBlocker(){block = reset; }
private:
    bool &block;
    bool reset;
};



template <typename T> 
inline T scs_object_cast(CscsObject* o, const std::string& classname){
	if(!o) return 0;
	if (o->className()==classname||o->inherits(classname.data())){
		return  static_cast<T>(o);
	}
	return 0;
}

template <typename T> 
inline  T scs_object_cast(const CscsObject* o, const std::string& classname){
	if(!o) return 0;
	if (o->className()==classname||o->inherits(classname.data())){
		return  static_cast<T>(const_cast<CscsObject*>(o));
	}
	return 0;
}


END_NAMESPACE

#endif
