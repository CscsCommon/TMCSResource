#ifndef SCSSTRINGLIST_H
#define SCSSTRINGLIST_H
#include "scslist.h"
#include "scsstring.h"
#include "scsregexp.h"

BEGIN_NAMESPACE(Gemini)

class CscsStringList : public CscsList<CscsString>
{
public:
    inline CscsStringList() { }
    inline explicit CscsStringList(const CscsString &i) { append(i); }
    inline CscsStringList(const CscsStringList &l) : CscsList<CscsString>(l) { }
    inline CscsStringList(const CscsList<CscsString> &l) : CscsList<CscsString>(l) { }
     inline void sort();
    inline CscsString join(const CscsString &sep) const;

    inline CscsStringList filter(const CscsString &str, CscsString::CaseSensitivity cs = CscsString::CaseSensitive) const;
    inline bool contains(const CscsString &str, CscsString::CaseSensitivity cs = CscsString::CaseSensitive) const;

    inline CscsStringList &replaceInStrings(const CscsString &before, const CscsString &after, CscsString::CaseSensitivity cs = CscsString::CaseSensitive);


    inline CscsStringList operator+(const CscsStringList &other) const
    { 
    	CscsStringList n = *this; n += other; return n;
    }

    inline CscsStringList &operator<<(const CscsString &str)
    {   append(str); return *this; }
    inline CscsStringList &operator<<(const CscsStringList &l)
    { 
        *this += l; return *this;
    }

    inline CscsStringList filter(const CscsRegExp &rx) const;
    inline CscsStringList &replaceInStrings(const CscsRegExp &rx, const CscsString &after);
    inline int indexOf(const CscsRegExp &rx, int from = 0) const;
    inline int lastIndexOf(const CscsRegExp &rx, int from = -1) const;

    using CscsList<CscsString>::indexOf;
    using CscsList<CscsString>::lastIndexOf;

};

void StringList_sort(CscsStringList *that);
CscsString StringList_join(const CscsStringList *that, const CscsString &sep);
CscsStringList StringList_filter(const CscsStringList *that, const CscsString &str,
                                               CscsString::CaseSensitivity cs);
bool  StringList_contains(const CscsStringList *that, const CscsString &str, CscsString::CaseSensitivity cs);
void  StringList_replaceInStrings(CscsStringList *that, const CscsString &before, const CscsString &after,
                                      CscsString::CaseSensitivity cs);

void  StringList_replaceInStrings(CscsStringList *that, const CscsRegExp &rx, const CscsString &after);
CscsStringList  StringList_filter(const CscsStringList *that, const CscsRegExp &re);
int  StringList_indexOf(const CscsStringList *that, const CscsRegExp &rx, int from);
int  StringList_lastIndexOf(const CscsStringList *that, const CscsRegExp &rx, int from);

inline void CscsStringList::sort()
{
    StringList_sort(this);
}

inline CscsString CscsStringList::join(const CscsString &sep) const
{
    return StringList_join(this, sep);
}

inline CscsStringList CscsStringList::filter(const CscsString &str, CscsString::CaseSensitivity cs) const
{
    return StringList_filter(this, str, cs);
}

inline bool CscsStringList::contains(const CscsString &str, CscsString::CaseSensitivity cs) const
{
    return StringList_contains(this, str, cs);
}

inline CscsStringList &CscsStringList::replaceInStrings(const CscsString &before, const CscsString &after, CscsString::CaseSensitivity cs)
{
    StringList_replaceInStrings(this, before, after, cs);
    return *this;
}


inline CscsStringList &CscsStringList::replaceInStrings(const CscsRegExp &rx, const CscsString &after)
{
    StringList_replaceInStrings(this, rx, after);
    return *this;
}

inline CscsStringList CscsStringList::filter(const CscsRegExp &rx) const
{
    return StringList_filter(this, rx);
}

inline int CscsStringList::indexOf(const CscsRegExp &rx, int from) const
{
    return StringList_indexOf(this, rx, from);
}

inline int CscsStringList::lastIndexOf(const CscsRegExp &rx, int from) const
{
    return StringList_lastIndexOf(this, rx, from);
}

END_NAMESPACE

#endif