 /*Created by J.Wong 2018/09/19
 version:    version 1.0,
 dependency: base on  or greater than c++11
 function: type erase
 gcc4.9+
 */

#ifndef CSCSUTILS_H
#define CSCSUTILS_H

#include <regex>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <limits.h>
#include <sys/types.h>
#include <stdlib.h>
#include <errno.h>
#include <list>
#include <string>
#include <vector>
#include <cmath>
#include <ctype.h>
#include <config.h>
#include "scstypes.h"

BEGIN_NAMESPACE(Gemini)

inline bool scs_isascii(int c){
	#ifdef D_WIN32
		return iswascii(c);
	#else
		return isascii(c);
	#endif
}

//void scs_client_enqueue(const CscsEvent* e);
//CscsEvent*  scs_client_dequeue();

//bool scs_client_queue_empty();

//bool scs_set_socket_handler(int sockfd, int type,CscsObject* obj,bool enable);
//bool processNextEvent(bool canWait);

std::string scs_simplifywhitespace(std::string str);
stringarray scs_string_split(std::string str, char split);

char* scs_strdup(const char* src);
bool  scs_strcmp(const char* src, const char* dst);

bool scs_is_upper(char ch);
bool scs_is_digit(char ch);
char scs_to_lower(char ch);
int  scs_to_int(const std::string& input, bool* ok=0,int base=10);
double scs_to_double(const std::string& input,bool* ok=0);
template <typename Iterator>
void scs_delete_all(Iterator begin, Iterator end)
{
    while (begin != end) {
        delete *begin;
        ++begin;
    }
}

template <typename Container>
inline void scs_delete_all(const Container &c)
{
    scs_delete_all(c.begin(), c.end());
    //c.clear();
}


inline bool scs_fuzzy_null(double d)
{
    return std::fabs(d)<= 0.000000000001;
}

int scsAllocMore(int alloc, int extra);


template <typename RandomAccessIterator, typename T>
inline RandomAccessIterator scsBinaryFind(RandomAccessIterator begin, RandomAccessIterator end, const T &value)
{
    int l = 0;
    int r = end - begin - 1;
    if (r < 0)
        return end;
    int i = (l + r + 1) / 2;

    while (r != l) {
        if (value < begin[i])
            r = i - 1;
        else
            l = i;
        i = (l + r + 1) / 2;
    }
    if (begin[i] < value || value < begin[i])
        return end;
    else
        return begin + i;
}

inline int scsscsIsLittleEndian()
{
    union w
    {
        int a;
        char b;
    }w1;
    w1.a = 1;
    return (w1.b == 1);

}

template <typename T>
inline void scsAtomicAssignX(T *&d, T *x)
{
    x->ref++;
    {
        T* tmp=x;
        x=d;
        d=tmp;
    }
    if (!--x->ref)
        delete x;
}


template <typename T>
inline void scsAtomicDetachX(T *&d)
{
    if (d->ref == 1)
        return;
    T *x = new T(*d);
    {
        T* tmp=x;
        x=d;
        d=tmp;
    }
    if (!--x->ref)
        delete x;
}

inline void *scs_atomic_set_ptr(volatile void *ptr, void *newval)
{
    register void *ret = *reinterpret_cast<void * volatile *>(ptr);
    *reinterpret_cast<void * volatile *>(ptr) = newval;
    return ret;
}

template <typename T>
inline T scsAtomicSetPtrX(volatile T *ptr, T newval)
{ return static_cast<T>(scs_atomic_set_ptr(ptr, newval)); }



//bit最大位为63
void writeLED(uint bit, bool on);
//测试LED状态
bool testLED(uint bit);

END_NAMESPACE

#endif
