#ifndef SCSBUFFER_H
#define SCSBUFFER_H

#include "scsdevice.h"
#include "scsobject.h"
#include "scsbytearray.h"

BEGIN_NAMESPACE(Gemini)

class CscsBufferPrivate;

class  CscsBuffer : public CscsDevice
{

public:
     explicit CscsBuffer(CscsObject *parent = 0);
     CscsBuffer(CscsByteArray *buf, CscsObject *parent = 0);
    ~CscsBuffer();

    CscsByteArray &buffer();
    const CscsByteArray &buffer() const;
    void setBuffer(CscsByteArray *a);

    void setData(const CscsByteArray &data);
    inline void setData(const char *data, int len);
    const CscsByteArray &data() const;

    bool open(SCSOpenMode openMode);

    void close();
    int64 size() const;
    int64 pos() const;
    bool seek(int64 off);
    bool atEnd() const;
    bool canReadLine() const;

protected:
    int64 readData(char *data, int64 maxlen);
    int64 writeData(const char *data, int64 len);

private:
    CscsBufferPrivate* d_func()const;
};

inline void CscsBuffer::setData(const char *adata, int alen)
{ setData(CscsByteArray(adata, alen)); }

END_NAMESPACE

#endif