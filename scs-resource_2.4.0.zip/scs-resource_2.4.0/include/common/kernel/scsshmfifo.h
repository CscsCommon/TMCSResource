/*Created by J.Wong 2018/09/30
version:    version 1.0,
dependency: base on  or greater than c++11
function: type erase
gcc4.9+
*/

#ifndef CSCSSHMFIFO_H
#define CSCSSHMFIFO_H

typedef void (*Cleanup)(int signo);

typedef struct scs_shm_head{
	int dirty;
	int ref;
	int msg_type;
	int rd_idx;	 // 读位置
	int wr_idx;	 // 写位置
	int blocks;	 // 块数
	int blksz;   // 每块大小
	unsigned long long leds;
} scs_head_t;

typedef struct scs_shmfifo {
	scs_head_t *p_head; // 共享内存段的头
	char *p_payload; // 有效数据地址
	int shmid;      // 共享内存id
	int sem_full;   // 表示满
	int sem_empty;  // 表示还有几个可消费
	int sem_mutex;  // 互斥量
}scs_shmfifo_t;

scs_shmfifo_t* scs_shmfifo_init(int key);

int	scs_fifo_blksz_get(scs_shmfifo_t *fifo);


int scs_shmfifo_put(scs_shmfifo_t *fifo, int msg_type, const void *buf);

int scs_shmfifo_get(scs_shmfifo_t *fifo, int* msg_type, void *buf);

void scs_shmfifo_destroy(scs_shmfifo_t *fifo);

void scs_exit_interrupt(Cleanup __cleanup);

unsigned long long scs_shmfifo_leds_get(scs_shmfifo_t *fifo);
//灯对应的bit位
void scs_shmfifo_leds_set(scs_shmfifo_t *fifo,unsigned int bit, bool on); 
#endif
