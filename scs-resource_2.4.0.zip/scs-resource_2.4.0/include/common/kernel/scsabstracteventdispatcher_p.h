#ifndef SCSABSTRACTDISPATHCER_P_H
#define SCSABSTRACTDISPATHCER_P_H
#include "scsobject_p.h"

BEGIN_NAMESPACE(Gemini)
class CscsAbstractEventDispatcher;

class CscsAbstractEventDispatcherPrivate:public CscsObjectPrivate
{
 
public:
    inline CscsAbstractEventDispatcherPrivate():CscsObjectPrivate(),event_filter(0){ 
    }
    void init();
    CscsAbstractEventDispatcher::EventFilter event_filter;
    CscsAbstractEventDispatcher* mm_func()const;

};
END_NAMESPACE

#endif