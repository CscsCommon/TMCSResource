 /*Created by J.Wong 2018/09/19
 version:    version 1.0,
 dependency: base on  or greater than c++11
 function: type erase
 gcc4.9+
 */


#ifndef CSCSEVENT_H
#define CSCSEVENT_H

//#include "scsmpoint.hpp"
#include "scsobject.h"
#include "scsflags.h"
#include "scsvariant.h"

BEGIN_NAMESPACE(Gemini)

class CscsEventPrivate;
class CscsEvent{

public:
	enum SCSType{
		None=0,
		Timer=1,
		MouseButtonPress=2,
		MouseButtonRelease=3,
		MouseButtonDbClick=4,
		MouseMove=5,
		KeyPress=6,
		KeyRelease=7,
		Key=8,
		Mouse=9,

		Accel=30,
		Wheel=31,
		Enter=35,
		Leave=36,
		Paint=37,
		Move=38,
		Resize=39,
		Create=40,
		Destroy=41,
		Show=42,
		Hide=43,
		WidgetUpdate=44,
		Close=45,
		Quit=46,

		PaintOnScreen=47,

		SockActive=50,
		DataSensor=51,
		
		ActivationChange=55,
		WindowActivate=56,
		WindowDeactivate=57,
		LayoutDirectionChange=59,
		WindowTitleChange=60,
		ApplicationFontChange=65,
		ApplicationLayoutDirectionChange=66,
		ApplicationPaletteChange=67,
		PaletteChange = 68,
		FontChange = 69,
		StyleChange = 70, 
		ThreadChange =71,
		ShowWindowRequest = 73,
	 	LayoutRequest = 76,
		Tablet=87,

		FocusIn =100,
		FocusOut=101,
		EnabledChange = 102,
		ShowToParent =103,
		HideToParent =104,
		MouseTrackingChange = 105,
		ZOrderChange = 126,

		WindowBlocked = 127,                    // window is about to be blocked modally
        WindowUnblocked = 128,                  // windows modal blocking has ended
		WindowStateChange=130,

		TouchBegin=194,
		TouchUpdate=195,
		TouchEnd=196,
		TouchCancel=209,
		SwipeBegin=214,
		SwipeUpdate=215,	//滑动距离更新
		SwipeEnd=216,
		ChildPolished=239,
		ChildInserted=240,
		ChildRemoved=241,
		ParentChange=242,
		ParentAboutToChange=243,

		
		UpdateRequest=245,
		RepaintSurface=246,

		InvokeEvent=252,
		PolishedRequest=253,
		Polish=254,
		LanguageChange=255,

			
		DeferredDelete=256,
		#ifdef D_WIN32
		WindowsPaint=257,
		WinEventAct=258,
		#endif
		
		Resource=260,
		User=1000,
		MaxUser=65535
	};




	CscsEvent(SCSType type):t(type),posted(false),spont(false),accepted(true){}

	virtual ~CscsEvent();

	SCSType type()const{
		return t;
	}

	bool spontaneous()const{return spont;}
	bool isAccepted(){ return accepted;}
	void setAccepted(bool accept){accepted =accept;}

	void accept(){ accepted=true;}
	void ignore(){ accepted=false;}
	
protected:
	SCSType t;
	CscsEventPrivate* d;
private:
	bool posted;
	bool spont;
	bool accepted;
	friend class CscsThreadInfo;
	friend class CscsApplicationPlusPrivate;
	friend class CscsApplicationPlus;
	friend class CscsApplicationPrivate;
	friend class CscsApplication;
};


class CscsTimerEvent:public CscsEvent
 {
 public:
 	CscsTimerEvent(int timerId):CscsEvent(Timer),id(timerId)
 	{

 	}

 	virtual ~CscsTimerEvent(){}

 	int timerId()const{
 		return id;
 	}

 protected:
 	int id;

 };

class CscsChildEvent:public CscsEvent{
public:
	CscsChildEvent(SCSType type, CscsObject* child):CscsEvent(type),c(child){}
	CscsObject* child()const{ return c; }
	bool inserted()const { return t==ChildInserted;}
	bool removed()const { return t==ChildRemoved;}
protected:
	CscsObject* c;
};

class CscsInvokeEvent:public CscsEvent{
public:
	CscsInvokeEvent(const CscsObject* sender,const char* method,CscsVariant param)
	:CscsEvent(InvokeEvent),sender_(sender),method_(method),arg_(param)
	{

	}
	~CscsInvokeEvent(){}

	inline const CscsObject* sender()const{return sender_;}
	inline const char* method(){return method_;}
	inline CscsVariant arg()const{return arg_;}
private:
	const CscsObject* sender_;
	const char* method_;
	CscsVariant arg_;
};

class CscsCustomEvent:public CscsEvent{
public:
	CscsCustomEvent(int type):CscsEvent(SCSType(type)),d(0){ }
	CscsCustomEvent(int type, void* data):CscsEvent(SCSType(type)),d(data){ }

	void setData(void* data){
		d=data;
	}
	void* data()const{
		return d;
	}
protected:
	void* d;
};

class CscsResourceEvent:public CscsEvent{

public:
	enum Action{
		None,
		Add,
		Delete
	};

	enum SourceType{
		Unkown,
		MessageBus
	};

	CscsResourceEvent()
	:CscsEvent(Resource),
	d(0),
	act(None),
	sourceT(Unkown)
	{

	}

	CscsResourceEvent(void* source,int action, int type)
	:CscsEvent(Resource)
	,d(source),
	act(action),
	sourceT(type)
	{ 

	}

	inline void setAction(int action){
		act=action;
	}

	inline int action()const{
		return act;
	}

	inline void setSourceType(int type){
		sourceT=type;
	}

	inline int sourceType()const{
		return sourceT;
	}

	inline void setSource(void* source){
		d=source;
	}
	inline void* source()const{
		return d;
	}
protected:
	void* d;
	int act:8;
	int sourceT:8;
};



END_NAMESPACE

#endif
