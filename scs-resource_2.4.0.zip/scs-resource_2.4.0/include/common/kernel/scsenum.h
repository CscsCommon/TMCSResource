#ifndef SCSENUM
#define SCSENUM
#include <kernel/scsflags.h>
#include <painting/scsenum.h>

BEGIN_NAMESPACE(Gemini)

namespace SCS{

    enum AspectRatioMode{
    IgnoreAspectRatio,          //The size is scaled freely. The aspect ratio is not preserved.
    KeepAspectRatio,            //The size is scaled to a rectangle as large as possible inside a given rectangle, preserving the aspect ratio.
    KeepAspectRatioByExpanding  //The size is scaled to a rectangle as small as possible outside a given rectangle, preserving the aspect ratio.
    };

    enum FillRule{
        WindingFill,
        OddEvenFill
    };

    enum SizeMode{
        RelativeSize,
        AbsoluteSize
    };

     enum WindowState {
        WindowNoState    = 0x00000000,
        WindowMinimized  = 0x00000001,
        WindowMaximized  = 0x00000002,
        WindowFullScreen = 0x00000004,
        WindowActive     = 0x00000008
    };
    SCS_DECLARE_FLAGS(WindowStates,WindowState)

	enum WindowType{
		Widget = 0x00000000,
        Window = 0x00000001,
        Dialog = 0x00000002 | Window,
        Sheet = 0x00000004 | Window,
        Drawer = Sheet | Dialog,
        Popup = 0x00000008 | Window,
        Tool = Popup | Dialog,
        ToolTip = Popup | Sheet,
        SplashScreen = ToolTip | Dialog,
        Desktop = 0x00000010 | Window,
        SubWindow = 0x00000012,
        ForeignWindow = 0x00000020 | Window,
        CoverWindow = 0x00000040 | Window,
        WindowType_Mask = 0x000000ff,

        FramelessWindowHint = 0x00000800,
        WindowTitleHint = 0x00001000,
        WindowSystemMenuHint = 0x00002000,
        WindowMinimizeButtonHint = 0x00004000,
        WindowMaximizeButtonHint = 0x00008000,
        WindowMinMaxButtonsHint = WindowMinimizeButtonHint | WindowMaximizeButtonHint,
        WindowContextHelpButtonHint = 0x00010000,
        WindowShadeButtonHint = 0x00020000,
        WindowStaysOnTopHint = 0x00040000,
        WindowTransparentForInput = 0x00080000,
        WindowOverridesSystemGestures = 0x00100000,
        WindowDoesNotAcceptFocus = 0x00200000,
        MaximizeUsingFullscreenGeometryHint = 0x0040000,
	};
	SCS_DECLARE_FLAGS(WindowFlags, WindowType)

	enum WidgetAttribute {
        WA_Disabled = 0,
        WA_UnderMouse = 1,
        WA_MouseTracking = 2,
        WA_ContentsPropagated,
        WA_OpaquePaintEvent = 4,
        WA_NoBackground = WA_OpaquePaintEvent,
        WA_LaidOut = 7,
        WA_PaintOnScreen = 8,
        WA_NoSystemBackground = 9,
        WA_UpdatesDisabled = 10,
        WA_Mapped = 11,
        WA_InputMethodEnabled = 14,
        WA_WState_Visible = 15,
        WA_WState_Hidden = 16,

        WA_ForceDisabled = 32,
        WA_KeyCompression = 33,
        WA_PendingMoveEvent = 34,
        WA_PendingResizeEvent = 35,
        WA_SetPalette = 36,
        WA_SetFont = 37,
        WA_SetCursor = 38,
        WA_NoChildEventsFromChildren = 39,
        WA_Resized = 42,
        WA_Moved = 43,
        WA_PendingUpdate = 44,
        WA_InvalidSize = 45,
        WA_LayoutOnEntireRect = 48,
        WA_TransparentForSwipeEvent=49,
        WA_TransparentForMouseEvents=51,
        WA_PaintUnclipped = 52,
        WA_NoMouseReplay = 54,
        WA_DeleteOnClose = 55,
        WA_RightToLeft = 56,
        WA_SetLayoutDirection = 57,

        WA_NoChildEventsForParent = 58,
        WA_ForceUpdatesDisabled = 59,

        WA_WState_Created = 60,
        WA_WState_InPaintEvent = 62,
        WA_WState_Reparented = 63,
        WA_WState_ConfigPending = 64,
        WA_WState_Polished = 66,
        WA_WState_OwnSizePolicy = 68,
        WA_WState_ExplicitShowHide = 69,
        WA_ShowModal = 70,
        WA_MouseNoMask = 71,
        WA_GroupLeader = 72,
        WA_NoMousePropagation = 73,
        WA_Hover = 74,
        WA_QuitOnClose = 76,

        WA_KeyboardFocusChange = 77,
        WA_WindowPropagation = 80,
        WA_SetStyle = 86,
        WA_StyledBackground = 93, // internal
        WA_StyleSheet = 97, // internal

        WA_ShowWithoutActivating = 98,
        WA_NativeWindow = 100,
        WA_DontCreateNativeAncestors = 101,

        WA_DontShowOnScreen = 103,
        WA_SetWindowModality = 118,
        WA_WState_WindowOpacitySet = 119, // internal
        WA_TranslucentBackground = 120,
        WA_AlwaysStackOnTop = 128,
        // Add new attributes before this line
        WA_AttributeCount
    };

    enum FocusReason{
        MouseFocusReason,
        TabFocusReason,
        BacktabFocusReason,
        ActiveWindowFocusReason,
        PopupFocusReason,
        ShortcutFocusReason,
        MenuBarFocusReason,
        OtherFocusReason,
        NoFocusReason

    };
    enum FocusPolicy{
        NoFocus=0,
        TabFocus=0x01,
        ClickFocus=0x02,
        StrongFocus=TabFocus|ClickFocus|0x08,
        WheelFocus=StrongFocus|0x04
    };

    // enum Key{
    //     Key_Escape=0x1000,
    //     Key_Tab=0x1001,
    //     Key_Backspace=0x1003,
    //     Key_Enter=0x1004,
    //     Key_Shift=0x1020,
    //     Key_Ctrl=0x1021,
    //     Key_Alt=0x1023,
    //     Key_CapsLock=0x1024,
    //     Key_Up=0x1013,
    //     Key_Down=0x1015,
    //     Key_Left=0x1012,
    //     Key_Right=0x1014,
    //     Key_PageUp=0x1016,
    //     Key_PageDown=0x1017,
    //     Key_Home=0x1010,
    //     Key_End=0x1011
    // };

   enum CursorShape{
    ArrowCursor,
    UpArrowCursor,
    CrossCursor,
    WaitCursor,
    IBeamCursor,
    SizeVCursor,
    SizeHCursor,
    SizeBDialCursor,
    SizeFDialCursor,
    SizeAllCursor,
    BlankCursor,
    SplitVCursor,
    SplitHCursor,
    PointingHandCursor,
    ForbiddenCursor,
    WhatThisCursor,
    BusyCursor,
    OpenHandCursor,
    CloseHandCursor,
    DragCopyCursor,
    DragMoveCursor,
    DragLinkCursor,
    LastCursor=DragLinkCursor,
    BitmapCursor=24,
    CustomCursor=25,
   };

   enum LayoutDirection{
    LeftToRight,
    RightToLeft,
    LayoutDirectionAuto
   };


   enum AlignmentFlag {
        AlignLeft = 0x0001,
        AlignLeading = AlignLeft,
        AlignRight = 0x0002,
        AlignTrailing = AlignRight,
        AlignHCenter = 0x0004,
        AlignJustify = 0x0008,
        AlignAbsolute = 0x0010,
        AlignHorizontal_Mask = AlignLeft | AlignRight | AlignHCenter | AlignJustify | AlignAbsolute,

        AlignTop = 0x0020,
        AlignBottom = 0x0040,
        AlignVCenter = 0x0080,
        AlignBaseline = 0x0100,
        AlignVertical_Mask = AlignTop | AlignBottom | AlignVCenter | AlignBaseline,
        AlignCenter = AlignVCenter | AlignHCenter
    };

    SCS_DECLARE_FLAGS(Alignment, AlignmentFlag)

    enum Orientation{
        Horizontal=0x01,
        Vertical=0x02
    };
    SCS_DECLARE_FLAGS(Orientations,Orientation)

     enum ArrowType {
        NoArrow,
        UpArrow,
        DownArrow,
        LeftArrow,
        RightArrow
    };

    enum CheckState {
        Unchecked,
        PartiallyChecked,
        Checked
    };

    enum ToolButtonStyle {
        ToolButtonIconOnly,
        ToolButtonTextOnly,
        ToolButtonTextBesideIcon,
        ToolButtonTextUnderIcon,
        ToolButtonFollowStyle
    };

     enum Corner {
        TopLeftCorner = 0x00000,
        TopRightCorner = 0x00001,
        BottomLeftCorner = 0x00002,
        BottomRightCorner = 0x00003
    };

    enum CaseSensitivity{
        CaseInsensitive,
        CaseSensitive
    };

    enum CursorPosition{
        CursorBetweenCharacters,
        CursorOnCharacter
    };

    enum ToolBarArea{
        LeftToolBarArea = 0x1,
        RightToolBarArea = 0x2,
        TopToolBarArea = 0x4,
        BottomToolBarArea = 0X8,

        ToolBarArea_Mask = 0xf,
        AllToolBarAreas = ToolBarArea_Mask,
        NoToolBarArea = 0
    };
    SCS_DECLARE_FLAGS(ToolBarAreas, ToolBarArea)
    enum ToolBarAreaSizes{
        NToolBarArea = 4
    };

        enum TextFlag {
        TextSingleLine = 0x0100,
        TextDontClip = 0x0200,
        TextExpandTabs = 0x0400,
        TextShowMnemonic = 0x0800,
        TextWordWrap = 0x1000,
        TextWrapAnywhere = 0x2000,
        TextDontPrint = 0x4000,
        TextIncludeTrailingSpaces = 0x08000000,
        TextHideMnemonic = 0x8000,
        TextJustificationForced = 0x10000,
        TextForceLeftToRight = 0x20000,
        TextForceRightToLeft = 0x40000,
        TextLongestVariant = 0x80000
    };


    enum ScrollBarPolicy {
        ScrollBarAsNeeded,
        ScrollBarAlwaysOff,
        ScrollBarAlwaysOn
    };
	
	enum DockWidgetArea {
        LeftDockWidgetArea = 0x1,
        RightDockWidgetArea = 0x2,
        TopDockWidgetArea = 0x4,
        BottomDockWidgetArea = 0x8,

        DockWidgetArea_Mask = 0xf,
        AllDockWidgetAreas = DockWidgetArea_Mask
    };
    enum {
        NDockWidgetAreas = 4
    };

    enum Axis {
        XAxis,
        YAxis,
        ZAxis
    };

    SCS_DECLARE_FLAGS(DockWidgetAreas, DockWidgetArea)

    enum KeyboardModifier {
        NoModifier           = 0x00000000,
        ShiftModifier        = 0x02000000,
        ControlModifier      = 0x04000000,
        AltModifier          = 0x08000000,
        KeypadModifier       = 0x20000000,
        KeyboardModifierMask = 0xfe000000
    };
    SCS_DECLARE_FLAGS(KeyboardModifiers, KeyboardModifier)

     enum MatchFlag {
        MatchExactly = 0,
        MatchContains = 1,
        MatchStartsWith = 2,
        MatchEndsWith = 3,
        MatchRegExp = 4,
        MatchWildcard = 5,
        MatchFixedString = 8,
        MatchCaseSensitive = 16,
        MatchWrap = 32,
        MatchRecursive = 64
    };
    SCS_DECLARE_FLAGS(MatchFlags, MatchFlag)

    enum DropAction {
        CopyAction = 0x1,
        MoveAction = 0x2,
        LinkAction = 0x4,
        ActionMask = 0xff,
        TargetMoveAction = 0x8002,
        IgnoreAction = 0x0
    };
    SCS_DECLARE_FLAGS(DropActions, DropAction)

    enum ItemDataRole {
        DisplayRole = 0,
        DecorationRole = 1,
        EditRole = 2,
        ToolTipRole = 3,
        StatusTipRole = 4,
        WhatsThisRole = 5,
        FontRole = 6,
        TextAlignmentRole = 7,
        BackgroundColorRole = 8,
        TextColorRole = 9,
        BackgroundRole=8,
        ForegroundRole=9,
        CheckStateRole = 10,
        AccessibleTextRole = 11,
        AccessibleDescriptionRole = 12,
        SizeHintRole=13,
        UserRole = 32
    };

    enum SortOrder {
        AscendingOrder,
        DescendingOrder
    };

    enum TextElideMode {
        ElideLeft,
        ElideRight,
        ElideMiddle,
        ElideNone
    };

    enum ItemFlag {
        ItemIsSelectable = 1,
        ItemIsEditable = 2,
        ItemIsDragEnabled = 4,
        ItemIsDropEnabled = 8,
        ItemIsUserCheckable = 16,
        ItemIsEnabled = 32,
        ItemIsTristate = 64
    };
    SCS_DECLARE_FLAGS(ItemFlags, ItemFlag)

    enum HitTestAccuracy{
        ExactHit,
        FuzzyHit
    };

    enum WhiteSpaceMode {
        WhiteSpaceNormal,
        WhiteSpacePre,
        WhiteSpaceNoWrap,
        WhiteSpaceModeUndefined = -1
    };

    enum TextInteractionFlag {
        NoTextInteraction         = 0,
        TextSelectableByMouse     = 1,
        TextSelectableByKeyboard  = 2,
        LinksAccessibleByMouse    = 4,
        LinksAccessibleByKeyboard = 8,
        TextEditable              = 16,

        TextEditorInteraction     = TextSelectableByMouse | TextSelectableByKeyboard | TextEditable,
        TextBrowserInteraction    = TextSelectableByMouse | LinksAccessibleByMouse | LinksAccessibleByKeyboard
    };
    SCS_DECLARE_FLAGS(TextInteractionFlags, TextInteractionFlag)

    enum TextFormat {
        PlainText,
        RichText,
        AutoText
    };

}

SCS_DECLARE_OPERATORS_FOR_FLAGS(SCS::WindowFlags)
SCS_DECLARE_OPERATORS_FOR_FLAGS(SCS::Alignment)
SCS_DECLARE_OPERATORS_FOR_FLAGS(SCS::Orientations)
SCS_DECLARE_OPERATORS_FOR_FLAGS(SCS::WindowStates)
SCS_DECLARE_OPERATORS_FOR_FLAGS(SCS::DockWidgetAreas)
SCS_DECLARE_OPERATORS_FOR_FLAGS(SCS::ToolBarAreas)
SCS_DECLARE_OPERATORS_FOR_FLAGS(SCS::KeyboardModifiers)
SCS_DECLARE_OPERATORS_FOR_FLAGS(SCS::MatchFlags)
SCS_DECLARE_OPERATORS_FOR_FLAGS(SCS::ItemFlags)
SCS_DECLARE_OPERATORS_FOR_FLAGS(SCS::DropActions)
SCS_DECLARE_OPERATORS_FOR_FLAGS(SCS::TextInteractionFlags)

class  CscsInternal {
public:
    enum PaintDeviceFlags {
        UnknownDevice = 0x00,
        Widget = 0x01,
        Pixmap = 0x02,
        Image = 0x03,
        Printer = 0x04,
        Picture = 0x05
    };
    enum RelayoutType {
        RelayoutNormal,
        RelayoutDragging,
        RelayoutDropped
    };
};

END_NAMESPACE
#endif