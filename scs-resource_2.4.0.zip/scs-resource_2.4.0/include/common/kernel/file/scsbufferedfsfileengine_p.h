#ifndef SCSBUFFEREDFSFILEENGINE_H
#define SCSBUFFEREDFSFILEENGINE_H

#include "scsfileengine.h"
#include "scsfsfileengine.h"

BEGIN_NAMESPACE(Gemini)

class CscsBufferedFSFileEnginePrivate;
class CscsBufferedFSFileEngine : public CscsFSFileEngine
{
    CscsBufferedFSFileEnginePrivate* d_func()const;
public:
    CscsBufferedFSFileEngine(const CscsString &fileName = CscsString());
    ~CscsBufferedFSFileEngine();

    Type type() const;
    bool open(int flags);
    bool open(int flags, FILE *fh);
    bool close();
    bool flush();
    int64 at() const;
    bool seek(int64);
    int64 read(char *data, int64 maxlen);
    int64 readLine(char *data, int64 maxlen);
    int64 write(const char *data, int64 len);
};

class CscsBufferedFSFileEnginePrivate : public CscsFSFileEnginePrivate
{
    CscsBufferedFSFileEngine* mm_func()const{
    	return reinterpret_cast<CscsBufferedFSFileEngine*>(mm_ptr);
    }

public:
    inline CscsBufferedFSFileEnginePrivate()
    {
        fh = 0;
        lastIOCommand = IOFlushCommand;
        closeFileHandle = false;
    }

    FILE *fh;
    bool closeFileHandle;
    
    enum LastIOCommand
    {
        IOFlushCommand,
        IOReadCommand,
        IOWriteCommand
    };
    LastIOCommand  lastIOCommand;
};

END_NAMESPACE

#endif