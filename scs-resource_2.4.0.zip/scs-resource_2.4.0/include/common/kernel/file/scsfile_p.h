#ifndef SCSFILEPRIV_H
#define SCSFILEPRIV_H

#include <kernel/scsdevice_p.h>
#include <kernel/scsbytearray.h>
#include <algorithm>
#include <stdio.h>
#include "scsfile.h"
#include "scsfileengine.h"

BEGIN_NAMESPACE(Gemini)

class CscsCircularBuffer {
    CscsByteArray buf[2];
    uint curr_used, start_off, start_buff, curr_buff, buff_growth;
public:
    inline CscsCircularBuffer(uint growth) : curr_used(0), start_off(0), start_buff(0),
                                          curr_buff(0), buff_growth(growth) { }

    char *alloc(uint buflen);
    char *take(uint maxsize, uint *realsize=0);
    inline void free(uint buflen);
    void push(char c);
    inline void truncate(uint len) { curr_used -= len; }

    inline int growth() const { return buff_growth; }
    inline int numBuffers() const { return 2; }
    inline bool isEmpty() const { return !used(); }
    inline uint used() const { return curr_used; }
    inline void clear() { if(!isEmpty()) free(used()); }
};

inline char *CscsCircularBuffer::alloc(uint size)
{
    if(buf[curr_buff].size() <
       (int)(curr_used+size+(curr_buff == start_buff ? start_off : 0))) {
        if(curr_buff == start_buff && buf[curr_buff].size()) {
            buf[curr_buff].resize(start_off + curr_used);
            curr_buff = !curr_buff;
            if(!buf[curr_buff].size())
                buf[curr_buff].resize(buff_growth*2);
        } else {
            int sz = buf[curr_buff].size();
            buf[curr_buff].resize(std::max((uint)sz + (sz / 2), (buff_growth*2)));
        }
    }
    int off = curr_used;
    curr_used += size;
    if(curr_buff != start_buff)
        off -= buf[start_buff].size() - start_off;
    else
        off += start_off;
    return buf[curr_buff].data()+off;
}
inline char *CscsCircularBuffer::take(uint size, uint *real_size)
{
    if(size > curr_used) {
        printf("Warning: asked to take too much %d [%d]\n", size, curr_used);
        size = curr_used;
    }
    if(real_size)
        *real_size = std::min(size, buf[start_buff].size() - start_off);
    return buf[start_buff].data()+start_off;
}

inline void CscsCircularBuffer::free(uint size)
{
    if(size > curr_used) {
        printf("Warning: asked to free too much %d [%d]\n", size, curr_used);
        size = curr_used;
    }
    curr_used -= size;
    if(curr_used == 0) {
        curr_buff = start_buff = start_off = 0;
        return;
    }

    uint start_size = buf[start_buff].size() - start_off;
    if(start_size > size) {
        start_off += size;
    } else if(start_buff != curr_buff) {
        start_buff = curr_buff;
        start_off = start_size - size;
    } else {
        start_off = 0;
    }
}

inline void CscsCircularBuffer::push(char ch)
{
    curr_used++;
    buf[start_buff].insert(start_off, ch);
}



class CscsFilePrivate : public CscsDevicePrivate
{

    CscsFilePrivate* d_func()const;

protected:
    CscsFilePrivate();
    ~CscsFilePrivate();

    bool openExternalFile(int flags, int fd);
    bool openExternalFile(int flags, FILE *fh);

    CscsString fileName;
    mutable CscsFileEngine *fileEngine;
    bool isOpen;

    bool lastWasWrite;
    CscsRingBuffer writeBuffer;
    inline bool ensureFlushed() const;

    bool putCharHelper(char c);

    CscsFile::FileError error;
    CscsString errorString;
    void setError(CscsFile::FileError err);
    void setError(CscsFile::FileError err, const CscsString &errorString);
    void setError(CscsFile::FileError err, int errNum);

private:
    static CscsFile::EncoderFn encoder;
    static CscsFile::DecoderFn decoder;
    friend class CscsFile;
};

END_NAMESPACE

#endif