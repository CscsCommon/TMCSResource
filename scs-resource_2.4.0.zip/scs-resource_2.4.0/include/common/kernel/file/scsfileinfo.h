#ifndef SCSFILEINFO_H
#define SCSFILEINFO_H

#include "scsfile.h"
#include <kernel/scslist.h>
#include <kernel/scstime.h>

BEGIN_NAMESPACE(Gemini)

class CscsDir;
class CscsFileInfoPrivate;
class  CscsFileInfo
{
public:
    CscsFileInfo();
    CscsFileInfo(const CscsString &file);
    CscsFileInfo(const CscsFile &file);
    CscsFileInfo(const CscsDir &dir, const CscsString &file);
    CscsFileInfo(const CscsFileInfo &fileinfo);
    ~CscsFileInfo();

    CscsFileInfo &operator=(const CscsFileInfo &fileinfo);
    bool operator==(const CscsFileInfo &fileinfo);
    inline bool operator!=(const CscsFileInfo &fileinfo) { return !(operator==(fileinfo)); }

    void setFile(const CscsString &file);
    void setFile(const CscsFile &file);
    void setFile(const CscsDir &dir, const CscsString &file);
    bool exists() const;
    void refresh();

    CscsString filePath() const;
    CscsString absoluteFilePath() const;
    CscsString canonicalFilePath() const;
    CscsString fileName() const;
    CscsString baseName() const;
    CscsString completeBaseName() const;
    CscsString suffix() const;
    CscsString completeSuffix() const;

    CscsString path() const;
    CscsString absolutePath() const;
    CscsString canonicalPath() const;
    CscsDir dir() const;
    CscsDir absoluteDir() const;

    bool isReadable() const;
    bool isWritable() const;
    bool isExecutable() const;
    bool isHidden() const;

    bool isRelative() const;
    inline bool isAbsolute() const { return !isRelative(); }
    bool makeAbsolute();

    bool isFile() const;
    bool isDir() const;
    bool isSymLink() const;
    bool isRoot() const;

    CscsString readLink() const;

    CscsString owner() const;
    uint ownerId() const;
    CscsString group() const;
    uint groupId() const;

    bool permission(CscsFile::Permissions permissions) const;
    CscsFile::Permissions permissions() const;

    int64 size() const;

    CscsDateTime created() const;
    CscsDateTime lastModified() const;
    CscsDateTime lastRead() const;

    void detach();

    bool caching() const;
    void setCaching(bool on);

protected:
    CscsFileInfoPrivate *d_ptr;
private:
    CscsFileInfoPrivate* d_func()const;
    friend class CscsFileInfoPrivate;
};

SCS_DECLARE_TYPENAME_INFO(CscsFileInfo, SCS_MOVABLE_TYPE)

typedef CscsList<CscsFileInfo> CscsFileInfoList;


END_NAMESPACE

#endif