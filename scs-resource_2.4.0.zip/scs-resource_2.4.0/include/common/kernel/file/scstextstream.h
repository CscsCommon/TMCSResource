#ifndef SCSTEXTSTREAM_H
#define SCSTEXTSTREAM_H

#include <kernel/scsdevice.h>
#include <kernel/scsstring.h>
#include <kernel/scschar.h>
#include <kernel/scsflags.h>
#include <stdio.h>

BEGIN_NAMESPACE(Gemini)

class CscsTextStreamPrivate;
class  CscsTextStream:public CscsNoCopyable                               // text stream class
{
    CscsTextStreamPrivate* d_func()const;
public:
    enum RealNumberNotation {
        SmartNotation,
        FixedNotation,
        ScientificNotation
    };
    enum FieldAlignment {
        AlignLeft,
        AlignRight,
        AlignCenter,
        AlignAccountingStyle
    };
    enum NumberFlag {
        ShowBase = 0x1,
        ForcePoint = 0x2,
        ForceSign = 0x4,
        UppercaseBase = 0x8,
        UppercaseDigits = 0x10
    };
    SCS_DECLARE_FLAGS(NumberFlags, NumberFlag)

    CscsTextStream();
    explicit CscsTextStream(CscsDevice *device);
    explicit CscsTextStream(FILE *fileHandle, CscsDevice::SCSOpenMode openMode = CscsDevice::ReadWrite);
    explicit CscsTextStream(CscsString *string, CscsDevice::SCSOpenMode openMode = CscsDevice::ReadWrite);
    explicit CscsTextStream(CscsByteArray *array, CscsDevice::SCSOpenMode openMode = CscsDevice::ReadWrite);
    explicit CscsTextStream(const CscsByteArray &array, CscsDevice::SCSOpenMode openMode = CscsDevice::ReadOnly);
    virtual ~CscsTextStream();


    void setDevice(CscsDevice *device);
    CscsDevice *device() const;

    void setString(CscsString *string, CscsDevice::SCSOpenMode openMode = CscsDevice::ReadWrite);
    CscsString *string() const;

    bool atEnd() const;
    void reset();
    void flush();
    bool seek(int64 pos);

    void skipWhiteSpace();

    CscsString readLine(int64 maxlen = 0);
    CscsString readAll();

    void setFieldAlignment(FieldAlignment alignment);
    FieldAlignment fieldAlignment() const;

    void setPadChar(CscsChar ch);
    CscsChar padChar() const;

    void setFieldWidth(int width);
    int fieldWidth() const;

    void setNumberFlags(NumberFlags flags);
    NumberFlags numberFlags() const;

    void setIntegerBase(int base);
    int integerBase() const;

    void setRealNumberNotation(RealNumberNotation notation);
    RealNumberNotation realNumberNotation() const;

    void setRealNumberPrecision(int precision);
    int realNumberPrecision() const;

    CscsTextStream &operator>>(CscsChar &ch);
    CscsTextStream &operator>>(char &ch);
    CscsTextStream &operator>>(signed short &i);
    CscsTextStream &operator>>(unsigned short &i);
    CscsTextStream &operator>>(signed int &i);
    CscsTextStream &operator>>(unsigned int &i);
    CscsTextStream &operator>>(signed long &i);
    CscsTextStream &operator>>(unsigned long &i);
    CscsTextStream &operator>>(int64 &i);
    CscsTextStream &operator>>(uint64 &i);
    CscsTextStream &operator>>(float &f);
    CscsTextStream &operator>>(double &f);
    CscsTextStream &operator>>(CscsString &s);
    CscsTextStream &operator>>(CscsByteArray &array);
    CscsTextStream &operator>>(char *c);

    CscsTextStream &operator<<(CscsChar ch);
    CscsTextStream &operator<<(char ch);
    CscsTextStream &operator<<(signed short i);
    CscsTextStream &operator<<(unsigned short i);
    CscsTextStream &operator<<(signed int i);
    CscsTextStream &operator<<(unsigned int i);
    CscsTextStream &operator<<(signed long i);
    CscsTextStream &operator<<(unsigned long i);
    CscsTextStream &operator<<(int64 i);
    CscsTextStream &operator<<(uint64 i);
    CscsTextStream &operator<<(float f);
    CscsTextStream &operator<<(double f);
    CscsTextStream &operator<<(const CscsString &s);
    CscsTextStream &operator<<(const CscsByteArray &array);
    CscsTextStream &operator<<(const char *c);
    CscsTextStream &operator<<(const void *ptr);

    void setCodec(CscsTextCodec *codec);
    void setCodec(const char *codecName);
    CscsTextCodec *codec() const;
    void setAutoDetectUnicode(bool enabled);
    bool autoDetectUnicode() const;
    void setGenerateByteOrderMark(bool generate);
    bool generateByteOrderMark() const;


private:
    CscsTextStreamPrivate *d_ptr;
    friend class CscsTextStreamPrivate;
};

SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsTextStream::NumberFlags)

typedef CscsTextStream & (*CscsTextStreamFunction)(CscsTextStream &);// manipulator function
typedef void (CscsTextStream::*CscsTSMFI)(int); // manipulator w/int argument
typedef void (CscsTextStream::*CscsTSMFC)(CscsChar); // manipulator w/CscsChar argument

class  CscsTextStreamManipulator
{
public:
    CscsTextStreamManipulator(CscsTSMFI m, int a) { mf = m; mc = 0; arg = a; }
    CscsTextStreamManipulator(CscsTSMFC m, CscsChar c) { mf = 0; mc = m; ch = c; }
    void exec(CscsTextStream &s) { if (mf) { (s.*mf)(arg); } else { (s.*mc)(ch); } }

private:
    CscsTSMFI mf;                                        // CscsTextStream member function
    CscsTSMFC mc;                                        // CscsTextStream member function
    int arg;                                          // member function argument
    CscsChar ch;
};

inline CscsTextStream &operator>>(CscsTextStream &s, CscsTextStreamFunction f)
{ return (*f)(s); }

inline CscsTextStream &operator<<(CscsTextStream &s, CscsTextStreamFunction f)
{ return (*f)(s); }

inline CscsTextStream &operator<<(CscsTextStream &s, CscsTextStreamManipulator m)
{ m.exec(s); return s; }


 CscsTextStream &bin(CscsTextStream &s);
 CscsTextStream &oct(CscsTextStream &s);
 CscsTextStream &dec(CscsTextStream &s);
 CscsTextStream &hex(CscsTextStream &s);

 CscsTextStream &showbase(CscsTextStream &s);
 CscsTextStream &forcesign(CscsTextStream &s);
 CscsTextStream &forcepoint(CscsTextStream &s);
 CscsTextStream &noshowbase(CscsTextStream &s);
 CscsTextStream &noforcesign(CscsTextStream &s);
 CscsTextStream &noforcepoint(CscsTextStream &s);

 CscsTextStream &uppercasebase(CscsTextStream &s);
 CscsTextStream &uppercasedigits(CscsTextStream &s);
 CscsTextStream &lowercasebase(CscsTextStream &s);
 CscsTextStream &lowercasedigits(CscsTextStream &s);

 CscsTextStream &fixed(CscsTextStream &s);
 CscsTextStream &scientific(CscsTextStream &s);

 CscsTextStream &left(CscsTextStream &s);
 CscsTextStream &right(CscsTextStream &s);
 CscsTextStream &center(CscsTextStream &s);

 CscsTextStream &endl(CscsTextStream &s);
 CscsTextStream &flush(CscsTextStream &s);
 CscsTextStream &reset(CscsTextStream &s);

 CscsTextStream &bom(CscsTextStream &s);

 CscsTextStream &ws(CscsTextStream &s);

inline CscsTextStreamManipulator scsSetFieldWidth(int width)
{
    CscsTSMFI func = &CscsTextStream::setFieldWidth;
    return CscsTextStreamManipulator(func,width);
}

inline CscsTextStreamManipulator scsSetPadChar(CscsChar ch)
{
    CscsTSMFC func = &CscsTextStream::setPadChar;
    return CscsTextStreamManipulator(func, ch);
}

inline CscsTextStreamManipulator scsSetRealNumberPrecision(int precision)
{
    CscsTSMFI func = &CscsTextStream::setRealNumberPrecision;
    return CscsTextStreamManipulator(func, precision);
}


END_NAMESPACE

#endif