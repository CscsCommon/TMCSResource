#ifndef SCSSTRINGMATCHER_H
#define SCSSTRINGMATCHER_H
#include "scsstring.h"

BEGIN_NAMESPACE(Gemini)

class CscsStringMatcherPrivate;

class  CscsStringMatcher
{
public:
    CscsStringMatcher();
    CscsStringMatcher(const CscsString &pattern,
                   CscsString::CaseSensitivity cs = CscsString::CaseSensitive);
    CscsStringMatcher(const CscsStringMatcher &other);
    ~CscsStringMatcher();

    CscsStringMatcher &operator=(const CscsStringMatcher &other);

    void setPattern(const CscsString &pattern);
    void setCaseSensitivity(CscsString::CaseSensitivity cs);

    int indexIn(const CscsString &str, int from = 0) const;
    inline CscsString pattern() const { return q_pattern; }
    inline CscsString::CaseSensitivity caseSensitivity() const { return q_cs; }

private:
    CscsStringMatcherPrivate *d_ptr;
    CscsString q_pattern;
    CscsString::CaseSensitivity q_cs;
    uint q_skiptable[256];
};

END_NAMESPACE

#endif