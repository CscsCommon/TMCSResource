#ifndef SCSATOMIC_H
#define SCSATOMIC_H
#include "scsnamespace.h"

BEGIN_NAMESPACE(Gemini)

inline int s_atomic_test_and_set_int(volatile int *ptr, int expected, int newval)
{
    if (*ptr == expected) {
        *ptr = newval;
        return 1;
    }
    return 0;
}

inline int s_atomic_test_and_set_ptr(volatile void *ptr, void *expected, void *newval)
{
    if (*reinterpret_cast<void * volatile *>(ptr) == expected) {
        *reinterpret_cast<void * volatile *>(ptr) = newval;
        return 1;
    }
    return 0;
}

inline int s_atomic_increment(volatile int *ptr)
{ return ++(*ptr); }

inline int s_atomic_decrement(volatile int *ptr)
{ return --(*ptr); }

inline int s_atomic_set_int(volatile int *ptr, int newval)
{
    register int ret = *ptr;
    *ptr = newval;
    return ret;
}

inline void *s_atomic_set_ptr(volatile void *ptr, void *newval)
{
    register void *ret = *reinterpret_cast<void * volatile *>(ptr);
    *reinterpret_cast<void * volatile *>(ptr) = newval;
    return ret;
}

struct CscsBasicAtomic {
    volatile int atomic;

    void init(int x = 0)
    { atomic = x; }

    inline bool ref()
    { return s_atomic_increment(&atomic) != 0; }

    inline bool deref()
    { return s_atomic_decrement(&atomic) != 0; }

    inline bool operator==(int x) const
    { return atomic == x; }

    inline bool operator!=(int x) const
    { return atomic != x; }

    inline bool operator!() const
    { return atomic == 0; }

    inline operator int() const
    { return atomic; }

    inline CscsBasicAtomic &operator=(int x)
    {
        (void) s_atomic_set_int(&atomic, x);
        return *this;
    }

    inline bool testAndSet(int expected, int newval)
    { return s_atomic_test_and_set_int(&atomic, expected, newval) != 0; }

    inline int exchange(int newval)
    { return s_atomic_set_int(&atomic, newval); }
};

template <typename T>
struct CscsBasicAtomicPointer
{
    volatile T *pointer;

    void init(T *t = 0)
    { pointer = t; }

    inline bool operator==(T *t) const
    { return pointer == t; }

    inline bool operator!=(T *t) const
    { return !operator==(t); }

    inline bool operator!() const
    { return operator==(0); }

    inline operator T *() const
    { return const_cast<T *>(pointer); }

    inline T *operator->() const
    { return const_cast<T *>(pointer); }

    inline CscsBasicAtomicPointer<T> &operator=(T *t)
    {
        (void) s_atomic_set_ptr(&pointer, t);
        return *this;
    }

    inline bool testAndSet(T *expected, T *newval)
    { return s_atomic_test_and_set_ptr(&pointer, expected, newval); }

    inline T *exchange(T * newval)
    { return static_cast<T *>(s_atomic_set_ptr(&pointer, newval)); }
};

#define SCS_ATOMIC_INIT(a) { (a) }


template <typename T>
inline T scsAtomicSetPtr(volatile T *ptr, T newval)
{ return static_cast<T>(s_atomic_set_ptr(ptr, newval)); }

// High-level atomic integer operations
class CscsAtomic : public CscsBasicAtomic
{
public:
    inline CscsAtomic(int x = 0)
    { init(x); }
    inline CscsAtomic(const CscsAtomic &copy)
    { init(copy); }

    inline CscsAtomic &operator=(int x)
    {
        (void) CscsBasicAtomic::operator=(x);
        return *this;
    }

    inline CscsAtomic &operator=(const CscsAtomic &copy)
    {
        (void) CscsBasicAtomic::operator=(copy);
        return *this;
    }
};

// High-level atomic pointer operations
template <typename T>
class CscsAtomicPointer : public CscsBasicAtomicPointer<T>
{
public:
    inline CscsAtomicPointer(T *t = 0)
    { init(t); }
    inline CscsAtomicPointer(const CscsAtomicPointer<T> &copy)
    { init(copy); }

    inline CscsAtomicPointer<T> &operator=(T *t)
    {
        (void) CscsBasicAtomicPointer<T>::operator=(t);
        return *this;
    }

    inline CscsAtomicPointer<T> &operator=(const CscsAtomicPointer<T> &copy)
    {
        (void) CscsBasicAtomicPointer<T>::operator=(copy);
        return *this;
    }
};

template <typename T>
inline void scsAtomicAssign(T *&d, T *x)
{
    x->ref.ref();
    x = scsAtomicSetPtr(&d, x);
    if (!x->ref.deref())
        delete x;
}

template <typename T>
inline void scsAtomicAssign(CscsBasicAtomicPointer<T> &d, T *x)
{
    x->ref.ref();
    x = d.exchange(x);
    if (!x->ref.deref())
        delete x;
}

template <typename T>
inline void scsAtomicAssign(CscsBasicAtomicPointer<T> &d, const CscsBasicAtomicPointer<T> &x)
{ scsAtomicAssign<T>(d, x); }

template <typename T>
inline void scsAtomicDetach(T *&d)
{
    if (d->ref == 1)
        return;
    T *x = new T(*d);
    x = scsAtomicSetPtr(&d, x);
    if (!x->ref.deref())
        delete x;
}

template <typename T>
inline void scsAtomicDetach(CscsBasicAtomicPointer<T> &d)
{
    if (d->ref == 1)
        return;
    T *x = new T(*d);
    x = d.exchange(x);
    if (!x->ref.deref())
        delete x;
}


END_NAMESPACE

#endif