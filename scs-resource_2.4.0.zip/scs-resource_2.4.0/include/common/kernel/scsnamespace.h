#ifndef SCSNAMESPACE_H
#define SCSNAMESPACE_H

#define BEGIN_NAMESPACE(VENDOR) \
namespace VENDOR { 


#define END_NAMESPACE \
	 }


#define USING_NAMESPACE(VENDOR) \
	using namespace VENDOR ;

#define NAMESPACE(VENDOR) VENDOR



#endif

