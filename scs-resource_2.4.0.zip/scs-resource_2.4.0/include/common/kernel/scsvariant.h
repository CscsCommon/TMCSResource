#ifndef SCSVARIANT_H
#define SCSVARIANT_H
#include "scsatomic.h"
#include "scslist.h"
#include "scsmap.h"
#include "scstypeinfo.h"

BEGIN_NAMESPACE(Gemini)

class CscsDate;
class CscsDateTime;
class CscsLine;
class CscsLineF;
class CscsLocale;
class CscsString;
class CscsStringList;
class CscsBitArray;
class CscsTime;
class CscsPoint;
class CscsPointF;
class CscsSize;
class CscsSizeF;
class CscsRect;
class CscsRectF;
class CscsRgba;
class CscsUrl;
class CscsVariant;
class CscsImage;
class CscsFont;
class CscsIcon;
class CscsBrush;
class CscsPen;
class CscsPalette;
class CscsPolygon;
class CscsRegion;
class CscsSizePolicy;
class CscsTextFormat;
class CscsTextLength;

class CscsVariantComparisonHelper;


template <typename T>
inline CscsVariant scsVariantFromValue(const T &);

template <typename T>
inline void scsVariantSetValue(CscsVariant &, const T &);

template<typename T>
inline T scsVariantValue(const CscsVariant &);

template<typename T>
inline bool scsVariantCanConvert(const CscsVariant &);

class CscsVariant{
	public:
		enum Type{
		Invalid = 0,
        Bool = 1,
        Int = 2,
        UInt = 3,
        LongLong = 4,
        ULongLong = 5,
        Double = 6,
        Char = 7,
		StdString=8,
        Map = 9,
        List = 10,
        String = 11,
        StringList = 12,
        ByteArray = 13,
        BitArray = 14,
        Date = 15,
        Time = 16,
        DateTime = 17,
        Url = 18,
        Locale = 19,
	
        Rect = 20,
        RectF = 21,
        Size = 22,
        SizeF = 23,
        Line = 24,
        LineF = 25,
        Point = 26,
        PointF = 27,
        Font = 64,
        Pixmap = 65,
        Brush = 66,
        Color = 67,
        Palette = 68,
        Icon = 69,
        Image = 70,
        Polygon = 71,
        Region = 72,
        Bitmap = 73,
        Cursor = 74,
        SizePolicy = 75,
        KeySequence = 76,
        Pen = 77,
        TextLength = 78,
        TextFormat = 79,
        UserType = 127,
        LastType = 0xffffffff
		};
		
	inline CscsVariant();
    ~CscsVariant();
    CscsVariant(Type type);
    CscsVariant(int typeOrUserType, const void *copy);
    CscsVariant(const CscsVariant &other);

    CscsVariant(int i);
    CscsVariant(uint ui);
    CscsVariant(int64 ll);
    CscsVariant(uint64 ull);
    CscsVariant(bool b);
    CscsVariant(double d);
    CscsVariant(const char *str);


    CscsVariant(const CscsByteArray &bytearray);
    CscsVariant(const CscsBitArray &bitarray);
    CscsVariant(const CscsString &string);
    CscsVariant(const CscsLatin1String &string);
    CscsVariant(const std::string&);
    CscsVariant(const CscsStringList &stringlist);
    CscsVariant(const CscsChar &schar);
    CscsVariant(const CscsDate &date);
    CscsVariant(const CscsTime &time);
    CscsVariant(const CscsDateTime &datetime);
    CscsVariant(const CscsList<CscsVariant> &list);
    CscsVariant(const CscsMap<CscsString,CscsVariant> &map);
    CscsVariant(const CscsSize &size);
    CscsVariant(const CscsSizeF &size);
    CscsVariant(const CscsPoint &pt);
    CscsVariant(const CscsPointF &pt);
    CscsVariant(const CscsLine &line);
    CscsVariant(const CscsLineF &line);
    CscsVariant(const CscsRect &rect);
    CscsVariant(const CscsRectF &rect);
    CscsVariant(const CscsRgba& rgba);
    CscsVariant(const CscsUrl &url);
    CscsVariant(const CscsLocale &locale);
    CscsVariant(const CscsImage& image);
    CscsVariant(const CscsFont& font);
    CscsVariant(const CscsIcon& icon);
    CscsVariant(const CscsBrush& brush);
    CscsVariant(const CscsPen& pen);
    CscsVariant(const CscsPalette& palette);
    CscsVariant(const CscsPolygon& poly);
    CscsVariant(const CscsRegion& region);
    CscsVariant(const CscsSizePolicy& plicy);
    CscsVariant(const CscsTextLength& textLength);
    CscsVariant(const CscsTextFormat& textFormat);
    CscsVariant& operator=(const CscsVariant &other);

    Type type() const;
    int userType() const;
    const char *typeName() const;

    bool canConvert(Type t) const;
    bool convert(Type t);

    inline bool isValid() const;
    bool isNull() const;

    void clear();

    void detach();
    inline bool isDetached() const;

    int toInt(bool *ok = 0) const;
    uint toUInt(bool *ok = 0) const;
    int64 toLongLong(bool *ok = 0) const;
    uint64 toULongLong(bool *ok = 0) const;
    bool toBool() const;
    double toDouble(bool *ok = 0) const;
    CscsByteArray toByteArray() const;
    CscsBitArray toBitArray() const;
    CscsString toString() const;
	std::string toStdString()const;
    CscsStringList toStringList() const;
    CscsChar toChar() const;
    CscsDate toDate() const;
    CscsTime toTime() const;
    CscsDateTime toDateTime() const;
    CscsList<CscsVariant> toList() const;
    CscsMap<CscsString,CscsVariant> toMap() const;
    CscsPoint toPoint() const;
    CscsPointF toPointF() const;
    CscsRect toRect() const;
    CscsRectF toRectF() const;
    CscsSize toSize() const;
    CscsSizeF toSizeF() const;
    CscsLine toLine() const;
    CscsLineF toLineF() const;
    CscsRgba toRgba()const;
    CscsUrl toUrl() const;
    CscsImage toImage()const;
    CscsFont toFont()const;
    CscsIcon toIcon()const;
    CscsBrush toBrush()const;
    CscsPen toPen()const;
    CscsPalette toPalette()const;
    CscsPolygon toPolygon()const;
    CscsRegion toRegion()const;
    CscsLocale toLocale() const;
    CscsSizePolicy toSizePolicy()const;
    CscsTextLength toTextLength()const;
    CscsTextFormat toTextFormat()const;



    static const char *typeToName(Type type);
    static Type nameToType(const char *name);


    void* data();
    const void *constData() const;
    inline const void *data() const { return constData(); }

    template<typename T>
    inline void setValue(const T &value);

    template<typename T>
    inline T value() const
    { return scsVariantValue<T>(*this); }

    template<typename T>
    static inline CscsVariant fromValue(const T &value)
    { return scsVariantFromValue(value); }

    template<typename T>
    bool canConvert() const
    { return scsVariantCanConvert<T>(*this); }
	
 public:
    struct PrivateShared
    {
        inline PrivateShared() : ref(1) { }
        inline PrivateShared(void *v) : ref(1) { ptr = v; }
        void *ptr;
        CscsAtomic ref;
    };
    struct Private
    {
        inline Private(): type(Invalid), is_shared(false), is_null(true) { data.ptr = 0; }
        inline Private(const Private &other)
            : data(other.data), type(other.type),
              is_shared(other.is_shared), is_null(other.is_null)
        {}
        union Data
        {
            int i;
            uint u;
            bool b;
            double d;
            int64 ll;
            uint64 ull;
            void *ptr;
            PrivateShared *shared;
        } data;
        uint type : 30;
        uint is_shared : 1;
        uint is_null : 1;
    };
 public:
    typedef void (*f_construct)(Private *, const void *);
    typedef void (*f_clear)(Private *);
    typedef bool (*f_null)(const Private *);

    typedef bool (*f_compare)(const Private *, const Private *);
    typedef bool (*f_convert)(const CscsVariant::Private *d, Type t, void *, bool *);
    typedef bool (*f_canConvert)(const CscsVariant::Private *d, Type t);
    struct Handler {
        f_construct construct;
        f_clear clear;
        f_null isNull;

        f_compare compare;
        f_convert convert;
        f_canConvert canConvert;
    };

    inline bool operator==(const CscsVariant &v) const
    { return cmp(v); }
    inline bool operator!=(const CscsVariant &v) const
    { return !cmp(v); }

protected:
    friend inline bool scsvariant_cast_helper(const CscsVariant &, CscsVariant::Type, void *);
    friend int scsRegisterGuiVariant();
    friend inline bool operator==(const CscsVariant &,
                                  const CscsVariantComparisonHelper &);
    Private d;

    static const Handler *handler;

    void create(int type, const void *copy);
    bool cmp(const CscsVariant &other) const;
};
SCS_DECLARE_TYPENAME_INFO(CscsVariant,SCS_MOVABLE_TYPE)

typedef CscsList<CscsVariant> CscsVariantList;
typedef CscsMap<CscsString, CscsVariant> CscsVariantMap;

inline bool scsvariant_cast_helper(const CscsVariant &v, CscsVariant::Type tp, void *ptr)
{ return CscsVariant::handler->convert(&v.d, tp, ptr, 0); }

template <typename T>
inline int scs_variant_type_id(T *)
{ return CscsTypeId<T>::scs_type_id(); }

template<>
inline int scs_variant_type_id(CscsVariantMap *) { return CscsVariant::Map; }
template<>
inline int scs_variant_type_id(CscsVariantList *) { return CscsVariant::List; }
template<>
inline int scs_variant_type_id(CscsStringList *) { return CscsVariant::StringList; }
// class CscsFont;
// template<>
// inline int scs_variant_type_id(CscsFont *) { return CscsVariant::Font; }
// class CscsPixmap;
// template<>
// inline int scs_variant_type_id(CscsPixmap *) { return CscsVariant::Pixmap; }
// class CscsBrush;
// template<>
// inline int scs_variant_type_id(CscsBrush *) { return CscsVariant::Brush; }
// template<>
// inline int scs_variant_type_id(CscsRect *) { return CscsVariant::Rect; }
// template<>
// inline int scs_variant_type_id(CscsSize *) { return CscsVariant::Size; }
// template<>
// inline int scs_variant_type_id(CscsSizeF *) { return CscsVariant::SizeF; }
// class CscsColor;
// template<>
// inline int scs_variant_type_id(CscsColor *) { return CscsVariant::Color; }
// class CscsPalette;
// template<>
// inline int scs_variant_type_id(CscsPalette *) { return CscsVariant::Palette; }
// class CscsIcon;
// template<>
// inline int scs_variant_type_id(CscsIcon *) { return CscsVariant::Icon; }
// class CscsPoint;
// template<>
// inline int scs_variant_type_id(CscsPoint *) { return CscsVariant::Point; }
// class CscsPointF;
// template<>
// inline int scs_variant_type_id(CscsPointF *) { return CscsVariant::PointF; }
// class CscsImage;
// template<>
// inline int scs_variant_type_id(CscsImage*) { return CscsVariant::Image; }
// class CscsPolygon;
// template<>
// inline int scs_variant_type_id(CscsPolygon *) { return CscsVariant::Polygon; }
// class CscsRegion;
// template<>
// inline int scs_variant_type_id(CscsRegion *) { return CscsVariant::Region; }
// class CscsBitmap;
// template<>
// inline int scs_variant_type_id(CscsBitmap *) { return CscsVariant::Bitmap; }
// class CscsCursor;
// template<>
// inline int scs_variant_type_id(CscsCursor *) { return CscsVariant::Cursor; }
// class CscsSizePolicy;
// template<>
// inline int scs_variant_type_id(CscsSizePolicy *) { return CscsVariant::SizePolicy; }
template<>
inline int scs_variant_type_id(CscsDate *) { return CscsVariant::Date; }
template<>
inline int scs_variant_type_id(CscsTime *) { return CscsVariant::Time; }
template<>
inline int scs_variant_type_id(CscsDateTime *) { return CscsVariant::DateTime; }
template<>
inline int scs_variant_type_id(CscsBitArray *) { return CscsVariant::BitArray; }
// class CscsKeySequence;
// template<>
// inline int scs_variant_type_id(CscsKeySequence *) { return CscsVariant::KeySequence; }
// class CscsPen;
// template<>
// inline int scs_variant_type_id(CscsPen *) { return CscsVariant::Pen; }
template<>
inline int scs_variant_type_id(int64 *) { return CscsVariant::LongLong; }
template<>
inline int scs_variant_type_id(uint64 *) { return CscsVariant::ULongLong; }
// template<>
// inline int scs_variant_type_id(CscsUrl *) { return CscsVariant::Url; }
template<>
inline int scs_variant_type_id(CscsLocale *) { return CscsVariant::Locale; }
// template<>
// inline int scs_variant_type_id(CscsLineF *) { return CscsVariant::LineF; }
// template<>
// inline int scs_variant_type_id(CscsLine *) { return CscsVariant::Line; }
// template<>
// inline int scs_variant_type_id(CscsRectF *) { return CscsVariant::RectF; }
// template<>
// inline int scs_variant_type_id(std::string *) { return CscsVariant::StdString; }



template <typename T>
inline CscsVariant scsVariantFromValue(const T &t)
{
    return CscsVariant(scs_variant_type_id<T>(reinterpret_cast<T *>(0)), &t);
}

template <>
inline CscsVariant scsVariantFromValue(const CscsVariant &t) { return t; }

template <typename T>
inline void scsVariantSetValue(CscsVariant &v, const T &t)
{
    v = CscsVariant(scs_variant_type_id<T>(reinterpret_cast<T *>(0)), &t);
}


inline CscsVariant::CscsVariant() {}
inline bool CscsVariant::isValid() const { return d.type != Invalid; }



template<typename T>
inline void CscsVariant::setValue(const T &avalue)
{ scsVariantSetValue(*this, avalue); }


inline bool CscsVariant::isDetached() const
{ return !d.is_shared || d.data.shared->ref == 1; }


/* Helper class to add one more level of indirection to prevent
   implicit casts.
*/
class CscsVariantComparisonHelper
{
public:
    inline CscsVariantComparisonHelper(const CscsVariant &var)
        : v(&var) {}
private:
    friend inline bool operator==(const CscsVariant &,
                                  const CscsVariantComparisonHelper &);
    const CscsVariant *v;
};

inline bool operator==(const CscsVariant &v1, const CscsVariantComparisonHelper &v2)
{
    return v1.cmp(*v2.v);
}

inline bool operator!=(const CscsVariant &v1, const CscsVariantComparisonHelper &v2)
{
    return !operator==(v1, v2);
}




template<typename T> T scsvariant_cast(const CscsVariant &v)
{
    const int vid = scs_variant_type_id<T>(static_cast<T *>(0));
    if (vid == v.userType()){
        std::string vn=CscsTypeInfo::typeName(vid);
        if(CscsString::fromStdString(vn).contains("*"))//pointer-type
        {
            const int data=(int)v.constData();
            return *reinterpret_cast<const T *>((void*)&data);
        }
        else
            return *reinterpret_cast<const T *>(v.constData());
    }
    if (vid < int(CscsVariant::UserType)) {
        T t;
        scsvariant_cast_helper(v, CscsVariant::Type(vid), &t);
        return t;
    }
    return T();
}

template<typename T>
inline T scsVariantValue(const CscsVariant &variant)
{ return scsvariant_cast<T>(variant); }

template<typename T>
inline bool scsVariantCanConvert(const CscsVariant &variant)
{
    return variant.canConvert(static_cast<CscsVariant::Type>(
                scs_variant_type_id<T>(static_cast<T *>(0))));
}



void construct_point(CscsVariant::Private* x, const void* copy);
void construct_pointF(CscsVariant::Private* x, const void* copy);
void construct_rect(CscsVariant::Private* x, const void* copy);
void construct_rectF(CscsVariant::Private* x, const void* copy);
void construct_size(CscsVariant::Private* x, const void* copy);
void construct_sizeF(CscsVariant::Private* x, const void* copy);
void construct_line(CscsVariant::Private* x, const void* copy);
void construct_lineF(CscsVariant::Private* x, const void* copy);
void construct_rgba(CscsVariant::Private* x, const void* copy);
void construct_image(CscsVariant::Private* x, const void* copy);
void construct_font(CscsVariant::Private* x, const void* copy);
// void construct_icon(CscsVariant::Private* x, const void* copy);
void construct_brush(CscsVariant::Private* x, const void* copy);
void construct_pen(CscsVariant::Private* x, const void* copy);
// void construct_palette(CscsVariant::Private* x, const void* copy);
void construct_polygon(CscsVariant::Private* x, const void* copy);
void construct_region(CscsVariant::Private* x, const void* copy);
void construct_sizepolicy(CscsVariant::Private* x, const void* copy);
void construct_url(CscsVariant::Private* x, const void* copy);


void clear_point(CscsVariant::Private* x);
void clear_pointF(CscsVariant::Private* x);
void clear_rect(CscsVariant::Private* x);
void clear_rectF(CscsVariant::Private* x);
void clear_size(CscsVariant::Private* x);
void clear_sizeF(CscsVariant::Private* x);
void clear_line(CscsVariant::Private* x);
void clear_lineF(CscsVariant::Private* x);
void clear_rgba(CscsVariant::Private* x);
void clear_image(CscsVariant::Private* x);
void clear_font(CscsVariant::Private* x);
// void clear_icon(CscsVariant::Private* x);
void clear_brush(CscsVariant::Private* x);
void clear_pen(CscsVariant::Private* x);
// void clear_palette(CscsVariant::Private* x);
void clear_polygon(CscsVariant::Private* x);
void clear_region(CscsVariant::Private* x);
void clear_sizepolicy(CscsVariant::Private* x);
void clear_url(CscsVariant::Private* x);

bool isnull_point(const CscsVariant::Private* x);
bool isnull_pointF(const CscsVariant::Private* x);
bool isnull_rect(const CscsVariant::Private* x);
bool isnull_rectF(const CscsVariant::Private* x);
bool isnull_size(const CscsVariant::Private* x);
bool isnull_sizeF(const CscsVariant::Private* x);
bool isnull_line(const CscsVariant::Private* x);
bool isnull_lineF(const CscsVariant::Private* x);
bool isnull_image(const CscsVariant::Private* x);
// bool isnull_icon(const CscsVariant::Private* x);
bool isnull_brush(const CscsVariant::Private* x);
bool isnull_pen(const CscsVariant::Private* x);
bool isnull_polygon(const CscsVariant::Private* x);
bool isnull_region(const CscsVariant::Private* x);
bool isnull_url(const CscsVariant::Private* x);


bool compare_point(const CscsVariant::Private* a , const CscsVariant::Private* b);
bool compare_pointF(const CscsVariant::Private* a , const CscsVariant::Private* b);
bool compare_rect(const CscsVariant::Private* a , const CscsVariant::Private* b);
bool compare_rectF(const CscsVariant::Private* a , const CscsVariant::Private* b);
bool compare_size(const CscsVariant::Private* a , const CscsVariant::Private* b);
bool compare_sizeF(const CscsVariant::Private* a , const CscsVariant::Private* b);
bool compare_line(const CscsVariant::Private* a , const CscsVariant::Private* b);
bool compare_lineF(const CscsVariant::Private* a , const CscsVariant::Private* b);
bool compare_rgba(const CscsVariant::Private* a , const CscsVariant::Private* b);
bool compare_image(const CscsVariant::Private* a , const CscsVariant::Private* b);
bool compare_font(const CscsVariant::Private* a , const CscsVariant::Private* b);
// bool compare_icon(const CscsVariant::Private* a , const CscsVariant::Private* b);
bool compare_brush(const CscsVariant::Private* a , const CscsVariant::Private* b);
bool compare_pen(const CscsVariant::Private* a , const CscsVariant::Private* b);
// bool compare_palette(const CscsVariant::Private* a , const CscsVariant::Private* b);
bool compare_polygon(const CscsVariant::Private* a , const CscsVariant::Private* b);
bool compare_region(const CscsVariant::Private* a , const CscsVariant::Private* b);
bool compare_sizepolicy(const CscsVariant::Private* a , const CscsVariant::Private* b);
bool compare_url(const CscsVariant::Private* a , const CscsVariant::Private* b);

END_NAMESPACE

#endif