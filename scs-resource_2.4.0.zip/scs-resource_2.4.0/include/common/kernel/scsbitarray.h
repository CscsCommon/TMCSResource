#ifndef SCSBITARRAY_H
#define SCSBITARRAY_H
#include "scsbytearray.h"
#include "scsnamespace.h"

BEGIN_NAMESPACE(Gemini)

class CscsBitRef;
class  CscsBitArray
{
    CscsByteArray d;
public:
    inline CscsBitArray() {}
    explicit CscsBitArray(int size, bool val = false);
    CscsBitArray(const CscsBitArray &other) : d(other.d) {}
    inline CscsBitArray &operator=(const CscsBitArray &other) { d = other.d; return *this; }

    inline int size() const { return (d.size() << 3) - *d.constData(); }
    inline int count() const { return (d.size() << 3) - *d.constData(); }

    inline bool isEmpty() const { return d.isEmpty(); }
    inline bool isNull() const { return d.isNull(); }

    void resize(int size);

    inline void detach() { d.detach(); }
    inline bool isDetached() const { return d.isDetached(); }
    inline void clear() { d.clear(); }

    bool testBit(int i) const;
    void setBit(int i);
    void setBit(int i, bool val);
    void clearBit(int i);
    bool toggleBit(int i);

    bool at(int i) const;
    CscsBitRef operator[](int i);
    bool operator[](int i) const;
    CscsBitRef operator[](uint i);
    bool operator[](uint i) const;

    CscsBitArray& operator&=(const CscsBitArray &);
    CscsBitArray& operator|=(const CscsBitArray &);
    CscsBitArray& operator^=(const CscsBitArray &);
    CscsBitArray  operator~() const;

    inline bool operator==(const CscsBitArray& a) const { return d == a.d; }
    inline bool operator!=(const CscsBitArray& a) const { return d != a.d; }

    inline bool fill(bool val, int size = -1);
    void fill(bool val, int first, int last);

    inline void truncate(int pos) { if (pos < size()) resize(pos); }
};

SCS_DECLARE_TYPENAME_INFO(CscsBitArray,SCS_MOVABLE_TYPE)

inline bool CscsBitArray::fill(bool aval, int asize)
{ *this = CscsBitArray((asize < 0 ? this->size() : asize), aval); return true; }
CscsBitArray operator&(const CscsBitArray &, const CscsBitArray &);
CscsBitArray operator|(const CscsBitArray &, const CscsBitArray &);
CscsBitArray operator^(const CscsBitArray &, const CscsBitArray &);

inline bool CscsBitArray::testBit(int i) const
{ assert(i >= 0 && i < size());
 return (*(reinterpret_cast<const uint8*>(d.constData())+1+(i>>3)) & (1 << (i & 7))) != 0; }

inline void CscsBitArray::setBit(int i)
{ assert(i >= 0 && i < size());
 *(reinterpret_cast<uint8*>(d.data())+1+(i>>3)) |= (1 << (i & 7)); }

inline void CscsBitArray::clearBit(int i)
{ assert(i >= 0 && i < size());
 *(reinterpret_cast<uint8*>(d.data())+1+(i>>3)) &= ~(1 << (i & 7)); }

inline void CscsBitArray::setBit(int i, bool val)
{ if (val) setBit(i); else clearBit(i); }

inline bool CscsBitArray::toggleBit(int i)
{ assert(i >= 0 &&  i < size());
 uint8 b = 1<< (i&7); uint8* p = reinterpret_cast<uint8*>(d.data())+1+(i>>3);
 uint8 c = *p&b; *p^=b; return c!=0; }

inline bool CscsBitArray::operator[](int i) const { return testBit(i); }
inline bool CscsBitArray::operator[](uint i) const { return testBit(i); }
inline bool CscsBitArray::at(int i) const { return testBit(i); }

class  CscsBitRef
{
private:
    CscsBitArray& a;
    int i;
    inline CscsBitRef(CscsBitArray& array, int idx) : a(array), i(idx) {}
    friend class CscsBitArray;
public:
    inline operator bool() const { return a.testBit(i); }
    inline bool operator!() const { return !a.testBit(i); }
    CscsBitRef& operator=(const CscsBitRef& val) { a.setBit(i, val); return *this; }
    CscsBitRef& operator=(bool val) { a.setBit(i, val); return *this; }
};

inline CscsBitRef CscsBitArray::operator[](int i)
{ assert(i >= 0); return CscsBitRef(*this, i); }
inline CscsBitRef CscsBitArray::operator[](uint i)
{ return CscsBitRef(*this, i); }

END_NAMESPACE
#endif