#ifndef SCSLIBRARY_H
#define SCSLIBRARY_H
#include "scsobject.h"
#include "scsstring.h"

BEGIN_NAMESPACE(Gemini)

class CscsLibraryPrivate;
class  CscsLibrary : public CscsObject
{
public:
    explicit CscsLibrary(CscsObject *parent = 0);
    explicit CscsLibrary(const CscsString& fileName, CscsObject *parent = 0);
    ~CscsLibrary();

    void *resolve(const char *symbol);
    static void *resolve(const CscsString &fileName, const char *symbol);

    bool load();
    bool unload();
    bool isLoaded() const;

    static bool isLibrary(const CscsString &fileName);

    void setFileName(const CscsString &fileName);
    CscsString fileName() const;

private:
    CscsLibraryPrivate *d;
    bool did_load;
};
END_NAMESPACE

#endif