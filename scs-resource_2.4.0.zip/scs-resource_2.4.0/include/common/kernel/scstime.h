/*Created by J.Wong 2018/10/16
version:    version 1.0,
dependency: base on  or greater than c++11
function: type erase
gcc4.9+
*/
#ifndef SCSTIME_H
#define SCSTIME_H
#include <string>
#include "scstypes.h"

BEGIN_NAMESPACE(Gemini)

class CscsTime{

public:
	CscsTime();
	CscsTime(int h, int m, int s=0, int ms=0);

	bool isNull()const;
	bool isValid()const;

	int  hour()const;
	int  minute()const;
	int  second()const;
	int  msecs()const;
	uint64  value()const{
		return ds;
	}

	std::string toString()const;

	void setTime(int h, int m, int s, int ms=0);

	CscsTime addSecs(int secs)const;
	int 	 secsTo(const CscsTime& time)const;
	CscsTime addMsecs(int ms) const;
	int 	 msecsTo(const CscsTime& time)const;

	bool operator==(const CscsTime& o) const;
	bool operator!=(const CscsTime& o)const;
	bool operator<(const CscsTime& o)const;
	bool operator<=(const CscsTime& o)const;
	bool operator>(const CscsTime& o)const;
	bool operator>=(const CscsTime& o)const;

	static CscsTime currentTime();
	static CscsTime fromString(const std::string& s);
	static bool isValid(int h, int m, int s, int ms=0);
    static void     usleep(int ms);

	void start();
	int restart();
	int elapsed();

private:
	static bool currentTime(CscsTime* t);

	uint64 ds;
	friend class CscsDateTime;
};
SCS_DECLARE_TYPENAME_INFO(CscsTime,SCS_MOVABLE_TYPE)

class  CscsDate
{
public:
    enum DayOfWeek {
        Monday = 1,
        Tuesday = 2,
        Wednesday = 3,
        Thursday = 4,
        Friday = 5,
        Saturday = 6,
        Sunday = 7
    };
    CscsDate() { jd = 0; }
    CscsDate(int y, int m, int d);

    bool isNull() const { return jd == 0; }
    bool isValid() const;

    int year() const;
    int month() const;
    int day() const;
    int dayOfWeek() const;
    int dayOfYear() const;
    int daysInMonth() const;
    int daysInYear() const;
    int weekNumber(int *yearNum = 0) const;
    static std::string shortMonthName(int month);
    static std::string shortDayName(int weekday);
    static std::string longMonthName(int month);
    static std::string longDayName(int weekday);
    std::string toString() const;
    bool setYMD(int y, int m, int d);

    CscsDate addDays(int days) const;
    CscsDate addMonths(int months) const;
    CscsDate addYears(int years) const;
    int daysTo(const CscsDate &) const;

    bool operator==(const CscsDate &other) const { return jd == other.jd; }
    bool operator!=(const CscsDate &other) const { return jd != other.jd; }
    bool operator<(const CscsDate &other) const { return jd < other.jd; }
    bool operator<=(const CscsDate &other) const { return jd <= other.jd; }
    bool operator>(const CscsDate &other) const { return jd > other.jd; }
    bool operator>=(const CscsDate &other) const { return jd >= other.jd; }

    static CscsDate currentDate();
    static CscsDate fromString(const std::string &s);
    static bool isValid(int y, int m, int d);
    static bool isLeapYear(int year);

    static uint gregorianToJulian(int y, int m, int d);
    static void julianToGregorian(uint jd, int &y, int &m, int &d);


    static inline CscsDate fromJulianDay(int jd) { CscsDate d; d.jd = jd; return d; }
    inline int toJulianDay() const { return jd; }

private:
    uint jd;

    friend class CscsDateTime;
};
SCS_DECLARE_TYPENAME_INFO(CscsDate,SCS_MOVABLE_TYPE)

//DateTime
class CscsDateTimePrivate;

class  CscsDateTime
{
public:
	enum TimeSpec{
		LocalTime,
		UTC,
        OffsetFromUTC
	};



    CscsDateTime();
    explicit CscsDateTime(const CscsDate &);
    CscsDateTime(const CscsDate &, const CscsTime &, CscsDateTime::TimeSpec spec = CscsDateTime::LocalTime);
    CscsDateTime(const CscsDateTime &other);
    ~CscsDateTime();

    CscsDateTime &operator=(const CscsDateTime &other);

    bool isNull() const;
    bool isValid() const;

    CscsDate date() const;
    CscsTime time() const;
    CscsDateTime::TimeSpec timeSpec() const;
    uint toTime_t() const;
    void setDate(const CscsDate &date);
    void setTime(const CscsTime &time);
    void setTimeSpec(CscsDateTime::TimeSpec spec);
    void setTime_t(uint secsSince1Jan1970UTC);
    void setOffsetFromUtc(int offsetSeconds);
    
    std::string toString() const;
    CscsDateTime addDays(int days) const;
    CscsDateTime addMonths(int months) const;
    CscsDateTime addYears(int years) const;
    CscsDateTime addSecs(int secs) const;
    CscsDateTime toTimeSpec(CscsDateTime::TimeSpec spec) const;
    inline CscsDateTime toLocalTime() const { return toTimeSpec(CscsDateTime::LocalTime); }
    inline CscsDateTime toUTC() const { return toTimeSpec(CscsDateTime::UTC); }
    int offsetFromUtc()const;
    int daysTo(const CscsDateTime &) const;
    int secsTo(const CscsDateTime &) const;

    bool operator==(const CscsDateTime &other) const;
    inline bool operator!=(const CscsDateTime &other) const { return !(*this == other); }
    bool operator<(const CscsDateTime &other) const;
    inline bool operator<=(const CscsDateTime &other) const { return !(other < *this); }
    inline bool operator>(const CscsDateTime &other) const { return other < *this; }
    inline bool operator>=(const CscsDateTime &other) const { return !(*this < other); }
    static void     setCurrentDateTime(const CscsDateTime& dt);
    static CscsDateTime currentDateTime();
    static CscsDateTime fromString(const std::string &s);


private:
    void detach();
    CscsDateTimePrivate *d;

};
SCS_DECLARE_TYPENAME_INFO(CscsDateTime,SCS_MOVABLE_TYPE)

END_NAMESPACE

#endif