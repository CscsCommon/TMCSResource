/*
 * Created by J.W 2019/05/22
 */
#ifndef SCSABSTRACTDATASENSOR_H
#define SCSABSTRACTDATASENSOR_H
#include <kernel/scsobject.h>
#include <kernel/scsmutex.h>
#include <kernel/scshash.h>
#include <kernel/scslist.h>

BEGIN_NAMESPACE(Gemini)
class CscsTimerEvent;
class CscsDataSensorEvent;

class CscsDataSensor:public CscsObject{
	public:
		CscsDataSensor(CscsObject* parent=nullptr);
		~CscsDataSensor();
		void setDetectTimeInterval(int msecs);
		int  detectTimeInterval()const;
		void post(CscsDataSensorEvent* event);
		void bind(int uid, CscsObject* owner);
		void unbind(int uid,CscsObject* owner);
	protected:
		void timerEvent(CscsTimerEvent* e);

	private:
		CscsRecursiveMutex lock;
		int dectTimeInterval;
		int timerId;
		CscsMultiHash<int, CscsObject*> owners;
		CscsList<CscsDataSensorEvent*> postDataSensorEventList;
};


END_NAMESPACE

#endif