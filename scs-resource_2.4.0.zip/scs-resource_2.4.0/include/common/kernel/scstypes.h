#ifndef SCSTYPES_H
#define SCSTYPES_H
#include <string.h>
#include <vector>
#include <string>
#include "scsnamespace.h"


/*! \file scstypes.h
 * 类型别名
 */
 
/*!offset_t*/ 
typedef unsigned long   offset_t;
/*! ulong*/ 
typedef unsigned long   ulong;
/*!bytearray*/
typedef std::vector<char> bytearray;
/*!stringarray*/
typedef std::vector<std::string> stringarray;
/*!uint*/
typedef unsigned int    uint;
/*!uint32*/
typedef uint            uint32;
/*!uint8*/
typedef unsigned char   uint8;
/*!int8*/
typedef char 			int8;
/*!uint16*/
typedef unsigned short  uint16;
/*!int16*/
typedef short 			int16;
/*!uint64*/
typedef unsigned long long uint64;
/*!int64*/
typedef long long      int64;
/*!int32*/
typedef int 		   int32;

typedef unsigned short ushort;

/*! \def SLOTS
    \brief 槽类型.  
*/
#define 	SLOTS 		public

/*! \def SIGNALS
    \brief 信号类型.  
*/
#define 	SIGNALS     public

/*! \def SCS_LIKELY(expr)
    \brief 期望为真 \a expr.  
*/
#  define SCS_LIKELY(expr)    __builtin_expect(!!(expr), true)

/*! \def SCS_UNLIKELY(expr)
    \brief 期望为假 \a expr.  
*/
#  define SCS_UNLIKELY(expr)  __builtin_expect(!!(expr), false)

#  define WIDGET_EXPORT


template <typename T>
class CscsForeachContainer {
public:
    inline CscsForeachContainer(const T& t) : c(t), brk(0), i(c.begin()), e(c.end()) { }
    const T c;
    int brk;
    typename T::const_iterator i, e;
};

#define SCS_FOREACH(variable, container)                                \
for (CscsForeachContainer<__typeof__(container)> _container_(container); \
     !_container_.brk && _container_.i != _container_.e;              \
     __extension__  ({ ++_container_.brk; ++_container_.i; }))                       \
    for (variable = *_container_.i;; __extension__ ({--_container_.brk; break;}))

#ifndef foreach
#define foreach SCS_FOREACH
#endif

#ifndef forever
#define forever for(;;)
#endif

BEGIN_NAMESPACE(Gemini)
template <typename T>
class CscsTypeNameInfo
{
public:
    enum {
        isPointer = false,
        isComplex = true,
        isStatic = true,
        isLarge = (sizeof(T)>sizeof(void*)),
        isDummy = false
    };
};

template <typename T>
class CscsTypeNameInfo<T*>
{
public:
    enum {
        isPointer = true,
        isComplex = false,
        isStatic = false,
        isLarge = false,
        isDummy = false
    };
};


enum { // TYPENAME flags
    SCS_COMPLEX_TYPE = 0,
    SCS_PRIMITIVE_TYPE = 0x1,
    SCS_STATIC_TYPE = 0,
    SCS_MOVABLE_TYPE = 0x2,
    SCS_DUMMY_TYPE = 0x4
};

#define SCS_DECLARE_TYPENAME_INFO(TYPE, FLAGS) \
template <> \
class CscsTypeNameInfo<TYPE> \
{ \
public: \
    enum { \
        isComplex = (((FLAGS) & SCS_PRIMITIVE_TYPE) == 0), \
        isStatic = (((FLAGS) & (SCS_MOVABLE_TYPE | SCS_PRIMITIVE_TYPE)) == 0), \
        isLarge = (sizeof(TYPE)>sizeof(void*)), \
        isPointer = false, \
        isDummy = (((FLAGS) & SCS_DUMMY_TYPE) != 0) \
    }; \
    static inline const char *name() { return #TYPE; } \
};

SCS_DECLARE_TYPENAME_INFO(bool, SCS_PRIMITIVE_TYPE)
SCS_DECLARE_TYPENAME_INFO(int8, SCS_PRIMITIVE_TYPE)
SCS_DECLARE_TYPENAME_INFO(uint8, SCS_PRIMITIVE_TYPE)
SCS_DECLARE_TYPENAME_INFO(int16, SCS_PRIMITIVE_TYPE)
SCS_DECLARE_TYPENAME_INFO(ushort, SCS_PRIMITIVE_TYPE)
SCS_DECLARE_TYPENAME_INFO(int, SCS_PRIMITIVE_TYPE)
SCS_DECLARE_TYPENAME_INFO(uint, SCS_PRIMITIVE_TYPE)
SCS_DECLARE_TYPENAME_INFO(long, SCS_PRIMITIVE_TYPE)
SCS_DECLARE_TYPENAME_INFO(ulong, SCS_PRIMITIVE_TYPE)
SCS_DECLARE_TYPENAME_INFO(int64, SCS_PRIMITIVE_TYPE)
SCS_DECLARE_TYPENAME_INFO(uint64, SCS_PRIMITIVE_TYPE)
SCS_DECLARE_TYPENAME_INFO(float, SCS_PRIMITIVE_TYPE)
SCS_DECLARE_TYPENAME_INFO(double, SCS_PRIMITIVE_TYPE)

END_NAMESPACE





#endif
