#ifndef SCSXML_H
#define SCSXML_H

#include <kernel/scsstring.h>
#include <kernel/scsstringlist.h>
#include <kernel/scslist.h>
#include <kernel/scsdevice.h>
#include <kernel/scsnocopy.hpp>

BEGIN_NAMESPACE(Gemini)

class CscsXmlNamespaceSupport;
class CscsXmlAttributes;
class CscsXmlContentHandler;
class CscsXmlDefaultHandler;
class CscsXmlDTDHandler;
class CscsXmlEntityResolver;
class CscsXmlErrorHandler;
class CscsXmlLexicalHandler;
class CscsXmlDeclHandler;
class CscsXmlInputSource;
class CscsXmlLocator;
class CscsXmlNamespaceSupport;
class CscsXmlParseException;

class CscsXmlReader;
class CscsXmlSimpleReader;

class CscsXmlSimpleReaderPrivate;
class CscsXmlNamespaceSupportPrivate;
class CscsXmlAttributesPrivate;
class CscsXmlInputSourcePrivate;
class CscsXmlParseExceptionPrivate;
class CscsXmlLocatorPrivate;
class CscsXmlDefaultHandlerPrivate;


//
// SAX Namespace Support
//

class  CscsXmlNamespaceSupport
{
public:
    CscsXmlNamespaceSupport();
    ~CscsXmlNamespaceSupport();

    void setPrefix(const CscsString&, const CscsString&);

    CscsString prefix(const CscsString&) const;
    CscsString uri(const CscsString&) const;
    void splitName(const CscsString&, CscsString&, CscsString&) const;
    void processName(const CscsString&, bool, CscsString&, CscsString&) const;
    CscsStringList prefixes() const;
    CscsStringList prefixes(const CscsString&) const;

    void pushContext();
    void popContext();
    void reset();

private:
    CscsXmlNamespaceSupportPrivate *d;

    friend class CscsXmlSimpleReaderPrivate;
};


//
// SAX Attributes
//

class  CscsXmlAttributes
{
public:
    CscsXmlAttributes() {}
    virtual ~CscsXmlAttributes() {}

    int index(const CscsString& name) const;
    int index(const CscsString& uri, const CscsString& localPart) const;
    int length() const;
    int count() const;
    CscsString localName(int index) const;
    CscsString name(int index) const;
    CscsString uri(int index) const;
    CscsString type(int index) const;
    CscsString type(const CscsString& name) const;
    CscsString type(const CscsString& uri, const CscsString& localName) const;
    CscsString value(int index) const;
    CscsString value(const CscsString& name) const;
    CscsString value(const CscsString& uri, const CscsString& localName) const;

    void clear();
    void append(const CscsString &name, const CscsString &uri, const CscsString &localPart, const CscsString &value);

private:
    struct Attribute {
        CscsString sname, uri, localname, value;
    };
    typedef CscsList<Attribute> AttributeList;
    AttributeList attList;

    CscsXmlAttributesPrivate *d;
};

//
// SAX Input Source
//

class  CscsXmlInputSource:public CscsNoCopyable
{
public:
    CscsXmlInputSource();
    CscsXmlInputSource(CscsDevice *dev);
    virtual ~CscsXmlInputSource();

    virtual void setData(const CscsString& dat);
    virtual void setData(const CscsByteArray& dat);
    virtual void fetchData();
    virtual CscsString data() const;
    virtual CscsChar next();
    virtual void reset();

    static const uint16 EndOfData;
    static const uint16 EndOfDocument;


protected:
    virtual CscsString fromRawData(const CscsByteArray &data, bool beginning = false);

private:
    void init();
    CscsXmlInputSourcePrivate *d;
};

//
// SAX Exception Classes
//

class  CscsXmlParseException:public CscsNoCopyable
{
public:
    explicit CscsXmlParseException(const CscsString &name = CscsString(), int c = -1, int l = -1,
                                const CscsString &p = CscsString(), const CscsString &s = CscsString());
    ~CscsXmlParseException();

    int columnNumber() const;
    int lineNumber() const;
    CscsString publicId() const;
    CscsString systemId() const;
    CscsString message() const;

private:
    CscsXmlParseExceptionPrivate *d;
};


//
// XML Reader
//

class  CscsXmlReader
{
public:
    virtual ~CscsXmlReader() {}
    virtual bool feature(const CscsString& name, bool *ok = 0) const = 0;
    virtual void setFeature(const CscsString& name, bool value) = 0;
    virtual bool hasFeature(const CscsString& name) const = 0;
    virtual void* property(const CscsString& name, bool *ok = 0) const = 0;
    virtual void setProperty(const CscsString& name, void* value) = 0;
    virtual bool hasProperty(const CscsString& name) const = 0;
    virtual void setEntityResolver(CscsXmlEntityResolver* handler) = 0;
    virtual CscsXmlEntityResolver* entityResolver() const = 0;
    virtual void setDTDHandler(CscsXmlDTDHandler* handler) = 0;
    virtual CscsXmlDTDHandler* DTDHandler() const = 0;
    virtual void setContentHandler(CscsXmlContentHandler* handler) = 0;
    virtual CscsXmlContentHandler* contentHandler() const = 0;
    virtual void setErrorHandler(CscsXmlErrorHandler* handler) = 0;
    virtual CscsXmlErrorHandler* errorHandler() const = 0;
    virtual void setLexicalHandler(CscsXmlLexicalHandler* handler) = 0;
    virtual CscsXmlLexicalHandler* lexicalHandler() const = 0;
    virtual void setDeclHandler(CscsXmlDeclHandler* handler) = 0;
    virtual CscsXmlDeclHandler* declHandler() const = 0;
    virtual bool parse(const CscsXmlInputSource& input) = 0;
    virtual bool parse(const CscsXmlInputSource* input) = 0;
};

class CscsXmlSimpleReader : public CscsXmlReader
{
public:
    CscsXmlSimpleReader();
    virtual ~CscsXmlSimpleReader();

    bool feature(const CscsString& name, bool *ok = 0) const;
    void setFeature(const CscsString& name, bool value);
    bool hasFeature(const CscsString& name) const;

    void* property(const CscsString& name, bool *ok = 0) const;
    void setProperty(const CscsString& name, void* value);
    bool hasProperty(const CscsString& name) const;

    void setEntityResolver(CscsXmlEntityResolver* handler);
    CscsXmlEntityResolver* entityResolver() const;
    void setDTDHandler(CscsXmlDTDHandler* handler);
    CscsXmlDTDHandler* DTDHandler() const;
    void setContentHandler(CscsXmlContentHandler* handler);
    CscsXmlContentHandler* contentHandler() const;
    void setErrorHandler(CscsXmlErrorHandler* handler);
    CscsXmlErrorHandler* errorHandler() const;
    void setLexicalHandler(CscsXmlLexicalHandler* handler);
    CscsXmlLexicalHandler* lexicalHandler() const;
    void setDeclHandler(CscsXmlDeclHandler* handler);
    CscsXmlDeclHandler* declHandler() const;

    bool parse(const CscsXmlInputSource& input);
    bool parse(const CscsXmlInputSource* input);
    virtual bool parse(const CscsXmlInputSource* input, bool incremental);
    virtual bool parseContinue();

private:
	CscsXmlSimpleReaderPrivate* d_func()const;
    CscsXmlSimpleReaderPrivate* d_ptr;
    friend class CscsXmlSimpleReaderLocator;
};

//
// SAX Locator
//

class  CscsXmlLocator
{
public:
    CscsXmlLocator();
    virtual ~CscsXmlLocator();

    virtual int columnNumber() const = 0;
    virtual int lineNumber() const = 0;
};

//
// SAX handler classes
//

class CscsXmlContentHandler
{
public:
    virtual ~CscsXmlContentHandler() {}
    virtual void setDocumentLocator(CscsXmlLocator* locator) = 0;
    virtual bool startDocument() = 0;
    virtual bool endDocument() = 0;
    virtual bool startPrefixMapping(const CscsString& prefix, const CscsString& uri) = 0;
    virtual bool endPrefixMapping(const CscsString& prefix) = 0;
    virtual bool startElement(const CscsString& namespaceURI, const CscsString& localName, const CscsString& qName, const CscsXmlAttributes& atts) = 0;
    virtual bool endElement(const CscsString& namespaceURI, const CscsString& localName, const CscsString& qName) = 0;
    virtual bool characters(const CscsString& ch) = 0;
    virtual bool ignorableWhitespace(const CscsString& ch) = 0;
    virtual bool processingInstruction(const CscsString& target, const CscsString& data) = 0;
    virtual bool skippedEntity(const CscsString& name) = 0;
    virtual CscsString errorString() const = 0;
};

class CscsXmlErrorHandler
{
public:
    virtual ~CscsXmlErrorHandler() {}
    virtual bool warning(const CscsXmlParseException& exception) = 0;
    virtual bool error(const CscsXmlParseException& exception) = 0;
    virtual bool fatalError(const CscsXmlParseException& exception) = 0;
    virtual CscsString errorString() const = 0;
};

class CscsXmlDTDHandler
{
public:
    virtual ~CscsXmlDTDHandler() {}
    virtual bool notationDecl(const CscsString& name, const CscsString& publicId, const CscsString& systemId) = 0;
    virtual bool unparsedEntityDecl(const CscsString& name, const CscsString& publicId, const CscsString& systemId, const CscsString& notationName) = 0;
    virtual CscsString errorString() const = 0;
};

class CscsXmlEntityResolver
{
public:
    virtual ~CscsXmlEntityResolver() {}
    virtual bool resolveEntity(const CscsString& publicId, const CscsString& systemId, CscsXmlInputSource*& ret) = 0;
    virtual CscsString errorString() const = 0;
};

class CscsXmlLexicalHandler
{
public:
    virtual ~CscsXmlLexicalHandler() {}
    virtual bool startDTD(const CscsString& name, const CscsString& publicId, const CscsString& systemId) = 0;
    virtual bool endDTD() = 0;
    virtual bool startEntity(const CscsString& name) = 0;
    virtual bool endEntity(const CscsString& name) = 0;
    virtual bool startCDATA() = 0;
    virtual bool endCDATA() = 0;
    virtual bool comment(const CscsString& ch) = 0;
    virtual CscsString errorString() const = 0;
};

class CscsXmlDeclHandler
{
public:
    virtual ~CscsXmlDeclHandler() {}
    virtual bool attributeDecl(const CscsString& eName, const CscsString& aName, const CscsString& type, const CscsString& valueDefault, const CscsString& value) = 0;
    virtual bool internalEntityDecl(const CscsString& name, const CscsString& value) = 0;
    virtual bool externalEntityDecl(const CscsString& name, const CscsString& publicId, const CscsString& systemId) = 0;
    virtual CscsString errorString() const = 0;
};


class CscsXmlDefaultHandler : public CscsXmlContentHandler, public CscsXmlErrorHandler, public CscsXmlDTDHandler, public CscsXmlEntityResolver, public CscsXmlLexicalHandler, public CscsXmlDeclHandler
{
public:
    CscsXmlDefaultHandler() { }
    virtual ~CscsXmlDefaultHandler() { }

    void setDocumentLocator(CscsXmlLocator* locator);
    bool startDocument();
    bool endDocument();
    bool startPrefixMapping(const CscsString& prefix, const CscsString& uri);
    bool endPrefixMapping(const CscsString& prefix);
    bool startElement(const CscsString& namespaceURI, const CscsString& localName, const CscsString& name, const CscsXmlAttributes& atts);
    bool endElement(const CscsString& namespaceURI, const CscsString& localName, const CscsString& name);
    bool characters(const CscsString& ch);
    bool ignorableWhitespace(const CscsString& ch);
    bool processingInstruction(const CscsString& target, const CscsString& data);
    bool skippedEntity(const CscsString& name);

    bool warning(const CscsXmlParseException& exception);
    bool error(const CscsXmlParseException& exception);
    bool fatalError(const CscsXmlParseException& exception);

    bool notationDecl(const CscsString& name, const CscsString& publicId, const CscsString& systemId);
    bool unparsedEntityDecl(const CscsString& name, const CscsString& publicId, const CscsString& systemId, const CscsString& notationName);

    bool resolveEntity(const CscsString& publicId, const CscsString& systemId, CscsXmlInputSource*& ret);

    bool startDTD(const CscsString& name, const CscsString& publicId, const CscsString& systemId);
    bool endDTD();
    bool startEntity(const CscsString& name);
    bool endEntity(const CscsString& name);
    bool startCDATA();
    bool endCDATA();
    bool comment(const CscsString& ch);

    bool attributeDecl(const CscsString& eName, const CscsString& aName, const CscsString& type, const CscsString& valueDefault, const CscsString& value);
    bool internalEntityDecl(const CscsString& name, const CscsString& value);
    bool externalEntityDecl(const CscsString& name, const CscsString& publicId, const CscsString& systemId);

    CscsString errorString() const;

private:
    CscsXmlDefaultHandlerPrivate *d;
};

// inlines

inline int CscsXmlAttributes::count() const
{ return length(); }

END_NAMESPACE

#endif