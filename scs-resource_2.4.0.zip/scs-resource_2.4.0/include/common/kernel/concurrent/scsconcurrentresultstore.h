#ifndef SCSCONCURRENTRESULTSTORE_H
#define SCSCONCURRENTRESULTSTORE_H
#include <kernel/scsmap.h>
BEGIN_NAMESPACE(Gemini)


class ResultItem
{
public:
    ResultItem(const void *_result, int _count) : m_count(_count), result(_result) { }
    ResultItem(const void *_result) : m_count(0), result(_result) { }
    ResultItem() : m_count(0), result(0) { }
    bool isValid() const { return result != 0; }
    bool isVector() const { return m_count != 0; }
    int count() const { return (m_count == 0) ?  1 : m_count; }
    int m_count;
    const void *result;
};

class  ResultIteratorBase
{
public:
    ResultIteratorBase();
    ResultIteratorBase(CscsMap<int, ResultItem>::const_iterator _mapIterator, int _vectorIndex = 0);
    int vectorIndex() const;
    int resultIndex() const;

    ResultIteratorBase operator++();
    int batchSize() const;
    void batchedAdvance();
    bool operator==(const ResultIteratorBase &other) const;
    bool operator!=(const ResultIteratorBase &other) const;
    bool isVector() const;
    bool canIncrementVectorIndex() const;
protected:
    CscsMap<int, ResultItem>::const_iterator mapIterator;
    int m_vectorIndex;
};

template <typename T>
class  ResultIterator : public ResultIteratorBase
{
public:
    ResultIterator(const ResultIteratorBase &base)
    : ResultIteratorBase(base) { }

    const T &value() const
    {
        return *pointer();
    }

    const T *pointer() const
    {
        if (mapIterator.value().isVector())
            return &(reinterpret_cast<const CscsVector<T> *>(mapIterator.value().result)->at(m_vectorIndex));
        else
            return reinterpret_cast<const T *>(mapIterator.value().result);
    }
};

class  ResultStoreBase
{
public:
    ResultStoreBase();
    void setFilterMode(bool enable);
    bool filterMode() const;
    int addResult(int index, const void *result);
    int addResults(int index, const void *results, int vectorSize, int logicalCount);
    ResultIteratorBase begin() const;
    ResultIteratorBase end() const;
    bool hasNextResult() const;
    ResultIteratorBase resultAt(int index) const;
    bool contains(int index) const;
    int count() const;
    virtual ~ResultStoreBase() { };

protected:
    int insertResultItem(int index, ResultItem &resultItem);
    void insertResultItemIfValid(int index, ResultItem &resultItem);
    void syncPendingResults();
    void syncResultCount();
    int updateInsertIndex(int index, int _count);

    CscsMap<int, ResultItem> m_results;
    int insertIndex;
    int resultCount;

    bool m_filterMode;
    CscsMap<int, ResultItem> pendingResults;
    int filteredResults;
    
};

template <typename T>
class ResultStore : public ResultStoreBase
{
public:
    ResultStore() { }

    ResultStore(const ResultStoreBase &base)
    : ResultStoreBase(base) { }

    int addResult(int index, const T  *result)
    {
        if (result == 0)
            return ResultStoreBase::addResult(index, result);
        else
            return ResultStoreBase::addResult(index, new T(*result));
    }

    int addResults(int index, const CscsVector<T> *results)
    {
        return ResultStoreBase::addResults(index, new CscsVector<T>(*results), results->count(), results->count());
    }

    int addResults(int index, const CscsVector<T> *results, int totalCount)
    {
        return ResultStoreBase::addResults(index, new CscsVector<T>(*results), results->count(), totalCount);
    }

    int addCanceledResult(int index)
    {
        return addResult(index, 0);
    }

    int addCanceledResults(int index, int _count)
    {
        CscsVector<T> empty;
        return addResults(index, &empty, _count);
    }

    ResultIterator<T> begin() const
    {
        return static_cast<ResultIterator<T> >(ResultStoreBase::begin());
    }

    ResultIterator<T> end() const
    {
        return static_cast<ResultIterator<T> >(ResultStoreBase::end());
    }

    ResultIterator<T> resultAt(int index) const
    {
        return static_cast<ResultIterator<T> >(ResultStoreBase::resultAt(index));
    }

    void clear()
    {
        CscsMap<int, ResultItem>::const_iterator mapIterator = m_results.begin();
        while (mapIterator != m_results.end()) {
            if (mapIterator.value().isVector())
                delete reinterpret_cast<const CscsVector<T> *>(mapIterator.value().result);
            else
                delete reinterpret_cast<const T *>(mapIterator.value().result);
            ++mapIterator;
        }
        resultCount = 0;
        m_results.clear();
    }

    ~ResultStore()
    {
        clear();
    }

};
END_NAMESPACE

#endif