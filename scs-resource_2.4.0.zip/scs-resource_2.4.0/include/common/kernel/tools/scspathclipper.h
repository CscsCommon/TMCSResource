#ifndef SCSPATHCLIPPER_H
#define SCSPATHCLIPPER_H
#include "scspath.h"
#include "scsbezier.h"
#include "scsdatabuffer.h"
#include <kernel/scslist.h>
#include <kernel/scsnocopy.hpp>

BEGIN_NAMESPACE(Gemini)

class CscsWingedEdge;

class  CscsPathClipper:public CscsNoCopyable
{
public:
    enum Operation {
        BoolAnd,
        BoolOr,
        BoolSub,
        Simplify
    };
public:
    CscsPathClipper(const CscsPath &subject,
                 const CscsPath &clip);

    CscsPath clip(Operation op = BoolAnd);

    bool intersect();
    bool contains();

private:
    enum ClipperMode {
        ClipMode, // do the full clip
        CheckMode // for contains/intersects (only interested in whether the result path is non-empty)
    };

    bool handleCrossingEdges(CscsWingedEdge &list, double y, ClipperMode mode);
    bool doClip(CscsWingedEdge &list, ClipperMode mode);

    CscsPath subjectPath;
    CscsPath clipPath;
    Operation op;

    int aMask;
    int bMask;
};

struct CscsPathVertex
{
public:
    CscsPathVertex(const CscsPointF &p = CscsPointF(), int e = -1);
    operator CscsPointF() const;

    int edge;

    double x;
    double y;
};

class CscsPathEdge
{
public:
    enum Traversal {
        RightTraversal,
        LeftTraversal
    };

    enum Direction {
        Forward,
        Backward
    };

    enum Type {
        Line,
        Curve
    };

    CscsPathEdge(int a = -1, int b = -1);

    mutable int flag;

    int windingA;
    int windingB;

    int first;
    int second;

    double angle;
    double invAngle;

    const CscsBezier *bezier;
    double t0;
    double t1;

    int next(Traversal traversal, Direction direction) const;

    void setNext(Traversal traversal, Direction direction, int next);
    void setNext(Direction direction, int next);

    Direction directionTo(int vertex) const;
    int vertex(Direction direction) const;

    bool isBezier() const;

private:
    int m_next[2][2];
};

class CscsPathSegments
{
public:
    struct Intersection {
        int vertex;
        double t;

        int next;

        bool operator<(const Intersection &o) const {
            return t < o.t;
        }
    };

    struct Segment {
        Segment(int pathId, int vertexA, int vertexB, int bezierIndex = -1)
            : path(pathId)
            , bezier(bezierIndex)
            , va(vertexA)
            , vb(vertexB)
            , intersection(-1)
        {
        }

        int path;
        int bezier;

        // vertices
        int va;
        int vb;

        // intersection index
        int intersection;

        CscsRectF bounds;
    };


    CscsPathSegments();

    void setPath(const CscsPath &path);
    void addPath(const CscsPath &path);

    int intersections() const;
    int segments() const;
    int points() const;

    const Segment &segmentAt(int index) const;
    const CscsLineF lineAt(int index) const;
    const CscsBezier *bezierAt(int index) const;
    const CscsRectF &elementBounds(int index) const;
    int pathId(int index) const;

    const CscsPointF &pointAt(int vertex) const;
    int addPoint(const CscsPointF &point);

    const Intersection *intersectionAt(int index) const;
    void addIntersection(int index, const Intersection &intersection);

    void mergePoints();

private:
    CscsDataBuffer<CscsPointF> m_points;
    CscsDataBuffer<Segment> m_segments;
    CscsDataBuffer<CscsBezier> m_beziers;
    CscsDataBuffer<Intersection> m_intersections;

    int m_pathId;
};

class  CscsWingedEdge
{
public:
    struct TraversalStatus
    {
        int edge;
        CscsPathEdge::Traversal traversal;
        CscsPathEdge::Direction direction;

        void flipDirection();
        void flipTraversal();

        void flip();
    };

    CscsWingedEdge();
    CscsWingedEdge(const CscsPath &subject, const CscsPath &clip);

    void simplify();
    CscsPath toPath() const;

    int edgeCount() const;

    CscsPathEdge *edge(int edge);
    const CscsPathEdge *edge(int edge) const;

    int vertexCount() const;

    int addVertex(const CscsPointF &p);

    CscsPathVertex *vertex(int vertex);
    const CscsPathVertex *vertex(int vertex) const;

    TraversalStatus next(const TraversalStatus &status) const;

    int addEdge(const CscsPointF &a, const CscsPointF &b, const CscsBezier *bezier = 0, double t0 = 0, double t1 = 1);
    int addEdge(int vertexA, int vertexB, const CscsBezier *bezier = 0, double t0 = 0, double t1 = 1);

    bool isInside(double x, double y) const;

    static CscsPathEdge::Traversal flip(CscsPathEdge::Traversal traversal);
    static CscsPathEdge::Direction flip(CscsPathEdge::Direction direction);

private:
    void intersectAndAdd();

    void printNode(int i, FILE *handle);

    CscsBezier bezierFromIndex(int index) const;

    void removeEdge(int ei);
    void addBezierEdge(const CscsBezier *bezier, const CscsPointF &a, const CscsPointF &b, double alphaA, double alphaB, int path);
    void addBezierEdge(const CscsBezier *bezier, int vertexA, int vertexB, double alphaA, double alphaB, int path);

    int insert(const CscsPathVertex &vertex);
    TraversalStatus findInsertStatus(int vertex, int edge) const;

    double delta(int vertex, int a, int b) const;

    CscsDataBuffer<CscsPathEdge> m_edges;
    CscsDataBuffer<CscsPathVertex> m_vertices;

    CscsVector<double> m_splitPoints;

    CscsPathSegments m_segments;
};

inline CscsPathEdge::CscsPathEdge(int a, int b)
    : flag(0)
    , windingA(0)
    , windingB(0)
    , first(a)
    , second(b)
    , bezier(0)
{
    m_next[0][0] = -1;
    m_next[1][0] = -1;
    m_next[0][0] = -1;
    m_next[1][0] = -1;
}

inline int CscsPathEdge::next(Traversal traversal, Direction direction) const
{
    return m_next[int(traversal)][int(direction)];
}

inline void CscsPathEdge::setNext(Traversal traversal, Direction direction, int next)
{
    m_next[int(traversal)][int(direction)] = next;
}

inline void CscsPathEdge::setNext(Direction direction, int next)
{
    m_next[0][int(direction)] = next;
    m_next[1][int(direction)] = next;
}

inline CscsPathEdge::Direction CscsPathEdge::directionTo(int vertex) const
{
    return first == vertex ? Backward : Forward;
}

inline int CscsPathEdge::vertex(Direction direction) const
{
    return direction == Backward ? first : second;
}

inline bool CscsPathEdge::isBezier() const
{
    return bezier >= 0;
}

inline CscsPathVertex::CscsPathVertex(const CscsPointF &p, int e)
    : edge(e)
    , x(p.x())
    , y(p.y())
{
}

inline CscsPathVertex::operator CscsPointF() const
{
    return CscsPointF(x, y);
}

inline CscsPathSegments::CscsPathSegments()
{
}

inline int CscsPathSegments::segments() const
{
    return m_segments.size();
}

inline int CscsPathSegments::points() const
{
    return m_points.size();
}

inline const CscsPointF &CscsPathSegments::pointAt(int i) const
{
    return m_points.at(i);
}

inline int CscsPathSegments::addPoint(const CscsPointF &point)
{
    m_points << point;
    return m_points.size() - 1;
}

inline const CscsPathSegments::Segment &CscsPathSegments::segmentAt(int index) const
{
    return m_segments.at(index);
}

inline const CscsLineF CscsPathSegments::lineAt(int index) const
{
    const Segment &segment = m_segments.at(index);
    return CscsLineF(m_points.at(segment.va), m_points.at(segment.vb));
}

inline const CscsBezier *CscsPathSegments::bezierAt(int index) const
{
    const Segment &segment = m_segments.at(index);
    if (segment.bezier >= 0)
        return &m_beziers.at(segment.bezier);
    else
        return 0;
}

inline const CscsRectF &CscsPathSegments::elementBounds(int index) const
{
    return m_segments.at(index).bounds;
}

inline int CscsPathSegments::pathId(int index) const
{
    return m_segments.at(index).path;
}

inline const CscsPathSegments::Intersection *CscsPathSegments::intersectionAt(int index) const
{
    const int intersection = m_segments.at(index).intersection;
    if (intersection < 0)
        return 0;
    else
        return &m_intersections.at(intersection);
}

inline int CscsPathSegments::intersections() const
{
    return m_intersections.size();
}

inline void CscsPathSegments::addIntersection(int index, const Intersection &intersection)
{
    m_intersections << intersection;

    Segment &segment = m_segments.at(index);
    if (segment.intersection < 0) {
        segment.intersection = m_intersections.size() - 1;
    } else {
        Intersection *isect = &m_intersections.at(segment.intersection);

        while (isect->next != 0)
            isect += isect->next;

        isect->next = (m_intersections.size() - 1) - (isect - m_intersections.data());
    }
}

inline void CscsWingedEdge::TraversalStatus::flipDirection()
{
    direction = CscsWingedEdge::flip(direction);
}

inline void CscsWingedEdge::TraversalStatus::flipTraversal()
{
    traversal = CscsWingedEdge::flip(traversal);
}

inline void CscsWingedEdge::TraversalStatus::flip()
{
    flipDirection();
    flipTraversal();
}

inline int CscsWingedEdge::edgeCount() const
{
    return m_edges.size();
}

inline CscsPathEdge *CscsWingedEdge::edge(int edge)
{
    return edge < 0 ? 0 : &m_edges.at(edge);
}

inline const CscsPathEdge *CscsWingedEdge::edge(int edge) const
{
    return edge < 0 ? 0 : &m_edges.at(edge);
}

inline int CscsWingedEdge::vertexCount() const
{
    return m_vertices.size();
}

inline int CscsWingedEdge::addVertex(const CscsPointF &p)
{
    m_vertices << p;
    return m_vertices.size() - 1;
}

inline CscsPathVertex *CscsWingedEdge::vertex(int vertex)
{
    return vertex < 0 ? 0 : &m_vertices.at(vertex);
}

inline const CscsPathVertex *CscsWingedEdge::vertex(int vertex) const
{
    return vertex < 0 ? 0 : &m_vertices.at(vertex);
}

inline CscsPathEdge::Traversal CscsWingedEdge::flip(CscsPathEdge::Traversal traversal)
{
    return traversal == CscsPathEdge::RightTraversal ? CscsPathEdge::LeftTraversal : CscsPathEdge::RightTraversal;
}

inline CscsPathEdge::Direction CscsWingedEdge::flip(CscsPathEdge::Direction direction)
{
    return direction == CscsPathEdge::Forward ? CscsPathEdge::Backward : CscsPathEdge::Forward;
}

END_NAMESPACE
#endif