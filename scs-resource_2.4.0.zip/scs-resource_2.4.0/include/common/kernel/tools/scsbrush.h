#ifndef SCSBRUSH_H
#define SCSBRUSH_H
#include <memory>
#include "scsrgba.h"
#include "scsimage.h"
#include "scsgradient.h"

BEGIN_NAMESPACE(Gemini)

struct CscsBrushData;

class CscsBrush{
public:
	enum BrushType{
		NoBrush,
		ColorBrush,
		ImageBrush,
		GradientBrush
	};

	CscsBrush();
	CscsBrush(BrushType type);
	CscsBrush(const CscsRgba& color);
	CscsBrush(GlobalColor color);
	CscsBrush(const CscsImage& image);
	CscsBrush(const CscsGradient& gradient);

	CscsBrush(const CscsBrush& o);
	CscsBrush& operator=(const CscsBrush& o);

	virtual ~CscsBrush();
	CscsBrush::BrushType brushType()const;
	const CscsRgba& 	color()const;
	const CscsImage& 	image()const;
	const CscsGradient& gradient()const;

	void setColor(const CscsRgba& color);
	void setImage(const CscsImage& image);
	void setGradient(const CscsGradient& gradient);

	bool isValid()const;

	bool isOpaque()const;

	bool operator==(const CscsBrush& o)const;
	bool operator!=(const CscsBrush&o)const{
		return !(*this==o);
	}

private:
	CscsBrushData* data;
	CscsBrush& copyFrom(const CscsBrush& o);
};
SCS_DECLARE_TYPEINFO(CscsBrush)
SCS_DECLARE_TYPENAME_INFO(CscsBrush, SCS_MOVABLE_TYPE)

struct CscsBrushData{
	~CscsBrushData();
	CscsBrush::BrushType type;
	CscsRgba color;
	CscsImage image;
	CscsGradient gradient;
};


END_NAMESPACE

#endif