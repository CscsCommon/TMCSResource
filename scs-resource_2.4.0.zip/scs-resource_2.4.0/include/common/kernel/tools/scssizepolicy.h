#ifndef SCSSIZEPOLICY_H
#define SCSSIZEPOLICY_H
#include <kernel/scstypes.h>
#include "../scsenum.h"
#include <kernel/scstypeinfo.h>

BEGIN_NAMESPACE(Gemini)

class  CscsSizePolicy
{

public:
    enum PolicyFlag {
        GrowFlag = 1,
        ExpandFlag = 2,
        ShrinkFlag = 4,
        IgnoreFlag = 8
    };

    enum Policy {
        Fixed = 0,
        Minimum = GrowFlag,
        Maximum = ShrinkFlag,
        Preferred = GrowFlag | ShrinkFlag,
        MinimumExpanding = GrowFlag | ExpandFlag,
        Expanding = GrowFlag | ShrinkFlag | ExpandFlag,
        Ignored = ShrinkFlag|GrowFlag|IgnoreFlag
    };

    CscsSizePolicy() : data(0) { }

    CscsSizePolicy(Policy horizontal, Policy vertical)
        : data(horizontal | (vertical<<HSize)) { }

    Policy horizontalPolicy() const { return static_cast<Policy>(data & HMask); }
    Policy verticalPolicy() const { return static_cast<Policy>((data & VMask) >> HSize); }

    void setHorizontalPolicy(Policy d) { data = (data & ~HMask) | d; }
    void setVerticalPolicy(Policy d) { data = (data & ~(HMask << HSize)) | (d << HSize); }

    SCS::Orientations expandingDirections() const {
        SCS::Orientations result;
        if (verticalPolicy() & ExpandFlag)
            result |= SCS::Vertical;
        if (horizontalPolicy() & ExpandFlag)
            result |= SCS::Horizontal;
        return result;
    }

    void setHeightForWidth(bool b) { data = b ? (data | (1 << 2*HSize)) : (data & ~(1 << 2*HSize));  }
    bool hasHeightForWidth() const { return data & (1 << 2*HSize); }

    bool operator==(const CscsSizePolicy& s) const { return data == s.data; }
    bool operator!=(const CscsSizePolicy& s) const { return data != s.data; }

    int horizontalStretch() const { return data >> 24; }
    int verticalStretch() const { return (data >> 16) & 0xff; }
    void setHorizontalStretch(uint8 stretchFactor) { data = (data&0x00ffffff) | (uint(stretchFactor)<<24); }
    void setVerticalStretch(uint8 stretchFactor) { data = (data&0xff00ffff) | (uint(stretchFactor)<<16); }

    void transpose();

private:
    enum SizePolicyMasks {
        HSize = 4,
        HMask = 0x0f,
        VMask = HMask << HSize
    };

private:
    CscsSizePolicy(int i) : data(i) { }

    uint32 data;
};
SCS_DECLARE_TYPEINFO(CscsSizePolicy)

inline void CscsSizePolicy::transpose() {
    Policy hData = horizontalPolicy();
    Policy vData = verticalPolicy();
    uint8 hStretch = horizontalStretch();
    uint8 vStretch = verticalStretch();
    setHorizontalPolicy(vData);
    setVerticalPolicy(hData);
    setHorizontalStretch(vStretch);
    setVerticalStretch(hStretch);
}

END_NAMESPACE

#endif