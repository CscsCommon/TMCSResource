/*Created by J.Wong 2016/09/19*/

#ifndef SCSBEZIER_H
#define SCSBEZIER_H

#include <assert.h>
#include <iostream>

#include "scsdatabuffer.h"
#include "scspoint.h"
#include "scspolygon.h"
#include "scsrect.h"
#include "scsline.h"

BEGIN_NAMESPACE(Gemini)

//class CscsMatrix;
class CscsBezier{
	public:
	static CscsBezier fromPoints(const CscsPointF& p1,const CscsPointF& p2,
							  const CscsPointF& p3,const CscsPointF& p4);
	static void coefficients(double t,double& a, double& b, double& c, double& d);
	inline CscsPointF pointAt(double t)const;
	inline CscsPointF normalVector(double t)const;
	inline CscsPointF derivedAt(double t)const;
	inline CscsPointF secondDerivedAt(double t)const;
	CscsPolygonF toPolygon(double bezier_flattening_threshold =0.5)const;
	void 	addToPolygon(CscsPolygonF *p, double bezier_flattening_threshold=0.5)const;
	void 	addToPolygon(CscsDataBuffer<CscsPointF>& polygon,double bezier_flattening_threshold)const;
	CscsRectF	bounds()const;
	double 	length(double error=0.01)const;
	void	addIfClose(double* length, double error)const;
	double	tAtLength(double len)const;
	int		stationaryYPoints(double& t0, double& t1)const;
	double	tForY(double t0, double t1, double y)const;
	CscsPointF  	pt1()const{return CscsPointF(x1,y1);}
	CscsPointF 	pt2()const{return CscsPointF(x2,y2);}
	CscsPointF		pt3()const{return CscsPointF(x3,y3);}
	CscsPointF 	pt4()const{return CscsPointF(x4,y4);}
	// CscsBezier		mapBy(const CscsMatrix& matrix)const;
	
	inline		CscsPointF midPoint()const;
	inline 		CscsLineF	midTangent()const;
	
	inline 		CscsLineF	startTangent()const;
	inline		CscsLineF	endTangent()const;
	inline		void	parameterSplitLeft(double t, CscsBezier* left);
	inline		void	split(CscsBezier* firstHalf, CscsBezier* secondHalf)const;
	int 		shifted(CscsBezier* curveSegments, int maxSegmets, double offset, double threshold)const;
	CscsBezier		bezierOnInterval(double t0, double t1)const;
	CscsBezier		getSubRange(double t0, double t1)const;
	
	double x1, y1, x2, y2, x3, y3, x4, y4;
};



inline	CscsPointF CscsBezier::midPoint()const
{
	/*
	*	t:0~1
	*	P(t)=A*(1-t)^3+3*B*(1-t)^2*t+3*C*(1-t)*t^2+D*t^3
	*   P(0.5)=1/8*A+3/8*B+3/8*C+1/8*D
	*/
	return CscsPointF((x1+3*(x2+x3)+x4)/8.,(y1+3*(y2+y3)+y4)/8.);
}

inline 	CscsLineF	CscsBezier::midTangent()const
{
	CscsPointF mid=midPoint();
	CscsLineF dir=CscsLineF(CscsLineF(x1,y1,x2,y2).pointAt(0.5),CscsLineF(x3,y3,x4,y4).pointAt(0.5));
	return CscsLineF(mid.x() - dir.dx(), mid.y() - dir.dy(),
                  mid.x() + dir.dx(), mid.y() + dir.dy());
}

inline 	CscsLineF	CscsBezier::startTangent()const
{
	CscsLineF tangent(pt1(),pt2());
	if(tangent.isNull())
	{
		tangent=CscsLineF(pt1(),pt3());
	}
	if(tangent.isNull())
	{
		tangent=CscsLineF(pt1(),pt4());
	}
	return tangent;
}

inline		CscsLineF	CscsBezier::endTangent()const
{
	CscsLineF tangent(pt4(),pt3());
	if(tangent.isNull())
	{
		tangent=CscsLineF(pt4(),pt2());
	}
	if(tangent.isNull())
	{
		tangent=CscsLineF(pt4(),pt1());
	}
	return tangent;
}




inline CscsPointF  CscsBezier::pointAt(double t)const
{
	/*
	* P(t)=A*(1-t)^3+3*B*(1-t)^2*t+3*C*(1-t)*t^2+D*t^3
	* P(t)=(1-t)^2*(A*(1-t)+3*B*t)+t^2*(3*C*(1-t)+D*t)
	*/
	double x, y;
	double m_t=1-t;
	{
		double a=x1*m_t+3*x2*t;
		double b=3*x3*m_t+x4*t;
		double c=m_t*m_t;
		double d=t*t;
		x= a*c+b*d;
	}
	{
		double a=y1*m_t+3*y2*t;
		double b=3*y3*m_t+y4*t;
		double c=m_t*m_t;
		double d=t*t;
		y= a*c+b*d;
	}
	return CscsPointF(x,y);
}

inline CscsPointF  CscsBezier::normalVector(double t)const
{
	//p'(t) =  3*(-(1-2t+t^2) * p0 + (1 - 4 * t + 3 * t^2) * p1 + (2 * t - 3 * t^2) * p2 + t^2 * p3)
    //x(t)= -(1-t)^2*p0+(1-t)^2*p1-2*t(1-t)*p1+2*t(1-t)*p2-t^2*p2+t^2*p3
    //x(t)=a*(p1-p0)+b*(p2-p1)+c*(p3-p1)
    //a=(1-t)^2  b=2*t(1-t)  c=t^2
	//why not true
	double m_t =1-t;
	double a=m_t*m_t;
	double b=t*m_t;
	double c=t*t;
	return CscsPointF((y2-y1)*a+(y3-y2)*b+(y4-y3)*c,-(x2-x1)*a-(x3-x2)*b-(x4-x3)*c);
}

inline CscsPointF  CscsBezier::derivedAt(double t)const
{
	// p'(t) = 3 * (-(1-2t+t^2) * p0 + (1 - 4 * t + 3 * t^2) * p1 + (2 * t - 3 * t^2) * p2 + t^2 * p3)

    double m_t = 1. - t;

    double d = t * t;
    double a = -m_t * m_t;
    double b = 1 - 4 * t + 3 * d;
    double c = 2 * t - 3 * d;

    return 3 * CscsPointF(a * x1 + b * x2 + c * x3 + d * x4,
                       a * y1 + b * y2 + c * y3 + d * y4);
}

inline CscsPointF  CscsBezier::secondDerivedAt(double t)const
{
	// p"(t) = 3 * ((2-2t) * p0 + (- 4  + 6*t) * p1 + (2 - 6*t) * p2 + 2t * p3)
	
	double a = 2. - 2. * t;
    double b = -4 + 6 * t;
    double c = 2 - 6 * t;
    double d = 2 * t;

    return 3 * CscsPointF(a * x1 + b * x2 + c * x3 + d * x4,
                       a * y1 + b * y2 + c * y3 + d * y4);
}


inline		void	CscsBezier::parameterSplitLeft(double t, CscsBezier* left)
{
	
	left->x1 = x1;
    left->y1 = y1;

    left->x2 = x1 + t * ( x2 - x1 );
    left->y2 = y1 + t * ( y2 - y1 );

    left->x3 = x2 + t * ( x3 - x2 ); // temporary holding spot
    left->y3 = y2 + t * ( y3 - y2 ); // temporary holding spot

    x3 = x3 + t * ( x4 - x3 );
    y3 = y3 + t * ( y4 - y3 );

    x2 = left->x3 + t * ( x3 - left->x3);
    y2 = left->y3 + t * ( y3 - left->y3);

    left->x3 = left->x2 + t * ( left->x3 - left->x2 );
    left->y3 = left->y2 + t * ( left->y3 - left->y2 );

    left->x4 = x1 = left->x3 + t * (x2 - left->x3);
    left->y4 = y1 = left->y3 + t * (y2 - left->y3);
}

inline		void	CscsBezier::split(CscsBezier* firstHalf, CscsBezier* secondHalf)const
{
	assert(firstHalf);
    assert(secondHalf);

    double c = (x2 + x3)*.5;
    firstHalf->x2 = (x1 + x2)*.5;
    secondHalf->x3 = (x3 + x4)*.5;
    firstHalf->x1 = x1;
    secondHalf->x4 = x4;
    firstHalf->x3 = (firstHalf->x2 + c)*.5;
    secondHalf->x2 = (secondHalf->x3 + c)*.5;
    firstHalf->x4 = secondHalf->x1 = (firstHalf->x3 + secondHalf->x2)*.5;

    c = (y2 + y3)/2;
    firstHalf->y2 = (y1 + y2)*.5;
    secondHalf->y3 = (y3 + y4)*.5;
    firstHalf->y1 = y1;
    secondHalf->y4 = y4;
    firstHalf->y3 = (firstHalf->y2 + c)*.5;
    secondHalf->y2 = (secondHalf->y3 + c)*.5;
    firstHalf->y4 = secondHalf->y1 = (firstHalf->y3 + secondHalf->y2)*.5;
}

END_NAMESPACE

#endif