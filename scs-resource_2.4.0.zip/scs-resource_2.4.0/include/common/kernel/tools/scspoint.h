///////////////////////////////////////////////////////////
//  scspoint.h
//  Implementation of the Class CscsPoint
//  Created on:      29-10月-2018 16:06:56
//  Original author: jian.wang
///////////////////////////////////////////////////////////

#ifndef SCSPOINT_H
#define SCSPOINT_H
#include <iostream>
#include "scsmath.h"
#include <kernel/scstypeinfo.h>

BEGIN_NAMESPACE(Gemini)

class CscsPoint
{

public:
	CscsPoint();
	CscsPoint(int x, int y);
    ~CscsPoint();

    inline static int dotProduct(const CscsPoint& p1, const CscsPoint& p2);
    inline int manhattenLength() const;
    inline bool isNull() const;

    inline friend const CscsPoint operator+(const CscsPoint& p1, const CscsPoint& p2);
    inline friend const CscsPoint operator-(const CscsPoint& p1, const CscsPoint& p2);
    inline friend const CscsPoint operator*(const CscsPoint& point, int factor);
    inline friend const CscsPoint operator*(int factor, const CscsPoint& point);
    inline friend const CscsPoint operator/(const CscsPoint& point, int factor);

    inline friend const CscsPoint operator+(const CscsPoint& point);
    inline friend const CscsPoint operator-(const CscsPoint& point);

    inline CscsPoint& operator+=(const CscsPoint& p);
    inline CscsPoint& operator-=(const CscsPoint& p);
    inline CscsPoint& operator*=(int factor);
    inline CscsPoint& operator/=(int factor);
    inline CscsPoint& operator*=(double factor);
    inline CscsPoint& operator/=(double factor);

    inline friend bool operator!=(const CscsPoint& p1, const CscsPoint& p2);
    inline friend bool operator==(const CscsPoint& p1, const CscsPoint& p2);

    inline friend std::istream& operator>>(std::istream& is, CscsPoint& point);
    inline friend std::ostream& operator<<(std::ostream& os, const CscsPoint& point);

    inline void setX(int x);
    inline void setY(int y);
    inline int& rx();
    inline int& ry();
    inline int x() const;
    inline int y() const;

private:
	int m_x;
	int m_y;

};
SCS_DECLARE_TYPEINFO(CscsPoint)
SCS_DECLARE_TYPENAME_INFO(CscsPoint,SCS_MOVABLE_TYPE)

inline CscsPoint::CscsPoint():m_x(0), m_y(0){}

inline CscsPoint::CscsPoint(int x, int y):m_x(x), m_y(y){}

inline CscsPoint::~CscsPoint(){}


inline int CscsPoint::dotProduct(const CscsPoint& p1, const CscsPoint& p2)
{ return 0; }

inline int CscsPoint::manhattenLength() const
{ return 0; }

inline bool CscsPoint::isNull() const
{ return (m_x == 0 && m_y == 0); }


inline const CscsPoint operator+(const CscsPoint& p1, const CscsPoint& p2)
{ return  CscsPoint(p1.m_x+p2.m_x, p1.m_y+p2.m_y); }

inline const CscsPoint operator-(const CscsPoint& p1, const CscsPoint& p2)
{ return  CscsPoint(p1.m_x - p2.m_x, p1.m_y - p2.m_y); }

inline const CscsPoint operator*(int factor, const CscsPoint& point)
{ return  CscsPoint(point.m_x*factor, point.m_y*factor); }

inline const CscsPoint operator*(const CscsPoint& point, int factor)
{ return  CscsPoint(point.m_x*factor, point.m_y*factor); }

inline const CscsPoint operator/(const CscsPoint& point, int factor)
{ return  CscsPoint(point.m_x/factor, point.m_y/factor); }


inline const CscsPoint operator+(const CscsPoint& point)
{ return  point; }

inline const CscsPoint operator-(const CscsPoint& point)
{ return  CscsPoint(-point.m_x, -point.m_y); }

inline CscsPoint& CscsPoint::operator+=(const CscsPoint& p)
{ m_x += p.m_x; m_y += p.m_y; return  *this; }

inline CscsPoint& CscsPoint::operator-=(const CscsPoint& p)
{ m_x -= p.m_x; m_y -= p.m_y; return  *this; }

inline CscsPoint& CscsPoint::operator*=(int factor)
{ m_x *= factor; m_y *= factor; return  *this; }

inline CscsPoint& CscsPoint::operator/=(int factor)
{ m_x /= factor; m_y /= factor; return *this; }

inline CscsPoint& CscsPoint::operator*=(double factor)
{m_x *= factor; m_y *= factor; return  *this;}

inline CscsPoint& CscsPoint::operator/=(double factor)
{m_x /= factor; m_y /= factor; return *this;}

inline bool operator==(const CscsPoint& p1, const CscsPoint& p2)
{ return p1.m_x == p2.m_x && p1.m_y == p2.m_y; }


inline bool operator!=(const CscsPoint& p1, const CscsPoint& p2)
{ return (p1.m_x != p2.m_x || p1.m_y !=p2.m_y); }

inline std::ostream& operator<<(std::ostream& os, const CscsPoint& point)
{ os << point.m_x <<" "<< point.m_y << std::endl; return  os; }

inline std::istream& operator>>(std::istream& is, CscsPoint& point)
{
    is >> point.m_x >> point.m_y;
    if( !is )
        point = CscsPoint();
    return  is;
}


inline void CscsPoint::setX(int x)
{ m_x = x; }

inline void CscsPoint::setY(int y)
{ m_y = y; }

inline int& CscsPoint::rx()
{ return  m_x; }

inline int& CscsPoint::ry()
{ return  m_y; }

inline int CscsPoint::x() const
{ return m_x; }

inline int CscsPoint::y() const
{ return m_y; }




class CscsPointF
{

public:
	CscsPointF();
	CscsPointF(const CscsPoint& p);
	CscsPointF(double x, double y);
    virtual ~CscsPointF();


    inline static double dotProduct(const CscsPointF& p1, const CscsPointF& p2);
    inline double manhattenLength() const;
    inline CscsPoint toPoint() const;
    inline bool isNull() const;

    inline friend const CscsPointF operator+(const CscsPointF& p1, const CscsPointF& p2);
    inline friend const CscsPointF operator-(const CscsPointF& p1, const CscsPointF& p2);
    inline friend const CscsPointF operator*(const CscsPointF& p, double factor);
    inline friend const CscsPointF operator*(const CscsPointF& p, int factor);
    inline friend const CscsPointF operator*(double factor, const CscsPointF& p);
    inline friend const CscsPointF operator*(int factor, const CscsPointF& p);
    inline friend const CscsPointF operator/(const CscsPointF& p, int factor);
    inline friend const CscsPointF operator/(const CscsPointF& p, double factor);


    inline friend const CscsPointF operator+(const CscsPointF& p);
    inline friend const CscsPointF operator-(const CscsPointF& p);


    inline CscsPointF& operator+=(const CscsPointF& p);
    inline CscsPointF& operator-=(const CscsPointF& p);
    inline CscsPointF& operator*=(double factor);
    inline CscsPointF& operator/=(double factor);


    inline friend bool operator!=(const CscsPointF& p1, const CscsPointF& p2);
    inline friend bool operator==(const CscsPointF& p1, const CscsPointF& p2);
    inline friend std::istream& operator>>(std::istream& is, CscsPointF& p);
    inline friend std::ostream& operator<<(std::ostream& os, const CscsPointF& p);


    inline void setX(double x);
    inline void setY(double y);
    inline double& rx();
    inline double& ry();
    inline double x() const;
    inline double y() const;

private:
	double m_x;
	double m_y;

};
SCS_DECLARE_TYPEINFO(CscsPointF)
SCS_DECLARE_TYPENAME_INFO(CscsPointF,SCS_MOVABLE_TYPE)

inline CscsPointF::CscsPointF():m_x(0), m_y(0){
}
inline CscsPointF::CscsPointF(const CscsPoint& p):m_x(p.x()), m_y(p.y()){
}

inline CscsPointF::CscsPointF(double x, double y):m_x(x), m_y(y){
}
inline CscsPointF::~CscsPointF(){}


inline double CscsPointF::dotProduct(const CscsPointF& p1, const CscsPointF& p2){

    return 0;
}

inline double CscsPointF::manhattenLength() const{

    return 0;
}

inline CscsPoint CscsPointF::toPoint() const{

    return  CscsPoint(m_x,m_y);
}

inline bool CscsPointF::isNull() const
{ return scsIsNull(m_x) && scsIsNull(m_y); }


inline const CscsPointF operator+(const CscsPointF& p1, const CscsPointF& p2)
{ return  CscsPointF(p1.m_x+p2.m_x, p1.m_y+p2.m_y); }

inline const CscsPointF operator-(const CscsPointF& p1, const CscsPointF& p2)
{ return CscsPointF(p1.m_x - p2.m_x, p1.m_y - p2.m_y); }

inline const CscsPointF operator*(const CscsPointF& p, int factor)
{ return  CscsPointF(p.m_x*factor, p.m_y*factor); }

inline const CscsPointF operator*(double factor, const CscsPointF& p)
{ return  CscsPointF(p.m_x*factor, p.m_y*factor); }

inline const CscsPointF operator*(const CscsPointF& p, double factor)
{ return  CscsPointF(p.m_x*factor, p.m_y*factor); }

inline const CscsPointF operator*(int factor, const CscsPointF& p)
{ return  CscsPointF(p.m_x*factor, p.m_y*factor); }

inline const CscsPointF operator/(const CscsPointF& p, int factor)
{ return  CscsPointF(p.m_x/factor, p.m_y/factor); }

inline const CscsPointF operator/(const CscsPointF& p, double factor)
{ return  CscsPointF(p.m_x/factor, p.m_y/factor); }


inline const CscsPointF operator+(const CscsPointF& p)
{ return  p; }

inline const CscsPointF operator-(const CscsPointF& p)
{ return  CscsPointF(-p.m_x, -p.m_y); }


inline CscsPointF& CscsPointF::operator+=(const CscsPointF& p)
{ m_x += p.m_x; m_y += p.m_y; return  *this; }

inline CscsPointF& CscsPointF::operator-=(const CscsPointF& p)
{ m_x -= p.m_x; m_y -= p.m_y; return  *this; }

inline CscsPointF& CscsPointF::operator*=(double factor)
{ m_x *= factor; m_y *= factor; return  *this; }

inline CscsPointF& CscsPointF::operator/=(double factor)
{ m_x /= factor; m_y /= factor; return  *this; }


inline bool operator!=(const CscsPointF& p1, const CscsPointF& p2)
{ return (p1.m_x != p2.m_x || p1.m_y != p2.m_y); }

inline bool operator==(const CscsPointF& p1, const CscsPointF& p2)
{ return p1.m_x == p2.m_x && p1.m_y == p2.m_y; }


inline std::ostream& operator<<(std::ostream& os, const CscsPointF& p)
{ os << p.m_x <<" "<< p.m_y; return  os; }

inline std::istream& operator>>(std::istream& is, CscsPointF& p)
{ is >> p.m_x >> p.m_y; return  is; }


inline void CscsPointF::setX(double x)
{ m_x = x; }

inline void CscsPointF::setY(double y)
{ m_y = y; }

inline double& CscsPointF::rx()
{ return  m_x; }

inline double& CscsPointF::ry()
{ return  m_y; }

inline double CscsPointF::x() const
{
    return m_x;
}

inline double CscsPointF::y() const
{ return m_y; }

END_NAMESPACE

#endif // SCSPOINT_H
