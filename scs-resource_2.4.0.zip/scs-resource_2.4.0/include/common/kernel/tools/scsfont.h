#ifndef SCSFONT_H
#define SCSFONT_H
#include "scsrgba.h"
#include "scsmatrix.h"
#include <config.h>
#include <ft2build.h>
#include <freetype/freetype.h>
#include <cairo/cairo-ft.h>
#include <string>
#include <memory>

BEGIN_NAMESPACE(Gemini)

class CscsFontData;
class CscsFont{
public:
	enum {
       	Size 		  =0x01,
       	Color         =0x02,
       	Bold		  =0x04,
       	Italic		  =0x08,
       	FontKey       =0x10,
       	Matrix    	  =0x20,
        Complete      = 0x0fff
    };
	CscsFont();
	CscsFont(const std::string& file);
	CscsFont(const CscsFont& f);
	CscsFont& operator=(const CscsFont& f);
	~CscsFont();
	int fontSize()const;
	const std::string& key()const;
	const CscsRgba& color()const;
	const CscsMatrix& matrix()const;
	bool italic()const;
	bool bold()const;
	void setFontSize(int size);
	void setColor(const CscsRgba& color);
	void setMatrix(const CscsMatrix& matrix);
	void setBold(bool bold);
	void setItalic(bool italic);
	bool isCopyOf(const CscsFont& f)const;
	cairo_font_face_t* dataPtr()const;
	bool operator==(const CscsFont&)const;
	bool operator!=(const CscsFont&)const;
	void resolve(uint mask);
	uint resolve()const;
	CscsFont resolve(const CscsFont&) const; 
private:
	CscsFontData* data;
	CscsFont& copyFrom(const CscsFont& o);
	void resolve(uint mask,const CscsFont& o);
};
SCS_DECLARE_TYPEINFO(CscsFont)
END_NAMESPACE

#endif