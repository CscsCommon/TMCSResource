#ifndef SCSTIMELINE_H
#define SCSTIMELINE_H
#include <kernel/scsobject.h>

BEGIN_NAMESPACE(Gemini)

class CscsTimeLinePrivate;
class  CscsTimeLine : public CscsObject
{
public:
    enum State {
        NotRunning,
        Paused,
        Running
    };
    enum Direction {
        Forward,
        Backward
    };
    enum CurveShape {
        EaseInCurve,
        EaseOutCurve,
        EaseInOutCurve,
        LinearCurve,
        SineCurve,
        CosineCurve
    };

    explicit CscsTimeLine(int duration = 1000, CscsObject *parent = 0);
    virtual ~CscsTimeLine();

    State state() const;

    int loopCount() const;
    void setLoopCount(int count);

    Direction direction() const;
    void setDirection(Direction direction);

    int duration() const;
    void setDuration(int duration);

    int startFrame() const;
    void setStartFrame(int frame);
    int endFrame() const;
    void setEndFrame(int frame);
    void setFrameRange(int startFrame, int endFrame);

    int updateInterval() const;
    void setUpdateInterval(int interval);

    CurveShape curveShape() const;
    void setCurveShape(CurveShape shape);

    int currentTime() const;
    int currentFrame() const;
    double currentValue() const;

    int frameForTime(int msec) const;
    virtual double valueForTime(int msec) const;

SLOTS:
    void start();
    void resume();
    void stop();
    void setPaused(bool paused);
    void setCurrentTime(int msec);
    void toggleDirection();

SIGNALS:
    void valueChanged(double x){}
    void frameChanged(int){}
    void stateChanged(CscsTimeLine::State newState){}
    void finished(){}

protected:
    void timerEvent(CscsTimerEvent *event);

private:
    CscsTimeLinePrivate* d_func()const;

BEGIN_PROPERTY(CscsTimeLine,CscsObject)
    META_PROPERTY(int, duration, READ, duration, WRITE, setDuration)
    META_PROPERTY(int, updateInterval, READ, updateInterval, WRITE, setUpdateInterval)
    META_PROPERTY(int, currentTime, READ, currentTime, WRITE, setCurrentTime)
    META_PROPERTY(Direction, direction, READ, direction, WRITE, setDirection)
    META_PROPERTY(int, loopCount, READ, loopCount, WRITE, setLoopCount)
    META_PROPERTY(CurveShape, curveShape, READ, curveShape, WRITE, setCurveShape)
END_PROPERTY
};

END_NAMESPACE

#endif