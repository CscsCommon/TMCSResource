#ifndef SCSPAINTER_H
#define SCSPAINTER_H
#include <memory>
#include <config.h>
#include <cairo/cairo.h>
#include <kernel/scsnocopy.hpp>
#include "scspen.h"
#include "scsbrush.h"
#include "scsimage.h"
#include "scsmatrix.h"
#include "scsenum.h"
#include "scspoint.h"
#include "scspath.h"
#include "scsfont.h"
#include <stack>

BEGIN_NAMESPACE(Gemini)

class CscsLineF;
class CscsRectF;
class CscsRect;
class CscsPolygonF;
class CscsRegion;
class CscsWidget;
class CscsPaintDevice;
class CscsSurfaceView;


struct CscsPainterData;

class CscsPainter:public CscsNoCopyable{
public:
	enum ImageFillMode{
		ImageNormal,
		ImageRepeat,
		ImageReflect,
		ImagePad,
		ImageStretch
	};

	enum ClipOperation{
		Replace, //替换
		Union,    //和当前区域求并   
		InterSect, //和当前区域相交区域
		Subtract, //current-region2
		Xored
	};

	enum AntialiasMode{
		AntialiasDefault,
		AntialiasNone,
		AntialiasGray,
		AntialiasSubPixel,
		AntialiasFast,
		AntialiasGood,
		AntialiasBest
	};

	enum FillRule{
		WindingRule,
		EvenOddRule
	};

	enum AlignmentFlag{
		AlignLeft=0x01,
		AlignRight=0x02,
		AlignHCenter=0x04,
		AlignTop=0x20,
		AlignBottom=0x40,
		AlignVCenter=0x80
	};

	enum CompositionOperator{
	CompositionClear,
    CompositionSource,
    CompositionSourceOver,
    CompositionSourceIn,
    CompositionSourceOut,
    CompositionSourceATop,
    CompositionDest,
    CompositionDestOver,
    CompositionDestIn,
    CompositionDestOut,
    CompositionDestATop,
    CompositionXor,
    CompositionAdd,
    CompositionSaturate,
    CompositionMultiply,
    CompositionScreen,
    CompositionOverlay,
    CompositionDarken,
    CompositionLighten,
    CompositionColorDodge,
    CompositionColorBurn,
    CompositionHardLight,
    CompositionSoftLight,
    CompositionDifference,
    CompositionExclusion,
    CompositionHslHue,
    CompositionHslSaturation,
    CompositionHslColor,
    CompositionHslLuminosity
	};

	CscsPainter(const CscsImage* canvas=0);
	CscsPainter(const CscsPaintDevice* dev);
	virtual ~CscsPainter();
	bool isValid()const;


	void setFillRule(CscsPainter::FillRule rule);
	CscsPainter::FillRule fillRule()const;

	void setCompositionOperator(CscsPainter::CompositionOperator op);
	CscsPainter::CompositionOperator compositionOperator()const;
	void setAntialiased(CscsPainter::AntialiasMode mode);
	CscsPainter::AntialiasMode antialiased()const;

	void setPen(const CscsPen& pen);
	void setBrush(const CscsBrush& brush);

	const CscsPen& pen()const;
	const CscsBrush& brush()const;

	void setFont(const CscsFont& font);
	const CscsFont& font()const;

	const CscsPointF& origin()const;
	void setOrigin(const CscsPointF& p);
	void setOrigin(double x, double y){
		setOrigin(CscsPointF(x,y));
	}

	CscsRectF  boundingRect(const CscsRectF& rect, const std::string& text,int flags=0);
	CscsRectF  boundingRect(double x, double y, double w, double h, const std::string& text,int flags=0){
		return boundingRect(CscsRectF(x, y, w, h),text,flags);
	}

	int metricsText(const std::string& text);

	void save();
	void restore();

	void drawPoint(double x, double y);
	void drawPoint(const CscsPointF& point);
	void drawPoints(const CscsVector<CscsPointF>& points);
	void drawPoints(const CscsPointF* points, int size);
	void drawPoints(const CscsPoint* points, int size);

	void drawLine(double x1, double y1, double x2, double y2);
	inline void drawLine(const CscsPointF& p1, const CscsPointF& p2) {
		drawLine(p1.x(),p1.y(),p2.x(),p2.y());
	}
	void drawLine(const CscsLineF& line);
	void drawLines(const CscsVector<CscsLineF>& lines);

	void drawPolygon(const CscsPolygonF& poly);
 	void drawPolygon(const CscsPointF* points, int size);
 	void drawPolygon(const CscsPoint* points, int size);
 	void drawRect(double x, double y, double width, double height);
 	void drawRect(const CscsRectF& rect);
 	void drawRects(const CscsVector<CscsRectF>& rects);

 	void drawRoundedRect(const CscsRectF& rect, double xRadius, double yRadius,SCS::SizeMode mode=SCS::RelativeSize);
 	void drawRoundedRect(double x, double y, double width, double height,double xRadius,double yRadius,SCS::SizeMode mode=SCS::RelativeSize);


 	//angle is actual angle mutiply 16
 	void drawArc(const CscsRectF& rectangle, int startAngle, int spanAngle);
 	void drawArc(double x, double y, double width, double height, int startAngle, int spanAngle);

 	void drawChord(const CscsRectF& rect, int startAngle, int spanAngle);
 	void drawChord(double x, double y, double width ,double height, int startAngle, int spanAngle);

 	void drawPie(const CscsRectF& rect, int startAngle, int spanAngle);
 	void drawPie(double x, double y, double width, double height, int startAngle, int spanAngle);

 	void drawEllipse(const CscsRectF& rect);
 	void drawEllipse(double x, double y, double width, double height);

 	void drawImage(const CscsRectF& target, const CscsImage& image, ImageFillMode mode=ImageNormal);
 	void drawImage(double x, double y, const CscsImage& image);

 	void drawImage(const CscsRectF& target, const CscsImage& image, const CscsRectF& src);

 	void drawImage(const CscsRectF& target, const CscsSurfaceView& view, ImageFillMode mode=ImageNormal);
 	void drawImage(double x, double y, const CscsSurfaceView& view);



 	void drawTiledImage(const CscsRectF& rect, const CscsImage& image,const CscsPointF& pt=CscsPointF());
 	void drawTiledImage(double x, double y, double width, double height, const CscsImage& image, int sx=0, int sy=0);

 	void drawPath(const CscsPath& path);

 	void drawTextItem(int x, int y, const std::string& text);
 	
 	void drawText(int x,int  y,const std::string& text);
 	inline void drawText(const CscsPoint& pos, const std::string& text){
 		drawText(pos.x(),pos.y(),text);
 	}
 	void drawText(const CscsRectF& rect, const std::string& text,int flags=0,CscsRectF* bounding=0);
 	void drawRotateText(const CscsRectF& rect, const std::string& text,int flags);
 	void setClipPath(const CscsPath& path);
 	void setClipRect(const CscsRect& rect, CscsPainter::ClipOperation op=Replace);
 	void setClipRegion(const CscsRegion& region,CscsPainter::ClipOperation op=Replace);

 	void resetClip();

 	void setMatrix(const CscsMatrix& matrix);
 	void setWorldMatrix(const CscsMatrix& matrix,bool enabled);
 	void resetMatrix();
 	

 	CscsMatrix matrix()const;

 	void rotate(double angle);
 	void translate(double x, double y);
 	void shear(double sh,double sv);
 	void scale(double sx, double sy);




private:
	// std::shared_ptr<CscsPainterData> data;
	CscsPainterData* data;

	void set_canvas_helper(cairo_surface_t* surface);
	void set_canvas_helper(const CscsSurfaceView* view);
	void set_canvas_helper(const CscsImage* canvas);
	void set_pen_helper();
	void set_brush_pattern_helper();
	void paint_helper(double x=0, double y=0);
	bool isNeedPainter();
	void draw_ellipse_helper(double x, double y, double w, double h);
	void draw_rounded_rect_helper(double x, double y, double w, double h, double xRadius, double yRadius,SCS::SizeMode mode);
	void draw_path_helper(const CscsPath& path);

	void set_linear_gradient_helper(const CscsLinearGradient& linear);
	void set_radial_gradient_helper(const CscsRadialGradient& radial);

	void set_clip_path_helper(const CscsPath& path);
	void set_rect_path_helper(CscsRect* rects, int nums, CscsPainter::ClipOperation op);
	void set_region_path_helper(const CscsRegion& region,CscsPainter::ClipOperation op);

	void set_font_helper();
};


END_NAMESPACE

#endif
