#ifndef SCSMEMORYDATASTORAGE_H
#define SCSMEMORYDATASTORAGE_H

#include "scsparsedbjson.h"
#include <kernel/scsmutex.h>
#include <unordered_map>

BEGIN_NAMESPACE(Gemini)

class CscsMemoryDB;
class CscsTimerEvent;

class CscsMemoryDataStorage:public CscsAbstractDataStorage{

public:
    CscsMemoryDataStorage(CscsObject* parent=nullptr);
    ~CscsMemoryDataStorage();

    //通过StringID获取nameID
    virtual std::string nameID(uint id)const;
    //通过NameID获取StringID
    virtual uint  ID(const std::string& nameID)const;

    virtual uint commSource(uint id)const;
    virtual uint commSource(const std::string& nameID)const;

    virtual CscsVariant toStoreValue(uint storeType, const CscsVariant& currentVar)const;

    //批量获取nameID
    virtual std::vector<std::string> nameIDList(const std::vector<uint>& ids)const;

    //批量获取ID
    virtual std::vector<uint> IDList(const std::vector<std::string>& nameIDs)const;

    virtual std::vector<uint> commSourceList(const std::vector<uint>& ids)const;
    virtual std::vector<uint> commSourceList(const std::vector<std::string>&  nameIDs);

    //插入数据必须为整笔数据，整笔数据中应该保存的位置(内存还是文件)。
    virtual void insertData(const StorageData& data);
    //批量插入数据
    virtual void insertDataList(const std::vector<StorageData>& datas);

    //删除指定ID数据
    virtual void deleteData(uint id);
    //删除指定nameID数据
    virtual void deleteData(const std::string& nameID);

    //批量删除数据
    virtual void deleteDataList(const std::vector<uint>& ids);
    virtual void deleteDataList(const std::vector<std::string>& nameIDs);
    //条件操作
    virtual void deleteDataList(uint id, Operator op);
    virtual void deleteDataListBetween(uint id1, uint id2);
    //通过字段删除,字段不能为BLOB类型
    virtual void deleteDataListByField(const std::string field, FieldType fieldType, const CscsVariant& value, Operator op=CscsAbstractDataStorage::Equal);

    /*查询数据*/
    //查询值
    virtual CscsVariant queryValue(uint id)const;
    virtual CscsVariant queryValue(const std::string& nameID)const;
    //批量查询
    virtual std::vector<CscsVariant> queryValueList(const std::vector<uint>& ids)const;
    virtual std::vector<CscsVariant> queryValueList(const std::vector<std::string>& nameIDs);
    
    //查询一行数据
    virtual StorageData queryData(uint id)const;
    virtual StorageData queryData(const std::string& nameID)const;
    //批量查询一行数据
    virtual std::vector<StorageData> queryDataList(const std::vector<uint>& ids)const;
    virtual std::vector<StorageData> queryDataList(const std::vector<std::string>& nameIDs)const;

    //查询字段值
    virtual CscsVariant queryField(uint id, const std::string& field, FieldType fieldType)const;
    virtual CscsVariant queryField(const std::string& nameID, const std::string& field, FieldType fieldType)const;
    virtual std::vector<CscsVariant> queryFieldList(const std::vector<uint>& ids, const std::string& field, FieldType fieldType)const;
    virtual std::vector<CscsVariant> queryFieldList(const std::vector<std::string>& ids, const std::string& field, FieldType fieldType)const;
    //条件查询
    virtual std::vector<CscsVariant> queryValueList(uint id, Operator op)const;
    virtual std::vector<StorageData> queryDataList(uint id,Operator op)const;
    virtual std::vector<CscsVariant> queryValueListBetween(uint id1, uint id2)const;
    virtual std::vector<StorageData> queryDataListBetween(uint id1, uint id2)const;

    virtual std::vector<CscsVariant> queryFieldList(uint id, const std::string& field, FieldType fieldType,Operator op)const;
    virtual std::vector<CscsVariant> queryFieldListBetween(uint id1, uint id2, const std::string& field, FieldType fieldType)const;

    //更新数据
    virtual CscsVariant updateValue(uint id, const CscsVariant& data,bool merge=true);
    virtual CscsVariant updateValue(const std::string& nameID, const CscsVariant& data,bool merge=true);
    virtual void updateField(uint id, const std::string& field, const CscsVariant& data,bool merge=true);
    virtual void updateField(const std::string& nameID, const std::string& field, const CscsVariant& data,bool merge=true);

    virtual void updateData(const StorageData& data,bool merge=true);

    //批量更新
    virtual void updateValueList(const std::vector<uint>& ids, const std::vector<CscsVariant>& datas,bool merge=true);
    virtual void updateFieldList(const std::vector<uint>& ids, const std::string& field, const std::vector<CscsVariant>& datas,bool merge=true);
    virtual void updateValueList(const std::vector<std::string>& ids, const std::vector<CscsVariant>& datas,bool merge=true);
    virtual void updateFieldList(const std::vector<std::string>& ids, const std::string& field, const std::vector<CscsVariant>& datas,bool merge=true);

    virtual void updateDataList(const std::vector<StorageData>& datas,bool merge=true);
    virtual std::vector<CscsVariant> queryValueListByField(const std::string& field, FieldType fieldType,const CscsVariant& value, Operator op=CscsAbstractDataStorage::Equal)const;
    virtual std::vector<StorageData> queryDataListByField(const std::string& field, FieldType fieldType, const CscsVariant& value, Operator op=CscsAbstractDataStorage::Equal)const;
    virtual void readConfigFile(const std::string &fileName,bool sync=false);
    virtual bool loadLocalDB();
    virtual bool hasLocalDB()const;
    virtual void reset();
    virtual CscsMutex *mutex();

protected:
    void timerEvent(CscsTimerEvent* e);
private:
    std::unordered_map<uint, StorageData>  *m_idMap;
    std::unordered_map<std::string, uint> *m_nameMap;
    std::vector<StorageData> m_configInfoList;
    CscsMutex m_mtx;
    CscsMemoryDB* m_db;
    uint m_timerId;
    bool readDBFile(const std::string& dbName);
    bool readJsonFile(const std::string& jsonName);
    bool createLocalDB();
    void syncToMemoryDB();
    std::vector<uint> validID(uint id,Operator op)const;
    std::vector<uint> validIDByBlock(uint value,Operator op)const;
    std::vector<uint> validIDByDirty(uint value,Operator op)const;
    std::vector<uint> validID(uint id1, uint id2)const;// id1<=id<id2[)

    void updateRW(uint id, const CscsVariant& data);
    void updateBlock(uint id, const CscsVariant& data);
    void updateCommSource(uint id, const CscsVariant& data);
    void updateDefValue(uint id,const CscsVariant& data);
    void updateMaxValue(uint id,const CscsVariant& data);
    void updateMinValue(uint id,const CscsVariant& data);
    void updateDirty(uint id, const CscsVariant& data);

    friend class CscsDataDistrubte;
};

END_NAMESPACE
#endif