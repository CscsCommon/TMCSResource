/*Created by J.Wong 2018/10/23
version:    version 1.0,
dependency: base on  or greater than c++11
function: type erase
gcc4.9+
*/
#ifndef SCSTIMER_H
#define SCSTIMER_H
#include "scsobject.h"
#include "scsconnection.hpp"
#include "scsabstracteventdispatcher.h"

BEGIN_NAMESPACE(Gemini)

class CscsTimerEvent;

class CscsTimer:public CscsObject{
public:
	CscsTimer(CscsObject* parent=0);
	virtual ~CscsTimer();

	void start(int msecs=0);
	void stop();
	void setInterval(int msecs);
	int interval()const{
		return m_interval;
	}

	bool isActive()const{
		return m_id>=0;
	}
	int timerId()const{
		return m_id;
	}

	inline void setSingleShot(bool singleShot);
	inline bool isSingleShot()const{return m_single;}
	template<typename F>
	static inline void singleShot(int mecs, CscsObject* recv, F&& f);

SIGNALS:
	void timeOut(){}

protected:
	void timerEvent(CscsTimerEvent* e);
private:
	int m_interval;
	int m_id;
	int m_single;
	#ifdef D_WIN32
	friend class AdoptorTimer;
	#endif
};


class CscsSingleShotTimer : public CscsObject
{
    int timerId;
public:
    ~CscsSingleShotTimer();
    CscsSingleShotTimer();

SIGNALS:
    void timeOut(){}
protected:
    void timerEvent(CscsTimerEvent *);
   	template<typename F>
   	inline void bind(int msec,CscsObject* r, F&& f);
   	friend class CscsTimer;
	#ifdef D_WIN32
	friend class AdoptorTimer;
	#endif
};


template<typename F>
inline void CscsSingleShotTimer::bind(int msec,CscsObject* r, F&& f){
	CscsConnection::connection(this, "timeOut()", r, std::move(f),IID_GEN(this,"CscsSingleShotTimer::std::move(F&&)"));
	timerId = startTimer(msec);
}


template<typename F>
inline void CscsTimer::singleShot(int msec, CscsObject *receiver, F&& f)
{
    if (receiver){
        CscsSingleShotTimer* shot= new CscsSingleShotTimer();
        shot->bind(msec, receiver,std::move(f));
    }
}

inline void CscsTimer::setSingleShot(bool asingleShot) { m_single = asingleShot; }

END_NAMESPACE

#endif