 /*Created by J.Wong 2018/10/24
 version:    version 1.0,
 dependency: base on  or greater than c++11
 function: type erase
 gcc4.9+
 */

#ifndef SCSEVENTLOOP_H
#define SCSEVENTLOOP_H
#include "scsobject.h"
#include "scsflags.h"

BEGIN_NAMESPACE(Gemini)

class CscsEventLoopPrivate;

class CscsEventLoop:public CscsObject{
public:
	CscsEventLoop(CscsObject* parent=0);
	~CscsEventLoop();

	enum EventProcessFlag{
		AllEvents=0x00,
		ExcludeUserInputEvents=0x01,
		ExcludeSocketNotifiers=0x02,
		WaitForMoreEvents=0x04
	};
	SCS_DECLARE_FLAGS(EventProcess,EventProcessFlag);

	bool processEvents(EventProcess filter=AllEvents);
	void processEvents(EventProcess filter, int maxTime);

	int  exec(EventProcess filter=AllEvents);
	void exit(int returnCode=0);
	bool isRunning()const;

	void wakeUp();
	void quit();

	CscsEventLoopPrivate* d_func()const;

};

SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsEventLoop::EventProcess)

END_NAMESPACE
#endif