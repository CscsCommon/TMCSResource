#ifndef SCSMATRIX_H
#define SCSMATRIX_H
#include <kernel/scsutils.h>
#include <config.h>
#include <cairo/cairo.h>
#include <memory>
#include "scspoint.h"
#include "scsline.h"
#include "scsrect.h"
#include "scspolygon.h"

BEGIN_NAMESPACE(Gemini)

class CscsPath;
class CscsRegion;

class CscsMatrix{
public:
	CscsMatrix();
	CscsMatrix(double m11, double m12, double m21, double m22, double x0, double y0);
	CscsMatrix(const CscsMatrix& mtx);
	CscsMatrix& operator=(const CscsMatrix& mtx);
	virtual ~CscsMatrix();

	bool operator==(const CscsMatrix& mtx)const ;
	bool operator!=(const CscsMatrix& mtx)const{

		return !(*this==mtx);
	}

	void 	setMatrix(double m11, double m12, double m21, double m22, double x0, double y0);
	CscsMatrix& operator*=(const CscsMatrix& mtx);
	CscsMatrix  operator*(const CscsMatrix& mtx);
	bool isScaling()const;

	void translate(double x, double y);
	void rotate(double a);
	void scale(double sx, double sy);
	void shear(double sh, double sv);

	CscsPoint		map(const CscsPoint& p)const;
	CscsPointF		map(const CscsPointF& p)const;
	CscsRect		mapRect(const CscsRect& )const;
	CscsRectF 		mapRect(const CscsRectF& )const;
	CscsLine  		mapLine(const CscsLine& )const;
	CscsLineF   	mapLine(const CscsLineF& )const;
	CscsPolygon		map(const CscsPolygon& )const;
	CscsPolygonF 	map(const CscsPolygonF& )const;
	CscsPath 		map(const CscsPath& )const;
	double          m11()const;
	double     		m12()const;
	double   		m21()const;
	double 			m22()const;
	double 			dx()const;
	double 			dy()const;
	void reset();
	bool isIdentity()const;
	bool isInvertable()const;
	CscsMatrix inverted(bool* invertible=0)const;

	cairo_matrix_t* dataPtr();
private:
	cairo_matrix_t* data;
	CscsMatrix& copyFrom(const CscsMatrix& mtx);
};
SCS_DECLARE_TYPENAME_INFO(CscsMatrix, SCS_MOVABLE_TYPE)

inline  CscsPoint operator*(const CscsPoint &p, const CscsMatrix &m)
{ return m.map(p); }
inline  CscsPointF operator*(const CscsPointF &p, const CscsMatrix &m)
{ return m.map(p); }
inline  CscsLineF operator*(const CscsLineF &l, const CscsMatrix &m)
{ return m.mapLine(l); }
inline  CscsLine operator*(const CscsLine &l, const CscsMatrix &m)
{ return m.mapLine(l); }
inline  CscsPolygon operator *(const CscsPolygon &a, const CscsMatrix &m)
{ return m.map(a); }
inline  CscsPolygonF operator *(const CscsPolygonF &a, const CscsMatrix &m)
{ return m.map(a); }
CscsPath operator *(const CscsPath &p, const CscsMatrix &m);

std::ostream& operator<<(std::ostream &s, const CscsMatrix &m);

END_NAMESPACE

#endif