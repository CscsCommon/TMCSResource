#ifndef SCSGRADIENT_H
#define SCSGRADIENT_H
#include "scsrgba.h"
#include <kernel/scsvector.h>
#include <memory>

BEGIN_NAMESPACE(Gemini)

struct CscsGradientData;
struct CscsGradientStopData;
class CscsLinearGradient;
class CscsRadialGradient;
class CscsConicalGradient;



struct CscsGradientStopData{

	CscsGradientStopData(double p=-1.0,const CscsRgba& c=CscsRgba(0,0,0,1))
	:pos(p),color(c)
	{

	}
	double pos;
	CscsRgba color;
};

class CscsGradient{
public:
	enum GradientType{
		InvalidGradient,
		LinearGradient,
		RadialGradient,
		ConicalGradient
	};
	enum Spread{
		None,
		Repeat,
		Reflect,
		Pad
	};
	CscsGradient();
	CscsGradient(GradientType type);
	virtual ~CscsGradient();

	CscsGradient(const CscsGradient& o);
	CscsGradient& operator=(const CscsGradient& o);
	//pos:位置百分比值
	void addStop(double pos, const CscsRgba& color);
	void setStops(const CscsVector<CscsGradientStopData>& datas);
	CscsGradient::GradientType type()const;
	CscsGradient::Spread spread()const;
	void setSpread(CscsGradient::Spread spread);
	CscsGradientStopData gradientStopDataAt(int index)const;
	int  size()const;
	bool isValid()const;

private:
	friend class CscsLinearGradient;
	friend class CscsRadialGradient;
	friend class CscsConicalGradient;
	CscsGradientData* data;
	union {
        struct {
            double m_x1;
            double m_y1;
            double m_x2;
            double m_y2;
        } linear;
        struct {
            double m_cx1;
			double m_cy1;
			double m_radius1;
			double m_cx2;
			double m_cy2;
			double m_radius2;
        } radial;
        struct {
            double m_cx, m_cy, angle;
        } conical;
    }coords;
	CscsGradient& copyFrom(const CscsGradient& o);
};




struct CscsGradientData
{
	CscsGradient::GradientType type;
	CscsGradient::Spread spread;
	CscsVector<CscsGradientStopData> stops;

};


class CscsLinearGradient:public CscsGradient{
public:
	CscsLinearGradient()
	:CscsGradient(LinearGradient)
    
	{
	 coords.linear.m_x1=0.0;
	 coords.linear.m_y1=0.0;
     coords.linear.m_x2=0.0;
     coords.linear.m_y2=0.0;
	}

	CscsLinearGradient(double x1, double y1, double x2, double y2)
	:CscsGradient(LinearGradient)
	{
		coords.linear.m_x1=x1;
		coords.linear.m_y1=y1;
		coords.linear.m_x2=x2;
		coords.linear.m_y2=y2;
	}


	void setStartPos(double x, double y){
		coords.linear.m_x1=x;
		coords.linear.m_y1=y;
	}

	void setFinalPos(double x, double y){
		coords.linear.m_x2=x;
		coords.linear.m_y2=y;
	}

	double startX()const{
		return coords.linear.m_x1;
	}

	double startY()const{
		return coords.linear.m_y1;
	}

	double finalX()const{
		return coords.linear.m_x2;
	}

	double finalY()const{
		return coords.linear.m_y2;
	}

	~CscsLinearGradient(){}

};


class CscsRadialGradient:public CscsGradient{
public:
	CscsRadialGradient()
	:CscsGradient(RadialGradient)
	{
		coords.radial.m_cx1=0.0;
		coords.radial.m_cy1=0.0;
    	coords.radial.m_radius1=0.0;
    	coords.radial.m_cx2=0.0;
    	coords.radial.m_cy2=0.0;
    	coords.radial.m_radius2=0.0;
	}

	CscsRadialGradient(double cx1, double cy1, double radius1, double cx2, double cy2, double radius2)
	:CscsGradient(RadialGradient)
    {
    	coords.radial.m_cx1=cx1;
    	coords.radial.m_cy1=cy1;
		coords.radial.m_radius1=radius1;
    	coords.radial.m_cx2=cx2;
    	coords.radial.m_cy2=cy2;
    	coords.radial.m_radius2=radius2;
    }

    double startCenterX()const{

    	return coords.radial.m_cx1;
    }
    double startCenterY()const{

    	return coords.radial.m_cy1;
    }
    double startRadius()const{

    	return coords.radial.m_radius1;
    }

    double finalCenterX()const{

    	return coords.radial.m_cx2;
    }

    double finalCenterY()const{

    	return coords.radial.m_cy2;
    }
    double finalRadius()const{

    	return coords.radial.m_radius2;
    }

    void setStartCenter(double x,double y, double radius){
    	coords.radial.m_cx1=x;
    	coords.radial.m_cy1=y;
    	coords.radial.m_radius1=radius;
    }
    void setFinalCenter(double x, double y, double radius){
    	coords.radial.m_cx2=x;
    	coords.radial.m_cy2=y;
    	coords.radial.m_radius2=radius;
    }
    ~CscsRadialGradient(){}

};

END_NAMESPACE

#endif