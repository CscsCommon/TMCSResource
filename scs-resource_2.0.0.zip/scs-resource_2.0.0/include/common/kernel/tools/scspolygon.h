///////////////////////////////////////////////////////////
//  scspolygon.h
//  Implementation of the Class CscsPolygon
//  Created on:      29-10��-2018 19:19:43
//  Original author: jian.wang
///////////////////////////////////////////////////////////

#ifndef SCSPOLYGON_H
#define SCSPOLYGON_H

#include "scspoint.h"
#include "scsrect.h"
#include "scsenum.h"
#include <kernel/scstypes.h>
#include <iostream>
#include <kernel/scsvector.h>
#include <stdarg.h>

BEGIN_NAMESPACE(Gemini)

class CscsPolygon:public CscsVector<CscsPoint>
{

public:

    inline CscsPolygon() { }
    CscsPolygon(int size);
    CscsPolygon(const CscsPolygon& c) : CscsVector<CscsPoint>(c) { }
    CscsPolygon(const CscsRect& r, bool closed = false);
    CscsPolygon(int nPoints, const int* points);
    inline CscsPolygon(const std::vector<CscsPoint>& v) : CscsVector<CscsPoint>(CscsVector<CscsPoint>::fromStdVector(v)){ }
    inline CscsPolygon(const CscsVector<CscsPoint>& v) : CscsVector<CscsPoint>(v){ }

    inline ~CscsPolygon() { }

    // inline void append(const CscsPoint& p) ;
    // inline CscsPoint at(int index) const ;

    CscsRect boundingRect() const;
    // inline const CscsPoint* constData() const;
    // inline const CscsPoint* data() const;

    bool containsPoint(const CscsPoint& point, SCS::FillRule fillRule) const;
    // inline bool isEmpty() const;
    // inline int count() const;
    // inline int size() const;
    // inline void clear();

    CscsPolygon united(const CscsPolygon& r) const;
    CscsPolygon intersected(const CscsPolygon& r) const;

    // inline CscsPoint operator[](int index) const;

    inline friend std::ostream& operator<<(std::ostream& os, const CscsPolygon& polygon);
    inline friend std::istream& operator>>(std::istream& is, CscsPolygon& polygon);

    inline CscsPoint point(int index) const;
    void putPoints(int index, int nPoints, int firstx, int firsty, ...);
    void putPoints(int index, int nPoints, const CscsPolygon& fromPolygon, int fromIndex = 0);
    void putPoints(int index, int nPoints, const int* points);
    // inline void reserve(int size);

    inline void setPoint(int index, int x, int y);
    inline void setPoint(int index, const CscsPoint& point);
    void setPoints(int nPoints, const int* points);
    void setPoints(int nPoints, int firstx, int firsty, ...);
    CscsPolygon subtracted(const CscsPolygon& r) const;
    void swap(CscsPolygon& other);

    void translate(int dx, int dy);
    inline void translate(const CscsPoint& p);
    inline CscsPolygon translated(int dx, int dy) const;
    CscsPolygon translated(const CscsPoint& p) const;


// private:
//     std::vector<CscsPoint> m_p;
};
SCS_DECLARE_TYPEINFO(CscsPolygon)




// inline void CscsPolygon::reserve(int size)
// {
//     m_p.resize(size);
// }
// inline void CscsPolygon::clear()
// {
//     m_p.clear();
// }

// inline int CscsPolygon::count() const
// {
//     return m_p.size();
// }

// inline int CscsPolygon::size() const
// {
//     return m_p.size();
// }

// inline bool CscsPolygon::isEmpty() const
// {
//     return m_p.empty();
// }

// inline const CscsPoint* CscsPolygon::constData() const
// {
//     const CscsPoint *ptr;
//     return (ptr = m_p.data());
// }

// inline const CscsPoint* CscsPolygon::data() const
// {
//     return this->m_p.data();
// }

// inline CscsPoint CscsPolygon::operator[](int index) const
// {
//     if(index >= 0 && index < static_cast<int>(m_p.size()))
//         return  data()[index];
//     return CscsPoint();
// }

inline std::ostream& operator<<(std::ostream& os, const CscsPolygon& polygon)
{
    uint32 len = polygon.size();
    uint i;
    os << len;
    for(i = 0; i < len; ++i)
    {
        os << polygon.at(i).x()
           << polygon.at(i).y();
    }
    return os;
}

inline std::istream& operator>>(std::istream& is, CscsPolygon& polygon)
{
    uint32 len;
    uint i;

    is >> len;
    polygon.reserve(polygon.size() + (int)len);
    CscsPoint p;
    for (i = 0; i < len; ++i) {
        is >> p;
        polygon.append(p);
    }
    return is;
}

// inline void CscsPolygon::append(const CscsPoint& p)
// {
//     m_p.push_back(p);
// }

// inline CscsPoint CscsPolygon::at(int index) const
// {
//     return  m_p[index];
// }

inline CscsPoint CscsPolygon::point(int index) const{
    return  at(index);
}

inline void CscsPolygon::setPoint(int index, int x, int y)
{
    (*this)[index] = CscsPoint(x,y);
}

inline void CscsPolygon::setPoint(int index, const CscsPoint& point)
{
    (*this)[index] = point;
}

inline void CscsPolygon::translate(const CscsPoint& p){
    translate(p.x(), p.y());
}

inline CscsPolygon CscsPolygon::translated(const CscsPoint& p) const
{
    return translated(p.x(), p.y());
}

inline CscsPolygon CscsPolygon::translated(int dx, int dy) const
{
    CscsPolygon copy(*this);
    copy.translate(dx, dy);
    return copy;
}






class CscsPolygonF:public CscsVector<CscsPointF>
{

public:

    inline CscsPolygonF() {	}
    virtual ~CscsPolygonF() { }

    inline explicit CscsPolygonF(int size):CscsVector<CscsPointF>(size) {}
    inline CscsPolygonF(const std::vector<CscsPointF> v) : CscsVector<CscsPointF>(CscsVector<CscsPointF>::fromStdVector(v)) {	}
    CscsPolygonF(const CscsRectF& r);
    CscsPolygonF(const CscsPolygon& poly);
    inline CscsPolygonF(const CscsPolygonF& poly) : CscsVector<CscsPointF>(poly) { }
    CscsRectF boundingRect() const;


    // inline void append(const CscsPointF& p)
    // {
    //     m_p.push_back(p);
    // }

    // inline CscsPointF at(int index) const
    // {
    //     return  m_p[index];
    // }

    // inline void clear()
    // {
    //     m_p.clear();
    // }

    // inline const CscsPointF* constData() const
    // {
    //     const CscsPointF* ptr;
    //     return  (ptr = m_p.data());
    // }

    // inline const CscsPointF* data() const
    // {
    //     return m_p.data();
    // }

    // inline int count() const
    // {
    //     return m_p.size();
    // }

    inline bool isClosed() const
    {
        return !isEmpty() && first() ==last();
    }

    // inline bool isEmpty() const
    // {
    //     return m_p.empty();
    // }

    // inline CscsPointF operator[](int index) const
    // {
    //     if(index >= 0 && index < static_cast<int> (m_p.size()))
    //         return  data()[index];
    // }

    // inline CscsPolygonF& operator+=(const CscsPointF& pt)
    // {
    //     m_p.push_back(pt);
    //     return  *this;
    // }

    // inline CscsPolygonF& operator+=(CscsPolygonF& poly)
    // {
    //     for (std::vector<CscsPointF>::iterator it = poly.m_p.begin() ; it != poly.m_p.end(); ++it)
    //         m_p.push_back(*it);
    //     return  *this;
    // }

    // inline void reserve(int size)
    // {
    //     m_p.resize(size);
    // }

    // inline int size() const
    // {
    //     return m_p.size();
    // }

    inline void setPoint(int index, const CscsPointF& point)
    {
        (*this)[index] = point;
    }

    inline void translate(double dx, double dy);
    void translate(const CscsPointF& p);

    CscsPolygonF translated(double dx, double dy) const;
    CscsPolygonF translated(const CscsPointF& p) const;

    CscsPolygon toPolygon() const;


    bool containsPoint(const CscsPointF& pt, SCS::FillRule fillRule) const;
    CscsPolygonF intersected(const CscsPolygonF& r) const;
    CscsPolygonF subtracted(const CscsPolygonF& r) const;
    CscsPolygonF united(const CscsPolygonF& r) const;

    friend std::ostream& operator<<(std::ostream& os, const CscsPolygonF& polygon);
    friend std::istream& operator>>(std::istream& is, CscsPolygonF& polygon);

// private:
//     std::vector<CscsPointF> m_p;

};




inline void CscsPolygonF::translate(double dx, double dy)
{
    translate(CscsPointF(dx, dy));
}

inline CscsPolygonF CscsPolygonF::translated(double dx, double dy) const
{
    return  translated(CscsPointF(dx, dy));
}

inline std::ostream& operator<<(std::ostream& os, const CscsPolygonF& polygon)
{
    uint32 len = polygon.size();
    uint i;
    os << len;
    for(i = 0; i < len; ++i)
        os << polygon.at(i);
    return os;
}

inline std::istream& operator>>(std::istream& is, CscsPolygonF& polygon)
{
    uint32 len;
    uint i;

    is >> len;
    polygon.reserve(polygon.size() + (int)len);
    CscsPoint p;
    for (i = 0; i < len; ++i) {
        is >> p;
        polygon.append(p);
    }
    return is;
}

END_NAMESPACE

#endif // SCSPOLYGON_H
