///////////////////////////////////////////////////////////
//  scsmargin.h
//  Implementation of the Class CscsMargin
//  Created on:      29-10��-2018 16:35:51
//  Original author: jian.wang
///////////////////////////////////////////////////////////

#ifndef SCSMARGIN_H
#define SCSMARGIN_H
#include <iostream>
#include "scsmath.h"

BEGIN_NAMESPACE(Gemini)

class CscsMargin
{

public:

	CscsMargin();
	CscsMargin(int left, int top, int right, int bottom);
	virtual ~CscsMargin();

	inline bool isNull() const;

	inline friend const CscsMargin operator+(const CscsMargin& m1, const CscsMargin& m2);
	inline friend const CscsMargin operator+(const CscsMargin& m, int v);
	inline friend const CscsMargin operator-(const CscsMargin& m1, const CscsMargin& m2);
	inline friend const CscsMargin operator-(const CscsMargin& m, int v);
	inline friend const CscsMargin operator*(const CscsMargin& m, int factor);
	inline friend const CscsMargin operator*(int factor, const CscsMargin& m);
	inline friend const CscsMargin operator*(const CscsMargin& m, double factor);
	inline friend const CscsMargin operator*(double factor, const CscsMargin& m);
	inline friend const CscsMargin operator/(const CscsMargin& m, int factor);
	inline friend const CscsMargin operator/(const CscsMargin& m, double factor);
	
	inline friend const bool operator==(const CscsMargin& m1, const CscsMargin& m2);
	inline friend const bool operator!=(const CscsMargin& m1, const CscsMargin& m2);
	inline friend std::ostream& operator<<(std::ostream& os, const CscsMargin& m);
	inline friend std::istream& operator>>(std::istream& is, CscsMargin& m);
	
	inline CscsMargin& operator+=(const CscsMargin& m);
	inline CscsMargin& operator+=(int v);
	inline CscsMargin& operator-=(const CscsMargin& m);
	inline CscsMargin& operator-=(int v);
	inline CscsMargin& operator*=(int factor);
	inline CscsMargin& operator*=(double factor);
	inline CscsMargin& operator/=(int factor);
	inline CscsMargin& operator/=(double factor);


	inline void setBottom(int bottom);
	inline void setLeft(int left);
	inline void setRight(int right);
	inline void setTop(int top);
	inline int top() const;
	inline int right() const;
	inline int left() const;
	inline int bottom() const;

private:
	int m_top;
	int m_bottom;
	int m_left;
	int m_right;
	

};



	inline CscsMargin::CscsMargin():m_top(0), m_bottom(0), m_left(0), m_right(0){}
	inline CscsMargin::CscsMargin(int left, int top, int right, int bottom):m_top(top), m_bottom(bottom), m_left(left), m_right(right){}
	inline CscsMargin::~CscsMargin(){}


	inline bool CscsMargin::isNull() const
	{ return m_top == 0 && m_bottom == 0 && m_left == 0 && m_right == 0; }

	inline const CscsMargin operator+(const CscsMargin& m1, const CscsMargin& m2){
        return  CscsMargin(m1.left() + m2.left(), m1.top() + m2.top(),
						m1.right() + m2.right(), m1.bottom() + m2.bottom());
	}
	inline const CscsMargin operator+(const CscsMargin& m, int v)
	{ return  CscsMargin(m.left()+v, m.top()+v, m.right()+v, m.bottom()+v); }

	inline const CscsMargin operator-(const CscsMargin& m1, const CscsMargin& m2)
	{
        return  CscsMargin(m1.left() - m2.left(), m1.top() - m2.top(),
						m1.right() - m2.right(), m1.bottom() - m2.bottom());
	}
	inline const CscsMargin operator-(const CscsMargin& m, int v)
	{ return  CscsMargin(m.left()-v, m.top()-v, m.right()-v, m.bottom()-v); }

	inline const CscsMargin operator*(const CscsMargin& m, int factor)
	{ return  CscsMargin(m.left()*factor, m.top()*factor, m.right()*factor, m.bottom()*factor); }

	inline const CscsMargin operator*(int factor, const CscsMargin& m)
	{ return  CscsMargin(m.left()*factor, m.top()*factor, m.right()*factor, m.bottom()*factor); }
	
	inline const CscsMargin operator*(const CscsMargin& m, double factor)
	{ return  CscsMargin(scsRound(m.left()*factor), scsRound(m.top()*factor), scsRound(m.right()*factor), scsRound(m.bottom()*factor));}
	
	inline const CscsMargin operator*(double factor, const CscsMargin& m)
	{ return  CscsMargin(scsRound(m.left()*factor), scsRound(m.top()*factor), scsRound(m.right()*factor), scsRound(m.bottom()*factor));}
	
	inline const CscsMargin operator/(const CscsMargin& m, int factor)
	{
        return  CscsMargin(m.left()/factor, m.top()/factor, m.right()/factor, m.bottom()/factor);
	}
	
	inline const CscsMargin operator/(const CscsMargin& m, double factor)
	{
        return  CscsMargin(scsRound(m.left()/factor), scsRound(m.top()/factor),
						   scsRound(m.right()/factor), scsRound(m.bottom()/factor));
	}
	
	inline const bool operator==(const CscsMargin& m1, const CscsMargin& m2)
	{
		return 
		m1.m_left == m2.m_left &&
		m1.m_top == m2.m_top &&
		m1.m_right == m2.m_right &&
		m1.m_bottom == m2.m_bottom;
	}
	
	inline const bool operator!=(const CscsMargin& m1, const CscsMargin& m2)
	{	
		return 
		m1.m_left != m2.m_left ||
		m1.m_top != m2.m_top ||
		m1.m_right != m2.m_right ||
		m1.m_bottom != m2.m_bottom;
	}
	
	inline std::ostream& operator<<(std::ostream& os, const CscsMargin& m)
	{
		os << "m_top: " << m.m_top << " m_left: " << m.m_left << " m_bottom: " << m.m_bottom << " m_right: " << m.m_right << std::endl;
        return  os;
	}

	inline std::istream& operator>>(std::istream& is, CscsMargin& m){
		int top, left, bottom, right;
		is >> left;
		is >> top;
		is >> right;
		is >> bottom;
		m = CscsMargin(left, top, right, bottom);
        return  is;
	}
	
	inline CscsMargin& CscsMargin::operator+=(const CscsMargin& m)
    { return  *this = *this +m; }
	
	inline CscsMargin& CscsMargin::operator+=(int v)
	{ 
		m_top += v;
		m_bottom += v;
		m_left += v;
		m_right += v;
		return  *this; 
	}
	
	inline CscsMargin& CscsMargin::operator-=(const CscsMargin& m)
	{ return  *this = *this - m; }
	
	inline CscsMargin& CscsMargin::operator-=(int v){
		m_top -= v;
		m_bottom -= v;
		m_left -= v;
		m_right -= v;
        return  *this;
	}
	inline CscsMargin& CscsMargin::operator*=(int factor)
	{ return  *this = *this * factor; }

	inline CscsMargin& CscsMargin::operator*=(double factor)
	{ return  *this = *this * factor; }

	inline CscsMargin& CscsMargin::operator/=(int factor)
	{ return  *this = *this / factor; }
	
	inline CscsMargin& CscsMargin::operator/=(double factor)
	{ return  *this = *this / factor; }


	inline void CscsMargin::setBottom(int bottom)
	{ m_bottom = bottom; }
	
	inline void CscsMargin::setLeft(int left)
	{ m_left = left; }
	
	inline void CscsMargin::setRight(int right)
	{ m_right = right; }
	
	inline void CscsMargin::setTop(int top)
	{ m_top = top; }
	
	inline int CscsMargin::top() const
	{ return m_top; }
	
	inline int CscsMargin::right() const
	{ return m_right; }
	
	inline int CscsMargin::left() const
	{ return m_left; }
	
	inline int CscsMargin::bottom() const
	{ return m_bottom; }

class CscsMarginF
{

public:

	CscsMarginF();
	CscsMarginF(double left, double top, double right, double bottom);
	CscsMarginF(const CscsMargin& m);
	virtual ~CscsMarginF();

	inline bool isNull() const;
	
	inline friend const CscsMarginF operator+(const CscsMarginF& m1, const CscsMarginF& m2);
	inline friend const CscsMarginF operator+(const CscsMarginF& m, double v);
	inline friend const CscsMarginF operator-(const CscsMarginF& m1, const CscsMarginF& m2);
	inline friend const CscsMarginF operator-(const CscsMarginF& m, double v);
	inline friend const CscsMarginF operator*(const CscsMarginF& m, double factor);
	inline friend const CscsMarginF operator*(double factor, const CscsMarginF& m);
	inline friend const CscsMarginF operator/(const CscsMarginF& m, double factor);
	
	inline CscsMarginF& operator+=(const CscsMarginF& m);
	inline CscsMarginF& operator+=(double v);
	inline CscsMarginF& operator-=(const CscsMarginF& m);
	inline CscsMarginF& operator-=(double v);
	inline CscsMarginF& operator*=(double factor);
	inline CscsMarginF& operator/=(double factor);

	inline friend const bool operator==(const CscsMarginF& m1, const CscsMarginF& m2);
	inline friend const bool operator!=(const CscsMarginF& m1, const CscsMarginF& m2);
	inline friend std::istream& operator>>(std::istream& is, CscsMarginF& m);
	inline friend std::ostream& operator<<(std::ostream& os, const CscsMarginF& m);
	
	inline CscsMargin toMargin() const;
	inline void setBottom(double bottom);
	inline void setLeft(double left);
	inline void setRight(double right);
	inline void setTop(double top);
	inline double top() const;
	inline double right() const;
	inline double bottom() const;
	inline double left() const;
	
private:
	double m_left;
	double m_top;
	double m_right;
	double m_bottom;

};



    inline CscsMarginF::CscsMarginF():m_left(0), m_top(0), m_right(0), m_bottom(0){}
    inline CscsMarginF::CscsMarginF(double left, double top, double right, double bottom):m_left(left), m_top(top), m_right(right), m_bottom(bottom){}
    inline CscsMarginF::CscsMarginF(const CscsMargin& m):m_left(m.left()), m_top(m.top()), m_right(m.right()), m_bottom(m.bottom()){}
    inline CscsMarginF::~CscsMarginF(){}


	inline bool CscsMarginF::isNull() const
	{ return scsFuzzyIsNull(m_left) && scsFuzzyIsNull(m_top) && scsFuzzyIsNull(m_right) && scsFuzzyIsNull(m_bottom); }

	inline const CscsMarginF operator+(const CscsMarginF& m1, const CscsMarginF& m2)
	{
        return  CscsMarginF(m1.left()+m2.left(), m1.top()+m2.top(), m1.right()+m2.right(), m1.bottom()+m2.bottom());
	}
	
	inline const CscsMarginF operator+(const CscsMarginF& m, double v)
	{ return  CscsMarginF(m.left()+v, m.top()+v, m.right()+v, m.bottom()+v); }
	
	inline const CscsMarginF operator-(const CscsMarginF& m1, const CscsMarginF& m2)
	{
        return  CscsMarginF(m1.left()-m2.left(), m1.top()-m2.top(), m1.right()-m2.right(), m1.bottom()-m2.bottom());
	}
	
	inline const CscsMarginF operator-(const CscsMarginF& m, double v)
	{ return  CscsMarginF(m.left()-v, m.top()-v, m.right()-v, m.bottom()-v); }

	inline const CscsMarginF operator*(const CscsMarginF& m, double factor)
	{
        return  CscsMarginF(m.left()*factor, m.top()*factor, m.right()*factor, m.bottom()*factor);
	}
	
	inline const CscsMarginF operator*(double factor, const CscsMarginF& m)
	{
        return  CscsMarginF(m.left()*factor, m.top()*factor, m.right()*factor, m.bottom()*factor);
	}
	
	inline const CscsMarginF operator/(const CscsMarginF& m, double factor)
	{
        return  CscsMarginF(m.left()/factor, m.top()/factor, m.right()/factor, m.bottom()/factor);
	}
	
	inline CscsMarginF& CscsMarginF::operator+=(const CscsMarginF& m)
	{
        return  *this = *this + m;
	}
	
	inline CscsMarginF& CscsMarginF::operator+=(double v)
	{
		m_left += v;
		m_top += v;
		m_right += v;
		m_bottom += v;
        return  *this;
	}
	
	inline CscsMarginF& CscsMarginF::operator-=(const CscsMarginF& m)
	{
        return  *this = *this - m;
	}
	
	inline CscsMarginF& CscsMarginF::operator-=(double v)
	{
		m_left -= v;
		m_top -= v;
		m_right -= v;
		m_bottom -= v;
        return  *this;
	}

	inline CscsMarginF& CscsMarginF::operator*=(double factor)
	{
        return  *this *= factor;
	}

	inline CscsMarginF& CscsMarginF::operator/=(double factor)
	{
		
        return  *this /= factor;
	}

	inline const bool operator==(const CscsMarginF& m1, const CscsMarginF& m2)
	{
		return m1.top() == m2.top() && m1.left() == m2.left() && m1.right() == m2.right() && m1.bottom() == m2.bottom();
	}
	
	inline const bool operator!=(const CscsMarginF& m1, const CscsMarginF& m2)
	{
		return m1.top() != m2.top() || m1.left() != m2.left() || m1.right() != m2.right() || m1.bottom() != m2.bottom();
	}
		
	inline std::istream& operator>>(std::istream& is, CscsMarginF& m){
		double left, top, right, bottom;
		is >> left;
		is >> top;
		is >> right;
		is >> bottom;
		m = CscsMarginF(left, top, right, bottom);
        return  is;
	}
	inline std::ostream& operator<<(std::ostream& os, const CscsMarginF& m)
	{
		os << "m_top: " << m.m_top << " m_left: " << m.m_left << " m_bottom: " << m.m_bottom << " m_right: " << m.m_right << std::endl;
        return  os;
	}
	
	inline CscsMargin CscsMarginF::toMargin() const
	{
        return  CscsMargin(scsRound(m_left), scsRound(m_top), scsRound(m_right), scsRound(m_bottom));
	}
	
	inline void CscsMarginF::setBottom(double bottom)
	{
		m_bottom = bottom;
	}
	inline void CscsMarginF::setLeft(double left)
	{
		m_left = left;
	}
	inline void CscsMarginF::setRight(double right)
	{
		m_right = right;
	}
	inline void CscsMarginF::setTop(double top)
	{
		m_top = top;
	}

	inline double CscsMarginF::top() const
	{
		return m_top;
	}
	
	inline double CscsMarginF::right() const
	{
		return m_right;
	}
	
	inline double CscsMarginF::bottom() const
	{
		return m_bottom;
	}
	
	inline double CscsMarginF::left() const
	{
		return m_left;
	}

END_NAMESPACE
	
#endif // SCSMARGIN_H
