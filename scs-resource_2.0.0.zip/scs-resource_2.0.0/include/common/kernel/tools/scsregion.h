///////////////////////////////////////////////////////////
//  scsregion.h
//  Implementation of the Class CscsRegion
//  Created on:      29-10ÔÂ-2018 16:44:41
//  Original author: jian.wang
///////////////////////////////////////////////////////////

#ifndef SCSREGION_H
#define SCSREGION_H

#include "scsrect.h"
#include <kernel/scsvector.h>
#include <memory>
#include <config.h>
#include <cairo/cairo.h>

BEGIN_NAMESPACE(Gemini)

class CscsRegionData;
class CscsPath;

class CscsRegion
{

public:
	enum RegionOverlap{
		RegionOverlapIn, //完全在region内
		RegionOverlapOut,//完全在region外
		RegionOverlapPart//部分在region内
	};

	CscsRegion();
	CscsRegion(int x, int y, int w, int h);
	CscsRegion(const CscsRect& r);
    CscsRegion(const CscsVector<CscsRect>& rects);
	CscsRegion(const CscsRegion& region);
	~CscsRegion();
	CscsRect boundingRect() const;
	bool contains(const CscsPoint& p) const;
	CscsRegion::RegionOverlap contains(const CscsRect& r) const;
	
	
	bool isEmpty() const;
	bool isNull() const;

	bool operator==(const CscsRegion& r) const;
	inline bool operator!=(const CscsRegion& r) const{
		return !(*this==r);
	}

	CscsRegion intersected(const CscsRegion& r) const;
	CscsRegion intersected(const CscsRect& r) const;
	bool intersects(const CscsRegion& r) const;
	bool intersects(const CscsRect& r) const;

	CscsRegion united(const CscsRegion& r) const;
	CscsRegion united(const CscsRect& r) const;

	CscsRegion subtracted(const CscsRegion& r) const;
	CscsRegion subtracted(const CscsRect& r) const;
	

	CscsRegion xored(const CscsRegion& r) const;
	CscsRegion xored(const CscsRect& r) const;





	CscsRegion operator-(const CscsRegion& r) const;
	CscsRegion operator-(const CscsRect& r) const;

	CscsRegion& operator-=(const CscsRegion& r);
	CscsRegion& operator-=(const CscsRect& r);

	CscsRegion operator&(const CscsRegion& r) const;
	CscsRegion operator&(const CscsRect& r) const;

	CscsRegion& operator&=(const CscsRegion& r);
	CscsRegion& operator&=(const CscsRect& r);

	CscsRegion operator^(const CscsRegion& r) const;
	CscsRegion operator^(const CscsRect& r) const;

	CscsRegion& operator^=(const CscsRegion& r);
	CscsRegion& operator^=(const CscsRect& r);

	CscsRegion operator|(const CscsRegion& r) const;
	CscsRegion operator|(const CscsRect& r) const;

	CscsRegion& operator|=(const CscsRegion& r);
	CscsRegion& operator|=(const CscsRect& r);

	CscsRegion operator+(const CscsRegion& r) const;
	CscsRegion operator+(const CscsRect& r) const;

	CscsRegion& operator+=(const CscsRegion& r);
	CscsRegion& operator+=(const CscsRect& r);

	CscsRegion& operator=(const CscsRegion& prm1);
	
	void addPath(const CscsPath& path);

	int rectCount() const;
	CscsVector<CscsRect> rects() const;
	void setRects(const CscsRect* rects, int num);
	void setRects(const CscsVector<CscsRect>& rects);
	void translate(int dx, int dy);
	inline void translate(const CscsPoint& p){
		translate(p.x(),p.y());
	}
	CscsRegion translated(int dx, int dy) const;
	inline CscsRegion translated(const CscsPoint& p) const{
            return translated(p.x(),p.y());
	}

	cairo_region_t* dataPtr()const;
private:
	CscsRegionData* data;
	CscsRegion& copyFrom(const CscsRegion& r);

};
SCS_DECLARE_TYPEINFO(CscsRegion)

END_NAMESPACE

#endif // SCSREGION_H
