///////////////////////////////////////////////////////////
//  scsrect.h
//  Implementation of the Class CscsRect
//  Created on:      29-10��-2018 16:20:20
//  Original author: jian.wang
///////////////////////////////////////////////////////////

#ifndef SCSRECT_H
#define SCSRECT_H

#include "scspoint.h"
#include "scssize.h"
#include "scsmargin.h"
#include <kernel/scstypeinfo.h>

BEGIN_NAMESPACE(Gemini)

class CscsRect
{

public:

    CscsRect();
    CscsRect(const CscsPoint& topLeft, const CscsPoint& bottomRight);
    CscsRect(const CscsPoint& topLeft, const CscsSize& size);
    CscsRect(int left, int top, int w, int h);
    virtual ~CscsRect();

    inline bool isEmpty() const;
    inline bool isNull() const;
    inline bool isValid() const;

    inline int bottom() const;
    inline int left() const;
    inline int right() const;
    inline int top() const;
    CscsRect normalized() const;
    CscsRect visualRect()const;

    inline int x() const;
    inline int y() const;
    inline void setX(int x);
    inline void setY(int y);
    inline void setLeft(int left);
    inline void setRight(int right);
    inline void setBottom(int bottom);
    inline void setTop(int top);

    inline void setTopLeft(const CscsPoint& p);
    inline void setTopRight(const CscsPoint& p);
    inline void setBottomLeft(const CscsPoint& p);
    inline void setBottomRight(const CscsPoint& p);

    inline CscsPoint topLeft() const;
    inline CscsPoint topRight() const;
    inline CscsPoint bottomLeft() const;
    inline CscsPoint bottomRight() const;
    inline CscsPoint center() const;

    inline void moveTop(int pos);
    inline void moveBottom(int pos);
    inline void moveLeft(int pos);
    inline void moveRight(int pos);
    inline void moveTopLeft(const CscsPoint& p);
    inline void moveTopRight(const CscsPoint& p);
    inline void moveBottomLeft(const CscsPoint& p);
    inline void moveBottomRight(const CscsPoint& p);
    inline void moveCenter(const CscsPoint& p);

    inline void translate(int dx, int dy);
    inline void translate(const CscsPoint& p);
    inline CscsRect translated(int dx, int dy) const;
    inline CscsRect translated(const CscsPoint& p) const;
    inline CscsRect transposed() const;

    inline void moveTo(int dx, int dy);
    inline void moveTo(const CscsPoint& p);

    inline void setRect(int x, int y, int w, int h);
    inline void getRect(int* x, int* y, int* w, int* h) const;

    inline void setCoords(int x1, int y1, int x2, int y2);
    inline void getCoords(int* x1, int* y1, int* x2, int* y2) const;

    inline void adjust(int x1, int y1, int x2, int y2);
    inline CscsRect adjusted(int x1, int y1, int x2, int y2) const;

    inline CscsSize size() const;
    inline void setSize(const CscsSize& size);

    inline int height() const;
    inline int width() const;
    inline void setHeight(int h);
    inline void setWidth(int w);

    inline bool contains(int x, int y) const;
    inline bool contains(int x, int y, bool proper) const;
    bool contains(const CscsRect& r, bool proper = false) const;
    bool contains(const CscsPoint& p, bool proper = false) const;
    bool intersects(const CscsRect& r) const;
    inline CscsRect intersected(const CscsRect& r) const;
    inline CscsRect united(const CscsRect& r) const;

    inline CscsRect marginAdded(const CscsMargin& m) const;
    inline CscsRect marginRemoved(const CscsMargin& m) const;

    inline CscsRect& operator+=(const CscsMargin& m);
    inline CscsRect& operator-=(const CscsMargin& m);

    CscsRect operator&(const CscsRect& r) const;
    CscsRect operator|(const CscsRect& r) const;
    inline CscsRect& operator&=(const CscsRect& r);
    inline CscsRect& operator|=(const CscsRect& r);

    inline friend const CscsRect operator+(const CscsRect& r, const CscsMargin& m);
    inline friend const CscsRect operator+(const CscsMargin& m, const CscsRect& r);
    inline friend const CscsRect operator-(const CscsRect& r, const CscsMargin& m);


    inline friend const bool operator==(const CscsRect& r1, const CscsRect& r2);
    inline friend const bool operator!=(const CscsRect& r1, const CscsRect& r2);

    inline friend std::istream& operator>>(std::istream& is, CscsRect& r);
    inline friend std::ostream& operator<<(std::ostream& os, const CscsRect& r);

private:
    int m_x1;
    int m_y1;
    int m_x2;
    int m_y2;

    inline int max(int m, int n) const;
    inline int min(int m, int n) const;

};
SCS_DECLARE_TYPEINFO(CscsRect)
SCS_DECLARE_TYPENAME_INFO(CscsRect,SCS_MOVABLE_TYPE)

inline CscsRect::CscsRect():m_x1(0), m_y1(0), m_x2(-1), m_y2(-1){}
inline CscsRect::CscsRect(const CscsPoint& topLeft, const CscsPoint& bottomRight):m_x1(topLeft.x()), m_y1(topLeft.y()), m_x2(bottomRight.x()), m_y2(bottomRight.y()){ }
inline CscsRect::CscsRect(const CscsPoint& topLeft, const CscsSize& size):m_x1(topLeft.x()),m_y1(topLeft.y()),m_x2(topLeft.x()+size.width()-1),m_y2(topLeft.y()+size.height()-1){}
inline CscsRect::CscsRect(int left, int top, int w, int h):m_x1(left), m_y1(top), m_x2(left+w-1), m_y2(top+h-1){}
inline CscsRect::~CscsRect(){}

inline bool CscsRect::isEmpty() const { return m_x1 > m_x2 || m_y1 > m_y2; }
inline bool CscsRect::isNull() const { return m_x2 == m_x1-1 && m_y2 == m_y1-1; }
inline bool CscsRect::isValid() const { return m_x1 <= m_x2 && m_y1 <= m_y2; }

inline int CscsRect::bottom() const { return m_y2; }
inline int CscsRect::left() const { return m_x1; }
inline int CscsRect::right() const { return m_x2; }
inline int CscsRect::top() const { return m_y1; }

inline int CscsRect::x() const { return m_x1; }
inline int CscsRect::y() const { return m_y1; }
inline void CscsRect::setX(int x) { m_x1 = x; }
inline void CscsRect::setY(int y) { m_y1 = y; }
inline void CscsRect::setLeft(int left) { m_x1 = left; }
inline void CscsRect::setRight(int right) { m_x2 = right; }
inline void CscsRect::setBottom(int bottom) { m_y2 = bottom; }
inline void CscsRect::setTop(int top) { m_y1 = top; }

inline void CscsRect::setTopLeft(const CscsPoint& p) { m_x1 = p.x(); m_y1 = p.y(); }
inline void CscsRect::setTopRight(const CscsPoint& p) { m_x2 = p.x(); m_y1 = p.y(); }
inline void CscsRect::setBottomLeft(const CscsPoint& p) { m_x1 = p.x(); m_y2 = p.y(); }
inline void CscsRect::setBottomRight(const CscsPoint& p) { m_x2 = p.x(); m_y2 = p.y(); }

inline CscsPoint CscsRect::topLeft() const { return CscsPoint(m_x1, m_y1); }
inline CscsPoint CscsRect::topRight() const { return CscsPoint(m_x2, m_y1); }
inline CscsPoint CscsRect::bottomLeft() const { return CscsPoint(m_x1, m_y2); }
inline CscsPoint CscsRect::bottomRight() const { return CscsPoint(m_x2, m_y2); }
inline CscsPoint CscsRect::center() const { return CscsPoint(int((scsInt64(m_x1)+m_x2)/2), int((scsInt64(m_y1+m_y2))/2)); }

inline void CscsRect::moveTop(int pos) { m_y2 += (pos - m_y1); m_y1 = pos; }
inline void CscsRect::moveBottom(int pos) { m_y1 += (pos - m_y2); m_y2 = pos; }
inline void CscsRect::moveLeft(int pos) { m_x2 += (pos - m_x1); m_x1 = pos;}
inline void CscsRect::moveRight(int pos) { m_x1 += (pos - m_x2); m_x2 = pos; }
inline void CscsRect::moveTopLeft(const CscsPoint& p) { moveTop(p.y()); moveLeft(p.x()); }
inline void CscsRect::moveTopRight(const CscsPoint& p) { moveTop(p.y()); moveRight(p.x()); }
inline void CscsRect::moveBottomLeft(const CscsPoint& p) { moveBottom(p.y()); moveLeft(p.x()); }
inline void CscsRect::moveBottomRight(const CscsPoint& p) {moveBottom(p.y()); moveRight(p.x()); }
inline void CscsRect::moveCenter(const CscsPoint& p)
{
    int w = m_x2 - m_x1;
    int h = m_y2 - m_y1;
    m_x1 = p.x() - w/2;
    m_y1 = p.y() - h/2;
    m_x2 = m_x1 + w;
    m_y2 = m_y1 + h;
}

inline void CscsRect::translate(int dx, int dy) { m_x1 += dx; m_x2 += dx; m_y1 += dy; m_y2 += dy; }
inline void CscsRect::translate(const CscsPoint& p) { m_x1 += p.x(); m_y1 += p.y(); m_x2 += p.x(); m_y2 += p.y();}
inline CscsRect CscsRect::translated(int dx, int dy) const { return CscsRect(CscsPoint(m_x1+dx, m_y1+dy), CscsPoint(m_x2+dx, m_y2+dy)); }
inline CscsRect CscsRect::translated(const CscsPoint& p) const { return CscsRect(CscsPoint(m_x1+p.x(), m_y1+p.y()), CscsPoint(m_x2+p.x(), m_y2+p.y())); }
inline CscsRect CscsRect::transposed() const { return CscsRect(topLeft(), size().transposed()); }

inline void CscsRect::moveTo(int dx, int dy) { m_x2 += dx - m_x1; m_y2 += dy - m_y1; m_x1 = dx; m_y1 = dy; }
inline void CscsRect::moveTo(const CscsPoint& p) { m_x2 += p.x() - m_x1; m_y2 += p.y() - m_y1; m_x1 = p.x(); m_y1 = p.y(); }

inline void CscsRect::setRect(int x, int y, int w, int h) { m_x1 = x; m_y1 = y;  m_x2 = x + w-1; m_y2 = y+h-1; }
inline void CscsRect::getRect(int* x, int* y, int* w, int* h) const { *x = m_x1; *y = m_y1; *w = m_x2 - m_x1+1; *h =m_y2-m_y1+1;}

inline void CscsRect::setCoords(int x1, int y1, int x2, int y2) { m_x1 = x1; m_y1 = y1; m_x2 = x2; m_y2 = y2; }
inline void CscsRect::getCoords(int* x1, int* y1, int* x2, int* y2) const { *x1 = m_x1; *y1 = m_y1; *x2 = m_x2; *y2 = m_y2; }

inline void CscsRect::adjust(int x1, int y1, int x2, int y2) { m_x1 += x1; m_y1 += y1; m_x2 += x2; m_y2 += y2; }
inline CscsRect CscsRect::adjusted(int x1, int y1, int x2, int y2) const { return CscsRect(CscsPoint(m_x1+x1, m_y1+y1), CscsPoint(m_x2+x2, m_y2+y2)); }

inline CscsSize CscsRect::size() const { return CscsSize(width(), height()); }
inline void CscsRect::setSize(const CscsSize& size) { m_x2 = size.width() + m_x1 - 1; m_y2 = m_y1 + size.height() - 1;}

inline int CscsRect::height() const { return m_y2 - m_y1 + 1; }
inline int CscsRect::width() const { return m_x2 - m_x1 + 1; }
inline void CscsRect::setHeight(int h) { m_y2 = (m_y1 + h - 1); }
inline void CscsRect::setWidth(int w) { m_x2 =(m_x1 + w - 1);}

inline bool CscsRect::contains(int x, int y) const { return contains( CscsPoint(x, y), false); }
inline bool CscsRect::contains(int x, int y, bool proper) const { return contains(CscsPoint(x, y), proper); }

inline CscsRect CscsRect::intersected(const CscsRect& r) const { return *this & r; }
inline CscsRect CscsRect::united(const CscsRect& r) const { return *this | r;}

inline CscsRect CscsRect::marginAdded(const CscsMargin& m) const
{
    return CscsRect(CscsPoint(m_x1 - m.left(), m_y1 - m.top()),
                    CscsPoint(m_x2 + m.right(), m_y2 + m.bottom()));
}
inline CscsRect CscsRect::marginRemoved(const CscsMargin& m) const
{
    return CscsRect(CscsPoint(m_x1 + m.left(), m_y1 + m.top()),
                    CscsPoint(m_x2 - m.right(), m_y2 - m.bottom()));
}

inline CscsRect& CscsRect::operator+=(const CscsMargin& m) { *this = marginAdded(m); return *this; }
inline CscsRect& CscsRect::operator-=(const CscsMargin& m) { *this = marginRemoved(m); return *this; }

inline CscsRect& CscsRect::operator&=(const CscsRect& r) { *this = *this & r; return *this; }
inline CscsRect& CscsRect::operator|=(const CscsRect& r) { *this = *this | r; return *this; }

inline const CscsRect operator+(const CscsRect& r, const CscsMargin& m)
{
    return CscsRect(CscsPoint(r.left() - m.left(), r.top() - m.top()),
                    CscsPoint(r.right() + m.right(), r.bottom() + m.bottom()));

}

inline const CscsRect operator+(const CscsMargin& m, const CscsRect& r)
{
    return CscsRect(CscsPoint(r.left() - m.left(), r.top() - m.top()),
                    CscsPoint(r.right() + m.right(), r.bottom() + m.bottom()));
}

inline const CscsRect operator-(const CscsRect& r, const CscsMargin& m)
{
    return CscsRect(CscsPoint(r.left() + m.left(), r.top() + m.top()),
                    CscsPoint(r.right() - m.right(), r.bottom() - m.bottom()));

}

inline const bool operator==(const CscsRect& r1, const CscsRect& r2)
{
    return r1.m_x1==r2.m_x1 && r1.m_x2==r2.m_x2 && r1.m_y1==r2.m_y1 && r1.m_y2==r2.m_y2;
}
inline const bool operator!=(const CscsRect& r1, const CscsRect& r2)
{
    return r1.m_x1!=r2.m_x1 || r1.m_x2!=r2.m_x2 || r1.m_y1!=r2.m_y1 || r1.m_y2!=r2.m_y2;
}

inline std::istream& operator>>(std::istream& is, CscsRect& r)
{
    unsigned int  x1, y1, x2, y2;
    is >> x1; is >> y1; is >> x2; is >> y2;
    r.setCoords(x1, y1, x2, y2);
    return is;
}
inline std::ostream& operator<<(std::ostream& os, const CscsRect& r)
{
    os <<r.x()<<" "<<r.y()
    << " "<<r.width()
    << " "<<r.height();
    return os;
}

inline int CscsRect::max(int m, int n) const{
    return (m > n) ? m : n;
}
inline int CscsRect::min(int m, int n) const{
    return (m < n) ? m : n;
}





class CscsRectF
{

public:

    CscsRectF():m_x1(0.), m_y1(0.), m_w(0.), m_h(0.) {}
    CscsRectF(double x1, double y1, double width, double height);
    CscsRectF(const CscsPointF& topLeft, const CscsPointF& bottomRight);
    CscsRectF(const CscsPointF& topLeft, const CscsSizeF& size);
    CscsRectF(const CscsRect& r);
    virtual ~CscsRectF();

    inline bool isEmpty() const;
    inline bool isNull() const;
    inline bool isValid() const;
    CscsRectF normalized() const;

    inline double left() const;
    inline double right() const;
    inline double top() const;
    inline double bottom() const;

    inline double x() const;
    inline double y() const;
    inline void setX(double x);
    inline void setY(double y);

    inline void setLeft(double pos);
    inline void setRight(double pos);
    inline void setTop(double pos);
    inline void setBottom(double pos);

    inline CscsPointF topLeft() const;
    inline CscsPointF topRight() const;
    inline CscsPointF bottomLeft() const;
    inline CscsPointF bottomRight() const;
    inline CscsPointF center() const;

    inline void setTopLeft(const CscsPointF& topLeft);
    inline void setTopRight(const CscsPointF& topRight);
    inline void setBottomLeft(const CscsPointF& bottomLeft);
    inline void setBottomRight(const CscsPointF& bottomRight);

    inline void moveLeft(double pos);
    inline void moveRight(double pos);
    inline void moveTop(double pos);
    inline void moveBottom(double pos);
    inline void moveTopLeft(const CscsPointF& pos);
    inline void moveTopRight(const CscsPointF& pos);
    inline void moveBottomLeft(const CscsPointF& pos);
    inline void moveBottomRight(const CscsPointF& pos);
    inline void moveCenter(const CscsPointF& pos);
    inline void moveTo(double x, double y);
    inline void moveTo(const CscsPointF& p);

    inline void translate(double dx, double dy);
    inline void translate(const CscsPointF& p);
    inline CscsRectF translated(double dx, double dy) const;
    inline CscsRectF translated(const CscsPointF& p) const;

    inline CscsRectF transposed() const;

    inline void getRect(double* x, double* y, double* w, double* h) const;
    inline void setRect(double x, double y, double w, double h);
    inline void getCoords(double* x1, double* y1, double* x2, double* y2);
    inline void setCoords(double x1, double y1, double x2, double y2);

    inline void adjust(double x1, double y1, double x2, double y2);
    inline CscsRectF adjusted(double x1, double y1, double x2, double y2) const;

    inline double width() const;
    inline double height() const;
    inline CscsSizeF size() const;
    inline void setWidth(double w);
    inline void setHeight(double h);
    inline void setSize(const CscsSizeF& p);

    bool contains(const CscsRectF& r) const;
    bool contains(const CscsPointF& p) const;
    inline bool contains(double x, double y) const;

    bool intersects(const CscsRectF& r) const;
    inline CscsRectF united(const CscsRectF& other) const;
    inline CscsRectF intersected(const CscsRectF& other) const;

    inline CscsRectF marginAdded(const CscsMarginF& margin) const;
    inline CscsRectF marginRemoved(const CscsMarginF& margin) const;

    CscsRectF operator&(const CscsRectF& r) const;
    CscsRectF operator|(const CscsRectF& r) const;
    inline CscsRectF& operator&=(const CscsRectF& r);
    inline CscsRectF& operator|=(const CscsRectF& r);

    inline friend const CscsRectF operator+(const CscsRectF& r, const CscsMarginF& m);
    inline friend const CscsRectF operator+(const CscsMarginF& m, const CscsRectF& r);
    inline friend const CscsRectF operator-(const CscsRectF& r, const CscsMarginF& m);

    inline CscsRectF & operator+=(const CscsMarginF& margin);
    inline CscsRectF & operator-=(const CscsMarginF& margin);

    inline friend const bool operator==(const CscsRectF& r1, const CscsRectF& r2);
    inline friend const bool operator!=(const CscsRectF& r1, const CscsRectF& r2);

    inline friend std::ostream& operator<<(std::ostream& os, const CscsRectF& r);
    inline friend std::istream& operator>>(std::istream& is, CscsRectF& r);

    inline CscsRect toRect() const;
    CscsRect toAlignedRect() const;

private:
    double m_x1;
    double m_y1;
    double m_w;
    double m_h;

};
SCS_DECLARE_TYPEINFO(CscsRectF)
SCS_DECLARE_TYPENAME_INFO(CscsRectF,SCS_MOVABLE_TYPE)


inline CscsRectF::CscsRectF(double x1, double y1, double width, double height):m_x1(x1), m_y1(y1), m_w(width), m_h(height) {}
inline CscsRectF::CscsRectF(const CscsPointF& topLeft, const CscsPointF& bottomRight):m_x1(topLeft.x()), m_y1(topLeft.y()), m_w(bottomRight.x() - topLeft.x()), m_h(bottomRight.y() - topLeft.y()) { }
inline CscsRectF::CscsRectF(const CscsPointF& topLeft, const CscsSizeF& size):m_x1(topLeft.x()), m_y1(topLeft.y()), m_w(size.width()), m_h(size.height()) {}
inline CscsRectF::CscsRectF(const CscsRect& r):m_x1(r.x()), m_y1(r.y()), m_w(r.width()), m_h(r.height()) {}
inline CscsRectF::~CscsRectF() {}

inline bool CscsRectF::isEmpty() const { return m_w <= 0. || m_h <= 0.; }
inline bool CscsRectF::isNull() const { return m_w == 0. && m_h == 0. ;}
inline bool CscsRectF::isValid() const { return m_w > 0. && m_h > 0.; }

inline double CscsRectF::left() const { return m_x1; }
inline double CscsRectF::right() const { return m_x1 + m_w; }
inline double CscsRectF::top() const { return m_y1; }
inline double CscsRectF::bottom() const { return m_y1 + m_h; }

inline double CscsRectF::x() const { return m_x1; }
inline double CscsRectF::y() const { return m_y1; }
inline void CscsRectF::setX(double x) { m_x1 = x; }
inline void CscsRectF::setY(double y) { m_y1 = y; }

inline void CscsRectF::setLeft(double pos)
{
    double diff = pos - m_x1; m_x1 += diff; m_w -= diff;
}

inline void CscsRectF::setRight(double pos)
{
    m_w = pos - m_x1;
}

inline void CscsRectF::setTop(double pos)
{
    double diff = pos - m_y1; m_y1 += diff; m_h -= diff;
}

inline void CscsRectF::setBottom(double pos)
{
    m_h = pos - m_y1;
}

inline CscsPointF CscsRectF::topLeft() const
{
    return CscsPointF( m_x1, m_y1);
}

inline CscsPointF CscsRectF::topRight() const
{
    return CscsPointF(m_x1+m_w, m_y1);
}

inline CscsPointF CscsRectF::bottomLeft() const
{
    return CscsPointF(m_x1, m_y1 + m_h);
}

inline CscsPointF CscsRectF::bottomRight() const
{
    return CscsPointF(m_x1 + m_w, m_y1 + m_h);
}

inline CscsPointF CscsRectF::center() const
{
    return CscsPointF(m_x1 + m_w/2, m_y1 + m_h/2);
}

inline void CscsRectF::setTopLeft(const CscsPointF& topLeft)
{ setLeft(topLeft.x()); setTop(topLeft.y()); }

inline void CscsRectF::setTopRight(const CscsPointF& topRight)
{ setRight(topRight.x()); setTop(topRight.y()); }

inline void CscsRectF::setBottomLeft(const CscsPointF& bottomLeft)
{ setLeft(bottomLeft.x()); setBottom(bottomLeft.y()); }

inline void CscsRectF::setBottomRight(const CscsPointF& bottomRight)
{ setRight(bottomRight.x()); setBottom(bottomRight.y()); }

inline void CscsRectF::moveLeft(double pos)
{ m_x1 = pos; }

inline void CscsRectF::moveRight(double pos)
{ m_x1 = pos - m_w; }

inline void CscsRectF::moveTop(double pos)
{ m_y1 = pos; }

inline void CscsRectF::moveBottom(double pos)
{ m_y1 = pos - m_h; }

inline void CscsRectF::moveTopLeft(const CscsPointF& pos)
{ moveLeft(pos.x()); moveTop(pos.y()); }

inline void CscsRectF::moveTopRight(const CscsPointF& pos)
{ moveRight(pos.x()); moveTop(pos.y()); }

inline void CscsRectF::moveBottomLeft(const CscsPointF& pos)
{ moveLeft(pos.x()); moveBottom(pos.y()); }

inline void CscsRectF::moveBottomRight(const CscsPointF& pos)
{ moveRight(pos.x()); moveBottom(pos.y()); }

inline void CscsRectF::moveCenter(const CscsPointF& pos)
{ m_x1 = pos.x() - m_w/2; m_y1 = pos.y() - m_h/2; }

inline void CscsRectF::moveTo(double x, double y)
{ m_x1 = x; m_y1 = y; }

inline void CscsRectF::moveTo(const CscsPointF& p)
{ m_x1 = p.x(); m_y1 = p.y(); }

inline void CscsRectF::translate(double dx, double dy)
{ m_x1 += dx; m_y1 += dy; }

inline void CscsRectF::translate(const CscsPointF& p)
{ m_x1 += p.x(); m_y1 += p.y(); }

inline CscsRectF CscsRectF::translated(double dx, double dy) const
{ return CscsRectF(m_x1 + dx, m_y1 + dy, m_w, m_h); }

inline CscsRectF CscsRectF::translated(const CscsPointF& p) const
{ return CscsRectF(m_x1 + p.x(), m_y1 + p.y(), m_w, m_h); }

inline CscsRectF CscsRectF::transposed() const
{ return CscsRectF(topLeft(), size().transposed()); }

inline void CscsRectF::getRect(double* x, double* y, double* w, double* h) const
{ *x = this->m_x1; *y = this->m_y1; *w = this->m_w; *h = this->m_h; }

inline void CscsRectF::setRect(double x, double y, double w, double h)
{ this->m_x1 = x; this->m_y1 = y; this->m_w = w; this->m_h = h; }

inline void CscsRectF::getCoords(double* x1, double* y1, double* x2, double* y2)
{ *x1 = m_x1; *y1 = m_y1; *x2 = m_x1 + m_w; *y2 = m_y1 + m_h; }

inline void CscsRectF::setCoords(double x1, double y1, double x2, double y2)
{ m_x1 = x1; m_y1 = y1; m_w = x2 -x1; m_h = y2 -y1; }

inline void CscsRectF::adjust(double x1, double y1, double x2, double y2)
{ m_x1 += x1; m_y1 += y1; m_w += x2 - x1; m_h += y2 - y1; }

inline CscsRectF CscsRectF::adjusted(double x1, double y1, double x2, double y2) const
{ return CscsRectF(m_x1 + x1, m_y1 + y1, m_w + x2 - x1, m_h + y2 - y1); }

inline double CscsRectF::width() const
{ return m_w; }

inline double CscsRectF::height() const
{ return m_h; }

inline CscsSizeF CscsRectF::size() const
{ return CscsSizeF(m_w, m_h); }

inline void CscsRectF::setWidth(double w)
{ this->m_w = w; }

inline void CscsRectF::setHeight(double h)
{ this->m_h = h; }

inline void CscsRectF::setSize(const CscsSizeF& p)
{ m_w = p.width(); m_h = p.height(); }

inline bool CscsRectF::contains(double x, double y) const
{ return contains(CscsPointF(x, y)); }

inline CscsRectF CscsRectF::united(const CscsRectF& other) const
{ return *this | other; }

inline CscsRectF CscsRectF::intersected(const CscsRectF& other) const
{ return *this & other; }

inline CscsRectF CscsRectF::marginAdded(const CscsMarginF& margin) const
{
    return CscsRectF(CscsPointF(m_x1 - margin.left(), m_y1 - margin.top()),
                     CscsSizeF(m_w + margin.left() + margin.right(), m_h + margin.top() + margin.bottom()));
}
inline CscsRectF CscsRectF::marginRemoved(const CscsMarginF& margin) const
{
    return CscsRectF(CscsPointF(m_x1 + margin.left(), m_y1 + margin.top()),
                     CscsSizeF(m_w - margin.left() - margin.right(), m_h - margin.top() - margin.bottom()));
}

inline CscsRectF& CscsRectF::operator&=(const CscsRectF& r)
{ *this = *this & r; return *this; }

inline CscsRectF& CscsRectF::operator|=(const CscsRectF& r)
{ *this = *this | r; return *this; }

inline const CscsRectF operator+(const CscsRectF& r, const CscsMarginF& m)
{
    return CscsRectF(CscsPointF(r.left() - m.left(), r.top() - m.top()),
                     CscsSizeF(r.width() + m.left() + m.right(), r.height() + m.top() + m.bottom()));
}

inline const CscsRectF operator+(const CscsMarginF& m, const CscsRectF& r)
{
    return CscsRectF(CscsPointF(r.left() - m.left(), r.top() - m.top()),
                     CscsSizeF(r.width() + m.left() + m.right(), r.height() + m.top() + m.bottom()));
}

inline const CscsRectF operator-(const CscsRectF& r, const CscsMarginF& m)
{
    return CscsRectF(CscsPointF(r.left() + m.left(), r.top() + m.top()),
                     CscsSizeF(r.width() - m.left() - m.right(), r.height() - m.top() - m.bottom()));
}

inline CscsRectF & CscsRectF::operator+=(const CscsMarginF& margin)
{ *this = marginAdded(margin); return *this; }

inline CscsRectF & CscsRectF::operator-=(const CscsMarginF& margin)
{ *this = marginRemoved(margin); return *this; }

inline const bool operator==(const CscsRectF& r1, const CscsRectF& r2)
{
    return scsFuzzyCompare(r1.m_x1, r2.m_x1) && scsFuzzyCompare(r1.m_y1, r2.m_y1)
            && scsFuzzyCompare(r1.m_w, r2.m_w) && scsFuzzyCompare(r1.m_h, r2.m_h);
}

inline const bool operator!=(const CscsRectF& r1, const CscsRectF& r2)
{
    return !scsFuzzyCompare(r1.m_x1, r2.m_x1) || !scsFuzzyCompare(r1.m_y1, r2.m_y1)
            || !scsFuzzyCompare(r1.m_w, r2.m_w) || !scsFuzzyCompare(r1.m_h, r2.m_h);
}

inline std::ostream& operator<<(std::ostream& os, const CscsRectF& r)
{
    os << double(r.x())<<" " << double(r.y())<< " " << double(r.width())<<" "<< double(r.height());
    return os;
}
inline std::istream& operator>>(std::istream& is, CscsRectF& r)
{
    double x, y, w, h;
    is >> x;
    is >> y;
    is >> w;
    is >> h;
    r.setRect(x, y, w, h);
    return is;
}

inline CscsRect CscsRectF::toRect() const
{
    return CscsRect(scsRound(m_x1), scsRound(m_y1), scsRound(m_w), scsRound(m_h));
}


END_NAMESPACE

#endif // SCSRECT_H
