///////////////////////////////////////////////////////////
//  scsline.h
//  Implementation of the Class CscsLine
//  Created on:      29-10��-2018 19:44:33
//  Original author: jian.wang
///////////////////////////////////////////////////////////

#ifndef SCSLINE_H
#define SCSLINE_H

#include "scspoint.h"
#include <iostream>
#include <kernel/scstypeinfo.h>

BEGIN_NAMESPACE(Gemini)

class CscsLine
{

public:

	CscsLine();
	CscsLine(const CscsPoint p1, const CscsPoint p2);
	CscsLine(int x1, int y1, int x2, int y2);
	virtual ~CscsLine();


	inline bool isNull() const;
    inline bool operator==(const CscsLine& line) const;
    inline bool operator!=(const CscsLine& line) const;
	
	inline friend std::ostream& operator<<(std::ostream& os, const CscsLine& line);
	inline friend std::istream& operator>>(std::istream& is, CscsLine& line);
	
	inline void translate(const CscsPoint& p);
	inline void translate(int dx, int dy);
	inline CscsLine translated(const CscsPoint& p) const;
	inline CscsLine translated(int dx, int dy) const;
	
	inline CscsPoint p1() const;
	inline CscsPoint p2() const;
	inline void setLine(int x1, int y1, int x2, int y2);
	inline void setP1(const CscsPoint& p1);
	inline void setP2(const CscsPoint& p2);
	inline void setPoints(const CscsPoint& p1, const CscsPoint& p2);
	
	inline int dx() const;
	inline int dy() const;
	inline int x1() const;
	inline int x2() const;
	inline int y1() const;
	inline int y2() const;

private:
	CscsPoint m_p1;
	CscsPoint m_p2;

};
SCS_DECLARE_TYPEINFO(CscsLine)
SCS_DECLARE_TYPENAME_INFO(CscsLine,SCS_MOVABLE_TYPE)

inline CscsLine::CscsLine(){}
inline CscsLine::CscsLine(const CscsPoint p1, const CscsPoint p2):m_p1(p1), m_p2(p2){}
inline CscsLine::CscsLine(int x1, int y1, int x2, int y2):m_p1(CscsPoint(x1, y1)), m_p2(CscsPoint(x2, y2)){}
inline CscsLine::~CscsLine(){}

inline bool CscsLine::isNull() const
{ return m_p1 == m_p2; }

inline bool CscsLine::operator==(const CscsLine& line) const
{ return m_p1 == line.m_p1 && m_p2 == line.m_p2; }

inline bool CscsLine::operator!=(const CscsLine& line) const
{ return m_p1 != line.m_p1 || m_p2 != line.m_p2; }


inline std::ostream& operator<<(std::ostream& os, const CscsLine& line)
{
	os << line.m_p1 << line.m_p2;
    return  os;
}

inline std::istream& operator>>(std::istream& is, CscsLine& line){
	CscsPoint p1, p2;
	is >> p1;
	is >> p2;
    line = CscsLine(p1, p1);
    return is;
}


inline CscsPoint CscsLine::p1() const
{ return  m_p1; }

inline CscsPoint CscsLine::p2() const
{ return  m_p2; }
 
inline void CscsLine::setLine(int x1, int y1, int x2, int y2){
	m_p1 = CscsPoint(x1, y1);
	m_p2 = CscsPoint(x2, y2);
}

inline void CscsLine::setP1(const CscsPoint& p1)
{ m_p1 = p1; }

inline void CscsLine::setP2(const CscsPoint& p2)
{ m_p2 = p2; }

inline void CscsLine::setPoints(const CscsPoint& p1, const CscsPoint& p2)
{ m_p1 = p1; m_p2 = p2; }


inline void CscsLine::translate(const CscsPoint& p)
{
	m_p1 += p;
	m_p2 += p;
}
inline void CscsLine::translate(int dx, int dy){
    this->translated(CscsPoint(dx, dy));
}
inline CscsLine CscsLine::translated(const CscsPoint& p) const
{ return  CscsLine(m_p1+p, m_p2+p); }

inline CscsLine CscsLine::translated(int dx, int dy) const
{ return  translated(CscsPoint(dx, dy)); }


inline int CscsLine::dx() const
{ return m_p1.x() - m_p2.x(); }

inline int CscsLine::dy() const
{ return m_p1.y() - m_p2.y(); }

inline int CscsLine::x1() const
{ return m_p1.x(); }

inline int CscsLine::x2() const
{ return m_p2.x(); }

inline int CscsLine::y1() const
{ return m_p1.y(); }

inline int CscsLine::y2() const
{ return m_p2.y(); }


class CscsLineF
{

public:
	enum IntersectType
	{
		NoIntersection,
		BoundedIntersection,
		UnboundedIntersection
	};


	inline CscsLineF();
	inline CscsLineF(const CscsPointF& p1, const CscsPointF& p2);
	inline CscsLineF(double x1, double y1, double x2, double y2);
	inline CscsLineF(const CscsLine& l);
	inline virtual ~CscsLineF();

	inline bool isNull() const;
	
	void setAngle(double angle);
	double angle() const;
	double angle(const CscsLineF& l) const;
	double angleTo(const CscsLineF& l) const;
	
	void setLength(double len);
	double length() const;

	static CscsLineF fromPolar(double length, double angle);
	IntersectType intersects(const CscsLineF& l, CscsPointF* intersectionPoint) const;
	inline CscsLineF normalVector() const;
	CscsLineF unitVector() const;

	inline bool operator==(const CscsLineF& line) const;
    inline bool operator!=(const CscsLineF& line) const;
	inline friend std::ostream& operator<<(std::ostream& os, const CscsLineF& line);
	inline friend std::istream& operator>>(std::istream& is, CscsLineF& line);

	CscsPointF pointAt(double t);
	inline CscsPointF p1() const;
	inline CscsPointF p2() const;
	inline void setP1(const CscsPointF& p);
	inline void setP2(const CscsPointF& p);
	inline void setPoints(CscsPointF& p1, const CscsPointF& p2);
	inline CscsLine toLine() const;
	
	inline void translate(const CscsPointF& p);
	inline void translate(double dx, double dy);
	inline CscsLineF translated(const CscsPointF& p) const;
	inline CscsLineF translated(double dx, double dy) const;
	
	inline double dx() const;
	inline double dy() const;
	inline double x1() const;
	inline double x2() const;
	inline double y1() const;
	inline double y2() const;

private:
	CscsPointF m_p1;
	CscsPointF m_p2;

};

SCS_DECLARE_TYPEINFO(CscsLineF)
SCS_DECLARE_TYPENAME_INFO(CscsLineF,SCS_MOVABLE_TYPE)

inline CscsLineF::CscsLineF(){}
inline CscsLineF::CscsLineF(const CscsPointF& p1, const CscsPointF& p2):m_p1(p1), m_p2(p2){}
inline CscsLineF::CscsLineF(double x1, double y1, double x2, double y2):m_p1(x1, y1), m_p2(x2, y2){}
inline CscsLineF::CscsLineF(const CscsLine& l):m_p1(l.p1()), m_p2(l.p2()){}
inline CscsLineF::~CscsLineF(){}

inline bool CscsLineF::isNull() const
{ return scsFuzzyCompare(m_p1.x(), m_p2.x()) && scsFuzzyCompare(m_p1.y(), m_p2.y()); }

inline void CscsLineF::setLength(double len)
{
	if(isNull())
		return;
	CscsLineF v = unitVector();
	m_p2 = CscsPointF(m_p1.x() + v.dx() * len, m_p1.y() + v.dy() * len);
}


inline CscsLineF CscsLineF::normalVector() const
{ return  CscsLineF(p1(), p1() + CscsPointF(dy(), -dx())); }


inline bool CscsLineF::operator==(const CscsLineF& line) const
{ return m_p1 == line.m_p1 && m_p2 == line.m_p2; }

inline bool CscsLineF::operator!=(const CscsLineF& line) const
{ return !(*this == line); }

inline std::ostream& operator<<(std::ostream& os, const CscsLineF& line)
{
	os << line.p1() << std::endl;
	os << line.p2() << std::endl;
    return  os;
}

inline std::istream& operator>>(std::istream& is, CscsLineF& line){
	CscsPoint start, end;
	is >> start;
	is >> end;
    line = CscsLineF(start, start);
    return  is;
}


inline CscsPointF CscsLineF::p1() const
{ return  m_p1; }

inline CscsPointF CscsLineF::p2() const
{ return  m_p2; }


inline void CscsLineF::setP1(const CscsPointF& p)
{ m_p1 = p; }

inline void CscsLineF::setP2(const CscsPointF& p)
{ m_p2 = p; }

inline CscsPointF CscsLineF::pointAt(double t)
{
    return CscsPointF(m_p1.x() + (m_p2.x() - m_p1.x())*t, m_p1.y() + (m_p2.y() - m_p1.y()) * t);
}

inline void CscsLineF::setPoints(CscsPointF& p1, const CscsPointF& p2)
{ m_p1 = p1; m_p2 = p2; }

inline CscsLine CscsLineF::toLine() const
{ return  CscsLine(m_p1.toPoint(), m_p2.toPoint()); }


inline void CscsLineF::translate(const CscsPointF& p)
{ m_p1 += p; m_p2 += p; }
	
inline void CscsLineF::translate(double dx, double dy)
{ this->translated(CscsPointF(dx, dy)); }

inline CscsLineF CscsLineF::translated(const CscsPointF& p) const
{ return  CscsLineF(m_p1+p, m_p2+p); }

inline CscsLineF CscsLineF::translated(double dx, double dy) const
{ return  translated(dx, dy); }


inline double CscsLineF::dx() const
{ return m_p1.x() - m_p2.x(); }

inline double CscsLineF::dy() const
{ return m_p1.y() - m_p2.y(); }

inline double CscsLineF::x1() const
{ return m_p1.x(); }

inline double CscsLineF::x2() const
{ return m_p2.x(); }

inline double CscsLineF::y1() const
{ return m_p1.y(); }

inline double CscsLineF::y2() const
{ return m_p2.y(); }



END_NAMESPACE

#endif // SCSLINE_H
