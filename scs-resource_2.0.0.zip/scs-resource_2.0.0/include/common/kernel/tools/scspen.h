#ifndef SCSPEN_H
#define SCSPEN_H
#include <kernel/scsvector.h>
#include <memory>

#include "scsrgba.h"
#include "scsbrush.h"

BEGIN_NAMESPACE(Gemini)

struct CscsPenData;

class CscsPen{
public:
	enum PenType{
		NoPen,
		SolidPen,
		DashPen,
	};

	enum PenCap{
		ButtCap,
		RoundCap,
		SquareCap
	};

	enum PenJoin{
		MiterJoin,
		RoundJoin,
		BevelJoin
	};

	CscsPen();
	CscsPen(PenType type);
	CscsPen(const CscsRgba& color);
	CscsPen(const CscsRgba& color,int width, PenType type=SolidPen, PenCap cap=ButtCap, PenJoin join=MiterJoin);
	CscsPen(const CscsRgba& color,double width, PenType type=SolidPen, PenCap cap=ButtCap, PenJoin join=MiterJoin);
	CscsPen(const CscsBrush& brush, int width);
	CscsPen(const CscsBrush& brush, double width);
	CscsPen(const CscsBrush& brush,double width, PenType type, PenCap cap, PenJoin join=MiterJoin);
	CscsPen(const CscsPen& pen);
	virtual ~CscsPen();
	
	CscsPen& operator=(const CscsPen& pen);

	bool operator==(const CscsPen& pen)const;
	inline bool operator!=(const CscsPen& pen)const{
		return !(*this==pen);
	}


	CscsRgba color()const;
	bool 	 isReferenceBrush()const;
	CscsBrush brush()const;
	int 	 width()const;
	double   widthF()const;
	double 	 dashOffset()const;
	CscsVector<double> dashes()const;
	CscsPen::PenType penType()const;
	CscsPen::PenCap  penCap()const;
	CscsPen::PenJoin penJoin()const;

	void setColor(const CscsRgba& color);
	void setWidth(int width);
	void setWidthF(double width);
	void setDashOffset(double offset);
	void setBrush(const CscsBrush& brush);
	//on-pixels off-pixels ....
	void setDashes(const CscsVector<double>& dashes);
	void setPenType(CscsPen::PenType type);
	void setPenCap(CscsPen::PenCap cap);
	void setPenJoin(CscsPen::PenJoin join);

	bool isValid()const;

private:
	CscsPenData* data;
	CscsPen& copyFrom(const CscsPen& o);
};
SCS_DECLARE_TYPENAME_INFO(CscsPen,SCS_MOVABLE_TYPE)

struct CscsPenData{
	CscsPen::PenType type;
	CscsPen::PenCap  cap;
	CscsPen::PenJoin join;
	CscsRgba color;
	CscsBrush brush;
	bool referenceBrush;
	double width;
	CscsVector<double> dashes;
	double offset;
	~CscsPenData(){
	}
};
SCS_DECLARE_TYPEINFO(CscsPen)

END_NAMESPACE

#endif