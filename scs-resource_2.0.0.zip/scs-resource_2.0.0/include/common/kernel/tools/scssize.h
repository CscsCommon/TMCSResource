///////////////////////////////////////////////////////////
//  scssize.h
//  Implementation of the Class CscsSize
//  Created on:      29-10��-2018 15:30:20
//  Original author: jian.wang
///////////////////////////////////////////////////////////

#ifndef SCSSIZE_H
#define SCSSIZE_H
#include <iostream>
#include <assert.h>
#include "scsmath.h"
#include "scsenum.h"
#include <kernel/scstypeinfo.h>

BEGIN_NAMESPACE(Gemini)

class CscsSize
{

public:

    CscsSize() noexcept;
    CscsSize(int w, int h) noexcept;
    virtual ~CscsSize();

    inline CscsSize boundedTo(const CscsSize& size) const;
    inline CscsSize expandTo(const CscsSize& size) const;
    inline bool isEmpty() const;
    inline bool isNull() const;
    inline bool isValid() const;

    inline friend const CscsSize operator+(const CscsSize& s1, const CscsSize& s2);
    inline friend const CscsSize operator-(const CscsSize& s1, const CscsSize& s2);
    inline friend const CscsSize operator*(const CscsSize& s, double factor);
    inline friend const CscsSize operator*(double factor, const CscsSize& s);
    inline friend const CscsSize operator/(const CscsSize& s, double factor);

    inline CscsSize& operator+=(const CscsSize& size);
    inline CscsSize& operator-=(const CscsSize& size);
    inline CscsSize& operator*=(double factor);
    inline CscsSize& operator/=(double factor);

    inline friend const bool operator==(const CscsSize& s1, const CscsSize& s2);
    inline friend const bool operator!=(const CscsSize& s1, const CscsSize& s2);

    inline friend std::ostream& operator<<(std::ostream& os, const CscsSize& s);
    inline friend std::istream& operator>>(std::istream& is, CscsSize& s);

    inline void scale(int w, int h, SCS::AspectRatioMode mode);
    inline void scale(const CscsSize& size, SCS::AspectRatioMode mode);
    CscsSize scaled(int w, int h, SCS::AspectRatioMode mode) const;
    CscsSize scaled(const CscsSize& size, SCS::AspectRatioMode mode) const;



    void transpose();
    inline CscsSize transposed() const;

    inline void setHeight(int h);
    inline void setWidth(int w);
    inline int& rHeight();
    inline int& rWidth();
    inline int width() const;
    inline int height() const;

private:
    int m_h;
    int m_w;

    inline int max(int m, int n) const;
    inline int min(int m, int n) const;

};
SCS_DECLARE_TYPEINFO(CscsSize)
SCS_DECLARE_TYPENAME_INFO(Gemini::CscsSize,SCS_MOVABLE_TYPE)


inline CscsSize::CscsSize() noexcept : m_h(-1), m_w(-1){}
inline CscsSize::CscsSize(int w, int h) noexcept : m_h(h), m_w(w){}
inline CscsSize::~CscsSize(){}


inline CscsSize CscsSize::boundedTo(const CscsSize& size) const
{ return  CscsSize(min(m_w, size.m_w), min(m_h, size.m_h)); }

inline CscsSize CscsSize::expandTo(const CscsSize& size) const
{ return  CscsSize(max(m_w, size.m_w), max(m_h, size.m_h)); }

inline bool CscsSize::isEmpty() const
{ return m_w<1 || m_h<1; }

inline bool CscsSize::isNull() const
{ return m_w==0 && m_h==0; }

inline bool CscsSize::isValid() const
{ return m_w>=0 && m_h>=0; }


inline const CscsSize operator+(const CscsSize& s1, const CscsSize& s2)
{ return CscsSize(s1.m_w+s2.m_w, s1.m_h+s2.m_h); }

inline const CscsSize operator-(const CscsSize& s1, const CscsSize& s2)
{ return CscsSize(s1.m_w-s2.m_w, s1.m_h-s2.m_h); }

inline const CscsSize operator*(const CscsSize& s, double factor)
{ return  CscsSize(scsRound(s.m_w*factor), scsRound(s.m_h*factor)); }

inline const CscsSize operator*(double factor, const CscsSize& s)
{ return  CscsSize(scsRound(s.m_w*factor), scsRound(s.m_h*factor)); }

inline const CscsSize operator/(const CscsSize& s, double factor)
{   
    if(scsFuzzyIsNull(factor))
        assert(false);
    return  CscsSize(scsRound(s.m_w/factor), scsRound(s.m_h/factor));
}


inline CscsSize& CscsSize::operator+=(const CscsSize& size)
{ m_w+=size.m_w;m_h+=size.m_h; return  *this; }

inline CscsSize& CscsSize::operator-=(const CscsSize& size)
{ m_w-=size.m_w;m_h-=size.m_h; return  *this;}

inline CscsSize& CscsSize::operator*=(double factor)
{ m_w = scsRound(m_w*factor);m_h = scsRound(m_h*factor); return  *this; }

inline CscsSize& CscsSize::operator/=(double factor)
{
    if(scsFuzzyIsNull(factor))
        assert(false);
    m_w/=factor; m_h/=factor;
    return  *this;
}

inline const bool operator==(const CscsSize& s1, const CscsSize& s2)
{ return s1.m_w == s2.m_w && s1.m_h == s2.m_h; }

inline const bool operator!=(const CscsSize& s1, const CscsSize& s2)
{ return s1.m_w!=s2.m_w || s1.m_h!=s2.m_h; }


inline std::ostream& operator<<(std::ostream& os, const CscsSize& s)
{ os << s.m_w << std::endl; os << s.m_h; return  os; }

inline std::istream& operator>>(std::istream& is, CscsSize& s)
{ is >> s.m_w >> s.m_h; return  is; }



inline void CscsSize::scale(int w, int h, SCS::AspectRatioMode mode)
{ scale(CscsSize(w,h), mode); }

inline void CscsSize::scale(const CscsSize& size, SCS::AspectRatioMode mode)
{ *this = scaled(size, mode); }

inline CscsSize CscsSize::scaled(int w, int h, SCS::AspectRatioMode mode) const
{ return  scaled(CscsSize(w,h), mode); }

inline CscsSize CscsSize::transposed() const
{ return  CscsSize(m_w, m_h); }


inline void CscsSize::setHeight(int h)
{ m_h = h; }

inline void CscsSize::setWidth(int w)
{ m_w = w; }

inline int& CscsSize::rHeight()
{ return  m_h; }

inline int& CscsSize::rWidth()
{ return  m_w; }

inline int CscsSize::width() const
{ return m_w; }

inline int CscsSize::height() const
{ return m_h; }


inline int CscsSize::max(int m, int n) const
{ return m > n ? m : n; }

inline int CscsSize::min(int m, int n) const
{ return m < n ? m : n; }




class CscsSizeF
{

public:

    CscsSizeF() noexcept;
    CscsSizeF(double w, double h) noexcept;
    CscsSizeF(const CscsSize& s) noexcept;
    virtual ~CscsSizeF();

    inline CscsSizeF boundedTo(const CscsSizeF& s) const;
    inline CscsSizeF expandTo(const CscsSizeF& s) const;
    inline bool isEmpty() const;
    inline bool isNull() const;
    inline bool isValid() const;

    inline friend const CscsSizeF operator+(const CscsSizeF& s1, const CscsSizeF& s2);
    inline friend const CscsSizeF operator-(const CscsSizeF& s1, const CscsSizeF& s2);
    inline friend const CscsSizeF operator*(double c, const CscsSizeF& s);
    inline friend const CscsSizeF operator*(const CscsSizeF& s, double c);
    inline friend const CscsSizeF operator/(const CscsSizeF& s, double c);

    inline CscsSizeF& operator+=(const CscsSizeF& s);
    inline CscsSizeF& operator-=(const CscsSizeF& s);
    inline CscsSizeF& operator*=(double c);
    inline CscsSizeF& operator/=(double c);

    inline friend bool operator==(const CscsSizeF& s1, const CscsSizeF& s2);
    inline friend bool operator!=(const CscsSizeF& s1, const CscsSizeF& s2);

    inline friend std::istream& operator>>(std::istream& is, CscsSizeF& s);
    inline friend std::ostream& operator<<(std::ostream& os, const CscsSizeF& s);

    inline void scale(double w, double h, SCS::AspectRatioMode mode);
    inline void scale(const CscsSizeF& s, SCS::AspectRatioMode mode);
    inline CscsSizeF scaled(double w, double h, SCS::AspectRatioMode mode) const;
    CscsSizeF scaled(const CscsSizeF& s, SCS::AspectRatioMode mode) const;
    inline CscsSize toSize() const;
    void transpose();
    inline CscsSizeF transposed() const;


    inline void setHeight(double height);
    inline void setWidth(double width);
    inline double& rHeight();
    inline double& rWidth();
    inline double width() const;
    inline double height() const;

private:
    double m_w;
    double m_h;
    
};
SCS_DECLARE_TYPEINFO(CscsSizeF)
SCS_DECLARE_TYPENAME_INFO(Gemini::CscsSizeF,SCS_MOVABLE_TYPE)


inline CscsSizeF::CscsSizeF() noexcept : m_w(-1.), m_h(-1.){}
inline CscsSizeF::CscsSizeF(double w, double h) noexcept : m_w(w), m_h(h){}
inline CscsSizeF::CscsSizeF(const CscsSize& s) noexcept : m_w(s.width()), m_h(s.height()){}
inline CscsSizeF::~CscsSizeF(){}

inline CscsSizeF CscsSizeF::boundedTo(const CscsSizeF& s) const
{ return  CscsSizeF(scsMin(m_w, s.m_w), scsMin(m_h, s.m_h)); }

inline CscsSizeF CscsSizeF::expandTo(const CscsSizeF& s) const
{ return  CscsSizeF(scsMax(m_w,s.m_w), scsMax(m_h, s.m_h)); }

inline bool CscsSizeF::isEmpty() const
{ return m_w <= 0. || m_h <= 0.; }

inline bool CscsSizeF::isNull() const
{ return scsIsNull(m_w) && scsIsNull(m_h); }

inline bool CscsSizeF::isValid() const
{ return m_w >= 0. && m_h >= 0.; }

inline const CscsSizeF operator+(const CscsSizeF& s1, const CscsSizeF& s2)
{ return  CscsSizeF(s1.m_w+s2.m_w, s1.m_h+s2.m_h); }

inline const CscsSizeF operator-(const CscsSizeF& s1, const CscsSizeF& s2)
{ return  CscsSizeF(s1.m_w-s2.m_w, s1.m_h-s2.m_h); }

inline const CscsSizeF operator*(double c, const CscsSizeF& s)
{ return  CscsSizeF(s.m_w*c, s.m_h*c); }

inline const CscsSizeF operator*(const CscsSizeF& s, double c)
{ return  CscsSizeF(s.m_w*c, s.m_h*c); }

inline const CscsSizeF operator/(const CscsSizeF& s, double c)
{
    if(scsIsNull(c))
        assert(false);
    return CscsSizeF(s.m_w/c, s.m_h/c);
}

inline CscsSizeF& CscsSizeF::operator+=(const CscsSizeF& s)
{ m_w+=s.m_w; m_h+=s.m_h; return  *this; }

inline CscsSizeF& CscsSizeF::operator-=(const CscsSizeF& s)
{ m_w-=s.m_w;m_h-=s.m_h; return  *this; }

inline CscsSizeF& CscsSizeF::operator*=(double c)
{ m_w*=c;m_h*=c; return  *this; }

inline CscsSizeF& CscsSizeF::operator/=(double c)
{
    if(scsIsNull(c))
        assert(false);
    m_w /= c; m_h /= c;
    return  *this;
}

inline bool operator==(const CscsSizeF& s1, const CscsSizeF& s2)
{ return scsFuzzyCompare(s1.m_w,s2.m_w) && scsFuzzyCompare(s1.m_h, s2.m_h); }

inline bool operator!=(const CscsSizeF& s1, const CscsSizeF& s2)
{ return !scsFuzzyCompare(s1.m_w,s2.m_w) || !scsFuzzyCompare(s1.m_h, s2.m_h); }

inline std::istream& operator>>(std::istream& is, CscsSizeF& s)
{ is >> s.m_w >> s.m_h; return  is; }

inline std::ostream& operator<<(std::ostream& os, const CscsSizeF& s)
{
    os << s.m_w  << std::endl;os << s.m_h << std::endl;
    return  os;
}

inline void CscsSizeF::scale(double w, double h, SCS::AspectRatioMode mode)
{ scale(CscsSize(w,h), mode); }

inline void CscsSizeF::scale(const CscsSizeF& s, SCS::AspectRatioMode mode)
{ *this=scaled(s, mode); }

inline CscsSizeF CscsSizeF::scaled(double w, double h, SCS::AspectRatioMode mode) const
{ return  scaled(CscsSize(w, h), mode); }

inline CscsSize CscsSizeF::toSize() const
{ return  CscsSize(scsRound(m_w), scsRound(m_h)); }

inline CscsSizeF CscsSizeF::transposed() const
{ return  CscsSizeF(m_w, m_h); }

inline void CscsSizeF::setHeight(double height)
{ m_h=height; }

inline void CscsSizeF::setWidth(double width)
{ m_w=width; }

inline double& CscsSizeF::rHeight()
{ return  m_h; }

inline double& CscsSizeF::rWidth()
{ return  m_w; }

inline double CscsSizeF::width() const
{ return m_w; }

inline double CscsSizeF::height() const
{ return m_h; }


END_NAMESPACE

#endif // SCSSIZE_H
