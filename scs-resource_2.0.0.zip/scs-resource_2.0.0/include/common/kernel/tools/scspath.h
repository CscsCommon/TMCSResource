#ifndef SCSPATH_H
#define SCSPATH_H
#include <memory>
#include <vector>
#include "scspoint.h"
#include "scsrect.h"
#include "scspolygon.h"
#include "scsmatrix.h"
#include <kernel/scslist.h>

BEGIN_NAMESPACE(Gemini)

class CscsRect;
class CscsRectF;
class CscsPointF;

struct CscsPathData{
	enum PathElement{
		MoveToElement,
		LineToElement,
		CurveToElement,
		CurveToDataElement
	};
	enum FillRule
	{
		OddEvenFill,
        WindingFill
	};

	struct Element{
		double x;
		double y;
		CscsPathData::PathElement type;
		bool isMoveTo() const { return type == CscsPathData::MoveToElement; 	}
		bool isLineTo() const { return type == CscsPathData::LineToElement; 	}
		bool isCurveTo() const{ return type == CscsPathData::CurveToElement;    }
		operator CscsPointF () const { return CscsPointF(x, y); }
	};

	FillRule fillRule;
	CscsRectF bounds;
	bool dirtyBounds;
	int  start;
	std::vector<Element> elements;
};


class CscsPath{
public:
	

	CscsPath();
	CscsPath(const CscsPath& o);
	CscsPath operator=(const CscsPath& o);
	virtual ~CscsPath();
	int elementCount()const;
	int isEmpty()const; 
	bool isValid()const;

	CscsPath simplified()const;
   	CscsPath toReversed() const;
    CscsPathData::FillRule fillRule() const;
    void setFillRule(CscsPathData::FillRule fillRule);

	CscsRectF boundingRect()const;

	void setPointAt(int index, double x, double y);	
	CscsPathData::Element elementAt(int index)const;
	CscsPointF pointAt(int index)const;
	void moveTo(const CscsPointF& p){
		moveTo(p.x(), p.y());
	}
	void moveTo(double x, double y);

	void lineTo(const CscsPointF& p){
		lineTo(p.x(),p.y());
	}
	void lineTo(const double x, double y);

	void arcMoveTo(const CscsRectF& rect, double angle);
	void arcMoveTo(double x, double y, double w, double h, double angle){
		arcMoveTo(CscsRectF(x,y,w,h),angle);
	}

	void arcTo(const CscsRectF& rect, double startAngle,double spanAngle);

	void arcTo(double x, double y, double w, double h, double startAngle,double spanAngle){
		arcTo(CscsRectF(x,y,w,h),startAngle, spanAngle);
	}


	void cubicTo(const CscsPointF& c1, const CscsPointF& c2, const CscsPointF& end);
	
	void cubicTo(double cx1, double cy1, double cx2, double cy2, double endx, double endy){
		cubicTo(CscsPointF(cx1, cy1), CscsPointF(cx2,cy2), CscsPointF(endx, endy));
	}

	void quadTo(const CscsPointF& c, const CscsPointF& end);

	void quadTo(double cx, double cy, double endx, double endy){
		quadTo(CscsPointF(cx,cy),CscsPointF(endx,endy));
	}

	void addRect(double x, double y, double w, double h){
		addRect(CscsRectF(x,y,w,h));
	}

	void addRect(const CscsRectF& rect);

	void addRoundedRect(double x, double y, double w, double h, double xRadius, double yRadius,SCS::SizeMode mode=SCS::RelativeSize){
		addRoundedRect(CscsRectF(x,y,w,h),xRadius,yRadius,mode);
	}
	void addRoundedRect(const CscsRectF& rect, double xRadius, double yRadius,SCS::SizeMode mode=SCS::RelativeSize);

	void addEllipse(const CscsRectF& rect);
	void addEllipse(double x, double y, double w, double h){
		addEllipse(CscsRectF(x,y,w,h));
	}

	void addPolygon(const CscsPolygonF& polygon);

	bool contains(const CscsPointF &pt) const;
    bool contains(const CscsRectF &rect) const;
    bool intersects(const CscsRectF &rect) const;


    bool intersects(const CscsPath &p) const;
    bool contains(const CscsPath &p) const;
    CscsPath united(const CscsPath &r) const;
    CscsPath intersected(const CscsPath &r) const;
    CscsPath subtracted(const CscsPath &r) const;

	void addPath(const CscsPath& path);
	void connectPath(const CscsPath& path);

	void closeSubPath();

	bool operator==(const CscsPath& path)const;
	bool operator!=(const CscsPath& path)const{
		return !(*this==path);
	}

	CscsRectF controlPointRect() const;

	CscsList<CscsPolygonF> toSubpathPolygons(const CscsMatrix &matrix = CscsMatrix()) const;
	CscsPointF currentPosition() const;
private:
	CscsPathData* data;

	CscsPath& copyFrom(const CscsPath& path);

	friend class CscsMatrix;
};

END_NAMESPACE


#endif