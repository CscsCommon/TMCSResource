#ifndef SCSIMAGE_H
#define SCSIMAGE_H
#include <memory>
#include <config.h>
#include <cairo/cairo.h>
#include <kernel/scstypes.h>
#include <vector>
#include "scssize.h"

BEGIN_NAMESPACE(Gemini)

class CscsImageData;
class CscsRgba;
class CscsRect;

class CscsImage{
public:
	enum ImageFormat{
		InvalidFormat=-1,
		ARGB32Format=0,
	 	RGB24Format=1,
	 	A8Format=2,
	 	A1Format=3,
	 	RGB565Format=4,
	 	RGB30Format=5,

	};
	enum InvertMode{
		InvertRgb,
		InvertRgba
	};

	enum FillColorMode{
		ClearColor,
		SrcColor,
		DstColor,
		SrcOverColor,
		DstOverColor,
		SrcInColor,
		DstInColor,
		SrcOutColor,
		DstOutColor,
		SrcATopColor,
		DstATopColor,
		XorColor
	};

	CscsImage();
	CscsImage(int width, int height, CscsImage::ImageFormat);
	CscsImage(uint8* data, int width, int height, int stride,CscsImage::ImageFormat format);
	~CscsImage();
	CscsImage(const std::string& filename);

	CscsImage(const CscsImage& o);
	
	inline CscsImage& operator=(const CscsImage& o){
		return copyFrom(o);
	}

	bool operator==(const CscsImage& o)const;

	static int strideForWidth(int width, CscsImage::ImageFormat format);


	void fromPng(const std::string& pngfile);
	void toPng(const std::string& pngfile);


	
	int stride()const;
	int width()const;
	int height()const;
	CscsSize size()const;

	uint8* scanLine(int i)const;
	
	uint8* dataPtr()const;
	
	cairo_surface_t* surface()const;
	CscsImage::ImageFormat format()const;

	bool isValid()const;

	void invertPixels(InvertMode=InvertRgb);
	void setPixel(int x, int y, uint rgba);
	void setColor(int i, uint rgba);
	uint color(int i);
	void setNumColors(int );
	int  numColors()const;
	void setColor(const CscsRgba& c,FillColorMode mode=SrcInColor);
	void fill(const CscsRgba& c);
	CscsImage copy()const;
	CscsImage copy(const CscsRect& r)const;
	int serialNumber()const;
	CscsImage scaled(const CscsSize& size)const;
	CscsImage scaledToHeight(int h)const;
	CscsImage scaledToWidth(int w)const;

private:
	CscsImageData* data;
	CscsImage& copyFrom(const CscsImage& image);
	void get_fill_mode(uint8 as, uint8 ad, float& fs, float& fd, FillColorMode mode);
	uint32 get_combine_color(const CscsRgba& src, const CscsRgba& dst, FillColorMode mode);
};
SCS_DECLARE_TYPEINFO(CscsImage)
SCS_DECLARE_TYPENAME_INFO(CscsImage,SCS_MOVABLE_TYPE)


END_NAMESPACE

#endif