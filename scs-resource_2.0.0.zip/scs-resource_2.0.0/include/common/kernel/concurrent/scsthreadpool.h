#ifndef SCSTHREADPOOL_H
#define SCSTHREADPOOL_H
#include <kernel/scsthread.h>
#include "scsrunnable.h"

BEGIN_NAMESPACE(Gemini)
class CscsThreadPoolPrivate;

class  CscsThreadPool : public CscsObject
{
    CscsThreadPoolPrivate* d_func()const;

public:
    CscsThreadPool(CscsObject *parent = 0);
    ~CscsThreadPool();

    static CscsThreadPool *globalInstance();

    void start(CscsRunnable *runnable, int priority = 0);
    bool tryStart(CscsRunnable *runnable);

    int expiryTimeout() const;
    void setExpiryTimeout(int expiryTimeout);

    int maxThreadCount() const;
    void setMaxThreadCount(int maxThreadCount);

    int activeThreadCount() const;

    void reserveThread();
    void releaseThread();

    void waitForDone();

BEGIN_PROPERTY(CscsThreadPool, CscsObject)
    META_PROPERTY(int, expiryTimeout, READ, expiryTimeout, WRITE, setExpiryTimeout)
    META_PROPERTY(int, maxThreadCount, READ, maxThreadCount, WRITE, setMaxThreadCount)
    META_READ_PROPERTY(int, activeThreadCount, READ, activeThreadCount)
END_PROPERTY
};


END_NAMESPACE

#endif