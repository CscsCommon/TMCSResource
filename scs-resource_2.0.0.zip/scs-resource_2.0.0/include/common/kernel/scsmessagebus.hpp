/*
 Created by J.Wong 2018/08/07
 version:    version 1.0,
 dependency: base on  or greater than c++11
 function: manage and dispatch messages
 gcc:4.8+
 */

#ifndef CSCSMESSAGEBUS_H
#define CSCSMESSAGEBUS_H
#include <string>
#include <functional>
#include <map>
#include "scsany.hpp"
#include "scsfunction_traits.hpp"
#include "scsnocopy.hpp"
#include "scsmutex.h"

BEGIN_NAMESPACE(Gemini)

#define GCC_VERSION (__GNUC__ * 10000 \
                     + __GNUC_MINOR__ * 100 \
                     + __GNUC_PATCHLEVEL__)





using namespace std;
class CscsMessageBus:CscsNoCopyable{

public:
	CscsMessageBus():iid_seeds(0),dirty(false){}

	//register message
	template<typename F>
	long long   attach(F&& f, const std::string& messageTopic="", long long iid=-1)
	{
		//std::lock_guard<std::mutex> lock(m_mutex);
		long long ret=0;
		m_mutex.lock();
		auto func=to_function(std::forward<F>(f));
		ret=add(messageTopic,std::move(func), iid);
		m_mutex.unlock();
		return ret;

	}

	template<typename R,typename...Args,typename C, typename... DArgs, typename P>
	long long attach(R(C::*f)(DArgs...),P&& p, const std::string& messageTopic="", long long iid=-1){
		//std::lock_guard<std::mutex> lock(m_mutex);
		using function_type=std::function<R(Args...)>;
		 function_type func=[&, f](Args... args){return (*p.*f)(std::forward<Args>(args)...);};

		return add(messageTopic,std::move(func),iid);
	}

	template<typename R, typename... Args, typename F,
	 class=typename std::enable_if<!std::is_member_function_pointer<F>::value>::type>
	long long attach(F&& f, const std::string& messageTopic="", long long iid=-1){
		//std::lock_guard<std::mutex> lock(m_mutex);
		long long ret=0;
		m_mutex.lock();
		using function_type=std::function<R(Args...)>;
		function_type func=[&](Args... args){return f(std::forward<Args>(args)...);};
		ret=add(messageTopic,std::move(func), iid);
		m_mutex.unlock();
		return ret;
	}

	//send message
	// template<typename R>
	// void sendMsg(const std::string& messageTopic=""){
	// 	std::lock_guard<std::mutex> lock(m_mutex);
	// 	using function_type=std::function<R()>;
	// 	std::string mesgType=messageTopic+typeid(function_type).name();
	// 	auto range=m_map.equal_range(mesgType);
	// 	for(Iterator it=range.first; it!=range.second; ++it){
	// 		auto f=it->second.anyCast<function_type>();
	// 		f();
	// 	}
	// }

	template<typename R, typename... Args>
	bool sendMsg(Args... args, const std::string& messageTopic=""){
		//std::lock_guard<std::mutex> lock(m_mutex);
		m_mutex.lock();
		using function_type=std::function<R(Args...)>;
		std::string  mesgType=messageTopic;
		mesgType+=typeid(function_type).name();
		 // std::cout<<"transmit: "<<mesgType<<std::endl;
		auto range=m_map.equal_range(mesgType);
		for(Iterator it=range.first; it!=range.second; ++it){
			auto f=it->second.anyCast<function_type>();
			f(std::forward<Args>(args)...);
			if(dirty){
				m_mutex.unlock();
				//delete this;
				return false;
			}
		}
		m_mutex.unlock();
		return true;
	}


	//remove topic message
	template<typename R, typename...Args>
	void detach(const std::string& messageTopic=""){
		//std::lock_guard<std::mutex> lock(m_mutex);
		m_mutex.lock();
		using function_type=std::function<R(Args...)>;
		std::string mesgType=messageTopic;
		mesgType+=typeid(function_type).name();
		int count=m_map.count(mesgType);
		auto range=m_map.equal_range(mesgType);
		m_map.erase(range.first, range.second);

		auto rangeIID=m_mapIID.equal_range(mesgType);
		m_mapIID.erase(rangeIID.first, rangeIID.second);
		m_mutex.unlock();
	}

	void detachX(long long iid, const std::string& messageTopic){
		m_mutex.lock();
		std::string mesgType=messageTopic;
		auto range=m_map.equal_range(mesgType);
		for(Iterator it=range.first; it!=range.second; ++it){
			if(iid==it->second.iid()){
				m_map.erase(it);
				break;
			}
		}

		auto rangeIID=m_mapIID.equal_range(mesgType);
		for(IIDIterator it=rangeIID.first; it!=rangeIID.second; ++it){
			if(iid==it->second){
				m_mapIID.erase(it);
				break;
			}
		}
		m_mutex.unlock();
	}

	template<typename R, typename...Args>
	void detach(long long iid,const std::string& messageTopic=""){
		//std::lock_guard<std::mutex> lock(m_mutex);
		m_mutex.lock();
		using function_type=std::function<R(Args...)>;
		std::string mesgType=messageTopic;
		mesgType+=typeid(function_type).name();
		auto range=m_map.equal_range(mesgType);
		for(Iterator it=range.first; it!=range.second; ++it){
			if(iid==it->second.iid()){
				m_map.erase(it);
				break;
			}
		}


		auto rangeIID=m_mapIID.equal_range(mesgType);
		for(IIDIterator it=rangeIID.first; it!=rangeIID.second; ++it){
			if(iid==it->second){
				m_mapIID.erase(it);
				break;
			}
		}
		m_mutex.unlock();
	}


	inline void setDirty(bool v){
		dirty=v;
	}
	inline bool dirtyFlag(){
		return dirty;
	}
private:
	std::multimap<string, CscsAny> m_map;
	std::multimap<string, long long>m_mapIID;
	typedef std::multimap<string, CscsAny>::iterator Iterator;
	typedef std::multimap<string, long long>::iterator IIDIterator;

	template<typename F>
	long long add(const std::string& messageTopic, F&& f, long long iid){
		std::string mesgType=messageTopic;
		mesgType+=typeid(F).name();
		CscsAny any=std::forward<F>(f);
		if(iid==-1)
			any.setIID(iid_seeds++);
		else
			any.setIID(iid);


		auto range=m_map.equal_range(mesgType);
		for(Iterator it=range.first; it!=range.second; ++it){
			if(any.iid()==it->second.iid()){
				m_map.erase(it);
				#if (GCC_VERSION>=40800)
				    m_map.emplace(std::move(mesgType), any);
				#else
				    m_map.insert(std::make_pair(std::move(mesgType), any));
				#endif
				return any.iid();
			}
		}
		#if(GCC_VERSION>=40800)
		    m_map.emplace(std::move(mesgType), any);
		#else
		    m_map.insert(std::make_pair(std::move(mesgType), any));
 		#endif
		// mesgType=messageTopic+typeid(F).name();
		#if(GCC_VERSION>=40800)
		    m_mapIID.emplace(std::move(mesgType),any.iid());
		#else
		    m_mapIID.insert(std::make_pair(std::move(mesgType),any.iid()));
		#endif

		return any.iid();
	}

	//此处需要使用递归锁
	CscsRecursiveMutex m_mutex;

	int iid_seeds;
	bool dirty;
};

END_NAMESPACE

#endif
