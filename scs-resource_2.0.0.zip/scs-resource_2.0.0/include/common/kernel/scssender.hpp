/*
 Created by J.Wong 2018/08/08
 version:    version 1.0,
 dependency: base on  or greater than c++11
 function: sender message
 gcc:4.9+
 */

#ifndef CSCSSENDER_H
#define CSCSSENDER_H

#include "scsmessagebus.hpp"
#include "scsnocopy.hpp"
#include "scsstring.h"

BEGIN_NAMESPACE(Gemini)

class CscsSender:public CscsNoCopyable
{

public:
	CscsSender(CscsMessageBus* bus=nullptr):m_bus(bus){}


	void setMessageBus(CscsMessageBus* bus){
		m_bus=bus;
	}

	CscsMessageBus* messageBus() const{
		return m_bus;
	}

	bool operator==(const CscsSender& s)const{
		return s.m_bus==m_bus;
	}

	bool operator!=(const CscsSender& s)const{
		return s.m_bus!=m_bus;
	}
	// template<typename R>
	// void transmit( const std::string& messageTopic=""){
	// 	if(m_bus)
	// 		m_bus->sendMsg<R>(messageTopic);
	// }

	template<typename R, typename...Args>
	bool transmit(Args... args, const std::string& messageTopic=""){
		CscsString topic=CscsString::fromStdString(messageTopic);
		topic.remove(CscsChar(' '));
		topic.remove(CscsChar('('));
		topic.remove(CscsChar(')'));
		if(m_bus)
			return m_bus->sendMsg<R, Args...>(std::forward<Args>(args)...,topic.toStdString());
		return false;
	}
private:
	CscsMessageBus* m_bus;
};

END_NAMESPACE

#endif
