 /*Created by J.Wong 2018/10/25
 version:    version 1.0,
 dependency: base on  or greater than c++11
 function: type erase
 gcc4.9+
 */
#ifndef SCSAPPLICATIONPLUS_H
#define SCSAPPLICATIONPLUS_H
#include "scsobject.h"
#include "scseventloop.h"
#include "scsutils.h"
#include "scsevent.h"

BEGIN_NAMESPACE(Gemini)

#if defined(D_WIN32) && !defined(tagMSG)
typedef struct tagMSG MSG;
#endif

class CscsApplicationPlusPrivate;

class CscsPostEventList;
class CscsDataSensor;

class CscsApplicationPlus:public CscsObject{
public:
	CscsApplicationPlus();
	~CscsApplicationPlus();

	static CscsApplicationPlus* instance(){
		return self;
	}

	static int exec();

	static void processEvents(CscsEventLoop::EventProcess filter=CscsEventLoop::AllEvents);
	static void processEvents(CscsEventLoop::EventProcess filter, int maxtime);

	static void exit(int retcode=0);
	static void postEvent(CscsObject* receiver, CscsEvent* event,bool flag=true); 
	static bool sendEvent(CscsObject* receiver, CscsEvent* event);
	static bool sendSpontaneousEvent(CscsObject* receiver, CscsEvent* event);
	static void sendPostedEvents(CscsObject* receiver, int event_type);
	static void sendPostedEvents(){return sendPostedEvents(0,0);}
	static void removePostedEvents(CscsObject* receiver);
	static bool hasPendingEvents();

	static CscsDataSensor* dataSensor();



	virtual bool notify(CscsObject* obj, CscsEvent* event);

	static bool startingUp();
	static bool closingDown();

	typedef bool (*EventFilter)(void *message, long *result);
    EventFilter setEventFilter(EventFilter filter);
    bool filterEvent(void *message, long *result);

	static void flush();
	#if defined(D_WIN32)
    virtual bool winEventFilter(MSG *message, long *result);
	#endif
	#if defined(D_UNIX)
	static void handleUnixSignal(int signal, bool handle);
	#endif

	CscsApplicationPlusPrivate* d_func()const;


//slot
public:
	static void quit();
//signal
	void quited(){}
	void unixSignal(int){}

protected:
	CscsApplicationPlus(CscsApplicationPlusPrivate* d);

	bool event(CscsEvent* e);

	virtual bool mergeEvent(CscsEvent* e, CscsObject* receiver,CscsPostEventList* list);
private:
	static CscsApplicationPlus* self;

	void init();
	#if defined(D_WIN32)
    friend bool scs_sendSpontaneousEvent(CscsObject*, CscsEvent*);
	#endif

	friend class CscsApplicationPlusPrivate;

};


typedef void (*ScsCleanUpFunction)();


END_NAMESPACE

#endif