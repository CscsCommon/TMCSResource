 /*Created by J.Wong 2018/10/23
 version:    version 1.0,
 dependency: base on  or greater than c++11
 function: type erase
 gcc4.9+
 */

#ifndef SCSWRITEREADLOCK_H
#define SCSWRITEREADLOCK_H
#include <kernel/scsnocopy.hpp>

BEGIN_NAMESPACE(Gemini)

class CscsWriteReadLockPrivate;

class CscsWriteReadLock:public CscsNoCopyable{
public:
	CscsWriteReadLock();
	~CscsWriteReadLock();

	void lockForRead();
	bool tryLockForRead();

	void lockForWrite();
	bool tryLockForWrite();

	void unlock();

private:
	friend class CscsWaitCondition;
	CscsWriteReadLockPrivate* d;
	bool testAndSet(int expectedValue, int setValue);
};

class CscsReadLocker:public CscsNoCopyable{
public:
	CscsReadLocker(CscsWriteReadLock* readWriteLock):d(readWriteLock){
		lock();
	}
	~CscsReadLocker(){
		unlock();
	}

	void lock(){
		if(d)
			d->lockForRead();
	}
	void unlock(){
		if(d)
			d->unlock();
	}

	CscsWriteReadLock* writeReadLock()const{
		return d;
	}

private:
	CscsWriteReadLock* d;
};

class CscsWriteLocker:public CscsNoCopyable{
public:
	CscsWriteLocker(CscsWriteReadLock* readWriteLock):d(readWriteLock){
		lock();
	}
	~CscsWriteLocker(){
		unlock();
	}

	void lock(){
		if(d)
			d->lockForWrite();
	}
	void unlock(){
		if(d)
			d->unlock();
	}

	CscsWriteReadLock* writeReadLock()const{
		return d;
	}

private:
	CscsWriteReadLock* d;
};

END_NAMESPACE

#endif