 /*Created by J.Wong 2018/10/24
 version:    version 1.0,
 dependency: base on  or greater than c++11
 function: type erase
 gcc4.9+
 */
#ifndef SCSTHREAD_P_H
#define SCSTHREAD_P_H

#include <stack>
#include <condition_variable>
#include "scslist.h"
#include "scsatomic.h"

#include "scsobject.h"
#include "scsobject_p.h"
#include "scsevent.h"
#include "pthread.h"
#include <mutex>

BEGIN_NAMESPACE(Gemini)

class CscsEventLoop;
class CscsAbstractEventDispatcher;
class CscsThread;


class CscsPostEvent{
public:
	CscsObject* receiver;
	CscsEvent* ev;
	CscsPostEvent():receiver(0),ev(0){

	}

	CscsPostEvent(CscsObject* r, CscsEvent* e):receiver(r),ev(e){

	}
};


typedef CscsList<CscsPostEvent> CscsPostEventListImpl;
class CscsPostEventList:public CscsPostEventListImpl{
public:
	int recursion;
	CscsMutex mtx;

	CscsPostEventList():CscsPostEventListImpl(),recursion(0){

	}
};

class CscsThreadInfo{
public:
	CscsThreadInfo();
	~CscsThreadInfo();
	static CscsThreadInfo* get(CscsThread* thread);

	int id;
	bool quitNow;
	CscsAbstractEventDispatcher* dispatcher;
	std::vector<CscsEventLoop*> loops;
	CscsPostEventList postEventList;
	bool canWait;
	void** tls;
};

class CscsThreadPrivate:public CscsObjectPrivate{
public:
	CscsThreadPrivate();
	mutable std::mutex mtx;

	bool running;
	bool finished;
	bool terminated;

	int stackSize;
	static void setCurrentThread(CscsThread* thread);
	static CscsThread* threadForId(int id);
	
#ifdef D_WIN32
	HANDLE handle;
    unsigned int id;
    int waiters;
    bool terminationEnabled, terminatePending;

    static unsigned int __stdcall start(void *);
    static void finish(void *, bool lockAnyway=true);
#else
	pthread_t thread_id;
	std::condition_variable thread_done;
	static void* start(void* arg);
	static void finish(void* arg);
#endif
	CscsThreadInfo data;
private:
	bool testAndSet(int expectedValue, int setValue);
	std::mutex pmtx;
	CscsThread* mm_func()const;
	friend class CscsApplicationPlus;
	friend class CscsApplicationThreadPlus;
	friend class CscsThread;
};

END_NAMESPACE

#endif