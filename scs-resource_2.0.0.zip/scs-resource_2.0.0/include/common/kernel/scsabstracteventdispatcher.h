#ifndef SCSABSTRACTEVENTDISAPTCHER_H
#define SCSABSTRACTEVENTDISAPTCHER_H
#include <utility>
#include <vector>
#include "scsthread.h"
#include "scseventloop.h"
#include "scsobject.h"


BEGIN_NAMESPACE(Gemini)

class CscsAbstractEventDispatcherPrivate;
class CscsSocketNotifier;


class  CscsAbstractEventDispatcher : public CscsObject
{

public:
    typedef std::pair<int, int> TimerInfo;

    CscsAbstractEventDispatcher(CscsObject *parent = 0);

    virtual ~CscsAbstractEventDispatcher();

    static CscsAbstractEventDispatcher *instance(CscsThread *thread = 0);

    virtual bool processEvents(CscsEventLoop::EventProcess filter) = 0;
    virtual bool hasPendingEvents() = 0;

    virtual void registerSocketNotifier(CscsSocketNotifier *notifier) = 0;
    virtual void unregisterSocketNotifier(CscsSocketNotifier *notifier) = 0;

    virtual int registerTimer(int interval, CscsObject *object);
    virtual void registerTimer(int timerId, int interval, CscsObject *object) = 0;
    virtual bool unregisterTimer(int timerId) = 0;
    virtual bool unregisterTimers(CscsObject *object) = 0;
    virtual std::vector<TimerInfo> registeredTimers(CscsObject *object) const = 0;

    virtual void wakeUp() = 0;
    virtual void interrupt() = 0;
    virtual void flush() = 0;

    virtual void startingUp();
    virtual void closingDown();

    typedef bool(*EventFilter)(void *message);
    EventFilter setEventFilter(EventFilter filter);
    bool filterEvent(void *message);

	CscsAbstractEventDispatcherPrivate* d_func()const;


//signals
public:
    void aboutToBlock(){}
    void awake(){}

protected:
	CscsAbstractEventDispatcher(CscsAbstractEventDispatcherPrivate* dd,CscsObject* parent);
	friend class CscsEventDispatcher;
};

END_NAMESPACE
#endif