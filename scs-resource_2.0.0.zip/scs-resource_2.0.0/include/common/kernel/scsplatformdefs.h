#ifndef SCSPLATFORMDEFS_H
#define SCSPLATFORMDEFS_H
#include <config.h>
#define SCS_FPOS_T               fpos_t
#define SCS_OFF_T                long

#define SCS_FOPEN                ::fopen
#define SCS_FSEEK                ::fseek
#define SCS_FTELL                ::ftell
#define SCS_FGETPOS              ::fgetpos
#define SCS_FSETPOS              ::fsetpos

#ifdef D_UNIX
	#include <signal.h>
	#include <sys/types.h>
	#include <sys/socket.h>
	#include <sys/stat.h>
	#include <unistd.h>
	#include <features.h>
	#include <pthread.h>
	#include <dirent.h>
	#include <fcntl.h>
	#include <grp.h>
	#include <pwd.h>
	#include <signal.h>

	#include <sys/types.h>
	#include <sys/ioctl.h>
	#include <sys/ipc.h>
	#include <sys/time.h>
	#include <sys/shm.h>
	#include <sys/socket.h>
	#include <sys/stat.h>
	#include <sys/wait.h>
	#include <netinet/in.h>
	#include <net/if.h>
	#define SCS_STATBUF              struct stat

	#define SCS_STAT                 ::stat
	#define SCS_LSTAT                ::lstat
	#define SCS_TRUNCATE             ::truncate

	// File I/O
	#define SCS_OPEN                 ::open
	#define SCS_LSEEK                ::lseek
	#define SCS_FSTAT                ::fstat
	#define SCS_FTRUNCATE            ::ftruncate

	// Posix extensions to C89

	#undef 	SCS_OFF_T
	#undef 	SCS_FSEEK
	#undef 	SCS_FTELL
	#define SCS_OFF_T                off_t
	#define SCS_FSEEK                ::fseeko
	#define SCS_FTELL                ::ftello
	#define SCS_MMAP                 ::mmap

	#define SCS_STAT_MASK            S_IFMT
	#define SCS_STAT_REG             S_IFREG
	#define SCS_STAT_DIR             S_IFDIR
	#define SCS_STAT_LNK             S_IFLNK

	#define SCS_ACCESS               ::access
	#define SCS_GETCWD               ::getcwd
	#define SCS_CHDIR                ::chdir
	#define SCS_MKDIR                ::mkdir
	#define SCS_RMDIR                ::rmdir

	// File I/O
	#define SCS_CLOSE                ::close
	#define SCS_READ                 ::read
	#define SCS_WRITE                ::write

	#define SCS_OPEN_LARGEFILE       O_LARGEFILE
	#define SCS_OPEN_RDONLY          O_RDONLY
	#define SCS_OPEN_WRONLY          O_WRONLY
	#define SCS_OPEN_RDWR            O_RDWR
	#define SCS_OPEN_CREAT           O_CREAT
	#define SCS_OPEN_TRUNC           O_TRUNC
	#define SCS_OPEN_APPEND          O_APPEND

	// Posix extensions to C89
	#define SCS_FILENO               fileno

	// Directory iteration
	#define SCS_DIR                  DIR

	#define SCS_OPENDIR              ::opendir
	#define SCS_CLOSEDIR             ::closedir
	#define SCS_DIRENT               struct dirent
	#define SCS_READDIR              ::readdir
	#define SCS_READDIR_R            ::readdir_r
	#define SCS_SOCKLEN_T            socklen_t

	#define SCS_SOCKET_CONNECT       ::connect
	#define SCS_SOCKET_BIND          ::bind

	#define SCS_SIGNAL_RETTYPE       void
	#define SCS_SIGNAL_ARGS          int
	#define SCS_SIGNAL_IGNORE        SIG_IGN

	#undef SCS_SOCKLEN_T

	#if defined(__GLIBC__) && (__GLIBC__ < 2)
	#define SCS_SOCKLEN_T            int
	#else
	#define SCS_SOCKLEN_T            socklen_t
	#endif
	#define SCS_SNPRINTF             ::snprintf
	#define SCS_VSNPRINTF            ::vsnprintf
#else
	#include <tchar.h>
	#include <io.h>
	#include <direct.h>
	#include <stdio.h>
	#include <fcntl.h>
	#include <errno.h>
	#include <sys/stat.h>
	#include <stdlib.h>
	#include <limits.h>
	#define SCS_STATBUF				struct _stati64		// non-ANSI defs
	#define SCS_STATBUF4TSTAT		struct _stati64		// non-ANSI defs
	#define SCS_STAT				::_stati64
	#define SCS_FSTAT				::_fstati64
	#define SCS_STAT_REG             _S_IFREG
	#define SCS_STAT_DIR             _S_IFDIR
	#define SCS_STAT_MASK            _S_IFMT
	#if defined(_S_IFLNK)
	#  define SCS_STAT_LNK           _S_IFLNK
	#endif
	#define SCS_FILENO               _fileno
	#define SCS_OPEN                 ::_open
	#define SCS_CLOSE                ::_close
	#define SCS_LSEEK                ::_lseek
	#define SCS_TSTAT                ::_wstati64
	#define SCS_READ                 ::_read
	#define SCS_WRITE                ::_write
	#define SCS_ACCESS               ::_access
	#define SCS_GETCWD               ::_getcwd
	#define SCS_CHDIR                ::_chdir
	#define SCS_MKDIR                ::_mkdir
	#define SCS_RMDIR                ::_rmdir
	#define SCS_OPEN_LARGEFILE       0
	#define SCS_OPEN_RDONLY          _O_RDONLY
	#define SCS_OPEN_WRONLY          _O_WRONLY
	#define SCS_OPEN_RDWR            _O_RDWR
	#define SCS_OPEN_CREAT           _O_CREAT
	#define SCS_OPEN_TRUNC           _O_TRUNC
	#define SCS_OPEN_APPEND          _O_APPEND
	#if defined(O_TEXT)
	# define SCS_OPEN_TEXT           _O_TEXT
	# define SCS_OPEN_BINARY         _O_BINARY
	#endif
	#define SCS_SIGNAL_ARGS          int

	#define SCS_VSNPRINTF            ::_vsnprintf
	#define SCS_SNPRINTF             ::_snprintf

	# define F_OK   0
	# define X_OK   1
	# define W_OK   2
	# define R_OK   4
#endif
#ifdef __cplusplus
	#include <type_traits>
	#include <cstddef>
	#include <utility>
	#include <atomic>
	#include <set>
	#include <string>
	#include <limits>
	#include <algorithm> 
#endif

#endif