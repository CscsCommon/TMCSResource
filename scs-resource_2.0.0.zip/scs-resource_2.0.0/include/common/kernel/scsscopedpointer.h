#ifndef SCSSCOPEDPOINTER_H
#define SCSSCOPEDPOINTER_H

#include <stdlib.h>
#include "scsnocopy.hpp"
#include <algorithm>

BEGIN_NAMESPACE(Gemini)

template <typename T>
struct CscsScopedPointerDeleter
{
    static inline void cleanup(T *pointer)
    {
        // Enforce a complete type.
        // If you get a compile error here, read the section on forward declared
        // classes in the CscsScopedPointer documentation.
        typedef char IsIncompleteType[ sizeof(T) ? 1 : -1 ];
        (void) sizeof(IsIncompleteType);

        delete pointer;
    }
};

template <typename T>
struct CscsScopedPointerArrayDeleter
{
    static inline void cleanup(T *pointer)
    {
        // Enforce a complete type.
        // If you get a compile error here, read the section on forward declared
        // classes in the CscsScopedPointer documentation.
        typedef char IsIncompleteType[ sizeof(T) ? 1 : -1 ];
        (void) sizeof(IsIncompleteType);

        delete [] pointer;
    }
};

struct CscsScopedPointerPodDeleter
{
    static inline void cleanup(void *pointer) { if (pointer) free(pointer); }
};

template <typename T>
struct CscsScopedPointerObjectDeleteLater
{
    static inline void cleanup(T *pointer) { if (pointer) pointer->deleteLater(); }
};

class CscsObject;
typedef CscsScopedPointerObjectDeleteLater<CscsObject> CscsScopedPointerDeleteLater;

template <typename T, typename Cleanup = CscsScopedPointerDeleter<T> >
class CscsScopedPointer:public CscsNoCopyable
{
public:
    explicit inline CscsScopedPointer(T *p = nullptr) : d(p)
    {
    }

    inline ~CscsScopedPointer()
    {
        T *oldD = this->d;
        Cleanup::cleanup(oldD);
    }

    inline T &operator*() const
    {
        assert(d);
        return *d;
    }

    inline T *operator->() const
    {
        assert(d);
        return d;
    }

    inline bool operator!() const
    {
        return !d;
    }
    inline operator bool() const
    {
        return isNull() ? nullptr : &CscsScopedPointer::d;
    }

    inline T *data() const
    {
        return d;
    }

    inline bool isNull() const
    {
        return !d;
    }

    inline void reset(T *other = nullptr)
    {
        if (d == other)
            return;
        T *oldD = d;
        d = other;
        Cleanup::cleanup(oldD);
    }

    inline T *take()
    {
        T *oldD = d;
        d = nullptr;
        return oldD;
    }

    void swap(CscsScopedPointer<T, Cleanup> &other) 
    {
        std::swap(d, other.d);
    }

    typedef T *pointer;

protected:
    T *d;
};

template <class T, class Cleanup>
inline bool operator==(const CscsScopedPointer<T, Cleanup> &lhs, const CscsScopedPointer<T, Cleanup> &rhs)
{
    return lhs.data() == rhs.data();
}

template <class T, class Cleanup>
inline bool operator!=(const CscsScopedPointer<T, Cleanup> &lhs, const CscsScopedPointer<T, Cleanup> &rhs)
{
    return lhs.data() != rhs.data();
}

template <class T, class Cleanup>
inline void swap(CscsScopedPointer<T, Cleanup> &p1, CscsScopedPointer<T, Cleanup> &p2) 
{ p1.swap(p2); }


namespace SCSPrivate {
    template <typename X, typename Y> struct CscsScopedArrayEnsureSameType;
    template <typename X> struct CscsScopedArrayEnsureSameType<X,X> { typedef X* Type; };
    template <typename X> struct CscsScopedArrayEnsureSameType<const X, X> { typedef X* Type; };
}

template <typename T, typename Cleanup = CscsScopedPointerArrayDeleter<T> >
class CscsScopedArrayPointer : public CscsScopedPointer<T, Cleanup>
{
public:
    inline CscsScopedArrayPointer() : CscsScopedPointer<T, Cleanup>(nullptr) {}

    template <typename D>
    explicit inline CscsScopedArrayPointer(D *p, typename SCSPrivate::CscsScopedArrayEnsureSameType<T,D>::Type = nullptr)
        : CscsScopedPointer<T, Cleanup>(p)
    {
    }

    inline T &operator[](int i)
    {
        return this->d[i];
    }

    inline const T &operator[](int i) const
    {
        return this->d[i];
    }

    void swap(CscsScopedArrayPointer &other)  // prevent CscsScopedPointer <->CscsScopedArrayPointer swaps
    { CscsScopedPointer<T, Cleanup>::swap(other); }

private:
    explicit inline CscsScopedArrayPointer(void *) {
        // Enforce the same type.

        // If you get a compile error here, make sure you declare
        // CscsScopedArrayPointer with the same template type as you pass to the
        // constructor. See also the CscsScopedPointer documentation.

        // Storing a scalar array as a pointer to a different type is not
        // allowed and results in undefined behavior.
    }
};

template <typename T, typename Cleanup>
inline void swap(CscsScopedArrayPointer<T, Cleanup> &lhs, CscsScopedArrayPointer<T, Cleanup> &rhs) 
{ lhs.swap(rhs); }

END_NAMESPACE

#endif
