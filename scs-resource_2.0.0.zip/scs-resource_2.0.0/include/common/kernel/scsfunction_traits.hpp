 /*Created by J.Wong 2018/08/07
 version:    version 1.0,
 dependency: base on  or greater than c++11
 function: get function type , return type, params type and count
 gcc4.9+
 */

#ifndef CSCSFUNCTION_TRAITS_H
#define CSCSFUNCTION_TRAITS_H

#include <functional>
#include <tuple>
#include "scsnamespace.h"

// #ifndef size_t
// #define size_t int
// #endif

BEGIN_NAMESPACE(Gemini)

template <typename T>
struct scsfunction_traits;

/*! function traits class 提供类似 boost::function_traits功能，实现函數萃取*/
template<typename Ret, typename... Args>
struct scsfunction_traits<Ret(Args...)>
{
	public:
		enum
		{
			arity=sizeof...(Args)
		};

		typedef Ret function_type(Args...);

		typedef Ret return_type;

		using stl_function_type=std::function<function_type>;

		typedef Ret(*pointer)(Args...);

		template<size_t I>
		struct args{
			static_assert(I<arity,"index is out of range, index must less than sizeof Args");
			using type=typename std::tuple_element<I, std::tuple<Args...> >::type;
		};
		typedef std::tuple<std::remove_cv<std::remove_reference<Args>>...>tuple_type;
		typedef std::tuple<std::remove_const<std::remove_reference<Args>>...>bare_tuple_type;

};

//!special scs_function_traits
template<typename Ret, typename... Args>
struct scsfunction_traits<Ret(*)(Args...)>:scsfunction_traits<Ret(Args...)>{

};

//!special scs_function_traits
template<typename Ret, typename... Args>
struct scsfunction_traits<std::function<Ret(Args...)>>:scsfunction_traits<Ret(Args...)>{

};

/*! \def SCSFUNCTION_TRAITS(...)
*    \brief A macro that returns the maximum of \a ... .
*    Details.
*/
#define SCSFUNCTION_TRAITS(...) \
template <typename ReturnType, typename ClassType, typename... Args> \
struct scsfunction_traits<ReturnType(ClassType::*)(Args...)__VA_ARGS__>:scsfunction_traits<ReturnType(Args...)>{};\


SCSFUNCTION_TRAITS()
SCSFUNCTION_TRAITS(const)
SCSFUNCTION_TRAITS(volatile)
SCSFUNCTION_TRAITS(const volatile)


//!special scs_function_traits
template<typename Callable>
struct scsfunction_traits:scsfunction_traits<decltype(&Callable::operator())>{};

//!lambda表达式萃取为函数
template<typename Function>
typename scsfunction_traits<Function>::stl_function_type to_function(const  Function& lambda){
	return static_cast<typename scsfunction_traits<Function>::stl_function_type>(lambda);
}

//!lambda表达式萃取为函数
template<typename Function>
typename scsfunction_traits<Function>::stl_function_type to_function(Function&& lambda){
	return static_cast<typename scsfunction_traits<Function>::stl_function_type>(std::forward<Function>(lambda));
}

//!lambda表达式萃取为函数指针
template<typename Function>
typename scsfunction_traits<Function>::pointer to_function_pointer(const Function&& lambda){
	return static_cast<typename scsfunction_traits<Function>::pointer>(lambda);
}

END_NAMESPACE

#endif
