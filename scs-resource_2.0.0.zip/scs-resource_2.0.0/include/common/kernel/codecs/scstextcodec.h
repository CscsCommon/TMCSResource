#ifndef SCSTEXTCODEC_H
#define SCSTEXTCODEC_H
#include <kernel/scsbytearray.h>
#include <kernel/scsstring.h>
#include <kernel/scslist.h>
#include <kernel/scsflags.h>
#include <kernel/scschar.h>

BEGIN_NAMESPACE(Gemini)

class CscsTextCodec;
class CscsDevice;

class CscsTextDecoder;
class CscsTextEncoder;

class  CscsTextCodec
{
public:
    static CscsTextCodec* codecForName(const CscsByteArray &name);
    static CscsTextCodec* codecForName(const char *name) { return codecForName(CscsByteArray(name)); }
    static CscsTextCodec* codecForMib(int mib);

    static CscsList<CscsByteArray> availableCodecs();
    static CscsList<int> availableMibs();

    static CscsTextCodec* codecForLocale();
    static void setCodecForLocale(CscsTextCodec *c);

    static CscsTextCodec* codecForTr();
    static void setCodecForTr(CscsTextCodec *c);

    static CscsTextCodec* codecForCStrings();
    static void setCodecForCStrings(CscsTextCodec *c);

    CscsTextDecoder* makeDecoder() const;
    CscsTextEncoder* makeEncoder() const;

    bool canEncode(CscsChar) const;
    bool canEncode(const CscsString&) const;

    CscsString toUnicode(const CscsByteArray&) const;
    CscsString toUnicode(const char* chars) const;
    CscsByteArray fromUnicode(const CscsString& uc) const;
    enum ConversionFlag {
        DefaultConversion,
        ConvertInvalidToNull = 0x80000000,
        IgnoreHeader = 0x1
    };
    SCS_DECLARE_FLAGS(ConversionFlags, ConversionFlag)

    struct ConverterState {
        ConverterState(ConversionFlags f = DefaultConversion)
            : flags(f), remainingChars(0), invalidChars(0), d(0) { state_data[0] = state_data[1] = state_data[2] = 0; }
        ~ConverterState() { if (d) ::free(d); }
        ConversionFlags flags;
        int remainingChars;
        int invalidChars;
        uint state_data[3];
        void *d;
    };

    CscsString toUnicode(const char *in, int length, ConverterState *state = 0) const
        { return convertToUnicode(in, length, state); }
    CscsByteArray fromUnicode(const CscsChar *in, int length, ConverterState *state = 0) const
        { return convertFromUnicode(in, length, state); }

    virtual CscsByteArray name() const = 0;
    virtual CscsList<CscsByteArray> aliases() const;
    virtual int mibEnum() const = 0;

protected:
    virtual CscsString convertToUnicode(const char *in, int length, ConverterState *state) const = 0;
    virtual CscsByteArray convertFromUnicode(const CscsChar *in, int length, ConverterState *state) const = 0;

    CscsTextCodec();
    virtual ~CscsTextCodec();

public:

private:
    friend class CscsTextCodecCleanup;
    static CscsTextCodec *cftr;
};
SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsTextCodec::ConversionFlags)

inline CscsTextCodec* CscsTextCodec::codecForTr() { return cftr; }
inline void CscsTextCodec::setCodecForTr(CscsTextCodec *c) { cftr = c; }
inline CscsTextCodec* CscsTextCodec::codecForCStrings() { return CscsString::codecForCStrings; }
inline void CscsTextCodec::setCodecForCStrings(CscsTextCodec *c) { CscsString::codecForCStrings = c; }

class  CscsTextEncoder {
public:
    explicit CscsTextEncoder(const CscsTextCodec *codec) : c(codec) {}
    ~CscsTextEncoder();
    CscsByteArray fromUnicode(const CscsString& str);
    CscsByteArray fromUnicode(const CscsChar *uc, int len);
private:
    const CscsTextCodec *c;
    CscsTextCodec::ConverterState state;
};

class  CscsTextDecoder {
public:
    explicit CscsTextDecoder(const CscsTextCodec *codec) : c(codec) {}
    ~CscsTextDecoder();
    CscsString toUnicode(const char* chars, int len);
    CscsString toUnicode(const CscsByteArray &ba);
private:
    const CscsTextCodec *c;
    CscsTextCodec::ConverterState state;
};

END_NAMESPACE

#endif