#ifndef SCSTEMPORARYFILE_H
#define SCSTEMPORARYFILE_H
#include "scsfile.h"

BEGIN_NAMESPACE(Gemini)

class CscsTemporaryFilePrivate;
class  CscsTemporaryFile : public CscsFile
{
    CscsTemporaryFilePrivate* d_func()const;
public:
    explicit CscsTemporaryFile(CscsObject *parent=0);
    CscsTemporaryFile(const CscsString &templateName, CscsObject *parent=0);
    ~CscsTemporaryFile();

    bool autoRemove() const;
    void setAutoRemove(bool b);

    // ### Hides open(flags)
    bool open() { return open(CscsDevice::ReadWrite); }

    CscsString fileName() const;
    CscsString fileTemplate() const;
    void setFileTemplate(const CscsString &name);

    inline static CscsTemporaryFile *createLocalFile(const CscsString &fileName)
        { CscsFile file(fileName); return createLocalFile(file); }
    static CscsTemporaryFile *createLocalFile(CscsFile &file);

    virtual CscsFileEngine *fileEngine() const;

protected:
    bool open(SCSOpenMode flags);
};

END_NAMESPACE

#endif