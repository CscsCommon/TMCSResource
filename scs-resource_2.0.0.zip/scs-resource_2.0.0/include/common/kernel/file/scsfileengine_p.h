#ifndef SCSFILEENGINEPRIV_H
#define SCSFILEENGINEPRIV_H

#include "scsfileengine.h"

BEGIN_NAMESPACE(Gemini)

class CscsFileEnginePrivate
{
public:
    CscsFileEnginePrivate() { }
    virtual ~CscsFileEnginePrivate() { }
protected:
    CscsFileEngine *mm_ptr;
    CscsFileEngine* mm_func()const;
    friend class CscsFileEngine;
};

END_NAMESPACE

#endif