#ifndef SCSDIR_H
#define SCSDIR_H

#include <kernel/scsstring.h>
#include <kernel/scsstringlist.h>
#include "scsfileinfo.h"

BEGIN_NAMESPACE(Gemini)

class CscsDirPrivate;

class  CscsDir
{
protected:
    CscsDirPrivate *d_ptr;
public:
    enum Filter { Dirs        = 0x001,
                  Files       = 0x002,
                  Drives      = 0x004,
                  NoSymLinks  = 0x008,
                  TypeMask    = 0x00f,

                  Readable    = 0x010,
                  Writable    = 0x020,
                  Executable  = 0x040,
                  PermissionMask    = 0x070,

                  Modified    = 0x080,
                  Hidden      = 0x100,
                  System      = 0x200,
                  AccessMask  = 0x3F0,

                  AllDirs       = 0x400,
                  CaseSensitive = 0x800,
                  NoDot         = 0x2000,
                  NoDotDot      = 0x4000,
                  NoDotAndDotDot = NoDot | NoDotDot,
                  NoFilter = -1
    };
    SCS_DECLARE_FLAGS(Filters, Filter)

    enum SortFlag { Name        = 0x00,
                    Time        = 0x01,
                    Size        = 0x02,
                    Unsorted    = 0x03,
                    SortByMask  = 0x03,

                    DirsFirst   = 0x04,
                    Reversed    = 0x08,
                    IgnoreCase  = 0x10,
                    DirsLast    = 0x20,
                    Type        = 0x80,
                    NoSort = -1
    };
    SCS_DECLARE_FLAGS(SortFlags, SortFlag)

    CscsDir(const CscsDir &);
    CscsDir(const CscsString &path = CscsString());
    CscsDir(const CscsString &path, const CscsString &nameFilter,
         SortFlags sort = SortFlags(Name | IgnoreCase), Filters filter = TypeMask);
    ~CscsDir();

    CscsDirPrivate* d_func()const{
    	return reinterpret_cast<CscsDirPrivate*>(d_ptr);
    }

    CscsDir &operator=(const CscsDir &);
    CscsDir &operator=(const CscsString &path);

    void setPath(const CscsString &path);
    CscsString path() const;
    CscsString absolutePath() const;
    CscsString canonicalPath() const;

    static void addResourceSearchPath(const CscsString &path);

    CscsString dirName() const;
    CscsString filePath(const CscsString &fileName) const;
    CscsString absoluteFilePath(const CscsString &fileName) const;
    CscsString relativeFilePath(const CscsString &fileName) const;

    static CscsString convertSeparators(const CscsString &pathName);

    bool cd(const CscsString &dirName);
    bool cdUp();

    CscsStringList nameFilters() const;
    void setNameFilters(const CscsStringList &nameFilters);

    Filters filter() const;
    void setFilter(Filters filter);
    SortFlags sorting() const;
    void setSorting(SortFlags sort);

    uint count() const;
    CscsString operator[](int) const;

    static CscsStringList nameFiltersFromString(const CscsString &nameFilter);

    CscsStringList entryList(Filters filters = NoFilter, SortFlags sort = NoSort) const;
    CscsStringList entryList(const CscsStringList &nameFilters, Filters filters = NoFilter,
                          SortFlags sort = NoSort) const;

    CscsFileInfoList entryInfoList(Filters filters = NoFilter, SortFlags sort = NoSort) const;
    CscsFileInfoList entryInfoList(const CscsStringList &nameFilters, Filters filters = NoFilter,
                                SortFlags sort = NoSort) const;

    bool mkdir(const CscsString &dirName) const;
    bool rmdir(const CscsString &dirName) const;
    bool mkpath(const CscsString &dirPath) const;
    bool rmpath(const CscsString &dirPath) const;
    bool isReadable() const;
    bool exists() const;
    bool isRoot() const;

    static bool isRelativePath(const CscsString &path);
    inline static bool isAbsolutePath(const CscsString &path) { return !isRelativePath(path); }
    bool isRelative() const;
    inline bool isAbsolute() const { return !isRelative(); }
    bool makeAbsolute();

    bool operator==(const CscsDir &dir) const;
    inline bool operator!=(const CscsDir &dir) const {  return !operator==(dir); }

    bool remove(const CscsString &fileName);
    bool rename(const CscsString &oldName, const CscsString &newName);
    bool exists(const CscsString &name) const;

    static CscsFileInfoList drives();

    static CscsChar separator();

    static bool setCurrent(const CscsString &path);
    static inline CscsDir current() { return CscsDir(currentPath()); }
    static CscsString currentPath();

    static inline CscsDir home() { return CscsDir(homePath()); }
    static CscsString homePath();
    static inline CscsDir root() { return CscsDir(rootPath()); }
    static CscsString rootPath();
    static inline CscsDir temp() { return CscsDir(tempPath()); }
    static CscsString tempPath();

    static bool match(const CscsStringList &filters, const CscsString &fileName);
    static bool match(const CscsString &filter, const CscsString &fileName);
    static CscsString cleanPath(const CscsString &path);
    void refresh() const;

};

SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsDir::Filters)
SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsDir::SortFlags)

END_NAMESPACE

#endif