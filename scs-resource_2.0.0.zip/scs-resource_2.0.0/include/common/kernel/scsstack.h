#ifndef SCSSTACK_H
#define SCSSTACK_H
#include "scsvector.h"

BEGIN_NAMESPACE(Gemini)

template<class T>
class CscsStack : public CscsVector<T>
{
public:
    inline CscsStack() {}
    inline ~CscsStack() {}
    inline void push(const T &t) { append(t); }
    T pop();
    T &top();
    const T &top() const;
    using CscsVector<T>::append;
};

template<class T>
inline T CscsStack<T>::pop()
{ assert(!this->isEmpty()); T t = this->data()[this->size() -1];
  this->resize(this->size()-1); return t; }

template<class T>
inline T &CscsStack<T>::top()
{ assert(!this->isEmpty()); this->detach(); return this->data()[this->size()-1]; }

template<class T>
inline const T &CscsStack<T>::top() const
{ assert(!this->isEmpty()); return this->data()[this->size()-1]; }

END_NAMESPACE

#endif