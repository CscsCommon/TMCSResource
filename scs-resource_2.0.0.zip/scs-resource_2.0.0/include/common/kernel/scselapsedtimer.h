#ifndef SCSELAPSEDTIMER_H
#define SCSELAPSEDTIMER_H
#include "scstypes.h"

BEGIN_NAMESPACE(Gemini)

class  CscsElapsedTimer
{
public:
    enum ClockType {
        SystemTime,
        MonotonicClock,
        TickCounter,
        MachAbsoluteTime,
        PerformanceCounter
    };

    CscsElapsedTimer()
        : t1(0x8000000000000000LL),
          t2(0x8000000000000000LL)
    {
    }

    static ClockType clockType() ;
    static bool isMonotonic() ;

    void start() ;
    int64 restart() ;
    void invalidate() ;
    bool isValid() const ;

    int64 nsecsElapsed() const ;
    int64 elapsed() const ;
    bool hasExpired(int64 timeout) const ;

    int64 msecsSinceReference() const ;
    int64 msecsTo(const CscsElapsedTimer &other) const ;
    int64 secsTo(const CscsElapsedTimer &other) const ;

    bool operator==(const CscsElapsedTimer &other) const 
    { return t1 == other.t1 && t2 == other.t2; }
    bool operator!=(const CscsElapsedTimer &other) const 
    { return !(*this == other); }

    friend bool  operator<(const CscsElapsedTimer &v1, const CscsElapsedTimer &v2) ;

private:
    int64 t1;
    int64 t2;
};

END_NAMESPACE

#endif