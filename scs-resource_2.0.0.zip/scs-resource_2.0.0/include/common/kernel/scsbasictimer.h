#ifndef SCSBASICTIMER_H
#define SCSBASICTIMER_H

#include "scsnamespace.h"
#include "scstypes.h"

BEGIN_NAMESPACE(Gemini)

class CscsObject;

class  CscsBasicTimer
{
    int id;
public:
    explicit CscsBasicTimer() : id(0) {}
    ~CscsBasicTimer() { if (id) stop(); }

    inline bool isActive() const { return id != 0; }
    inline int timerId() const { return id; }

    void start(int msec, CscsObject *obj);
    void stop();
};
SCS_DECLARE_TYPENAME_INFO(CscsBasicTimer,SCS_MOVABLE_TYPE);

END_NAMESPACE

#endif
