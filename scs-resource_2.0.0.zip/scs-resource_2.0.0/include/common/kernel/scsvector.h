#ifndef SCSVECTOR_H
#define SCSVECTOR_H
#include <cstddef>
#include <iterator>
#include <vector>
#include <algorithm>
#include <atomic>
#include "scstypes.h"
#include "scsutils.h"
#include "scslist.h"
#include <assert.h>
#include <type_traits>

BEGIN_NAMESPACE(Gemini)

struct  CscsVectorData
{
    std::atomic<int> ref;
    int alloc;
    int size;
    uint sharable : 1;

    static CscsVectorData shared_null;
    static CscsVectorData *malloc(int sizeofTypedData, int size, int sizeofT, CscsVectorData *init);
    static int grow(int sizeofTypedData, int size, int sizeofT, bool excessive);
};

template <typename T>
struct CscsVectorTypedData
{
    std::atomic<int> ref;
    int alloc;
    int size;
    uint sharable : 1;
    T array[1];
};


template <typename T>
class CscsVector
{
    typedef CscsVectorTypedData<T> Data;
    union { CscsVectorData *p; CscsVectorTypedData<T> *d; };

public:
    inline CscsVector() : p(&CscsVectorData::shared_null) { d->ref++; }
    explicit CscsVector(int size);
    CscsVector(int size, const T &t);
    inline CscsVector(const CscsVector &v) : d(v.d) { d->ref++; if (!d->sharable) detach_helper(); }
    inline ~CscsVector() { if (!d) return; if (!--d->ref) free(d); }
    CscsVector &operator=(const CscsVector &v);
    bool operator==(const CscsVector &v) const;
    inline bool operator!=(const CscsVector &v) const { return !(*this == v); }
    void swap(CscsVector<T> &other) { std::swap(d, other.d);}

    inline int size() const { return d->size; }

    inline bool isEmpty() const { return d->size == 0; }

    void resize(int size);

    inline int capacity() const { return d->alloc; }
    void reserve(int size);
    inline void squeeze() { realloc(d->size, d->size); }

    inline void detach() { if (d->ref != 1) detach_helper(); }
    inline bool isDetached() const { return d->ref == 1; }
    inline void setSharable(bool sharable) { if (!sharable) detach(); d->sharable = sharable; }

    inline T *data() { detach(); return d->array; }
    inline const T *data() const { return d->array; }
    inline const T *constData() const { return d->array; }
    void clear();

    const T &at(int i) const;
    T &operator[](int i);
    const T &operator[](int i) const;
    void append(const T &t);
    void prepend(const T &t);
    void insert(int i, const T &t);
    void insert(int i, int n, const T &t);
    void replace(int i, const T &t);
    void remove(int i);
    void remove(int i, int n);

    CscsVector &fill(const T &t, int size = -1);

    int indexOf(const T &t, int from = 0) const;
    int lastIndexOf(const T &t, int from = -1) const;
    bool contains(const T &t) const;
    int count(const T &t) const;

    // STL-style
    typedef T* iterator;
    typedef const T* const_iterator;
    inline iterator begin() { detach(); return d->array; }
    inline const_iterator begin() const { return d->array; }
    inline const_iterator constBegin() const { return d->array; }
    inline iterator end() { detach(); return d->array + d->size; }
    inline const_iterator end() const { return d->array + d->size; }
    inline const_iterator constEnd() const { return d->array + d->size; }
    iterator insert(iterator before, int n, const T &x);
    inline iterator insert(iterator before, const T &x) { return insert(before, 1, x); }
    iterator erase(iterator begin, iterator end);
    inline iterator erase(iterator pos) { return erase(pos, pos+1); }

    // more SCS
    inline int count() const { return d->size; }
    inline T& first() { if(isEmpty()) assert(false); return *begin(); }
    inline const T &first() const { if(isEmpty()) assert(false); return *begin(); }
    inline T& last() {if(isEmpty()) assert(false); return *(end()-1); }
    inline const T &last() const { if(isEmpty()) assert(false); return *(end()-1); }
    CscsVector<T> mid(int pos, int length = -1) const;

    T value(int i) const;
    T value(int i, const T &defaultValue) const;

    // STL compatibility
    typedef T value_type;
    typedef value_type* pointer;
    typedef const value_type* const_pointer;
    typedef value_type& reference;
    typedef const value_type& const_reference;
    typedef ptrdiff_t difference_type;

    typedef iterator Iterator;
    typedef const_iterator ConstIterator;
    typedef int size_type;
    inline void push_back(const T &t) { append(t); }
    inline void push_front(const T &t) { prepend(t); }
    void pop_back() { if(isEmpty()) assert(false); erase(end()-1); }
    void pop_front() { if(isEmpty()) assert(false); erase(begin()); }
    inline bool empty() const
    { return d->size == 0; }
    inline T& front() { return first(); }
    inline const_reference front() const { return first(); }
    inline reference back() { return last(); }
    inline const_reference back() const { return last(); }

    // comfort
    CscsVector &operator+=(const CscsVector &l);
    inline CscsVector operator+(const CscsVector &l) const
    { CscsVector n = *this; n += l; return n; }
    inline CscsVector &operator+=(const T &t)
    { append(t); return *this; }
    inline CscsVector &operator<< (const T &t)
    { append(t); return *this; }
    inline CscsVector &operator<<(const CscsVector &l)
    { *this += l; return *this; }

    CscsList<T> toList() const;

    static CscsVector<T> fromList(const CscsList<T> &list);

    static inline CscsVector<T> fromStdVector(const std::vector<T> &vector)
    { CscsVector<T> tmp; std::copy(vector.begin(), vector.end(), std::back_inserter(tmp)); return tmp; }
    inline std::vector<T> toStdVector() const
    { std::vector<T> tmp; std::copy(constBegin(), constEnd(), std::back_inserter(tmp)); return tmp; }

private:
    void detach_helper();
    CscsVectorData *malloc(int alloc);
    void realloc(int size, int alloc);
    void free(Data *d);
};

template <typename T>
void CscsVector<T>::detach_helper()
{ realloc(d->size, d->alloc); }
template <typename T>
void CscsVector<T>::reserve(int asize)
{ if (asize > d->alloc) realloc(d->size, asize); }
template <typename T>
void CscsVector<T>::resize(int asize)
{ realloc(asize, (asize > d->alloc || (asize < d->size && asize < (d->alloc >> 1))) ?
          size_t(CscsVectorData::grow(sizeof(Data), asize, sizeof(T), CscsTypeNameInfo<T>::isStatic))
          : size_t(d->alloc)); }
template <typename T>
inline void CscsVector<T>::clear()
{ *this = CscsVector<T>(); }
template <typename T>
inline const T &CscsVector<T>::at(int i) const
{ 
  if(i<0||i>=d->size){
  	printf("CscsVector<T>::at index out of range\n");
  	assert(false);
  }
  return d->array[i];
}
template <typename T>
inline const T &CscsVector<T>::operator[](int i) const
{ 
    if(i<0||i>=d->size){
  	printf("CscsVector<T>::operator[] index out of range\n");
  	assert(false);
  }
  return d->array[i]; 
}
template <typename T>
inline T &CscsVector<T>::operator[](int i)
{ 
	if(i<0||i>=d->size){
  	printf("CscsVector<T>::operator[] index out of range\n");
  	assert(false);
  }
  return data()[i];
}
template <typename T>
inline void CscsVector<T>::insert(int i, const T &t)
{ 
  if(i<0||i>d->size){
  	printf("CscsVector<T>::insert index out of range\n");
  	assert(false);
  }
  insert(begin() + i, 1, t);
}
template <typename T>
inline void CscsVector<T>::insert(int i, int n, const T &t)
{  
  if(i<0||i>d->size){
  	printf("CscsVector<T>::insert index out of range\n");
  	assert(false);
  }
  insert(begin() + i, n, t);
}
template <typename T>
inline void CscsVector<T>::remove(int i, int n)
{ 
  if(i<0||(i+n)>d->size||n<0){
  	printf("CscsVector<T>::remove index out of range\n");
  	assert(false);
  }
  erase(begin() + i, begin() + i + n);
}
template <typename T>
inline void CscsVector<T>::remove(int i)
{ 
  if(i<0||i>=d->size){
  	printf("CscsVector<T>::remove index out of range\n");
  	assert(false);
  }
  erase(begin() + i, begin() + i + 1); }
template <typename T>
inline void CscsVector<T>::prepend(const T &t)
{ insert(begin(), 1, t); }

template <typename T>
inline void CscsVector<T>::replace(int i, const T &t)
{
   if(i<0||i>=d->size){
  	printf("CscsVector<T>::replace index out of range\n");
  	assert(false);
   }
    const T copy(t);
    data()[i] = copy;
}

template <typename T>
CscsVector<T> &CscsVector<T>::operator=(const CscsVector<T> &v)
{
    typename CscsVector::Data *x = v.d;
    x->ref++;
    {
    	typename CscsVector::Data* tmp=x;
    	x=d;
    	d=tmp;
    }
    if (!--x->ref)
        free(x);
    if (!d->sharable)
        detach_helper();
    return *this;
}

template <typename T>
inline CscsVectorData *CscsVector<T>::malloc(int aalloc)
{
    return static_cast<CscsVectorData *>(::malloc(sizeof(Data) + (aalloc - 1) * sizeof(T)));
}

template <typename T>
CscsVector<T>::CscsVector(int asize)
{
    p = malloc(asize);
    d->ref=1;
    d->alloc = d->size = asize;
    d->sharable = true;
    if (CscsTypeNameInfo<T>::isComplex) {
        T* b = d->array;
        T* i = d->array + d->size;
        while (i != b)
            new (--i) T;
    } else {
        ::memset(d->array, 0, asize * sizeof(T));
    }
}

template <typename T>
CscsVector<T>::CscsVector(int asize, const T &t)
{
    p = malloc(asize);
    d->ref=1;
    d->alloc = d->size = asize;
    d->sharable = true;
    T* i = d->array + d->size;
    while (i != d->array)
        new (--i) T(t);
}

template <typename T>
void CscsVector<T>::free(Data *x)
{
    if (CscsTypeNameInfo<T>::isComplex){
        T* b = x->array;
        T* i = b + x->size;
        while (i-- != b)
             i->~T();
    }
    ::free(x);
}

template <typename T>
void CscsVector<T>::realloc(int asize, int aalloc)
{
    T *j, *i, *b;
    union { CscsVectorData *p; Data *d; } x;
    x.d = d;

    if ((CscsTypeNameInfo<T>::isComplex) && aalloc == d->alloc && d->ref == 1) {
        // pure resize
        i = d->array + d->size;
        j = d->array + asize;
        if (i > j) {
            while (i-- != j)
                i->~T();
        } else {
            while (j-- != i)
                new (j) T;
        }
        d->size = asize;
        return;
    }

    if (aalloc != d->alloc || d->ref != 1) {
        // (re)allocate memory
        if (CscsTypeNameInfo<T>::isStatic) {
            x.p = malloc(aalloc);
        } else if (d->ref != 1) {
            x.p = CscsVectorData::malloc(sizeof(Data), aalloc, sizeof(T), p);
        } else {
            if (CscsTypeNameInfo<T>::isComplex) {
                // call the destructor on all objects that need to be
                // destroyed when shrinking
                if (asize < d->size) {
                    j = d->array + asize;
                    i = d->array + d->size;
                    while (i-- != j)
                        i->~T();
                    i = d->array + asize;
                }
            }
            x.p = p =
                  static_cast<CscsVectorData *>(::realloc(p, sizeof(Data) + (aalloc - 1) * sizeof(T)));
        }
        x.d->ref=1;
        x.d->sharable = true;
    }
    if (CscsTypeNameInfo<T>::isComplex) {
        if (asize < d->size) {
            j = d->array + asize;
            i = x.d->array + asize;
        } else {
            // construct all new objects when growing
            i = x.d->array + asize;
            j = x.d->array + d->size;
            while (i != j)
                new (--i) T;
            j = d->array + d->size;
        }
        if (i != j) {
            // copy objects from the old array into the new array
            b = x.d->array;
            while (i != b)
                new (--i) T(*--j);
        }
    } else if (asize > d->size) {
        // initialize newly allocated memory to 0
        ::memset(x.d->array + d->size, 0, (asize - d->size) * sizeof(T));
    }
    x.d->size = asize;
    x.d->alloc = aalloc;
    if (d != x.d) {
        {
        	typename CscsVector::Data *tmp=x.d;
        	x.d=d;
        	d=tmp;
        }
        if (!--x.d->ref)
            free(x.d);
    }
}

template<typename T>
 T CscsVector<T>::value(int i) const
{
    if (i < 0 || i >= p->size) {
        return T();
    }
    return d->array[i];
}
template<typename T>
 T CscsVector<T>::value(int i, const T &defaultValue) const
{
    return ((i < 0 || i >= p->size) ? defaultValue : d->array[i]);
}

template <typename T>
void CscsVector<T>::append(const T &t)
{
    const T copy(t);
    if (d->ref != 1 || d->size + 1 > d->alloc)
        realloc(d->size, CscsVectorData::grow(sizeof(Data), d->size + 1, sizeof(T),
                                           CscsTypeNameInfo<T>::isStatic));
    if (CscsTypeNameInfo<T>::isComplex)
        new (d->array + d->size) T(copy);
    else
        d->array[d->size] = copy;
    ++d->size;
}


template <typename T>
typename CscsVector<T>::iterator CscsVector<T>::insert(iterator before, size_type n, const T &t)
{
    int offset = before - d->array;
    if (n != 0) {
        const T copy(t);
        if (d->ref != 1 || d->size + n > d->alloc)
            realloc(d->size, CscsVectorData::grow(sizeof(Data), d->size + n, sizeof(T),
                                               CscsTypeNameInfo<T>::isStatic));
        if (CscsTypeNameInfo<T>::isStatic) {
            T *b = d->array + d->size;
            T *i = d->array + d->size + n;
            while (i != b)
                new (--i) T;
            i = d->array + d->size;
            T *j = i + n;
            b = d->array + offset;
            while (i != b)
                *--j = *--i;
            i = b+n;
            while (i != b)
                *--i = copy;
        } else {
            T *b = d->array + offset;
            T *i = b + n;
            ::memmove(i, b, (d->size - offset) * sizeof(T));
            while (i != b)
                new (--i) T(copy);
        }
        d->size += n;
    }
    return d->array + offset;
}

template <typename T>
typename CscsVector<T>::iterator CscsVector<T>::erase(iterator abegin, iterator aend)
{
    int f = abegin - d->array;
    int l = aend - d->array;
    int n = l - f;
    detach();
    if (CscsTypeNameInfo<T>::isComplex) {
        std::copy(d->array+l, d->array+d->size, d->array+f);
        T *i = d->array+d->size;
        T* b = d->array+d->size-n;
        while (i != b) {
            --i;
            i->~T();
        }
    } else {
        ::memmove(d->array + f, d->array + l, (d->size-l)*sizeof(T));
    }
    d->size -= n;
    return d->array + f;
}

template <typename T>
bool CscsVector<T>::operator==(const CscsVector<T> &v) const
{
    if (d->size != v.d->size)
        return false;
    if (d == v.d)
        return true;
    T* b = d->array;
    T* i = b + d->size;
    T* j = v.d->array + d->size;
    while (i != b)
        if (!(*--i == *--j))
            return false;
    return true;
}

template <typename T>
CscsVector<T> &CscsVector<T>::fill(const T &from, int asize)
{
    const T copy(from);
    resize(asize < 0 ? d->size : asize);
    if (d->size) {
        T *i = d->array + d->size;
        T *b = d->array;
        while (i != b)
            *--i = copy;
    }
    return *this;
}

template <typename T>
CscsVector<T> &CscsVector<T>::operator+=(const CscsVector &l)
{
    int newSize = d->size + l.d->size;
    realloc(d->size, newSize);

    T *w = d->array + newSize;
    T *i = l.d->array + l.d->size;
    T *b = l.d->array;
    while (i != b) {
        if (CscsTypeNameInfo<T>::isComplex)
            new (--w) T(*--i);
        else
            *--w = *--i;
    }
    d->size = newSize;
    return *this;
}

template <typename T>
int CscsVector<T>::indexOf(const T &t, int from) const
{
    if (from < 0)
        from = std::max(from + d->size, 0);
    if (from < d->size) {
        T* n = d->array + from - 1;
        T* e = d->array + d->size;
        while (++n != e)
            if (*n == t)
                return n - d->array;
    }
    return -1;
}

template <typename T>
int CscsVector<T>::lastIndexOf(const T &t, int from) const
{
    if (from < 0)
        from += d->size;
    else if (from >= d->size)
        from = d->size-1;
    if (from >= 0) {
        T* b = d->array;
        T* n = d->array + from + 1;
        while (n != b) {
            if (*--n == t)
                return n - b;
        }
    }
    return -1;
}

template <typename T>
bool CscsVector<T>::contains(const T &t) const
{
    T* b = d->array;
    T* i = d->array + d->size;
    while (i != b)
        if (*--i == t)
            return true;
    return false;
}

template <typename T>
int CscsVector<T>::count(const T &t) const
{
    int c = 0;
    T* b = d->array;
    T* i = d->array + d->size;
    while (i != b)
        if (*--i == t)
            ++c;
    return c;
}

template <typename T>
CscsVector<T> CscsVector<T>::mid(int pos, int length) const
{
    if (length < 0)
        length = size() - pos;
    if (pos == 0 && length == size())
        return *this;
    CscsVector<T> copy;
    if (pos + length > size())
        length = size() - pos;
    for (int i = pos; i < pos + length; ++i)
        copy += at(i);
    return copy;
}

template <typename T>
CscsList<T> CscsVector<T>::toList() const
{
    CscsList<T> result;
    for (int i = 0; i < size(); ++i)
        result.append(at(i));
    return result;
}

template <typename T>
CscsVector<T> CscsList<T>::toVector() const
{
    CscsVector<T> result(size());
    for (int i = 0; i < size(); ++i)
        result[i] = at(i);
    return result;
}

template <typename T>
CscsVector<T> CscsVector<T>::fromList(const CscsList<T> &list)
{
    return list.toVector();
}

template <typename T>
CscsList<T> CscsList<T>::fromVector(const CscsVector<T> &vector)
{
    return vector.toList();
}
SCS_DECLARE_SEQUENTIAL_ITERATOR(Vector)
SCS_DECLARE_MUTABLE_SEQUENTIAL_ITERATOR(Vector)

END_NAMESPACE

#endif