#ifndef SCSFLAGS_H
#define SCSFLAGS_H

 /*Created by J.Wong 2018/08/11
 version:    version 1.0,
 dependency: base on  or greater than c++11
 function: type erase
 gcc4.9+
 */
 
#include "scstypes.h"

BEGIN_NAMESPACE(Gemini)
 
class CscsFlag{
public:
	inline CscsFlag(int i);
	inline operator int(){return i;}
private:
	int i;
};

inline CscsFlag::CscsFlag(int ai):i(ai){

}

/*! \class CscsFlags scsflags.h "kernel/scsflags.h"
 *  \brief 		枚举值操作类.
 * 	\brief		CscsFlags类：实现枚举值操作运算.
 * 	\author 	J.Wong
 *	\date  		2018/08/11
 * 	\version 	1.0
 * 	
 */

template <typename Enum>
class CscsFlags{
	typedef void** Zero;
public:
	/*! 枚举模板类型别名 */ 
	typedef Enum enum_type;
	/*! 拷贝构造CscsFlags*/
	inline CscsFlags(const CscsFlags& f):i(f.i){}
	/*! 构造CscsFlags 传入Enum \a flag*/
	inline CscsFlags(Enum f):i(f){}
	/*! 构造CscsFlags 传入Zero \a zero*/
	inline CscsFlags(Zero zero=0):i(0){}
	/*! 构造CscsFlags 传入CscsFlag \a f \n
	 * 	CscsFlag是一个帮助类,统一化处理任意枚举类型转换为CscsFlag处理
	*/
	inline CscsFlags(CscsFlag f):i(f){}
	/*! 赋值操作*/
	inline CscsFlags& operator=(const CscsFlags& f){
		i=f.i;
		return *this;
	}
	/*! 和 \a mask 进行与操作,将保存结果该对象中,并返回该对象引用*/
	inline CscsFlags& operator&=(int mask){
		i&=mask;
		return *this;
	}
	/*! 重载操作 \a mask*/
	inline CscsFlags& operator&=(uint mask){
		i&=mask;
		return *this;
	}
	/*! 和 \a f 进行或操作,将保存结果该对象中,并返回该对象引用*/
	inline CscsFlags& operator|=(CscsFlags f){
		i|=f.i;
		return *this;
	}
	/*! 重载操作 \a f*/
	inline CscsFlags& operator|=(Enum f){
		i|=f;
		return *this;
	}
	
	/*! 和 \a f 进行异或操作,将保存结果该对象中,并返回该对象引用*/
	inline CscsFlags& operator^=(CscsFlags f){
		i^=f.i;
		return *this;
	}
	
	/*! 重载操作 \a f*/
	inline CscsFlags& operator^=(Enum f){
		i^=f;
		return *this;
	}

	inline operator int()const{return i;}
	
	/*! 返回一个和 \a f 进行或操作后的对象
	 * \sa operator^=(), operator&(), operator~().
	*/
	inline CscsFlags operator|(CscsFlags f)const{
		CscsFlags g;
		g.i=i|f.i;
		return g;
	}
	
	/*! 重载操作 \a f*/
	inline CscsFlags operator|(Enum f)const{
		CscsFlags g;
		g.i=i|f;
		return g;
	}
	
	/*! 返回一个和 \a f 进行异或操作后的对象
	 * \sa operator^=(),operator|=(), operator&(), operator~().
	*/
	inline CscsFlags operator^(CscsFlags f) const{
		CscsFlags g;
		g.i = i ^ f.i;
		return g;
	}
	/*! 重载操作 \a f*/
    inline CscsFlags operator^(Enum f) const{
     	CscsFlags g;
     	g.i = i ^ f;
      	return g;
    }
	/*! 返回一个和 \a mask 进行与操作后的对象
	 * \sa operator&=(),operator|(), operator^(), operator~().
	*/
    inline CscsFlags operator&(int mask) const{
     	CscsFlags g;
     	g.i = i & mask;
     	return g; 
 	}
	/*! 重载操作 \a mask*/
    inline CscsFlags operator&(uint mask) const {
    	CscsFlags g;
    	g.i = i & mask;
     	return g;
    }
    /*! 重载操作 \a f*/
    inline CscsFlags operator&(Enum f) const{
     	CscsFlags g;
      	g.i = i & f;
       	return g;
    }
	/*! 返回一个进行取反操作后的对象
	 * \sa operator&(),operator|(), operator^().
	*/
    inline CscsFlags operator~() const {
    	CscsFlags g;
    	g.i = ~i;
    	return g;
    }
	/*! 返回一个进行非操作后的对象
	 * \sa operator&(),operator|(), operator^()，operator~().
	*/
    inline bool operator!() const {
     return !i;
    }

    inline bool testFlag(Enum f) const  { return (i & int(f)) == int(f) && (int(f) != 0 || i == int(f) ); }


private:

	int i;
};

/*! \file scsflags.h
 * 
 */
 
/*! \def SCS_DECLARE_FLAGS(Flags,Enum)
    \brief 为枚举类型定义Flags类型别名 \a Flags \a Enum.  
*/
#define SCS_DECLARE_FLAGS(Flags, Enum)\
typedef CscsFlags<Enum> Flags;

/*! \def SCS_DECLARE_OPERATORS_FOR_FLAGS(Flags)
    \brief 实现Flags类型 Operator|操作 \a Flags.  
*/

#define SCS_DECLARE_OPERATORS_FOR_FLAGS(Flags) \
inline CscsFlags<Flags::enum_type> operator|(Flags::enum_type f1, Flags::enum_type f2) \
{ return CscsFlags<Flags::enum_type>(f1) | f2; } \
inline CscsFlags<Flags::enum_type> operator|(Flags::enum_type f1, CscsFlags<Flags::enum_type> f2) \
{ return f2 | f1; }

END_NAMESPACE

#endif