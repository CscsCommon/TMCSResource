#ifndef SCSSTRING_H
#define SCSSTRING_H
#include <kernel/scsbytearray.h>
#include <kernel/scsutils.h>
#include <kernel/scstypes.h>
#include <kernel/scsflags.h>
#include "scschar.h"
#include <atomic>
#include <stdarg.h>

 /*Created by J.Wong 2019/01/06
 version:    version 1.0,
 dependency: base on  or greater than c++11
 function: type erase
 gcc4.9+
 */
BEGIN_NAMESPACE(Gemini)

class CscsCharRef;
class CscsStringList;
class CscsLatin1String;
class CscsRegExp;

class CscsTextCodec;

/*! \class CscsString scsstring.h "kernel/scsstring.h"
 *  \brief 		字符串操作类.
 * 	\brief		CscsString类：提供UniCode编码字符串操作. \n
 *	CscsString类型存储的是一串16bit的 \link CscsChar \endlink 集，一个 \link CscsChar \endlink 代表一个Unicode字符
 * 	\author 	J.Wong
 *	\date  		2019/01/06
 * 	\version 	1.0
 * 	
 */
 
class  CscsString
{
public:
	/*! \enum CaseSensitivity
	 * 指定CscsString类型大小写是否敏感
	 */
    enum CaseSensitivity{
        CaseInsensitive, /*!< 0  大小写不敏感	*/
        CaseSensitive	/*!<  1   大小写敏感	*/
    };
	
	/*! 构造一个空字串
	 * \sa isEmpty()
	 */
    inline CscsString();
	
	/*! 构造字符串, 初始化参数为 \link CscsChar \endlink 数组,size表示传入数组的大小 \n
	 *  size为负时或者unicode=0 构造一个空字串
	 *
	 */
    CscsString(const CscsChar *unicode, int size=-1);
	
	/*! 构造一个包含字符的字串*/
    explicit CscsString(CscsChar c);
	
	/*! 构造一个size大小的字符串，并把所有字符初始化为c */
    CscsString(int size, CscsChar c);
	
	/*! 通过拷贝一个Latin-1 latin1字符串构造字符串*/
    inline CscsString(const CscsLatin1String &latin1);
	
	/*! 拷贝构造字符串*/
    inline CscsString(const CscsString &);
	
	/*! 字串析构操作*/
    inline ~CscsString();
	
	/*!赋值一个字符给该字串，重载操作符*/
    CscsString &operator=(CscsChar c);
	
	/*!赋值一个字串给该字串，重载操作符*/
    CscsString &operator=(const CscsString &);
	
	/*!赋值Latin-1字串给该字串，重载操作符*/
    inline CscsString &operator=(const CscsLatin1String &);
	
	/*! 返回字串字符个数 size()获取到的字符串不计入尾部填充的'\0' \n
	 *	\sa \link isEmpty() \endlink , \link resize() \endlink .
	 */
    inline int size() const { return d->size; }
	
	/*! Same as \link size() \endlink */
    inline int count() const { return d->size; }
	
	/*! Same as \link size() \endlink */
    inline int length() const;
	
	/*! 空字符串返回true,反之返回false 
	 * \sa size().
	 */
    inline bool isEmpty() const;
	
	/*! 修改字符串大小,如果原先的字符串长度比设置值大则截断，反之则填充 \n
	 *  example: \n
	 *   		CscsString s = "Hello world"; \n
	 *			s.resize(5);	\n
	 *			// s == "Hello"	\n
	 *							\n
	 *			s.resize(8);	\n
	 *			// s == "Hello???" (where ? stands for any character) \n
	 */
    void resize(int size);
	
	/*! 使用字符c对字串进行填充,如果size不为-1，则将字串resize为size大小进行填充 \n
	 *	example: \n
	 *	CscsString str="Hello"; \n
	 *	str.fill('z'); \n
	 *	//str=="zzzzz" \n
	 *	str.fill('A',2); \n
	 *	//str=="AA" \n
	 */
    CscsString &fill(CscsChar c, int size = -1);
	
	/*! 截断字串到给定的索引位置 \n
	 *	如果给定的索引在字串的结尾，则不会发生任何操作
	 *	\sa \link chop() \endlink , \link resize() \endlink , \link left() \endlink .
	 */
    void truncate(int pos);
	
	/*! 从字串结尾处开始移除指定个数 \a n 字符 \n 
	 *	如果 \a n >= \link size() \endlink ,则结果变为一个空字符串，如果n<0，不会发生任何操作 \n
	 * \sa \link truncate() \endlink , \link resize() \endlink , \link remove() \endlink .
	 */
    void chop(int n);
	
	/*!	返回最大可存储字符个数，在不需要重新分配内存的情况下
	 * \sa \link reserve() \endlink , \link squeeze() \endlink .
	 */
    int capacity() const;
	
	/*!	分配至少可容纳size大小字符的内存
	 * 	\sa \link squeeze() \endlink , \link capacity() \endlink .
	 */
    inline void reserve(int size);

	/*!	释放掉多余的内存，可容纳size大小字串 
	 *	\sa \link capacity() \endlink , \link reserve() \endlink .
	 */
    inline void squeeze() { if (d->size < d->alloc) realloc(); }

	/*! 返回'\0'结尾的字符指针 */
    inline const CscsChar *unicode() const;
	
	/*! Same as \link unicode() \endlink .*/
    inline CscsChar *data();
	
	/*! 重载函数*/
    inline const CscsChar *data() const;
	
	/*! 重载函数*/
    inline const CscsChar *constData() const;

    inline void detach();
    inline bool isDetached() const;
	
	/*! 清除字串，返回空字串*/
    void clear();
	
	/*! 返回位置i处字符*/
    inline const CscsChar at(int i) const;
	
	/*! 操作符重载
	 * \sa \link at() \endlink .
	 */
    const CscsChar operator[](int i) const;
	
	/*! 操作符重载
	 * \sa \link at() \endlink .
	 */
    CscsCharRef operator[](int i);
    
	/*! 操作符重载
	 * \sa \link at() \endlink .
	*/
	const CscsChar operator[](uint i) const;
	
	/*! 操作符重载
	 * \sa \link at() \endlink .
	 */
    CscsCharRef operator[](uint i);

	/*! */
    CscsString arg(int64 a, int fieldwidth=0, int base=10, const CscsChar &fillChar = CscsLatin1Char(' ')) const;
    CscsString arg(uint64 a, int fieldwidth=0, int base=10, const CscsChar &fillChar = CscsLatin1Char(' ')) const;
    CscsString arg(long a, int fieldwidth=0, int base=10, const CscsChar &fillChar = CscsLatin1Char(' ')) const;
    CscsString arg(ulong a, int fieldwidth=0, int base=10, const CscsChar &fillChar = CscsLatin1Char(' ')) const;
    CscsString arg(int a, int fieldWidth = 0, int base = 10, const CscsChar &fillChar = CscsLatin1Char(' ')) const;
    CscsString arg(uint a, int fieldWidth = 0, int base = 10, const CscsChar &fillChar = CscsLatin1Char(' ')) const;
    CscsString arg(int16 a, int fieldWidth = 0, int base = 10, const CscsChar &fillChar = CscsLatin1Char(' ')) const;
    CscsString arg(uint16 a, int fieldWidth = 0, int base = 10, const CscsChar &fillChar = CscsLatin1Char(' ')) const;
    CscsString arg(double a, int fieldWidth = 0, char fmt = 'g', int prec = -1, const CscsChar &fillChar = CscsLatin1Char(' ')) const;
    CscsString arg(char a, int fieldWidth = 0, const CscsChar &fillChar = CscsLatin1Char(' ')) const;
    CscsString arg(CscsChar a, int fieldWidth = 0, const CscsChar &fillChar = CscsLatin1Char(' ')) const;
    CscsString arg(const CscsString &a, int fieldWidth = 0, const CscsChar &fillChar = CscsLatin1Char(' ')) const;
    CscsString arg(const CscsString &a1, const CscsString &a2) const;
    CscsString arg(const CscsString &a1, const CscsString &a2, const CscsString &a3) const;
    CscsString arg(const CscsString &a1, const CscsString &a2, const CscsString &a3, const CscsString &a4) const;

    CscsString    &vsprintf(const char *format, va_list ap);
    CscsString    &sprintf(const char *format, ...);

    int indexOf(CscsChar c, int from = 0, CscsString::CaseSensitivity cs = CscsString::CaseSensitive) const;
    int indexOf(const CscsString &s, int from = 0, CscsString::CaseSensitivity cs = CscsString::CaseSensitive) const;
    int lastIndexOf(CscsChar c, int from = -1, CscsString::CaseSensitivity cs = CscsString::CaseSensitive) const;
    int lastIndexOf(const CscsString &s, int from = -1, CscsString::CaseSensitivity cs = CscsString::CaseSensitive) const;


    int indexOf(const CscsRegExp &, int from = 0) const;
    int lastIndexOf(const CscsRegExp &, int from = -1) const;
    inline bool contains(const CscsRegExp &rx) const { return bool(indexOf(rx) != -1); }
    int count(const CscsRegExp &) const;

    inline bool contains(CscsChar c, CscsString::CaseSensitivity cs = CscsString::CaseSensitive) const;
    inline bool contains(const CscsString &s, CscsString::CaseSensitivity cs = CscsString::CaseSensitive) const;
    int count(CscsChar c, CscsString::CaseSensitivity cs = CscsString::CaseSensitive) const;
    int count(const CscsString &s, CscsString::CaseSensitivity cs = CscsString::CaseSensitive) const;
	
	/*! \enum SectionFlag
	 *  section操作枚举值
	 */
    enum SectionFlag {
        SectionDefault             = 0x00, /*!< 0x00  使用空字符作为分隔符	*/
        SectionSkipEmpty           = 0x01, /*!< 0x01  忽略字串开始和结尾部分的空字符串分隔符*/
        SectionIncludeLeadingSep   = 0x02, /*!< 0x02  字符串结果集中，分隔符作为前导*/
        SectionIncludeTrailingSep  = 0x04, /*!< 0x04  字符串结果集中，分隔符作为尾部*/
        SectionCaseInsensitiveSeps = 0x08  /*!< 0x08  分隔符大小写敏感*/
    };
    SCS_DECLARE_FLAGS(SectionFlags, SectionFlag)

    CscsString section(CscsChar sep, int start, int end = -1, SectionFlags flags = SectionDefault) const;
    CscsString section(const CscsString &in_sep, int start, int end = -1, SectionFlags flags = SectionDefault) const;
    CscsString section(const CscsRegExp &reg, int start, int end = -1, SectionFlags flags = SectionDefault) const;
    CscsString left(int len) const;
    CscsString right(int len) const;
    CscsString mid(int i, int len = -1) const;

    bool startsWith(const CscsString &s, CscsString::CaseSensitivity cs = CscsString::CaseSensitive) const;
    bool startsWith(const CscsLatin1String &s, CscsString::CaseSensitivity cs = CscsString::CaseSensitive) const;
    bool startsWith(const CscsChar &c, CscsString::CaseSensitivity cs = CscsString::CaseSensitive) const;
    bool endsWith(const CscsString &s, CscsString::CaseSensitivity cs = CscsString::CaseSensitive) const;
    bool endsWith(const CscsLatin1String &s, CscsString::CaseSensitivity cs = CscsString::CaseSensitive) const;
    bool endsWith(const CscsChar &c, CscsString::CaseSensitivity cs = CscsString::CaseSensitive) const;

    CscsString leftJustified(int width, CscsChar fill = CscsLatin1Char(' '), bool trunc = false) const;
    CscsString rightJustified(int width, CscsChar fill = CscsLatin1Char(' '), bool trunc = false) const;

    CscsString toLower() const;
    CscsString toUpper() const;

    CscsString trimmed() const;
    CscsString simplified() const;

    CscsString &insert(int i, CscsChar c);
    CscsString &insert(int i, const CscsChar *uc, int len);
    inline CscsString &insert(int i, const CscsString &s) { 
    	return insert(i, s.constData(), s.length());
     }
    CscsString &insert(int i, const CscsLatin1String &s);
    CscsString &append(CscsChar c);
    CscsString &append(const CscsString &s);
    CscsString &append(const CscsLatin1String &s);
    inline CscsString &prepend(CscsChar c) { return insert(0, c); }
    inline CscsString &prepend(const CscsString &s) { return insert(0, s); }
    inline CscsString &prepend(const CscsLatin1String &s) { return insert(0, s); }
    inline CscsString &operator+=(CscsChar c) { return append(c); }
    inline CscsString &operator+=(CscsChar::SpecialCharacter c) { return append(CscsChar(c)); }
    inline CscsString &operator+=(const CscsString &s) { return append(s); }
    inline CscsString &operator+=(const CscsLatin1String &s) { return append(s); }

    CscsString &remove(int i, int len);
    CscsString &remove(CscsChar c, CscsString::CaseSensitivity cs = CscsString::CaseSensitive);
    CscsString &remove(const CscsString &s, CscsString::CaseSensitivity cs = CscsString::CaseSensitive);
    CscsString &replace(int i, int len, CscsChar after);
    CscsString &replace(int i, int len, const CscsChar *s, int slen);
    CscsString &replace(int i, int len, const CscsString &after);
    CscsString &replace(CscsChar before, CscsChar after, CscsString::CaseSensitivity cs = CscsString::CaseSensitive);
    CscsString &replace(CscsChar c, const CscsString &after, CscsString::CaseSensitivity cs = CscsString::CaseSensitive);
    CscsString &replace(const CscsString &before, const CscsString &after,
                     CscsString::CaseSensitivity cs = CscsString::CaseSensitive);
    CscsString &replace(const CscsRegExp &rx, const CscsString &after);
    inline CscsString &remove(const CscsRegExp &rx)
    { return replace(rx, CscsString()); }
	
	/*! \enum SplitBehavior
	 *  split 操作枚举值
	 */
    enum SplitBehavior { 
		KeepEmptyParts, /*!< 0x00  包含空的字符处理集	*/
		SkipEmptyParts  /*!< 0x01  忽略空的字符处理集	*/
	};

    CscsStringList split(const CscsString &sep, SplitBehavior behavior = KeepEmptyParts,
                      CscsString::CaseSensitivity cs = CscsString::CaseSensitive) const;
    CscsStringList split(const CscsChar &sep, SplitBehavior behavior = KeepEmptyParts,
                      CscsString::CaseSensitivity cs = CscsString::CaseSensitive) const;

    CscsStringList split(const CscsRegExp &sep, SplitBehavior behavior = KeepEmptyParts) const;
	/*! \enum NormalizationForm
	 *  normalized 操作枚举值
	 *  <a href=" http://www.unicode.org/reports/tr15/">Unicode Standard Annex # 15</a>   .
	 */
    enum NormalizationForm {
        NormalizationForm_D,
        NormalizationForm_C,
        NormalizationForm_KD,
        NormalizationForm_KC
    };
    CscsString normalized(NormalizationForm mode) const;
    CscsString normalized(NormalizationForm mode, CscsChar::UnicodeVersion version) const;

    const uint16 *utf16() const;

    CscsByteArray toAscii() const;
    CscsByteArray toLatin1() const;
    CscsByteArray toUtf8() const;
    CscsByteArray toLocal8Bit() const;

    static CscsString fromAscii(const char *, int size = -1);
    static CscsString fromLatin1(const char *, int size = -1);
    static CscsString fromUtf8(const char *, int size = -1);
    static CscsString fromLocal8Bit(const char *, int size = -1);
    static CscsString fromUtf16(const uint16 *, int size = -1);
    static CscsString fromRawData(const CscsChar *, int size);

    CscsString &setUnicode(const CscsChar *unicode, int size);
    inline CscsString &setUtf16(const uint16 *utf16, int size);

    int compare(const CscsString &s) const;
    static inline int compare(const CscsString &s1, const CscsString &s2)
    { return s1.compare(s2); }
    int localeAwareCompare(const CscsString& s) const;
    static int localeAwareCompare(const CscsString& s1, const CscsString& s2)
    { return s1.localeAwareCompare(s2); }

    int16  toShort(bool *ok=0, int base=10) const;
    uint16 toUShort(bool *ok=0, int base=10) const;
    int toInt(bool *ok=0, int base=10) const;
    uint toUInt(bool *ok=0, int base=10) const;
    long toLong(bool *ok=0, int base=10) const;
    ulong toULong(bool *ok=0, int base=10) const;
    int64 toLongLong(bool *ok=0, int base=10) const;
    uint64 toULongLong(bool *ok=0, int base=10) const;
    float toFloat(bool *ok=0) const;
    double toDouble(bool *ok=0) const;

    CscsString &setNum(int16, int base=10);
    CscsString &setNum(uint16, int base=10);
    CscsString &setNum(int, int base=10);
    CscsString &setNum(uint, int base=10);
    CscsString &setNum(long, int base=10);
    CscsString &setNum(ulong, int base=10);
    CscsString &setNum(int64, int base=10);
    CscsString &setNum(uint64, int base=10);
    CscsString &setNum(float, char f='g', int prec=6);
    CscsString &setNum(double, char f='g', int prec=6);

    static CscsString number(int, int base=10);
    static CscsString number(uint, int base=10);
    static CscsString number(long, int base=10);
    static CscsString number(ulong, int base=10);
    static CscsString number(int64, int base=10);
    static CscsString number(uint64, int base=10);
    static CscsString number(double, char f='g', int prec=6);

    bool operator==(const CscsString &s) const;
    bool operator<(const CscsString &s) const;
    inline bool operator>(const CscsString &s) const { return s < *this; }
    inline bool operator!=(const CscsString &s) const { return !operator==(s); }
    inline bool operator<=(const CscsString &s) const { return !operator>(s); }
    inline bool operator>=(const CscsString &s) const { return !operator<(s); }

    bool operator==(const CscsLatin1String &s) const;
    bool operator<(const CscsLatin1String &s) const;
    bool operator>(const CscsLatin1String &s) const;
    inline bool operator!=(const CscsLatin1String &s) const { return !operator==(s); }
    inline bool operator<=(const CscsLatin1String &s) const { return !operator>(s); }
    inline bool operator>=(const CscsLatin1String &s) const { return !operator<(s); }

    // ASCII compatibility
    // inline CscsString(const char *ch) : d(&shared_null)
    // { d->ref++; *this = fromAscii(ch); }
    // inline CscsString(const bytearray &a) : d(&shared_null)
    // { d->ref++; *this = fromAscii(a.data()); }
    // inline CscsString &operator=(const char *ch)
    // { return (*this = fromAscii(ch)); }
    // inline CscsString &operator=(const bytearray &a)
    // { return (*this = fromAscii(a.data())); }
    // inline CscsString &operator=(char c)
    // { return (*this = CscsChar(c)); }

    inline  CscsString(const char *ch)
        : d(fromAscii_helper(ch, ch ? int(strlen(ch)) : -1))
    {}
    inline  CscsString(const CscsByteArray &a)
        : d(fromAscii_helper(a.constData(), strnlen(a.constData(), a.size())))
    {}
    inline  CscsString &operator=(const char *ch)
    { return (*this = fromUtf8(ch)); }
    inline  CscsString &operator=(const CscsByteArray &a)
    { return (*this = fromUtf8(a)); }
    inline  CscsString &operator=(char c)
    { return (*this = CscsChar::fromLatin1(c)); }

    // these are needed, so it compiles with STL support enabled
    // inline CscsString &prepend(const char *s)
    // { return prepend(CscsString::fromAscii(s)); }
    // inline CscsString &prepend(const bytearray &s)
    // { return prepend(CscsString(s)); }
    // inline CscsString &append(const char *s)
    // { return append(CscsString::fromAscii(s)); }
    // inline CscsString &append(const bytearray &s)
    // { return append(CscsString(s)); }
    // inline CscsString &operator+=(const char *s)
    // { return append(CscsString::fromAscii(s)); }
    // inline CscsString &operator+=(const bytearray &s)
    // { return append(CscsString(s)); }
    // inline CscsString &operator+=(char c)
    // { return append(CscsChar(c)); }
    inline  CscsString &prepend(const char *s)
    { return prepend(CscsString::fromUtf8(s)); }
    inline  CscsString &prepend(const CscsByteArray &s)
    { return prepend(CscsString::fromUtf8(s)); }
    inline  CscsString &append(const char *s)
    { return append(CscsString::fromUtf8(s)); }
    inline  CscsString &append(const CscsByteArray &s)
    { return append(CscsString::fromUtf8(s)); }
    inline  CscsString &insert(int i, const char *s)
    { return insert(i, CscsString::fromUtf8(s)); }
    inline  CscsString &insert(int i, const CscsByteArray &s)
    { return insert(i, CscsString::fromUtf8(s)); }
    inline  CscsString &operator+=(const char *s)
    { return append(CscsString::fromUtf8(s)); }
    inline  CscsString &operator+=(const CscsByteArray &s)
    { return append(CscsString::fromUtf8(s)); }
    inline  CscsString &operator+=(char c)
    { return append(CscsChar::fromLatin1(c)); }

    inline bool operator==(const char *s) const;
    inline bool operator!=(const char *s) const;
    inline bool operator<(const char *s) const;
    inline bool operator<=(const char *s2) const;
    inline bool operator>(const char *s2) const;
    inline bool operator>=(const char *s2) const;

    inline bool operator==(const bytearray &s) const { return (*this == CscsString(s.data())); }
    inline bool operator!=(const bytearray &s) const { return !(*this == CscsString(s.data())); }
    inline bool operator<(const bytearray &s) const { return *this < CscsString(s.data()); }
    inline bool operator>(const bytearray &s) const { return *this > CscsString(s.data()); }
    inline bool operator<=(const bytearray &s) const { return *this <= CscsString(s.data()); }
    inline bool operator>=(const bytearray &s) const { return *this >= CscsString(s.data()); }

    typedef CscsChar *iterator;
    typedef const CscsChar *const_iterator;
    typedef iterator Iterator;
    typedef const_iterator ConstIterator;
    iterator begin();
    const_iterator begin() const;
    const_iterator constBegin() const;
    iterator end();
    const_iterator end() const;
    const_iterator constEnd() const;

    // STL compatibility
    inline void push_back(CscsChar c) { append(c); }
    inline void push_back(const CscsString &s) { append(s); }
    inline void push_front(CscsChar c) { prepend(c); }
    inline void push_front(const CscsString &s) { prepend(s); }


    static inline CscsString fromStdString(const std::string &s);
    inline std::string toStdString() const;

    // compatibility
    struct Null { };
    static const Null null;
    inline CscsString(const Null &): d(&shared_null) { d->ref++; }
    inline CscsString &operator=(const Null &) { *this = CscsString(); return *this; }
    inline bool isNull() const { return d == &shared_null; }


    bool isSimpleText() const { if (!d->clean) updateProperties(); return d->simpletext; }
    bool isRightToLeft() const { if (!d->clean) updateProperties(); return d->righttoleft; }

private:

    struct Data {
        std::atomic<int> ref;
        int alloc, size;
        uint16 *data;
        uint16 clean : 1;
        uint16 simpletext : 1;
        uint16 righttoleft : 1;
        uint16 asciiCache : 1;
        uint16 reserved : 12;
        uint16 array[1];
    };
    static Data shared_null;
    static Data shared_empty;
    static CscsTextCodec *codecForCStrings;
    Data *d;
    CscsString(Data *dd, int /*dummy*/) : d(dd) {}
    static int grow(int);
    static void free(Data *);
    void realloc();
    void realloc(int alloc);
    void expand(int i);
    void updateProperties() const;
    CscsString multiArg(int numArgs, const CscsString **args) const;
    friend class CscsCharRef;
    friend class CscsTextCodec;

public:
    static Data *fromAscii_helper(const char *str, int size = -1);
};
SCS_DECLARE_TYPENAME_INFO(Gemini::CscsString,SCS_MOVABLE_TYPE)

class  CscsLatin1String
{
public:
    inline explicit CscsLatin1String(const char *s) : chars(s) {}
    inline const char *latin1() const { return chars; }

    inline bool operator==(const CscsString &s) const
    { return s == *this; }
    inline bool operator!=(const CscsString &s) const
    { return s != *this; }
    inline bool operator>(const CscsString &s) const
    { return s < *this; }
    inline bool operator<(const CscsString &s) const
    { return s > *this; }
    inline bool operator>=(const CscsString &s) const
    { return s <= *this; }
    inline bool operator<=(const CscsString &s) const
    { return s >= *this; }

private:
    const char *chars;
};
SCS_DECLARE_TYPENAME_INFO(Gemini::CscsLatin1String,SCS_MOVABLE_TYPE)

inline CscsString::CscsString(const CscsLatin1String &latin1) : d(&shared_null)
{ d->ref++; *this = fromLatin1(latin1.latin1()); }
inline int CscsString::length() const
{ return d->size; }
inline const CscsChar CscsString::at(int i) const
{  return d->data[i]; }
inline const CscsChar CscsString::operator[](int i) const
{  return d->data[i]; }
inline const CscsChar CscsString::operator[](uint i) const
{  return d->data[i]; }
inline bool CscsString::isEmpty() const
{ return d->size == 0; }
inline const CscsChar *CscsString::unicode() const
{ return reinterpret_cast<const CscsChar*>(d->data); }
inline const CscsChar *CscsString::data() const
{ return reinterpret_cast<const CscsChar*>(d->data); }
inline CscsChar *CscsString::data()
{ detach(); return reinterpret_cast<CscsChar*>(d->data); }
inline const CscsChar *CscsString::constData() const
{ return reinterpret_cast<const CscsChar*>(d->data); }
inline void CscsString::detach()
{ if (d->ref != 1 || d->data != d->array) realloc(); }
inline bool CscsString::isDetached() const
{ return d->ref == 1; }
inline CscsString &CscsString::operator=(const CscsLatin1String &s)
{
    *this = fromLatin1(s.latin1());
    return *this;
}
inline void CscsString::clear()
{ if (!isNull()) *this = CscsString(); }
inline CscsString::CscsString(const CscsString &s) : d(s.d)
{  d->ref++; }
inline int CscsString::capacity() const
{ return d->alloc; }
inline CscsString &CscsString::setNum(int16 n, int base)
{ return setNum(int64(n), base); }
inline CscsString &CscsString::setNum(uint16 n, int base)
{ return setNum(uint64(n), base); }
inline CscsString &CscsString::setNum(int n, int base)
{ return setNum(int64(n), base); }
inline CscsString &CscsString::setNum(uint n, int base)
{ return setNum(uint64(n), base); }
inline CscsString &CscsString::setNum(long n, int base)
{ return setNum(int64(n), base); }
inline CscsString &CscsString::setNum(ulong n, int base)
{ return setNum(uint64(n), base); }
inline CscsString &CscsString::setNum(float n, char f, int prec)
{ return setNum(double(n),f,prec); }
inline CscsString CscsString::arg(int a, int fieldWidth, int base, const CscsChar &fillChar) const
{ return arg(int64(a), fieldWidth, base, fillChar); }
inline CscsString CscsString::arg(uint a, int fieldWidth, int base, const CscsChar &fillChar) const
{ return arg(uint64(a), fieldWidth, base, fillChar); }
inline CscsString CscsString::arg(long a, int fieldWidth, int base, const CscsChar &fillChar) const
{ return arg(int64(a), fieldWidth, base, fillChar); }
inline CscsString CscsString::arg(ulong a, int fieldWidth, int base, const CscsChar &fillChar) const
{ return arg(uint64(a), fieldWidth, base, fillChar); }
inline CscsString CscsString::arg(int16 a, int fieldWidth, int base, const CscsChar &fillChar) const
{ return arg(int64(a), fieldWidth, base, fillChar); }
inline CscsString CscsString::arg(uint16 a, int fieldWidth, int base, const CscsChar &fillChar) const
{ return arg(uint64(a), fieldWidth, base, fillChar); }
inline CscsString CscsString::arg(const CscsString &a1, const CscsString &a2) const
{ const CscsString *args[2] = { &a1, &a2 }; return multiArg(2, args); }
inline CscsString CscsString::arg(const CscsString &a1, const CscsString &a2, const CscsString &a3) const
{ const CscsString *args[3] = { &a1, &a2, &a3 }; return multiArg(3, args); }
inline CscsString CscsString::arg(const CscsString &a1, const CscsString &a2, const CscsString &a3, const CscsString &a4) const
{ const CscsString *args[4] = { &a1, &a2, &a3, &a4 }; return multiArg(4, args); }
inline CscsString CscsString::section(CscsChar asep, int astart, int aend, SectionFlags aflags) const
{ return section(CscsString(asep), astart, aend, aflags); }


class  CscsCharRef {
    CscsString &s;
    int i;
    inline CscsCharRef(CscsString &str, int idx)
        : s(str),i(idx) {}
    friend class CscsString;
public:

    // most CscsChar operations repeated here

    // all this is not documented: We just say "like CscsChar" and let it be.
    inline operator CscsChar() const
        { return i < s.d->size ? s.d->data[i] : 0; }
    inline CscsCharRef &operator=(const CscsChar &c)
        { if (s.d->ref != 1 || i >= s.d->size) s.expand(i);
          s.d->data[i] = c.unicode();  return *this; }

    // An operator= for each CscsChar cast constructors
    inline CscsCharRef &operator=(char c) { return operator=(CscsChar(c)); }
    inline CscsCharRef &operator=(uint8 c) { return operator=(CscsChar(c)); }
    inline CscsCharRef &operator=(const CscsCharRef &c) { return operator=(CscsChar(c)); }
    inline CscsCharRef &operator=(uint16 rc) { return operator=(CscsChar(rc)); }
    inline CscsCharRef &operator=(int16 rc) { return operator=(CscsChar(rc)); }
    inline CscsCharRef &operator=(uint rc) { return operator=(CscsChar(rc)); }
    inline CscsCharRef &operator=(int rc) { return operator=(CscsChar(rc)); }

    // each function...
    inline bool isNull() const { return CscsChar(*this).isNull(); }
    inline bool isPrint() const { return CscsChar(*this).isPrint(); }
    inline bool isPunct() const { return CscsChar(*this).isPunct(); }
    inline bool isSpace() const { return CscsChar(*this).isSpace(); }
    inline bool isMark() const { return CscsChar(*this).isMark(); }
    inline bool isLetter() const { return CscsChar(*this).isLetter(); }
    inline bool isNumber() const { return CscsChar(*this).isNumber(); }
    inline bool isLetterOrNumber() { return CscsChar(*this).isLetterOrNumber(); }
    inline bool isDigit() const { return CscsChar(*this).isDigit(); }

    inline int digitValue() const { return CscsChar(*this).digitValue(); }
    CscsChar toLower() const { return CscsChar(*this).toLower(); }
    CscsChar toUpper() const { return CscsChar(*this).toUpper(); }


    CscsChar::Category category() const { return CscsChar(*this).category(); }
    CscsChar::Direction direction() const { return CscsChar(*this).direction(); }
    CscsChar::Joining joining() const { return CscsChar(*this).joining(); }
    bool hasMirrored() const { return CscsChar(*this).hasMirrored(); }

    CscsChar mirroredChar() const { return CscsChar(*this).mirroredChar(); }
    CscsString decomposition() const { return CscsChar(*this).decomposition(); }
    CscsChar::Decomposition decompositionTag() const { return CscsChar(*this).decompositionTag(); }
    uint8 combiningClass() const { return CscsChar(*this).combiningClass(); }

    CscsChar::UnicodeVersion unicodeVersion() const { return CscsChar(*this).unicodeVersion(); }

    inline uint8 cell() const { return CscsChar(*this).cell(); }
    inline uint8 row() const { return CscsChar(*this).row(); }
    inline void setCell(uint8 cell);
    inline void setRow(uint8 row);

    const char toAscii() const { return CscsChar(*this).toAscii(); }
    const char toLatin1() const { return CscsChar(*this).toLatin1(); }
    const uint16 unicode() const { return CscsChar(*this).unicode(); }
};


inline void CscsCharRef::setRow(uint8 arow) { CscsChar(*this).setRow(arow); }
inline void CscsCharRef::setCell(uint8 acell) { CscsChar(*this).setCell(acell); }


inline CscsString::CscsString() : d(&shared_null) { d->ref++; }
inline CscsString::~CscsString() { if (!--d->ref) free(d); }
inline void CscsString::reserve(int asize) { if (d->ref != 1 || asize > d->alloc) realloc(asize); }
inline CscsString &CscsString::setUtf16(const uint16 *autf16, int asize)
{ return setUnicode(reinterpret_cast<const CscsChar *>(autf16), asize); }
inline CscsCharRef CscsString::operator[](int i)
{ return CscsCharRef(*this, i); }
inline CscsCharRef CscsString::operator[](uint i)
{ return CscsCharRef(*this, i); }
inline CscsString::iterator CscsString::begin()
{ detach(); return reinterpret_cast<CscsChar*>(d->data); }
inline CscsString::const_iterator CscsString::begin() const
{ return reinterpret_cast<const CscsChar*>(d->data); }
inline CscsString::const_iterator CscsString::constBegin() const
{ return reinterpret_cast<const CscsChar*>(d->data); }
inline CscsString::iterator CscsString::end()
{ detach(); return reinterpret_cast<CscsChar*>(d->data + d->size); }
inline CscsString::const_iterator CscsString::end() const
{ return reinterpret_cast<const CscsChar*>(d->data + d->size); }
inline CscsString::const_iterator CscsString::constEnd() const
{ return reinterpret_cast<const CscsChar*>(d->data + d->size); }
inline bool CscsString::contains(const CscsString &s, CscsString::CaseSensitivity cs) const
{ return bool(indexOf(s, 0, cs) != -1); }
inline bool CscsString::contains(CscsChar c, CscsString::CaseSensitivity cs) const
{ return bool(indexOf(c, 0, cs) != -1); }


inline bool operator==(CscsString::Null, CscsString::Null) { return true; }
inline bool operator==(CscsString::Null, const CscsString &s) { return s.isNull(); }
inline bool operator==(const CscsString &s, CscsString::Null) { return s.isNull(); }
inline bool operator!=(CscsString::Null, CscsString::Null) { return false; }
inline bool operator!=(CscsString::Null, const CscsString &s) { return !s.isNull(); }
inline bool operator!=(const CscsString &s, CscsString::Null) { return !s.isNull(); }


inline bool CscsString::operator==(const char *s) const {

    return (*this == CscsLatin1String(s));
}
inline bool CscsString::operator!=(const char *s) const{ return !(*this == s); }
inline bool CscsString::operator<(const char *s) const { return *this < CscsString::fromAscii(s); }
inline bool CscsString::operator>(const char *s) const { return *this > CscsString::fromAscii(s); }
inline bool CscsString::operator<=(const char *s) const { return *this <= CscsString::fromAscii(s); }
inline bool CscsString::operator>=(const char *s) const { return *this >= CscsString::fromAscii(s); }

inline bool operator==(const char *s1, const CscsString &s2) { return (s2 == s1); }
inline bool operator!=(const char *s1, const CscsString &s2) { return !(s2 == s1); }
inline bool operator<(const char *s1, const CscsString &s2) { return (CscsString::fromAscii(s1) < s2); }
inline bool operator>(const char *s1, const CscsString &s2) { return (CscsString::fromAscii(s1) > s2); }
inline bool operator<=(const char *s1, const CscsString &s2) { return (CscsString::fromAscii(s1) <= s2); }
inline bool operator>=(const char *s1, const CscsString &s2) { return (CscsString::fromAscii(s1) >= s2); }






inline const CscsString operator+(const CscsString &s1, const CscsString &s2)
{ CscsString t(s1); t += s2; return t; }
inline const CscsString operator+(const CscsString &s1, CscsChar s2)
{ CscsString t(s1); t += s2; return t; }
inline const CscsString operator+(CscsChar s1, const CscsString &s2)
{ CscsString t(s1); t += s2; return t; }

inline const CscsString operator+(const CscsString &s1, const char *s2)
{ CscsString t(s1); t += CscsString::fromAscii(s2); return t; }
inline const CscsString operator+(const char *s1, const CscsString &s2)
{ CscsString t(s1); t += s2; return t; }
inline const CscsString operator+(char c, const CscsString &s)
{ CscsString t = s; t.prepend(CscsChar(c)); return t; }
inline const CscsString operator+(const CscsString &s, char c)
{ CscsString t(s); t += c; return t; }
inline const CscsString operator+(const CscsByteArray &ba, const CscsString &s)
{ CscsString t(ba); t += s; return t; }
inline const CscsString operator+(const CscsString &s, const CscsByteArray &ba)
{ CscsString t(s); t += ba; return t; }



inline std::string CscsString::toStdString() const
{ return toAscii().data(); }

inline CscsString CscsString::fromStdString(const std::string &s)
{ return fromAscii(s.c_str()); }


SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsString::SectionFlags)

END_NAMESPACE

#endif