#ifndef SCSMAP_H
#define SCSMAP_H

#include <kernel/scstypes.h>
#include <kernel/scslist.h>
#include <kernel/scsiterator.h>
#include <map>
#include <atomic>
#include <new>
#include <type_traits>

BEGIN_NAMESPACE(Gemini)

struct  CscsMapData
{
    struct Node {
        Node *backward;
        Node *forward[1];
    };
    enum { LastLevel = 11, Sparseness = 3 };

    Node *backward;
    Node *forward[CscsMapData::LastLevel + 1];
    std::atomic<int> ref;
    int topLevel;
    int size;
    uint randomBits;
    uint insertInOrder : 1;
    uint sharable : 1;

    static CscsMapData *createData();
    void continueFreeData(int offset);
    Node *node_create(Node *update[], int offset);
    void node_delete(Node *update[], int offset, Node *node);

    static CscsMapData shared_null;
};


/*
    CscsMap uses scsMapLessThanKey() to compare keys. The default
    implementation uses operator<(). For pointer types,
    scsMapLessThanKey() casts the pointers to integers before it
    compares them, because operator<() is undefined on pointers
    that come from different memory blocks. (In practice, this
    is only a problem when running a program such as
    BoundsChecker.)
*/

template <class Key> inline bool scsMapLessThanKey(const Key &key1, const Key &key2)
{
    return key1 < key2;
}

template <class Ptr> inline bool scsMapLessThanKey(Ptr *key1, Ptr *key2)
{
    assert(sizeof(ulong) == sizeof(Ptr *));
    return reinterpret_cast<ulong>(key1) < reinterpret_cast<ulong>(key2);
}

template <class Ptr> inline bool scsMapLessThanKey(const Ptr *key1, const Ptr *key2)
{
    assert(sizeof(ulong) == sizeof(const Ptr *));
    return reinterpret_cast<ulong>(key1) < reinterpret_cast<ulong>(key2);
}



template <class Key, class T>
class CscsMap
{
    struct Node {
        Key key;
        T value;
        CscsMapData::Node *backward;
        CscsMapData::Node *forward[1];
    };
    union {
        CscsMapData *d;
        CscsMapData::Node *e;
    };

    struct PayloadNode
    {
        Key key;
        T value;
        CscsMapData::Node *backward;
    };
    enum { Payload = sizeof(PayloadNode) - sizeof(CscsMapData::Node *) };

    static inline Node *concrete(CscsMapData::Node *node) {
        return reinterpret_cast<Node *>(reinterpret_cast<char *>(node) - Payload);
    }
public:
    inline CscsMap() : d(&CscsMapData::shared_null) { d->ref++; }
    inline CscsMap(const CscsMap<Key, T> &other) : d(other.d)
    { d->ref++; if (!d->sharable) detach(); }
    inline ~CscsMap() { if (!d) return; if (!(--d->ref)) freeData(d); }

    CscsMap<Key, T> &operator=(const CscsMap<Key, T> &other);
    explicit CscsMap(const typename std::map<Key, T> &other);
    std::map<Key, T> toStdMap() const;

    bool operator==(const CscsMap<Key, T> &other) const;
    inline bool operator!=(const CscsMap<Key, T> &other) const { return !(*this == other); }

    inline int size() const { return d->size; }

    inline bool isEmpty() const { return d->size == 0; }

    inline void detach() { if (d->ref != 1) detach_helper(); }
    inline bool isDetached() const { return d->ref == 1; }
    inline void setSharable(bool sharable) { if (!sharable) detach(); d->sharable = sharable; }

    void clear();

    int remove(const Key &key);
    T take(const Key &key);

    bool contains(const Key &key) const;
    const Key key(const T &value) const;
    const T value(const Key &key) const;
    const T value(const Key &key, const T &defaultValue) const;
    T &operator[](const Key &key);
    const T operator[](const Key &key) const;

    CscsList<Key> keys() const;
    CscsList<Key> keys(const T &value) const;
    CscsList<T> values() const;
    CscsList<T> values(const Key &key) const;
    int count(const Key &key) const;

    class const_iterator;

    class iterator
    {
        CscsMapData::Node *i;
    public:
        typedef std::bidirectional_iterator_tag iterator_category;
        typedef ptrdiff_t difference_type;
        typedef T value_type;
        typedef T *pointer;
        typedef T &reference;

        inline operator CscsMapData::Node *() const { return i; }
        inline iterator() : i(0) { }
        inline iterator(CscsMapData::Node *node) : i(node) { }

        inline const Key &key() const { return concrete(i)->key; }
        inline T &value() const { return concrete(i)->value; }
        inline T &operator*() const { return concrete(i)->value; }
        inline T *operator->() const { return &concrete(i)->value; }
        inline bool operator==(const iterator &o) const { return i == o.i; }
        inline bool operator!=(const iterator &o) const { return i != o.i; }
        inline bool operator==(const const_iterator &o) const
            { return i == reinterpret_cast<const iterator &>(o).i; }
        inline bool operator!=(const const_iterator &o) const
            { return i != reinterpret_cast<const iterator &>(o).i; }

        inline iterator &operator++() {
            i = i->forward[0];
            return *this;
        }
        inline iterator operator++(int) {
            iterator r = *this;
            i = i->forward[0];
            return r;
        }
        inline iterator &operator--() {
            i = i->backward;
            return *this;
        }
        inline iterator operator--(int) {
            iterator r = *this;
            i = i->backward;
            return r;
        }
        inline iterator operator+(int j) const
        { iterator r = *this; if (j > 0) while (j--) ++r; else while (j++) --r; return r; }
        inline iterator operator-(int j) const { return operator+(-j); }
        inline iterator &operator+=(int j) { return *this = *this + j; }
        inline iterator &operator-=(int j) { return *this = *this - j; }
    };
    friend class iterator;

    class const_iterator
    {
        CscsMapData::Node *i;
    public:
        typedef std::bidirectional_iterator_tag iterator_category;
        typedef ptrdiff_t difference_type;
        typedef T value_type;
        typedef T *pointer;
        typedef T &reference;

        inline operator CscsMapData::Node *() const { return i; }
        inline const_iterator() : i(0) { }
        inline const_iterator(CscsMapData::Node *node) : i(node) { }
        inline const_iterator(const iterator &o)
        { i = reinterpret_cast<const const_iterator &>(o).i; }

        inline const Key &key() const { return concrete(i)->key; }
        inline const T &value() const { return concrete(i)->value; }
        inline const T &operator*() const { return concrete(i)->value; }
        inline const T *operator->() const { return &concrete(i)->value; }
        inline bool operator==(const const_iterator &o) const { return i == o.i; }
        inline bool operator!=(const const_iterator &o) const { return i != o.i; }

        inline const_iterator &operator++() {
            i = i->forward[0];
            return *this;
        }
        inline const_iterator operator++(int) {
            const_iterator r = *this;
            i = i->forward[0];
            return r;
        }
        inline const_iterator &operator--() {
            i = i->backward;
            return *this;
        }
        inline const_iterator operator--(int) {
            iterator r = *this;
            i = i->backward;
            return r;
        }
        inline const_iterator operator+(int j) const
        { const_iterator r = *this; if (j > 0) while (j--) ++r; else while (j++) --r; return r; }
        inline const_iterator operator-(int j) const { return operator+(-j); }
        inline const_iterator &operator+=(int j) { return *this = *this + j; }
        inline const_iterator &operator-=(int j) { return *this = *this - j; }
    };
    friend class const_iterator;

    // STL style
    inline iterator begin() { detach(); return iterator(e->forward[0]); }
    inline const_iterator begin() const { return const_iterator(e->forward[0]); }
    inline const_iterator constBegin() const { return const_iterator(e->forward[0]); }
    inline iterator end() {
        detach();
        return iterator(e);
    }
    inline const_iterator end() const { return const_iterator(e); }
    inline const_iterator constEnd() const { return const_iterator(e); }
    iterator erase(iterator it);

    typedef iterator Iterator;
    typedef const_iterator ConstIterator;
    inline int count() const { return d->size; }
    iterator find(const Key &key);
    const_iterator find(const Key &key) const;
    iterator lowerBound(const Key &key);
    const_iterator lowerBound(const Key &key) const;
    iterator upperBound(const Key &key);
    const_iterator upperBound(const Key &key) const;
    iterator insert(const Key &key, const T &value);
    iterator insertMulti(const Key &key, const T &value);
    CscsMap<Key, T> &unite(const CscsMap<Key, T> &other);

    // STL compatibility
    inline bool empty() const { return isEmpty(); }

private:
    void detach_helper();
    void freeData(CscsMapData *d);
    CscsMapData::Node *findNode(const Key &key) const;
    CscsMapData::Node *mutableFindNode(CscsMapData::Node *update[], const Key &key) const;
    CscsMapData::Node *node_create(CscsMapData *d, CscsMapData::Node *update[], const Key &key,
                                const T &value);
};

template <class Key, class T>
inline CscsMap<Key, T> &CscsMap<Key, T>::operator=(const CscsMap<Key, T> &other)
{
    if (d != other.d) {
        CscsMapData *x = other.d;
        x->ref++;
        {
        	CscsMapData* tmp=x;
        	x=d;
        	d=tmp;
        }
        if (!--x->ref)
            freeData(x);
        if (!d->sharable)
            detach_helper();
    }
    return *this;
}

template <class Key, class T>
inline void CscsMap<Key, T>::clear()
{
    *this = CscsMap<Key, T>();
}

template <class Key, class T>
inline typename CscsMapData::Node *
CscsMap<Key, T>::node_create(CscsMapData *adt, CscsMapData::Node *aupdate[], const Key &akey, const T &avalue)
{
    CscsMapData::Node *abstractNode = adt->node_create(aupdate, Payload);
    Node *concreteNode = concrete(abstractNode);
    new (&concreteNode->key) Key(akey);
    new (&concreteNode->value) T(avalue);
    return abstractNode;
}

template <class Key, class T>
inline CscsMapData::Node *CscsMap<Key, T>::findNode(const Key &akey) const
{
    CscsMapData::Node *cur = e;
    CscsMapData::Node *next = e;

    for (int i = d->topLevel; i >= 0; i--) {
        while ((next = cur->forward[i]) != e && scsMapLessThanKey<Key>(concrete(next)->key, akey))
            cur = next;
    }

    if (next != e && !scsMapLessThanKey<Key>(akey, concrete(next)->key)) {
        return next;
    } else {
        return e;
    }
}

template <class Key, class T>
inline const T CscsMap<Key, T>::value(const Key &akey) const
{
    CscsMapData::Node *node = findNode(akey);
    if (node == e) {
        return T();
    } else {
        return concrete(node)->value;
    }
}

template <class Key, class T>
inline const T CscsMap<Key, T>::value(const Key &akey, const T &adefaultValue) const
{
    CscsMapData::Node *node = findNode(akey);
    if (node == e) {
        return adefaultValue;
    } else {
        return concrete(node)->value;
    }
}

template <class Key, class T>
inline const T CscsMap<Key, T>::operator[](const Key &akey) const
{
    return value(akey);
}

template <class Key, class T>
inline T &CscsMap<Key, T>::operator[](const Key &akey)
{
    detach();

    CscsMapData::Node *update[CscsMapData::LastLevel + 1];
    CscsMapData::Node *node = mutableFindNode(update, akey);
    if (node == e)
        node = node_create(d, update, akey, T());
    return concrete(node)->value;
}

template <class Key, class T>
inline int CscsMap<Key, T>::count(const Key &akey) const
{
    int cnt = 0;
    CscsMapData::Node *node = findNode(akey);
    if (node != e) {
        do {
            ++cnt;
            node = node->forward[0];
        } while (node != e && !scsMapLessThanKey<Key>(akey, concrete(node)->key));
    }
    return cnt;
}

template <class Key, class T>
inline bool CscsMap<Key, T>::contains(const Key &akey) const
{
    return findNode(akey) != e;
}

template <class Key, class T>
inline typename CscsMap<Key, T>::iterator CscsMap<Key, T>::insert(const Key &akey,
                                                                       const T &avalue)
{
    detach();

    CscsMapData::Node *update[CscsMapData::LastLevel + 1];
    CscsMapData::Node *node = mutableFindNode(update, akey);
    if (node == e) {
        node = node_create(d, update, akey, avalue);
    } else {
        concrete(node)->value = avalue;
    }
    return iterator(node);
}


template <class Key, class T>
inline typename CscsMap<Key, T>::iterator CscsMap<Key, T>::insertMulti(const Key &akey,
                                                                            const T &avalue)
{
    detach();

    CscsMapData::Node *update[CscsMapData::LastLevel + 1];
    mutableFindNode(update, akey);
    return iterator(node_create(d, update, akey, avalue));
}

template <class Key, class T>
inline typename CscsMap<Key, T>::const_iterator CscsMap<Key, T>::find(const Key &akey) const
{
    return const_iterator(findNode(akey));
}

template <class Key, class T>
inline typename CscsMap<Key, T>::iterator CscsMap<Key, T>::find(const Key &akey)
{
    detach();
    return iterator(findNode(akey));
}

template <class Key, class T>
inline CscsMap<Key, T> &CscsMap<Key, T>::unite(const CscsMap<Key, T> &other)
{
    CscsMap<Key, T> copy(other);
    const_iterator it = copy.constEnd();
    while (it != copy.constBegin()) {
        --it;
        insertMulti(it.key(), it.value());
    }
    return *this;
}

template <class Key, class T>
inline void CscsMap<Key, T>::freeData(CscsMapData *x)
{
    if (!std::is_fundamental<Key>::value || !std::is_fundamental<T>::value) {
        CscsMapData::Node *y = reinterpret_cast<CscsMapData::Node *>(x);
        CscsMapData::Node *cur = y;
        CscsMapData::Node *next = cur->forward[0];
        while (next != y) {
            cur = next;
            next = cur->forward[0];
            Node *concreteNode = concrete(cur);
            concreteNode->key.~Key();
            concreteNode->value.~T();
        }
    }
    x->continueFreeData(Payload);
}

template <class Key, class T>
inline int CscsMap<Key, T>::remove(const Key &akey)
{
    detach();

    CscsMapData::Node *update[CscsMapData::LastLevel + 1];
    CscsMapData::Node *cur = e;
    CscsMapData::Node *next = e;
    int oldSize = d->size;

    for (int i = d->topLevel; i >= 0; i--) {
        while ((next = cur->forward[i]) != e && scsMapLessThanKey<Key>(concrete(next)->key, akey))
            cur = next;
        update[i] = cur;
    }

    if (next != e && !scsMapLessThanKey<Key>(akey, concrete(next)->key)) {
        bool deleteNext = true;
        do {
            cur = next;
            next = cur->forward[0];
            deleteNext = (next != e && !scsMapLessThanKey<Key>(concrete(cur)->key, concrete(next)->key));
            concrete(cur)->key.~Key();
            concrete(cur)->value.~T();
            d->node_delete(update, Payload, cur);
        } while (deleteNext);
    }
    return oldSize - d->size;
}

template <class Key, class T>
inline T CscsMap<Key, T>::take(const Key &akey)
{
    detach();

    CscsMapData::Node *update[CscsMapData::LastLevel + 1];
    CscsMapData::Node *cur = e;
    CscsMapData::Node *next = e;

    for (int i = d->topLevel; i >= 0; i--) {
        while ((next = cur->forward[i]) != e && scsMapLessThanKey<Key>(concrete(next)->key, akey))
            cur = next;
        update[i] = cur;
    }

    if (next != e && !scsMapLessThanKey<Key>(akey, concrete(next)->key)) {
        T t = concrete(next)->value;
        concrete(next)->key.~Key();
        concrete(next)->value.~T();
        d->node_delete(update, Payload, next);
        return t;
    }
    return T();
}

template <class Key, class T>
inline typename CscsMap<Key, T>::iterator CscsMap<Key, T>::erase(iterator it)
{
    CscsMapData::Node *update[CscsMapData::LastLevel + 1];
    CscsMapData::Node *cur = e;
    CscsMapData::Node *next = e;

    if (it == iterator(e))
        return it;

    for (int i = d->topLevel; i >= 0; i--) {
        while ((next = cur->forward[i]) != e && scsMapLessThanKey<Key>(concrete(next)->key, it.key()))
            cur = next;
        update[i] = cur;
    }

    while (next != e) {
        cur = next;
        next = cur->forward[0];
        if (cur == it) {
            concrete(cur)->key.~Key();
            concrete(cur)->value.~T();
            d->node_delete(update, Payload, cur);
            return iterator(next);
        }

        for (int i = 0; i <= d->topLevel; ++i) {
            if (update[i]->forward[i] != cur)
                break;
            update[i] = cur;
        }
    }
    return end();
}

template <class Key, class T>
inline void CscsMap<Key, T>::detach_helper()
{
    union { CscsMapData *d; CscsMapData::Node *e; } x;
    x.d = CscsMapData::createData();
    if (d->size) {
        x.d->insertInOrder = true;
        CscsMapData::Node *update[CscsMapData::LastLevel + 1];
        CscsMapData::Node *cur = e->forward[0];
        update[0] = x.e;
        while (cur != e) {
            Node *concreteNode = concrete(cur);
            node_create(x.d, update, concreteNode->key, concreteNode->value);
            cur = cur->forward[0];
        }
        x.d->insertInOrder = false;
    }
    {
        CscsMapData* tmp=x.d;
        x.d=d;
        d=tmp;
    }
    if (!(--x.d->ref))
        freeData(x.d);
}

template <class Key, class T>
inline CscsMapData::Node *CscsMap<Key, T>::mutableFindNode(CscsMapData::Node *aupdate[],
                                                                   const Key &akey) const
{
    CscsMapData::Node *cur = e;
    CscsMapData::Node *next = e;

    for (int i = d->topLevel; i >= 0; i--) {
        while ((next = cur->forward[i]) != e && scsMapLessThanKey<Key>(concrete(next)->key, akey))
            cur = next;
        aupdate[i] = cur;
    }
    if (next != e && !scsMapLessThanKey<Key>(akey, concrete(next)->key)) {
        return next;
    } else {
        return e;
    }
}

template <class Key, class T>
inline CscsList<Key> CscsMap<Key, T>::keys() const
{
    CscsList<Key> res;
    const_iterator i = begin();
    while (i != end()) {
        res.append(i.key());
        ++i;
    }
    return res;
}

template <class Key, class T>
inline CscsList<Key> CscsMap<Key, T>::keys(const T &avalue) const
{
    CscsList<Key> res;
    const_iterator i = begin();
    while (i != end()) {
        if (i.value() == avalue)
            res.append(i.key());
        ++i;
    }
    return res;
}

template <class Key, class T>
inline const Key CscsMap<Key, T>::key(const T &avalue) const
{
    const_iterator i = begin();
    while (i != end()) {
        if (i.value() == avalue)
            return i.key();
        ++i;
    }

    return Key();
}

template <class Key, class T>
inline CscsList<T> CscsMap<Key, T>::values() const
{
    CscsList<T> res;
    const_iterator i = begin();
    while (i != end()) {
        res.append(i.value());
        ++i;
    }
    return res;
}

template <class Key, class T>
inline CscsList<T> CscsMap<Key, T>::values(const Key &akey) const
{
    CscsList<T> res;
    CscsMapData::Node *node = findNode(akey);
    if (node != e) {
        do {
            res.append(concrete(node)->value);
            node = node->forward[0];
        } while (node != e && !scsMapLessThanKey<Key>(akey, concrete(node)->key));
    }
    return res;
}

template <class Key, class T>
inline typename CscsMap<Key, T>::const_iterator
CscsMap<Key, T>::lowerBound(const Key &akey) const
{
    CscsMapData::Node *update[CscsMapData::LastLevel + 1];
    mutableFindNode(update, akey);
    return const_iterator(update[0]->forward[0]);
}

template <class Key, class T>
inline typename CscsMap<Key, T>::iterator CscsMap<Key, T>::lowerBound(const Key &akey)
{
    detach();
    return static_cast<CscsMapData::Node *>(const_cast<const CscsMap *>(this)->lowerBound(akey));
}

template <class Key, class T>
inline typename CscsMap<Key, T>::const_iterator
CscsMap<Key, T>::upperBound(const Key &akey) const
{
    CscsMapData::Node *update[CscsMapData::LastLevel + 1];
    mutableFindNode(update, akey);
    CscsMapData::Node *node = update[0]->forward[0];
    while (node != e && !scsMapLessThanKey<Key>(akey, concrete(node)->key))
        node = node->forward[0];
    return const_iterator(node);
}

template <class Key, class T>
inline typename CscsMap<Key, T>::iterator CscsMap<Key, T>::upperBound(const Key &akey)
{
    detach();
    return static_cast<CscsMapData::Node *>(const_cast<const CscsMap *>(this)->upperBound(akey));
}

template <class Key, class T>
inline bool CscsMap<Key, T>::operator==(const CscsMap<Key, T> &other) const
{
    if (size() != other.size())
        return false;
    if (d == other.d)
        return true;

    const_iterator it1 = begin();
    const_iterator it2 = other.begin();

    while (it1 != end()) {
        if (!(it1.value() == it2.value()) || scsMapLessThanKey(it1.key(), it2.key()) || scsMapLessThanKey(it2.key(), it1.key()))
            return false;
        ++it2;
        ++it1;
    }
    return true;
}

template <class Key, class T>
inline CscsMap<Key, T>::CscsMap(const std::map<Key, T> &other)
{
    d = CscsMapData::createData();
    d->insertInOrder = true;
    typename std::map<Key,T>::const_iterator it = other.end();
    while (it != other.begin()) {
        --it;
        insert((*it).first, (*it).second);
    }
    d->insertInOrder = false;
}

template <class Key, class T>
inline  std::map<Key, T> CscsMap<Key, T>::toStdMap() const
{
    std::map<Key, T> map;
    const_iterator it = end();
    while (it != begin()) {
        --it;
        map.insert(std::pair<Key, T>(it.key(), it.value()));
    }
    return map;
}


template <class Key, class T>
class CscsMultiMap : public CscsMap<Key, T>
{
public:
    CscsMultiMap() {}
    CscsMultiMap(const CscsMap<Key, T> &other) : CscsMap<Key, T>(other) {}

    inline typename CscsMap<Key, T>::iterator replace(const Key &key, const T &value);
    inline typename CscsMap<Key, T>::iterator insert(const Key &key, const T &value);

    inline CscsMultiMap &operator+=(const CscsMultiMap &other)
    { unite(other); return *this; }
    inline CscsMultiMap operator+(const CscsMultiMap &other) const
    { CscsMultiMap result = *this; result += other; return result; }

private:
    T &operator[](const Key &key);
    const T operator[](const Key &key) const;
};

template <class Key, class T>
inline typename CscsMap<Key, T>::iterator CscsMultiMap<Key, T>::replace(const Key &akey, const T &avalue)
{ return CscsMap<Key, T>::insert(akey, avalue); }

template <class Key, class T>
inline typename CscsMap<Key, T>::iterator CscsMultiMap<Key, T>::insert(const Key &akey, const T &avalue)
{ return CscsMap<Key, T>::insertMulti(akey, avalue); }

SCS_DECLARE_ASSOCIATIVE_ITERATOR(Map)
SCS_DECLARE_MUTABLE_ASSOCIATIVE_ITERATOR(Map)

END_NAMESPACE

#endif