#ifndef SCSMUTEX_H
#define SCSMUTEX_H
#include "scsnocopy.hpp"

BEGIN_NAMESPACE(Gemini)

class CscsPlatformMutex;
class CscsPlatformRecursiveMutex;

class CscsMutex:public CscsNoCopyable{
public:
	explicit CscsMutex();
	~CscsMutex();
	void lock();
	bool tryLock();
	void unlock();
private:
	CscsPlatformMutex* d;
	friend class CscsWaitCondition;
};

//递归锁
class CscsRecursiveMutex:public CscsNoCopyable{
public:
    explicit CscsRecursiveMutex();
	~CscsRecursiveMutex();
	void lock();
	bool tryLock();
	void unlock();
private:
	CscsPlatformRecursiveMutex* d;
};

class CscsMutexLocker:public CscsNoCopyable{
public:
    inline explicit CscsMutexLocker(CscsMutex *m) : mtx(m) { relock(); }
    inline ~CscsMutexLocker() { unlock(); }

    inline void unlock() { if (mtx) mtx->unlock(); }

    inline void relock() { if (mtx) mtx->lock(); }

    inline CscsMutex *mutex() const { return mtx; }

private:
    CscsMutex *mtx;
};

class CscsRecursiveMutexLocker:public CscsNoCopyable{
public:
    inline explicit CscsRecursiveMutexLocker(CscsRecursiveMutex *m) : mtx(m) { relock(); }
    inline ~CscsRecursiveMutexLocker() { unlock(); }

    inline void unlock() { if (mtx) mtx->unlock(); }

    inline void relock() { if (mtx) mtx->lock(); }

    inline CscsRecursiveMutex *mutex() const { return mtx; }

private:
    CscsRecursiveMutex *mtx;
};

END_NAMESPACE

#endif
