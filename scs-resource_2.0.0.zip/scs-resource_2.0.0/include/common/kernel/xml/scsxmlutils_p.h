#ifndef SCSXMLUTILSPRIV_H
#define SCSXMLUTILSPRIV_H
#include <kernel/scsstring.h>

BEGIN_NAMESPACE(Gemini)

class CscsXmlCharRange;
class  CscsXmlUtils
{
public:
    static bool isEncName(const CscsString encName);
    static bool isChar(const CscsChar c);
    static bool isNameChar(const CscsChar c);
    static bool isLetter(const CscsChar c);
    static bool isNCName(const CscsString ncName);
    static bool isPublicID(const CscsString candidate);

private:
    typedef const CscsXmlCharRange *RangeIter;
    static bool rangeContains(RangeIter begin, RangeIter end, const CscsChar c);
    static bool isBaseChar(const CscsChar c);
    static bool isDigit(const CscsChar c);
    static bool isExtender(const CscsChar c);
    static bool isIdeographic(const CscsChar c);
    static bool isCombiningChar(const CscsChar c);
};

END_NAMESPACE

#endif