#ifndef SCSOPTION_H
#define SCSOPTION_H
#include <kernel/scsstring.h>

BEGIN_NAMESPACE(Gemini)

struct CscsOption{
	unsigned int headerProtection:1;
	unsigned int copyrightHeader:1;
	unsigned int generateImplemetation:1;
	unsigned int generateNamespace:1;
	unsigned int autoConnection:1;
	unsigned int dependencies:1;

	CscsString inputFile;
	CscsString outputFile;
	CscsString indent;
	CscsString prefix;
	CscsString postfix;
	CscsString translateFunction;
	CscsString uicx; //xx?
	CscsOption()
        : headerProtection(1),
          copyrightHeader(1),
          generateImplemetation(0),
          generateNamespace(1),
          autoConnection(1),
          dependencies(0),
          prefix(CscsLatin1String("Ui_"))
    { indent.fill(CscsLatin1Char(' '), 4); }

};

END_NAMESPACE

#endif