#ifndef SCSWRITEICONDATA_H
#define SCSWRTIEICONDATA_H
#include "scstreewalker.h"

BEGIN_NAMESPACE(Gemini)

class CscsTextStream;
class CscsUIDriver;
class CscsUic;

struct CscsOption;

class CscsWriteIconData : public CscsTreeWalker
{
public:
    CscsWriteIconData(CscsUic *uic);

    void acceptUI(CscsDomUI *node);
    void acceptImages(CscsDomImages *images);
    void acceptImage(CscsDomImage *image);

private:
    CscsUIDriver *driver;
    CscsTextStream &output;
    const CscsOption &option;
};

END_NAMESPACE

#endif