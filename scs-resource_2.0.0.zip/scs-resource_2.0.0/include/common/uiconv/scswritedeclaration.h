#ifndef SCSWRITEDECLARATION_H
#define SCSWRITEDECLARATION_H
#include "scstreewalker.h"

BEGIN_NAMESPACE(Gemini)

class CscsTextStream;
class CscsUIDriver;
class CscsUic;

struct CscsOption;

struct CscsWriteDeclaration : public CscsTreeWalker
{
    CscsWriteDeclaration(CscsUic *uic);

    void acceptUI(CscsDomUI *node);
    void acceptWidget(CscsDomWidget *node);
    void acceptLayout(CscsDomLayout *node);
    void acceptSpacer(CscsDomSpacer *node);
    void acceptActionGroup(CscsDomActionGroup *node);
    void acceptAction(CscsDomAction *node);

private:
    CscsUic *uic;
    CscsUIDriver *driver;
    CscsTextStream &output;
    const CscsOption &option;
};

END_NAMESPACE

#endif