#ifndef SCSUIC_H
#define SCSUIC_H
#include "scscustomwidgetsinfo.h"
#include "scsuidatabaseinfo.h"
#include <kernel/scsstring.h>
#include <kernel/scsstringlist.h>
#include <kernel/scshash.h>
#include <kernel/scsstack.h>


BEGIN_NAMESPACE(Gemini)

class CscsTextStream;
class CscsDevice;
class CscsUIDriver;
class CscsDomUI;
class CscsDomWidget;
class CscsDomLayout;
class CscsDomLayoutItem;
class CscsDomItem;


struct CscsOption;

class CscsUic{
public:
	CscsUic(CscsUIDriver* driver);
	~CscsUic();

	bool printDependencies();

	inline CscsUIDriver* driver()const{
		return drv;
	}

	inline CscsTextStream& output(){
		return out;
	}

	inline const CscsOption& option()const{
		return opt;
	}

	inline CscsString pixmapFunction()const{
		return pixFunction;
	}

	inline void setPixmapFunction(const CscsString& f){
		pixFunction=f;
	}

	inline bool hasExternalPixmap()const{
		return externalPix;
	}

	inline void setExternalPixmap(bool b){
		externalPix=b;
	}

	inline const CscsUIDataBaseInfo* databaseInfo()const
	{
		return &info;
	}

	inline const CscsCustomWidgetsInfo* customWidgetsInfo()const{
		return &cWidgetsInfo;
	}

	bool write(CscsDevice* in);
	bool write(CscsDomUI* ui);

	bool isMainWindow(const CscsString& className)const;
	bool isToolBar(const CscsString& className)const;
	bool isStatusBar(const CscsString& className)const;
	bool isButton(const CscsString& className)const;
	bool isContainer(const CscsString& className)const;
	bool isMenuBar(const CscsString& className)const;
	bool isMenu(const CscsString& className)const;

private:
	void writeCopyrightHeader(CscsDomUI* ui);

	void writeHeaderProtectionStart();
	void writeHeaderProtectionEnd();

	CscsUIDriver* drv;
	CscsTextStream& out;
	const CscsOption& opt;

	CscsUIDataBaseInfo info;
	CscsCustomWidgetsInfo cWidgetsInfo;
	CscsString pixFunction;
	bool externalPix;
};

END_NAMESPACE

#endif