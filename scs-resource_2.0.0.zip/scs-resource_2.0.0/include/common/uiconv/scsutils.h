#ifndef SCSUTILS_H
#define SCSUTILS_H
#include "scsui.h"
#include <kernel/scsstring.h>
#include <kernel/scslist.h>
#include <kernel/scshash.h>

BEGIN_NAMESPACE(Gemini)

inline bool toBool(const CscsString &str)
{ return str.toLower() == CscsLatin1String("true"); }

inline CscsString toString(const CscsDomString *str)
{ return str ? str->text() : CscsString(); }

inline CscsString fixString(const CscsString &str)
{
	CscsByteArray utf8 = str.toUtf8();
	uint8 cbyte;
    CscsString result;

    for (int i = 0; i < utf8.length(); ++i) {
		cbyte = utf8.at(i);
		if (cbyte >= 0x80) {
			result += CscsLatin1Char('\\') + CscsString::number(cbyte, 8);
		} else {
			switch(cbyte) {
			case '\\':
				result += CscsLatin1String("\\\\"); break;
			case '\"':
				result += CscsLatin1String("\\\""); break;
			case '\r':
				break;
			case '\n':
				result += CscsLatin1String("\\n\"\n\""); break;
			default:
				result += CscsLatin1Char(cbyte);
			}
		}
    }
	return CscsLatin1String("\"") + result + CscsLatin1String("\"");
}

inline CscsHash<CscsString, CscsDomProperty *> propertyMap(const CscsList<CscsDomProperty *> &properties)
{
    CscsHash<CscsString, CscsDomProperty *> map;

    for (int i=0; i<properties.size(); ++i) {
        CscsDomProperty *p = properties.at(i);
        map.insert(p->attributeName(), p);
    }

    return map;
}

inline CscsStringList unique(const CscsStringList &lst)
{
    CscsHash<CscsString, bool> h;
    for (int i=0; i<lst.size(); ++i)
        h.insert(lst.at(i), true);
    return h.keys();
}

END_NAMESPACE

#endif