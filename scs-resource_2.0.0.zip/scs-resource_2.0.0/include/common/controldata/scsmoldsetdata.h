/*
 * Created by J.Wong 2019/10/12
 */

#ifndef SCSMOLDSETDATA_H
#define SCSMOLDSETDATA_H
#include "scsabstractcontroldata.h"
BEGIN_NAMESPACE(Gemini)

class CscsMoldSetData:public CscsAbstractControlData{
public:
	CscsMoldSetData(CscsObject* parent=nullptr);
	~CscsMoldSetData();
	
};

END_NAMESPACE
#endif