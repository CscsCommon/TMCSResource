/*
 * Created by J.Wong 2019/10/12
 */
#ifndef SCSMONIDATA_H
#define SCSMONIDATA_H
#include "scsabstractcontroldata.h"

BEGIN_NAMESPACE(Gemini)

class CscsMoniData:public CscsAbstractControlData{

public:
	CscsMoniData(CscsObject* parent=nullptr);
	~CscsMoniData();

	bool addMoniLog();
	bool clearMoniLog();
	uint moniLogCount()const;
	MoniData currentMoniLog()const;
	MoniData moniLog(uint index)const;
	std::vector<MoniData> moniLogs(uint start, uint count)const;


private:
	void prepareMoniTable();
	void prepareMoniIDs();
	uint m_shotCountID;
	static MoniData  m_currentMoniData;
	static std::vector<std::string> m_moniIDs;

}; 

END_NAMESPACE
#endif
