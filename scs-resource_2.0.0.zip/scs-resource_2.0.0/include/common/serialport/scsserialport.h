#ifndef SCSSERIALPORT_H
#define SCSSERIALPORT_H
#include <kernel/scsdevice.h>

BEGIN_NAMESPACE(Gemini)

class CscsSerialPortInfo;
class CscsSerialPortPrivate;

class  CscsSerialPort : public CscsDevice
{
    CscsSerialPortPrivate* d_func()const;
#if defined(D_WIN32)
    typedef void* Handle;
#else
    typedef int Handle;
#endif

public:

    enum Direction  {
        Input = 1,
        Output = 2,
        AllDirections = Input | Output
    };
    SCS_DECLARE_FLAGS(Directions, Direction)

    enum BaudRate {
        Baud1200 = 1200,
        Baud2400 = 2400,
        Baud4800 = 4800,
        Baud9600 = 9600,
        Baud19200 = 19200,
        Baud38400 = 38400,
        Baud57600 = 57600,
        Baud115200 = 115200,
        UnknownBaud = -1
    };

    enum DataBits {
        Data5 = 5,
        Data6 = 6,
        Data7 = 7,
        Data8 = 8,
        UnknownDataBits = -1
    };

    enum Parity {
        NoParity = 0,
        EvenParity = 2,
        OddParity = 3,
        SpaceParity = 4,
        MarkParity = 5,
        UnknownParity = -1
    };

    enum StopBits {
        OneStop = 1,
        OneAndHalfStop = 3,
        TwoStop = 2,
        UnknownStopBits = -1
    };

    enum FlowControl {
        NoFlowControl,
        HardwareControl,
        SoftwareControl,
        UnknownFlowControl = -1
    };

    enum PinoutSignal {
        NoSignal = 0x00,
        TransmittedDataSignal = 0x01,
        ReceivedDataSignal = 0x02,
        DataTerminalReadySignal = 0x04,
        DataCarrierDetectSignal = 0x08,
        DataSetReadySignal = 0x10,
        RingIndicatorSignal = 0x20,
        RequestToSendSignal = 0x40,
        ClearToSendSignal = 0x80,
        SecondaryTransmittedDataSignal = 0x100,
        SecondaryReceivedDataSignal = 0x200
    };
    SCS_DECLARE_FLAGS(PinoutSignals, PinoutSignal)


    enum SerialPortError {
        NoError,
        DeviceNotFoundError,
        PermissionError,
        OpenError,
        ParityError,
        FramingError,
        BreakConditionError,
        WriteError,
        ReadError,
        ResourceError,
        UnsupportedOperationError,
        UnknownError,
        TimeoutError,
        NotOpenError
    };

    explicit CscsSerialPort(CscsObject *parent = nullptr);
    explicit CscsSerialPort(const CscsString &name, CscsObject *parent = nullptr);
    explicit CscsSerialPort(const CscsSerialPortInfo &info, CscsObject *parent = nullptr);
    virtual ~CscsSerialPort();

    void setPortName(const CscsString &name);
    CscsString portName() const;

    void setPort(const CscsSerialPortInfo &info);

    bool open(SCSOpenMode mode) ;
    void close() ;

    bool setBaudRate(int32 baudRate, Directions directions = AllDirections);
    int32 baudRate(Directions directions = AllDirections) const;

    bool setDataBits(DataBits dataBits);
    DataBits dataBits() const;

    bool setParity(Parity parity);
    Parity parity() const;

    bool setStopBits(StopBits stopBits);
    StopBits stopBits() const;

    bool setFlowControl(FlowControl flowControl);
    FlowControl flowControl() const;

    bool setDataTerminalReady(bool set);
    bool isDataTerminalReady();

    bool setRequestToSend(bool set);
    bool isRequestToSend();

    PinoutSignals pinoutSignals();

    bool flush();
    bool clear(Directions directions = AllDirections);
    bool atEnd() const ; // ### Qt6: remove me


    SerialPortError error() const;
    void clearError();

    int64 readBufferSize() const;
    void setReadBufferSize(int64 size);

    bool isSequential() const ;

    int64 bytesAvailable() const ;
    int64 bytesToWrite() const ;
    bool canReadLine() const ;

    bool waitForReadyRead(int msecs) ;
    bool waitForBytesWritten(int msecs) ;

    bool setBreakEnabled(bool set = true);
    bool isBreakEnabled() const;

    Handle handle() const;

SIGNALS:
    void baudRateChanged(int baudRate, CscsSerialPort::Directions directions){}
    void dataBitsChanged(CscsSerialPort::DataBits dataBits){}
    void parityChanged(CscsSerialPort::Parity parity){}
    void stopBitsChanged(CscsSerialPort::StopBits stopBits){}
    void flowControlChanged(CscsSerialPort::FlowControl flowControl){}
    void dataTerminalReadyChanged(bool set){}
    void requestToSendChanged(bool set){}
    void error(CscsSerialPort::SerialPortError serialPortError){}
    void breakEnabledChanged(bool set){}

protected:
    int64 readData(char *data, int64 maxSize) ;
    int64 readLineData(char *data, int64 maxSize) ;
    int64 writeData(const char *data, int64 maxSize) ;

private:
    CscsSerialPortPrivate * const d_dummy;

};

SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsSerialPort::Directions)
SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsSerialPort::PinoutSignals)

END_NAMESPACE

#endif