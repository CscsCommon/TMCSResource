#ifndef SCSSERIALPORTINFO_H
#define SCSSERIALPORTINFO_H

#include <kernel/scslist.h>
#include <kernel/scsscopedpointer.h>
#include <kernel/scsstring.h>

BEGIN_NAMESPACE(Gemini)

class CscsSerialPort;
class CscsSerialPortInfoPrivate;
class CscsSerialPortInfoPrivateDeleter;

class  CscsSerialPortInfo
{
    CscsSerialPortInfoPrivate* d_func()const;
public:
    CscsSerialPortInfo();
    explicit CscsSerialPortInfo(const CscsSerialPort &port);
    explicit CscsSerialPortInfo(const CscsString &name);
    CscsSerialPortInfo(const CscsSerialPortInfo &other);
    ~CscsSerialPortInfo();

    CscsSerialPortInfo& operator=(const CscsSerialPortInfo &other);
    void swap(CscsSerialPortInfo &other);

    CscsString portName() const;
    CscsString systemLocation() const;
    CscsString description() const;
    CscsString manufacturer() const;
    CscsString serialNumber() const;

    uint16 vendorIdentifier() const;
    uint16 productIdentifier() const;

    bool hasVendorIdentifier() const;
    bool hasProductIdentifier() const;

    bool isNull() const;
    // bool isBusy() const;
    // bool isValid()const;

    static CscsList<int32> standardBaudRates();
    static CscsList<CscsSerialPortInfo> availablePorts();

private:
    CscsSerialPortInfo(const CscsSerialPortInfoPrivate &dd);
    friend CscsList<CscsSerialPortInfo> availablePortsByUdev(bool &ok);
    friend CscsList<CscsSerialPortInfo> availablePortsBySysfs(bool &ok);
    friend CscsList<CscsSerialPortInfo> availablePortsByFilterOfDevices(bool &ok);
    CscsScopedPointer<CscsSerialPortInfoPrivate, CscsSerialPortInfoPrivateDeleter> d_ptr;
};

inline bool CscsSerialPortInfo::isNull() const
{ return !d_ptr; }


END_NAMESPACE

#endif