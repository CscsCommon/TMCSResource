#ifndef SCSSQLITEDBOPERATOR_H
#define SCSSQLITEDBOPERATOR_H

#include <kernel/scsnocopy.hpp>
#include <kernel/scstypes.h>
#include <iostream>
#include "scssqlitedb.h"
#include <kernel/scsstring.h>


BEGIN_NAMESPACE(Gemini)
class CscsSqliteDBOperatorPrivate;
class CscsSqliteDB;

/**
**表字段附加属性
**/
enum SqliteFieldKey{
	SQLITE_NONE_KEY=0x00,
	SQLITE_NOT_NULL=0x01,
	SQLITE_PRIMARY_KEY=0x02
};

/**
**表字段对应的数据类型
**/
enum SqliteFieldType{
	SQLITE_UNKOWN_TYPE,
	SQLITE_INT2_TYPE,
	SQLITE_INT8_TYPE,
	SQLITE_INT_TYPE,
	SQLITE_INTEGER_TYPE,
	SQLITE_NUMERIC_TYPE,
	SQLITE_REAL_TYPE,
	SQLITE_TEXT_TYPE,
	SQLITE_BLOB_TYPE
};

/**
**子语句条件
**/
enum SqliteExpress{
	SQLITE_EXPRESS_NONE,/*无*/
	SQLITE_EXPRESS_EQUAL,/*=*/
	SQLITE_EXPRESS_NEQUAL,/*!=*/
	SQLITE_EXPRESS_LESS,/*<*/
	SQLITE_EXPRESS_GREATER,/*>*/
	SQLITE_EXPRESS_LE,/*<=*/
	SQLITE_EXPRESS_GE/*>=*/

};

// enum SqliteCondition{
// 	SQLITE_NONE_CONDITION,
// 	SQLITE_WHERE_CONDITION,
// 	SQLITE_OR_CONDITION,
// 	SQLITE_LIKE_CONDITION,
// 	SQLITE_LIMIT_CONDITION,
// 	SQLITE_ORDER_BY_CONDITION,
// 	SQLITE_GROUP_BY_CONDITION,
// 	SQLITE_HAVING_CONDITION,
// 	SQLITE_DISTINCT_CONDITION,
// 	SQLITE_UNION_CONDITION,
// 	SQLITE_UNION_ALL_CONDITION,
// 	SQLITE_IN_CONDITION
// };

/**
**触发器
**/
enum SqliteTrigger
{
	SQLITE_BINSERT_TRIGGER,
	SQLITE_AINSERT_TRIGGER,
	SQLITE_BUPDATE_TRIGGER,
	SQLITE_AUPDATE_TRIGGER,
	SQLITE_BDELETE_TRIGGER,
	SQLITE_ADELETE_TRIGGER
};

/**
**表连接
**/
enum SqliteConnection{
	SQLITE_NONE_CONNECTION,
	SQLITE_JOIN_CONNECTION,
	SQLITE_INNER_CONNECTION,
	SQLITE_CROSS_CONNECTION,
	SQLITE_LEFT_CONNECTION
};

enum SqliteOperator{
	SQLITE_INSERT_OPERATOR,
	SQLITE_REPLACE_OPERATOR
};

typedef struct tagSqliteField{
	std::string field;
	SqliteFieldType type;
	SqliteFieldKey key;
}SqliteField;

enum SqliteOrder{
	SQLITE_ORDER_ASCENT,
	SQLITE_ORDER_DESCENT
};


class CscsSqliteDBOperatorPrivate;
class CscsSqliteDBOperator:public CscsNoCopyable{
public:

	CscsSqliteDBOperator(CscsSqliteDB* db=nullptr);

	~CscsSqliteDBOperator();

	bool isValid()const;

	void setSqliteDB(CscsSqliteDB* db);

	CscsSqliteDB* sqliteDB()const;
	/**
	*选择当前表
	*/
	void selectTable(const std::string& tableName);
	/**
	*获取当前表名称
	**/
	std::string currentTable()const;
	/**
	** 检查当前表存在
	**/
	bool hasSelectTable()const;
	/**
	* 创建表
	*/
	template<typename... Args>
	bool createTable(const std::string& tableName, SqliteField&& first, Args&&... args){
		if(!isValid()) return false;
		std::string presqlstr="CREATE TABLE IF NOT EXISTS ";
		presqlstr+=tableName+"( ";
		std::string sqlstr=sub_combine_sqlstr_helper(first, std::forward<Args>(args)...);
		presqlstr+=sqlstr+" );";
		return execute_helper(presqlstr);
	}

	/**
	*删除表
	*/
	bool dropTable(const std::string& tableName);

	/**
	*获取数据库中的表
	**/
	std::vector<std::string> tables()const;
	
	/**
	*获取表中所有字段和字段数据类型，注意SqliteFieldKey无效
	**/
	std::vector<SqliteField> fields(const std::string& tableName)const;

	/**
	**批量操作 插入或替换准备
	**/
	template<typename... Args>
	bool prepareInsertOrReplace(SqliteOperator op, std::string&& first, Args&& ... args){
		if(!isValid()) return false;
		if(!hasSelectTable()) return false;
		std::string fieldsqlstr=do_fields_helper(first,std::forward<Args>(args)...);
		if(fieldsqlstr.empty()) return false;
		std::string opstr;
		switch(op){
			case SQLITE_REPLACE_OPERATOR:
			opstr="REPLACE INTO ";
			break;
			default:
			opstr="INSERT INTO ";
			break;
		}
		std::string presqlstr=opstr+currentTable()+" ( ";
		std::string valuesqlstr=" VALUES ( "+do_sqlstr_helper(first,std::forward<Args>(args)...);
		_sqlstr=presqlstr+fieldsqlstr+" ) "+valuesqlstr+" );";
		bool ret=sqliteDB()->prepare(_sqlstr);
		return ret;
	}

	/**
	**批量操作更新准备
	**/
	template<typename... Args>
	bool prepareUpdate(std::string&& condition, Args&& ... args){
		if(!isValid()) return false;
		if(!hasSelectTable()) return false;
		std::string fieldsqlstr=prepare_update_helper(std::forward<Args>(args)...);
		if(fieldsqlstr.empty()) return false;
		std::string presqlstr="UPDATE "+currentTable()+" SET "+fieldsqlstr;
		if(condition.empty())
			 presqlstr+=";";
		else	
			presqlstr+=condition+" ;";
		_sqlstr=presqlstr;
		bool ret=sqliteDB()->prepare(_sqlstr);
		return ret;
	}


	/**
	**批量操作数据
	**/
	template<typename... Args>
	bool executeArgs(Args&& ... args){
		if(!isValid()) return false;
		if(!hasSelectTable()) return false;
		if(_sqlstr.empty()) return false;
		return sqliteDB()->executeArgs(std::forward<Args>(args)...);
	}



	/**
	**开启事务操作
	**/
	inline bool begin()
	{
		if(!isValid()) return false;
		return sqliteDB()->begin();
	}

	/**
	**回滚
	**/
	inline bool rollBack()
	{
		if(!isValid()) return false;
		return sqliteDB()->rollBack();
	}


	/**
	**提交
	**/
	inline bool commit()
	{
		if(!isValid()) return false;
		return sqliteDB()->commit();
	}

	inline void done(){
		if(!isValid()) return ;
		sqliteDB()->done();
	}
	/**/
	/**
	**插入数据
	**/
	//单笔插入
	template <typename T, typename... Args> 
	bool insertData(T&& first, Args&& ... args){
		if(!isValid()) return false;
		if(!hasSelectTable()) return false;
		std::string sqlstr=do_sqlstr_helper(first,std::forward<Args>(args)...);
		if(sqlstr.empty()) return false;
		std::string presqlstr="INSERT INTO "+currentTable()+" VALUES( ";
		presqlstr+=sqlstr+" );";
		//std::cout<<presqlstr<<std::endl;
		return sqliteDB()->execute(presqlstr,first,std::forward<Args>(args)...);
	}

	/**
	**替换数据
	**/
	//单笔替换
	template <typename T, typename... Args> 
	bool replaceData(T&& first, Args&& ... args){
		if(!isValid()) return false;
		if(!hasSelectTable()) return false;
		std::string sqlstr=do_sqlstr_helper(first,std::forward<Args>(args)...);
		if(sqlstr.empty()) return false;
		std::string presqlstr="REPLACE INTO "+currentTable()+" VALUES( ";
		presqlstr+=sqlstr+" );";
		return sqliteDB()->execute(presqlstr,first,std::forward<Args>(args)...);
	}

	/**
	**更新数据
	**/
	//单笔更新
	template <typename T1, typename... Args>
	bool updateData(const std::string& field,T1&& fieldValue, Args&& ... args){
		if(!isValid()) return false;
		if(!hasSelectTable()) return false;
		std::string sqlstr=do_upate_helper(std::forward<Args>(args)...);
		//std::cout<<"sqlstr: "<<sqlstr<<std::endl;
		if(sqlstr.empty()) return false;
		std::string presqlstr="UPDATE "+currentTable()+" SET ";
		presqlstr+=sqlstr+" WHERE "+field+" = "+field_value_helper(fieldValue)+" ;";
		//std::cout<<presqlstr<<std::endl;
		return sqliteDB()->execute(presqlstr);
	}

	/**
	**查询数据
	**/

	template<typename... Args>
	std::shared_ptr<CscsList<CscsSqliteVariantVector> > query(std::string&& condition, Args&& ... args){
		if(!isValid()) return nullptr;
		if(!hasSelectTable()) return nullptr;
		std::string fieldsqlstr=do_fields_helper(std::forward<Args>(args)...);
		if(fieldsqlstr.empty()) return nullptr;
		std::string presqlstr="SELECT "+fieldsqlstr+" FROM "+currentTable()+" ";
		if(condition.empty())
			 presqlstr+=";";
		else	
			presqlstr+=condition+" ;";

		// std::cout<<presqlstr<<std::endl;
		return sqliteDB()->query(presqlstr);;
	}

	/**
	**导出当前表数据保存到json文件
	**注意不支持嵌套
	**
	**/
	bool exportTable(const std::string& fileName);
	/**
	**导入json文件数据到当前表
	**注意不支持嵌套
	**只支持符合exportTable函数导出格式的json文件
	**/
	bool importTable(const std::string& fileName);



	//condition
	template<typename... Args>
	std::string orderBy(SqliteOrder order,const std::string& field,Args&&... args)const{
		std::string sqlstr=" ORDER BY ";
		sqlstr+=orderby_helper(field,std::forward<Args>(args)...);
		switch(order){
			SQLITE_ORDER_DESCENT:
				sqlstr+=" DESC ";
			break;
			default:
				sqlstr+=" ASC ";
			break;
		}
		return sqlstr; 
	}

	template<typename T>
	std::string where(SqliteExpress expr, const std::string& field, T&& value)const{
		CscsString sqlstr(" WHERE ");
		sqlstr.append(field.data());
		switch(expr){
			case SQLITE_EXPRESS_NEQUAL:
			sqlstr.append(" != ");
			break;
			case SQLITE_EXPRESS_LESS:
			sqlstr.append(" < ");
			break;
			case SQLITE_EXPRESS_GREATER:
			sqlstr.append(" > ");
			break;
			case SQLITE_EXPRESS_LE:
			sqlstr.append(" <= ");
			break;
			case SQLITE_EXPRESS_GE:
			sqlstr.append(" >= ");
			break;
			default:
			sqlstr.append(" = ");
			break;
		}

		sqlstr.append(field_value_helper(value).data());
		return sqlstr.toStdString()+" ";

	}

	std::string like(const std::string& field, const std::string& value)const{
		std::string sqlstr=" WHERE ";
		sqlstr+=field+" LIKE "+"\'"+value+"\'";
		return sqlstr;
	}

	template<typename T>
	std::string Or(SqliteExpress expr,const std::string& field, T&& value)const{
		CscsString sqlstr(" OR ");
		sqlstr.append(field.data());
		switch(expr){
			case SQLITE_EXPRESS_NEQUAL:
			sqlstr.append(" != ");
			break;
			case SQLITE_EXPRESS_LESS:
			sqlstr.append(" < ");
			break;
			case SQLITE_EXPRESS_GREATER:
			sqlstr.append(" > ");
			break;
			case SQLITE_EXPRESS_LE:
			sqlstr.append(" <= ");
			break;
			case SQLITE_EXPRESS_GE:
			sqlstr.append(" >= ");
			break;
			default:
			sqlstr.append(" = ");
			break;
		}

		sqlstr.append(field_value_helper(value).data());
		return sqlstr.toStdString()+" ";
	}

	template<typename T>
	std::string And(SqliteExpress expr,const std::string& field, T&& value)const{
		CscsString sqlstr(" AND ");
		sqlstr.append(field.data());
		switch(expr){
			case SQLITE_EXPRESS_NEQUAL:
			sqlstr.append(" != ");
			break;
			case SQLITE_EXPRESS_LESS:
			sqlstr.append(" < ");
			break;
			case SQLITE_EXPRESS_GREATER:
			sqlstr.append(" > ");
			break;
			case SQLITE_EXPRESS_LE:
			sqlstr.append(" <= ");
			break;
			case SQLITE_EXPRESS_GE:
			sqlstr.append(" >= ");
			break;
			default:
			sqlstr.append(" = ");
			break;
		}

		sqlstr.append(field_value_helper(value).data());
		return sqlstr.toStdString()+" ";
	}


	std::string limit(uint rows, uint offset)const{
		CscsString sqlstr;
		sqlstr.append(" LIMIT ").append(CscsString::number(rows)).append(" OFFSET ").append(CscsString::number(offset));
		return sqlstr.toStdString();
	}

	template<typename... Args>
	std::string groupBy(const std::string& first, Args&&... args)const{
		std::string presqlstr=" GROUP BY "+first;
		std::string sqlstr=do_fields_helper(std::forward<Args>(args)...);
		if(!sqlstr.empty()) presqlstr+=" , ";
		return presqlstr+sqlstr;
	}

	/*配合groupBy使用*/
	template<typename T>
	std::string having(SqliteExpress expr,const std::string& field, T&& value)const{
		CscsString sqlstr(" HAVING ");
		sqlstr.append(field.data());
		switch(expr){
			case SQLITE_EXPRESS_NEQUAL:
			sqlstr.append(" != ");
			break;
			case SQLITE_EXPRESS_LESS:
			sqlstr.append(" < ");
			break;
			case SQLITE_EXPRESS_GREATER:
			sqlstr.append(" > ");
			break;
			case SQLITE_EXPRESS_LE:
			sqlstr.append(" <= ");
			break;
			case SQLITE_EXPRESS_GE:
			sqlstr.append(" >= ");
			break;
			default:
			sqlstr.append(" = ");
			break;
		}

		sqlstr.append(field_value_helper(value).data());
		return sqlstr.toStdString()+" ";
	}

	template<typename T>
	std::string in(const std::string& field, const std::vector<T>& values )const{
		if(values.empty()) return std::string();
		std::string sqlstr="WHERE ";
		sqlstr+=field+" IN ( ";
		size_t i=0;
		for(; i<values.size()-1;++i){
			sqlstr+=field_value_helper(values[i])+" , ";
		}
		sqlstr+=field_value_helper(values[i])+" )";
		return sqlstr;
	}

	template<typename... Args>
	std::string in(const std::string& field, Args&&... args)const{

		std::string sqlstr=in_helper(std::forward<Args>(args)...);
		if(sqlstr.empty()) return std::string();
		std::string presqlstr="WHERE ";
		presqlstr+=field+" IN ( ";
		presqlstr+=sqlstr+" )";
		return presqlstr;

	}

private:

	template<typename SqliteField, typename... Args>
	std::string sub_combine_sqlstr_helper(SqliteField&& first, Args&&... args)const{
		std::string presqlstr=first.field;
		switch(first.type){
			case SQLITE_INT2_TYPE:
			presqlstr+=" INT2 ";
			break;
			case SQLITE_INT8_TYPE:
			presqlstr+=" INT8 ";
			break;
			case SQLITE_INT_TYPE:
			presqlstr+=" INT ";
			break;
			case SQLITE_INTEGER_TYPE:
			presqlstr+=" INTEGER ";
			break;
			case SQLITE_NUMERIC_TYPE:
			presqlstr+=" NUMERIC ";
			break;
			case SQLITE_REAL_TYPE:
			presqlstr+=" REAL ";
			break;
			case SQLITE_TEXT_TYPE:
			presqlstr+=" TEXT ";
			break;
			case SQLITE_BLOB_TYPE:
			presqlstr+=" BLOB ";
			default:
			assert(false);
			break;
		}

		if(first.key&SQLITE_PRIMARY_KEY){
			presqlstr+=" PRIMARY KEY ";
		}

		if(first.key&SQLITE_NOT_NULL){
			presqlstr+=" NOT NULL ";
		}

		std::string sqlstr=sub_combine_sqlstr_helper(std::forward<Args>(args)...);
		if(!sqlstr.empty())
			presqlstr+=", "+sqlstr; 
		return presqlstr;
	}

	std::string sub_combine_sqlstr_helper()const{
		return std::string();
	}

	bool execute_helper(const std::string& sqlstr)const;

	template <typename T, typename... Args> 
	std::string do_sqlstr_helper(T&& first, Args&& ... args)const{

		std::string presqlstr=" ?";
		std::string sqlstr=do_sqlstr_helper(std::forward<Args>(args)...);
		if(!sqlstr.empty()){
			presqlstr+=", "+sqlstr;
		}
		return presqlstr;
	}

	std::string do_sqlstr_helper()const{
		return std::string();
	}


	template <typename T,typename... Args> 
	std::string do_fields_helper(T&& first, Args&& ... args)const{

		std::string presqlstr=first;
		std::string sqlstr=do_fields_helper(std::forward<Args>(args)...);
		if(!sqlstr.empty()){
			presqlstr+=", "+sqlstr;
		}
		return presqlstr;
	}

	std::string do_fields_helper()const{
		return std::string();
	}

	template <typename T,typename... Args> 
	std::string prepare_update_helper(T&& first, Args&& ... args)const{

		std::string presqlstr=first;
		std::string sqlstr=prepare_update_helper(std::forward<Args>(args)...);
		if(!sqlstr.empty()){
			presqlstr+="=?, "+sqlstr;
		}
		else
			presqlstr+="=? ";
		return presqlstr;
	}

	std::string prepare_update_helper()const{
		return std::string();
	}

	template<typename ...Args>
	std::string orderby_helper(const std::string& field,Args&&... args)const{

		std::string sqlstr=orderby_helper(std::forward<Args>(args)...);
		if(sqlstr.empty()) return field;
		return field+" , "+sqlstr;
	}

	std::string orderby_helper()const{
		return std::string();
	}

	template<typename T, typename... Args>
	std::string in_helper(T&& val, Args&&... args)const{
		std::string presqlstr=field_value_helper(val);
		std::string sqlstr=in_helper(std::forward<Args>(args)...);
		if(!sqlstr.empty()) presqlstr+=" ,"+sqlstr;
		return presqlstr;
	}

	std::string in_helper()const{
		return std::string();
	}

	template<typename FieldValue, typename... Args>
	std::string do_upate_helper(const std::string& field, FieldValue&& fieldValue, Args&&... args)const{
		std::string presqlstr=field+ " = "+field_value_helper(fieldValue);
		std::string sqlstr=do_upate_helper(std::forward<Args>(args)...);
		if(!sqlstr.empty()) presqlstr+=" , "+sqlstr;
		return presqlstr;

	}

	std::string do_upate_helper()const{
		return std::string();
	}

template<typename T>
typename std::enable_if<std::is_same<typename std::remove_reference<T>::type,char*>::value||std::is_same<typename std::remove_reference<T>::type,const char*>::value,std::string>::type
field_value_helper(T&& v)const{
	std::string sqlstr;
	if(strcmp(v,"?")==0) sqlstr+="?";
	else{
		sqlstr+="\'";
		sqlstr+=std::string(v)+"\'";
	}
	return sqlstr;
}


template<typename T>
typename std::enable_if<std::is_same<typename std::remove_const<typename std::remove_reference<T>::type>::type,std::string>::value,std::string>::type
field_value_helper(T&& v)const{
	std::string sqlstr;
	if(v=="?") sqlstr+="?";
	else{
		sqlstr+="\'";
		sqlstr+=v+"\'";
	}
	return sqlstr;
}

template<typename T>
typename std::enable_if<!std::is_same<typename std::remove_const<typename std::remove_reference<T>::type>::type,std::string>::value
&&!(std::is_same<typename std::remove_reference<T>::type,char*>::value||std::is_same<typename std::remove_reference<T>::type,const char*>::value),std::string>::type
field_value_helper(T&& v)const{
	return CscsString::number(v).toStdString();
}


private:
	CscsSqliteDBOperatorPrivate* d;
	std::string _sqlstr;
};

END_NAMESPACE

#endif