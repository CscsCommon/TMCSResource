#ifndef SCSMEMORYDATAOPERATOR_H
#define SCSMEMORYDATAOPERATOR_H
#include "scsabstractdataoperator.h"
#include <kernel/scshash.h>

BEGIN_NAMESPACE(Gemini)

class CscsByteArray;

class CscsMemoryDataElement;

class CscsMemoryDataOperator:public CscsAbstractDataOperator{
	public:
		CscsMemoryDataOperator(int initialMaxDataCount=10000,CscsObject* parent=nullptr);
		virtual ~CscsMemoryDataOperator();
		int dataCount()const;
		int maxDataCount()const;
		int castUIDFromStringKey(const std::string& key);
		std::string castStringKeyFromUID(int uid);
		void writeAsBool(int uid, bool value,
				CscsDataSensorEvent::DataMerge merge=CscsDataSensorEvent::Enable);
		void writeAsInt(int uid, int value,
				CscsDataSensorEvent::DataMerge merge=CscsDataSensorEvent::Enable);
		void writeAsDouble(int uid, double value,
				CscsDataSensorEvent::DataMerge merge=CscsDataSensorEvent::Enable);
		void writeAsByteArray(int uid, const CscsByteArray& value,
				CscsDataSensorEvent::DataMerge merge=CscsDataSensorEvent::Enable);
		void writeAsAny(int uid,const CscsVariant& value,CscsDataSensorEvent::SensorType type, CscsDataSensorEvent::DataMerge merge);
		bool      readAsBool(int uid)const;
		double    readAsDouble(int uid)const;
		int    	  readAsInt(int uid)const;
		CscsByteArray readAsByteArray(int uid)const;
		CscsVariant   readAsAny(int uid)const;

		void notify(int uid,CscsDataSensorEvent::DataMerge merge=CscsDataSensorEvent::Enable);

	private:
		int dataMaxCount;
		CscsHash<int, CscsMemoryDataElement*> dataset;
};

END_NAMESPACE


#endif