/*
 * Created by J.W 2019/5/28
 */

#ifndef SCSSQLITEVARIANTVECTOR_H
#define SCSSQLITEVARIANTVECTOR_H
#include <kernel/scsvector.h>
#include <kernel/scsstring.h>
#include "scsdatabase.h"

BEGIN_NAMESPACE(Gemini)

class CscsSqliteVariantVector:public CscsVector<SqliteValue>{
public:

	CscsSqliteVariantVector(){}

	template<typename T>
	inline T get(int index){

		return toValue<T>(index);
	}

private:
	template<typename R>
	typename std::enable_if<std::is_floating_point<R>::value,R>::type
	toValue(int index){

		assert(index>=0||index<count());
		if(value(index).isNull())
			return 0.0;
		SqliteValue val=value(index);
		if(val.is<int64_t>()){
			return val.get<int64_t>();
		}
		else if(val.is<string>()){
			return 0.0;
		}
		return val.get<double>();
	}

	template<typename R>
	typename std::enable_if<std::is_same<nullptr_t,R>::value,R>::type
	toValue(int index){
		return nullptr;
	}

	template<typename R>
	typename std::enable_if<std::is_integral<R>::value,int64_t>::type
	toValue(int index){
		assert(index>=0||index<count());
		if(value(index).isNull())
			return 0;
		SqliteValue val=value(index);
		if(val.is<string>()){
			return 0;
		}
		else if(val.is<double>()){
			return val.get<double>();
		}
		return val.get<int64_t>();
	}

	template<typename R>
	typename std::enable_if<std::is_same<std::string,R>::value,R>::type
	toValue(int index) {
		assert(index>=0||index<count());
		if(value(index).isNull())
			return std::string();
		SqliteValue val=value(index);
		if(val.is<double>()){
			return CscsString::number(val.get<double>()).toStdString();
		}
		else if(val.is<int64_t>()){
			return CscsString::number(val.get<int64_t>()).toStdString();
		}
		return val.get<string>();
	}

	template<typename R>
	typename std::enable_if<std::is_same<blob,R>::value,R>::type
	toValue(int index) {
		assert(index>=0||index<count());
		if(value(index).isNull())
			return blob{0,0};
		SqliteValue val=value(index);
		std::string valb;
		if(val.is<double>()){
			valb=CscsString::number(val.get<double>()).toStdString();
		}
		else if(val.is<int64_t>()){
			valb=CscsString::number(val.get<int64_t>()).toStdString();
		}
		else
			valb=val.get<string>();
		
		blob b{valb.data(),valb.size()};
		return b;
	}

	template<typename R>
	typename std::enable_if<std::is_same<char*,R>::value||std::is_same<const char*,R>::value,R>::type
	toValue(int index){
		assert(index>=0||index<count());
		if(value(index).isNull())
			return nullptr;
		std::string valb;
		SqliteValue val=value(index);
		if(val.is<double>()){
			valb=CscsString::number(val.get<double>()).toStdString();
		}
		else if(val.is<int64_t>()){
			valb=CscsString::number(val.get<int64_t>()).toStdString();
		}
		valb=val.get<string>();
		//it is a temperory data!!!
		return valb.data();

		// char* data=new[valb.size()];
		// memcpy(data,val.data(),valb.size());
		// return data;
	}

};
SCS_DECLARE_TYPENAME_INFO(CscsSqliteVariantVector,SCS_MOVABLE_TYPE)
END_NAMESPACE
#endif