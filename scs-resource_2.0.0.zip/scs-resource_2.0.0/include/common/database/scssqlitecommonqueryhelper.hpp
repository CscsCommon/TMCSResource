/*
 * Created by J.W 2019/05/28
 */
#ifndef SCSSQLITECOMMONQUERYHELPER_HPP
#define SCSSQLITECOMMONQUERYHELPER_HPP
#include "scssqlitevariantvector.h"
#include <kernel/scslist.h>

BEGIN_NAMESPACE(Gemini)

class CscsSqliteCommonQueryHelper{
public:
	CscsSqliteCommonQueryHelper(){}
	std::shared_ptr<CscsList<CscsSqliteVariantVector> >
	buildCommonQuery(sqlite3_stmt* stmt){
		auto list = std::make_shared<CscsList<CscsSqliteVariantVector> >();
		int colCount = sqlite3_column_count(stmt);
		while (true)
		{
			int m_code = sqlite3_step(stmt);
			if (m_code == SQLITE_DONE)
			{
				break;
			}
			list->append(readValues(stmt,colCount));
		}
		sqlite3_reset(stmt);
		return list;
	}

private:

	CscsSqliteVariantVector readValues(sqlite3_stmt* stmt, int count){
		CscsSqliteVariantVector values;
		// values.resize(count);

		for (int i = 0; i < count; ++i)
		{
			values.append(readValue(stmt, i));
		}
		//std::cout<<"values: "<<values.count()<<std::endl;
		return values;
		
	}

	SqliteValue readValue(sqlite3_stmt* stmt, int current){
		int type = sqlite3_column_type(stmt, current);
		auto it = m_valmap.find(type);
		if (it == m_valmap.end())
			throw std::invalid_argument("can not find this type");

		return it->second(stmt, current);
	}

	static std::unordered_map<int, std::function<SqliteValue(sqlite3_stmt*, int )> >m_valmap;

};

END_NAMESPACE
#endif