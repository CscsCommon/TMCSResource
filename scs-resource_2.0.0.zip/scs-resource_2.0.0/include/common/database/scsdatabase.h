/*
 * Created by J.W 2019/05/26
 */
#ifndef SCSDATABASE_H
#define SCSDATABASE_H

#include "scsmultiany.h"
#include <sqlite3.h>
#include <atomic>
#include <string.h>
#include <kernel/scstypes.h>
BEGIN_NAMESPACE(Gemini)


struct blob_data{
	char *pBuf;
	int size;
	std::atomic<int> ref;
};
struct blob
{
	blob(char* buf=0,int sz=0){
		d=new blob_data;
		d->ref=1;
		if(sz>0){
			d->size=sz;
			d->pBuf=new char[sz];
			::memcpy(d->pBuf,buf,sz);
		}
		else{
			d->size=0;
			d->pBuf=0;
		}
	}
	~blob(){
		if(!--d->ref){
			if(d->pBuf){
				delete[]d->pBuf;
				d->pBuf=0;
			}
			d->size=0;
			delete d;
		}
	}

	blob(const blob& b):d(b.d){
		d->ref++;
	}

 	blob& operator=(const blob& b){
 		if(!--d->ref){
			if(d->pBuf){
				delete[]d->pBuf;
				d->pBuf=0;
			}
			d->size=0;
		}
 		d=b.d;
 		d->ref++;
 		return *this;
 	}

 	char* pBuf()const{
 		return d->pBuf;
 	}

 	int size()const{

 		return d->size;
 	}
private:
	blob_data* d;
};

/**
*类型定义，数据库操作要用到的类型，如表、行、字段和值等类型
*/
typedef CscsMultiAny< int, uint32_t,double, sqlite3_int64, char*, const char*, blob, std::string, nullptr_t> SqliteValue;	//数据表中的值类型


END_NAMESPACE

#endif