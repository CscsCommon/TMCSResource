/*
 * Created by J.W 2019/05/26
 */
#ifndef SCSJSON_H
#define SCSJSON_H
/*
*CscsJson类
*文件标识：
*摘要：json序列化类，将结构体序列化成字符串；
 结构体必须提供字段名和字段值信息；
 结构体中不能有指针类型，可以是char定长数组；
 结构体中可以嵌套结构体，但是嵌套的结构体中不能有指针
*/

#include <string>
#include <kernel/rapidjson/writer.h>
#include <kernel/rapidjson/stringbuffer.h>
#include <kernel/rapidjson/document.h>
#include <kernel/scsnamespace.h>
#include <kernel/scsstring.h>

using namespace rapidjson;

BEGIN_NAMESPACE(Gemini)

typedef StringBuffer JsonBuffer;
typedef Document::AllocatorType JsonAllocatorType;

class CscsJson{
	typedef Writer<StringBuffer> JsonWriter;
public:
	CscsJson():m_writer(m_buf){

	}

	// CscsJson(StringBuffer buffer):m_writer(buffer),m_buf(buffer){

	// }

	~CscsJson(){

	}
	/**
	* 序列化结构体数组之前需调用此接口，然后再循环去Serialize
	*/
	void startArray(){
		m_writer.StartArray();
	}
	/**
	* 序列化结构体数组之后需调用此接口，循环Serialize完成之后调用
	*/
	void endArray(){
		m_writer.EndArray();
	}

	void startObject(){
		m_writer.StartObject();
	}

	void endObject()
	{
		m_writer.EndObject();
	}

	template<typename T>
	void writeJson(const std::string& key, T&& value){
		m_writer.String(key.c_str());
		writeValue(std::forward<T>(value));
	}

	template<typename T>
	void writeJson(const char* key, T&& value){
		m_writer.String(key);
		writeValue(std::forward<T>(value));
	}

	template<typename T>
	void writeJson(const CscsString& key, T&& value){
		m_writer.String(key.toUtf8().data());
		writeValue(std::forward<T>(value));
	}

	///**
	//* 返回对象序列化后端json字符串
	//*/
	const char* toString() const
	{
		return m_buf.GetString();
	}

private:
	template<typename T>
	typename std::enable_if<std::is_same<T, int>::value>::type 
	writeValue(T value){
		m_writer.Int(value);
	}

	template<typename T>
	typename std::enable_if<std::is_same<T,unsigned int>::value>::type
	writeValue(T value){
		m_writer.Uint(value);
	}

	template<typename T>
	typename std::enable_if<std::is_same<T,int64_t>::value>::type
	writeValue(T value){
		m_writer.Int64(value);
	}
	template<typename T>
	typename std::enable_if<std::is_floating_point<T>::value>::type
	writeValue(T value){
		m_writer.Double(value);
	}

	template<typename T>
	typename std::enable_if<std::is_same<T, bool>::value>::type
	writeValue(T value){
		m_writer.Bool(value);
	}

	template<typename T>
	typename std::enable_if<std::is_pointer<T>::value>::type
	writeValue(T value)
	{
		m_writer.String(value);
	}

	template<typename T>
	typename std::enable_if<std::is_array<T>::value>::type
	writeValue(T value)
	{
		m_writer.String(value);
	}

	template<typename T>
	typename std::enable_if<std::is_same<T, std::nullptr_t>::value>::type
	writeValue(T value)
	{
		m_writer.Null();
	}



private:
	StringBuffer m_buf; //json字符串的buf
	JsonWriter m_writer; //json写入器
	friend class CscsJsonDocument;
};

class CscsJsonValue{
public:
	typedef Value JsonValue;
	enum Type {
		JsonNullType = 0,		//!< null
		JsonFalseType = 1,		//!< false
		JsonTrueType = 2,		//!< true
		JsonObjectType = 3,		//!< object
		JsonArrayType = 4,		//!< array 
		JsonStringType = 5,		//!< string
		JsonNumberType = 6,		//!< number
	};

	CscsJsonValue(Type type):val(static_cast<rapidjson::Type>(type)){

	}

	CscsJsonValue(bool b):val(b){

	}

	CscsJsonValue(int i):val(i){

	}

	CscsJsonValue(uint i):val(i){

	}

	CscsJsonValue(int64_t i):val(i){

	}

	CscsJsonValue(uint64_t i):val(i){

	}

	CscsJsonValue(double d):val(d){

	}

	CscsJsonValue(const std::string value):val(value.data(),value.size()){

	}

	inline void setObject(){
		val.SetObject();
	}

	inline void setNull(){
		val.SetNull();
	}

	inline void setBool(bool b){
		val.SetBool(b);
	}

	inline void setInt(int i){
		val.SetInt(i);
	}

	inline void setUint(uint i){
		val.SetUint(i);
	}

	inline void setInt64(int64_t i){
		val.SetInt64(i);
	}

	inline void setUint64(uint64_t i){
		val.SetUint64(i);
	}

	inline void setDouble(double d){
		val.SetDouble(d);
	}

	inline void setString(const std::string& data){
		val.SetString(data.data(),data.size());
	}


	inline bool getBool()const{
		return val.GetBool();
	}

	inline int getInt()const{
		return val.GetInt();
	}

	inline uint getUint()const{
		return val.GetUint();
	}

	inline int64_t getInt64()const{
		return val.GetInt64();
	}

	inline uint64_t getUint64()const{
		return val.GetUint64();
	}

	inline double getDouble()const{
		return val.GetDouble();
	}
	
	inline std::string getString()const{
		return std::string(val.GetString());
	}

	inline void setArray(){
		val.SetArray();
	}

	inline size_t count(){
		return val.Size();
	}

	inline void clear(){
		val.Clear();
	}

	inline bool isEmpty(){
		return val.Empty();
	}

	inline Type type()const{
		return static_cast<Type>(val.GetType());
	}

	inline bool isNull()const{
		return val.IsNull();
	}

	inline bool isFalse()const{
		return val.IsFalse();
	}

	inline bool isTrue()const{
		return val.IsTrue();
	}

	inline bool isInt()const{
		return val.IsInt();
	}

	inline bool isUint()const{
		return val.IsUint();
	}

	inline bool isInt64()const{
		return val.IsInt64();
	}

	inline bool isUint64()const{
		return val.IsUint64();
	}

	inline bool isDouble()const{
		return val.IsDouble();
	}

	inline bool isString()const{
		return val.IsString();
	}

	inline bool isArray()const{
		return val.IsArray();
	}

	inline bool isObject()const{
		return val.IsObject();
	}


	template <typename T>
	inline void addMember(const std::string& name, T value, JsonAllocatorType& allocator){
		addBasicMember(name.data(),value,allocator);
	}

	bool hasMember(const std::string& name){
		return val.HasMember(name.data());
	}

	bool removeMember(const std::string& name){
		return val.RemoveMember(name.data());
	}

	void popBack(){

		val.PopBack();
	}

	void pushBack(CscsJsonValue& value, JsonAllocatorType& allocator){
		val.PushBack(value.val,allocator);
	}

	template<typename T>
	void pushBack(T value, JsonAllocatorType& allocator){
		CscsJsonValue v(value);
		val.PushBack(v.val,allocator);
	}


private:

	JsonValue val;

	friend class CscsJsonDocument;
	template<typename T>
	typename std::enable_if<std::is_arithmetic<T>::value, void>::type
	addBasicMember(const std::string& name, T value, JsonAllocatorType& allocator){
		val.AddMember(name.data(),value,allocator);
	}

	template<typename T>
	typename std::enable_if<std::is_same<char*,T>::value||std::is_same<const char*, T>::value, void>::type
	addBasicMember(const std::string& name, T value, JsonAllocatorType& allocator){
		val.AddMember(name.data(),value, allocator);
	}

	template<typename T>
	typename std::enable_if<std::is_same<std::string,T>::value>::type
	addBasicMember(const std::string& name, T value, JsonAllocatorType& allocator){
		val.AddMember(name.data(),value.data(),allocator);
	}

	template<typename T>
	typename std::enable_if<std::is_same<CscsJsonValue,T>::value>::type
	addBasicMember(const std::string& name, T value, JsonAllocatorType& allocator){
		val.AddMember(name.data(),value.val,allocator);
	}
};


class CscsJsonDocument{
public:

	CscsJsonDocument(){
		
	}

	inline void parse(const JsonBuffer& buffer){
		doc.Parse<0>(buffer.GetString());
	}

	inline void parse(const std::string& buffer){
		doc.Parse<0>(buffer.c_str());
	}

	inline void accept(CscsJson& json){
		doc.Accept(json.m_writer);
	}

	inline size_t count(){
		return doc.Size();
	}

	inline void setObject(){
		doc.SetObject();
	}

	inline JsonAllocatorType& allocator(){
		return doc.GetAllocator();
	}

	template <typename T>
	inline void addMember(const std::string& name, T value, JsonAllocatorType& allocator){
		addBasicMember(name.data(),value,allocator);
	}

	bool hasMember(const std::string& name){
		return doc.HasMember(name.data());
	}

	bool removeMember(const std::string& name){
		return doc.RemoveMember(name.data());
	}

	bool isEmpty()const{
		return doc.Empty();
	}

	void clear(){
		doc.Clear();
	}

	~CscsJsonDocument(){

	}

private:
	Document doc;
	StringBuffer m_buf;

	template<typename T>
	typename std::enable_if<std::is_arithmetic<T>::value, void>::type
	addBasicMember(const std::string& name, T value, JsonAllocatorType& allocator){
		doc.AddMember(name.data(),value,allocator);
	}

	template<typename T>
	typename std::enable_if<std::is_same<char*,T>::value||std::is_same<const char*, T>::value, void>::type
	addBasicMember(const std::string& name, T value, JsonAllocatorType& allocator){
		doc.AddMember(name.data(),value, allocator);
	}

	template<typename T>
	typename std::enable_if<std::is_same<std::string,T>::value>::type
	addBasicMember(const std::string& name, T value, JsonAllocatorType& allocator){
		doc.AddMember(name.data(),value.data(),allocator);
	}

	template<typename T>
	typename std::enable_if<std::is_same<CscsJsonValue,T>::value>::type
	addBasicMember(const std::string& name, T value, JsonAllocatorType& allocator){
		doc.AddMember(name.data(),value.val,allocator);
	}
};
END_NAMESPACE

#endif