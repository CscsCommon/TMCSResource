#ifndef SCSCOMMSOURCEFACTORY_H
#define SCSCOMMSOURCEFACTORY_H
#include <protocol/scsabstractcommsource.h>

BEGIN_NAMESPACE(Gemini)

class CscsCommSourceFactory{

public:
    static CscsCommSourceFactory *instance();
    static void ruinInstance(CscsAbstractCommSource::CommType type);

    CscsAbstractCommSource *get(CscsAbstractCommSource::CommType type);
    void setCommSource(CscsAbstractCommSource::CommType type, CscsAbstractCommSource* source);

private:
    CscsCommSourceFactory();
    ~CscsCommSourceFactory();

    static CscsCommSourceFactory    *m_factory;
    static CscsAbstractCommSource   *m_plc;
    static CscsAbstractCommSource   *m_dsp55;
	static CscsAbstractCommSource   *m_dsp28;
    static std::map<uint, CscsAbstractCommSource*> m_customs;

};

END_NAMESPACE

#endif