#ifndef SCSTABLEVIEW_H
#define SCSTABLEVIEW_H
#include "scsabstractitemview.h"
#include <painting/scspen.h>

BEGIN_NAMESPACE(Gemini)
class CscsHeaderView;
class CscsTableViewPrivate;

class WIDGET_EXPORT CscsTableView : public CscsAbstractItemView
{

public:
    explicit CscsTableView(CscsWidget *parent = nullptr);
    ~CscsTableView();

    void setModel(CscsAbstractItemModel *model);
    void setRootIndex(const CscsModelIndex &index);
    void setSelectionModel(CscsItemSelectionModel *selectionModel);

    CscsHeaderView *horizontalHeader() const;
    CscsHeaderView *verticalHeader() const;
    void setHorizontalHeader(CscsHeaderView *header);
    void setVerticalHeader(CscsHeaderView *header);

    int rowViewportPosition(int row) const;
    int rowAt(int y) const;

    void setRowHeight(int row, int height);
    int rowHeight(int row) const;
    

    int columnViewportPosition(int column) const;
    int columnAt(int x) const;

    void setColumnWidth(int column, int width);
    int columnWidth(int column) const;
    

    bool isRowHidden(int row) const;
    void setRowHidden(int row, bool hide);

    bool isColumnHidden(int column) const;
    void setColumnHidden(int column, bool hide);
    void setSortingEnabled(bool enable);
    bool isSortingEnabled() const;

    bool showGrid() const;
    

    CscsPen::PenType gridStyle() const;
    void setGridStyle(CscsPen::PenType style);

    void setWordWrap(bool on);
    bool wordWrap() const;

    void setCornerButtonEnabled(bool enable);
    bool isCornerButtonEnabled() const;

    CscsRect visualRect(const CscsModelIndex &index) const;
    void scrollTo(const CscsModelIndex &index, ScrollHint hint = EnsureVisible);
    CscsModelIndex indexAt(const CscsPoint &p) const;

    void setSpan(int row, int column, int rowSpan, int columnSpan);
    int rowSpan(int row, int column) const;
    int columnSpan(int row, int column) const;
    void clearSpans();

    void sortByColumn(int column, SCS::SortOrder order);

SLOTS:
    void selectRow(int row);
    void selectColumn(int column);
    void hideRow(int row);
    void hideColumn(int column);
    void showRow(int row);
    void showColumn(int column);
    void resizeRowToContents(int row);
    void resizeRowsToContents();
    void resizeColumnToContents(int column);
    void resizeColumnsToContents();
    void sortByColumn(int column);
    void setShowGrid(bool show);

protected:
    void rowMoved(int row, int oldIndex, int newIndex);
    void columnMoved(int column, int oldIndex, int newIndex);
    void rowResized(int row, int oldHeight, int newHeight);
    void columnResized(int column, int oldWidth, int newWidth);
    void rowCountChanged(int oldCount, int newCount);
    void columnCountChanged(int oldCount, int newCount);

protected:
    CscsTableView(CscsTableViewPrivate*, CscsWidget *parent);
    void scrollContentsBy(int dx, int dy);

    CscsStyleOptionViewItem viewOptions() const;
    void paintEvent(CscsPaintEvent *e);
    void timerEvent(CscsTimerEvent *event);

    int horizontalOffset() const;
    int verticalOffset() const;
    CscsModelIndex moveCursor(CursorAction cursorAction, SCS::KeyboardModifiers modifiers);

    void setSelection(const CscsRect &rect, CscsItemSelectionModel::SelectionFlags command);
    CscsRegion visualRegionForSelection(const CscsItemSelection &selection) const;
    CscsModelIndexList selectedIndexes() const;

    void updateGeometries();

    int sizeHintForRow(int row) const;
    int sizeHintForColumn(int column) const;

    void verticalScrollbarAction(int action);
    void horizontalScrollbarAction(int action);

    bool isIndexHidden(const CscsModelIndex &index) const;

    void selectionChanged(const CscsItemSelection &selected,
                          const CscsItemSelection &deselected);

    void currentChanged(const CscsModelIndex &current,
                          const CscsModelIndex &previous);

private:
    CscsTableViewPrivate* d_func()const;
    friend class CscsTableViewPrivate;
    int visualIndex(const CscsModelIndex &index) const;

BEGIN_PROPERTY(CscsTableView,CscsAbstractItemView)
    META_PROPERTY(bool, showGrid, READ, showGrid, WRITE, setShowGrid)
    META_PROPERTY(CscsPen::PenType, gridStyle, READ, gridStyle, WRITE ,setGridStyle)
    META_PROPERTY(bool, sortingEnabled, READ, isSortingEnabled, WRITE, setSortingEnabled)
    META_PROPERTY(bool, wordWrap, READ, wordWrap, WRITE, setWordWrap)
    META_PROPERTY(bool, cornerButtonEnabled, READ, isCornerButtonEnabled, WRITE ,setCornerButtonEnabled)
END_PROPERTY
};

END_NAMESPACE
#endif