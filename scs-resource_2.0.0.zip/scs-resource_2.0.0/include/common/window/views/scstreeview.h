#ifndef SCSTREEVIEW_H
#define SCSTREEVIEW_H

#include "scsabstractitemview.h"

BEGIN_NAMESPACE(Gemini)

class CscsTreeViewPrivate;
class CscsHeaderView;

class WIDGET_EXPORT CscsTreeView : public CscsAbstractItemView
{


public:
    explicit CscsTreeView(CscsWidget *parent = 0);
    ~CscsTreeView();

    void setModel(CscsAbstractItemModel *model);
    void setRootIndex(const CscsModelIndex &index);
    void setSelectionModel(CscsItemSelectionModel *selectionModel);

    CscsHeaderView *header() const;
    void setHeader(CscsHeaderView *header);

    int autoExpandDelay() const;
    void setAutoExpandDelay(int delay);

    int indentation() const;
    void setIndentation(int i);

    bool rootIsDecorated() const;
    void setRootIsDecorated(bool show);

    bool uniformRowHeights() const;
    void setUniformRowHeights(bool uniform);

    bool itemsExpandable() const;
    void setItemsExpandable(bool enable);

    bool expandsOnDoubleClick() const;
    void setExpandsOnDoubleClick(bool enable);

    int columnViewportPosition(int column) const;
    int columnWidth(int column) const;
    void setColumnWidth(int column, int width);
    int columnAt(int x) const;

    bool isColumnHidden(int column) const;
    void setColumnHidden(int column, bool hide);

    bool isHeaderHidden() const;
    void setHeaderHidden(bool hide);

    bool isRowHidden(int row, const CscsModelIndex &parent) const;
    void setRowHidden(int row, const CscsModelIndex &parent, bool hide);

    bool isFirstColumnSpanned(int row, const CscsModelIndex &parent) const;
    void setFirstColumnSpanned(int row, const CscsModelIndex &parent, bool span);
 
    bool isExpanded(const CscsModelIndex &index) const;
    void setExpanded(const CscsModelIndex &index, bool expand);

    void setSortingEnabled(bool enable);
    bool isSortingEnabled() const;

    void setAnimated(bool enable);
    bool isAnimated() const;

    void setAllColumnsShowFocus(bool enable);
    bool allColumnsShowFocus() const;

    void setWordWrap(bool on);
    bool wordWrap() const;

    // void keyboardSearch(const std::string &search);

    CscsRect visualRect(const CscsModelIndex &index) const;
    void scrollTo(const CscsModelIndex &index, ScrollHint hint = EnsureVisible);
    CscsModelIndex indexAt(const CscsPoint &p) const;
    CscsModelIndex indexAbove(const CscsModelIndex &index) const;
    CscsModelIndex indexBelow(const CscsModelIndex &index) const;

    void doItemsLayout();
    void reset();

    void sortByColumn(int column, SCS::SortOrder order);

SIGNALS:
    void expanded(const CscsModelIndex &index){}
    void collapsed(const CscsModelIndex &index){}

SLOTS:
    void dataChanged(const CscsModelIndex &topLeft, const CscsModelIndex &bottomRight);
    void hideColumn(int column);
    void showColumn(int column);
    void expand(const CscsModelIndex &index);
    void collapse(const CscsModelIndex &index);
    void resizeColumnToContents(int column);
    void sortByColumn(int column);
    void selectAll();
    void expandAll();
    void collapseAll();
    void expandToDepth(int depth);

protected:
    void columnResized(int column, int oldSize, int newSize);
    void columnCountChanged(int oldCount, int newCount);
    void columnMoved();
    void reexpand();
    void rowsRemoved(const CscsModelIndex &parent, int first, int last);

protected:
    CscsTreeView(CscsTreeViewPrivate* dd, CscsWidget *parent = 0);
    void scrollContentsBy(int dx, int dy);
    void rowsInserted(const CscsModelIndex &parent, int start, int end);
    void rowsAboutToBeRemoved(const CscsModelIndex &parent, int start, int end);

    CscsModelIndex moveCursor(CursorAction cursorAction, SCS::KeyboardModifiers modifiers);
    int horizontalOffset() const;
    int verticalOffset() const;

    void setSelection(const CscsRect &rect, CscsItemSelectionModel::SelectionFlags command);
    CscsRegion visualRegionForSelection(const CscsItemSelection &selection) const;
    CscsModelIndexList selectedIndexes() const;

    void timerEvent(CscsTimerEvent *event);
    void paintEvent(CscsPaintEvent *event);

    void drawTree(CscsPainter *painter, const CscsRegion &region) const;
    virtual void drawRow(CscsPainter *painter,
                         const CscsStyleOptionViewItem &options,
                         const CscsModelIndex &index) const;
    virtual void drawBranches(CscsPainter *painter,
                              const CscsRect &rect,
                              const CscsModelIndex &index) const;

    void mousePressEvent(CscsMouseEvent *event);
    void mouseReleaseEvent(CscsMouseEvent *event);
    void mouseDoubleClickEvent(CscsMouseEvent *event);
    void mouseMoveEvent(CscsMouseEvent *event);
    void keyPressEvent(CscsKeyEvent *event);
    bool viewportEvent(CscsEvent *event);

    void updateGeometries();

    int sizeHintForColumn(int column) const;
    int indexRowSizeHint(const CscsModelIndex &index) const;
    int rowHeight(const CscsModelIndex &index) const;

    void horizontalScrollbarAction(int action);

    bool isIndexHidden(const CscsModelIndex &index) const;
    void selectionChanged(const CscsItemSelection &selected,
                          const CscsItemSelection &deselected);
    void currentChanged(const CscsModelIndex &current, const CscsModelIndex &previous);

private:
    friend class CscsTreeViewPrivate;
    int visualIndex(const CscsModelIndex &index) const;
    CscsTreeViewPrivate* d_func()const;
    BEGIN_PROPERTY(CscsTreeView,CscsAbstractItemView)
    META_PROPERTY(int, autoExpandDelay, READ, autoExpandDelay, WRITE, setAutoExpandDelay)
    META_PROPERTY(int, indentation, READ, indentation, WRITE, setIndentation)
    META_PROPERTY(bool, rootIsDecorated, READ, rootIsDecorated, WRITE, setRootIsDecorated)
    META_PROPERTY(bool, uniformRowHeights, READ, uniformRowHeights, WRITE, setUniformRowHeights)
    META_PROPERTY(bool, itemsExpandable, READ, itemsExpandable, WRITE, setItemsExpandable)
    META_PROPERTY(bool, sortingEnabled, READ, isSortingEnabled, WRITE, setSortingEnabled)
    META_PROPERTY(bool, animated, READ, isAnimated, WRITE, setAnimated)
    META_PROPERTY(bool, allColumnsShowFocus, READ, allColumnsShowFocus, WRITE, setAllColumnsShowFocus)
    META_PROPERTY(bool, wordWrap, READ, wordWrap, WRITE, setWordWrap)
    META_PROPERTY(bool, headerHidden, READ, isHeaderHidden, WRITE, setHeaderHidden)
    META_PROPERTY(bool, expandsOnDoubleClick, READ, expandsOnDoubleClick, WRITE, setExpandsOnDoubleClick)
    END_PROPERTY

};
END_NAMESPACE

#endif