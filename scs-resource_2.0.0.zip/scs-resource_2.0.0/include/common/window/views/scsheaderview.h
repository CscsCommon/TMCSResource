#ifndef SCSHEADERVIEW_H
#define SCSHEADERVIEW_H

#include "scsabstractitemview.h"
#include <window/styles/scsstyleoption.h>

BEGIN_NAMESPACE(Gemini)
class CscsHeaderViewPrivate;

class  CscsHeaderView : public CscsAbstractItemView
{
public:

    enum ResizeMode
    {
        Interactive,
        Stretch,
        Fixed,
        ResizeToContents,
        Custom=Fixed
    };

    explicit CscsHeaderView(SCS::Orientation orientation, CscsWidget *parent = nullptr);
    virtual ~CscsHeaderView();

    void setModel(CscsAbstractItemModel *model);

    SCS::Orientation orientation() const;
    int offset() const;
    int length() const;
    CscsSize sizeHint() const;
    int sectionSizeHint(int logicalIndex) const;

    int visualIndexAt(int position) const;
    int logicalIndexAt(int position) const;

    inline int logicalIndexAt(int x, int y) const;
    inline int logicalIndexAt(const CscsPoint &pos) const;

    int sectionSize(int logicalIndex) const;
    int sectionPosition(int logicalIndex) const;
    int sectionViewportPosition(int logicalIndex) const;

    void moveSection(int from, int to);
    void swapSections(int first, int second);
    void resizeSection(int logicalIndex, int size);
    void resizeSections(CscsHeaderView::ResizeMode mode);

    bool isSectionHidden(int logicalIndex) const;
    void setSectionHidden(int logicalIndex, bool hide);
    int hiddenSectionCount() const;

    inline void hideSection(int logicalIndex);
    inline void showSection(int logicalIndex);

    int count() const;
    int visualIndex(int logicalIndex) const;
    int logicalIndex(int visualIndex) const;

    void setMovable(bool movable);
    bool isMovable() const;

    void setClickable(bool clickable);
    bool isClickable() const;

    void setHighlightSections(bool highlight);
    bool highlightSections() const;

    void setResizeMode(ResizeMode mode);
    void setResizeMode(int logicalIndex, ResizeMode mode);
    ResizeMode resizeMode(int logicalIndex) const;
    int stretchSectionCount() const;

    void setSortIndicatorShown(bool show);
    bool isSortIndicatorShown() const;

    void setSortIndicator(int logicalIndex, SCS::SortOrder order);
    int sortIndicatorSection() const;
    SCS::SortOrder sortIndicatorOrder() const;

    bool stretchLastSection() const;
    void setStretchLastSection(bool stretch);

    bool cascadingSectionResizes() const;
    void setCascadingSectionResizes(bool enable);

    int defaultSectionSize() const;
    void setDefaultSectionSize(int size);

    int minimumSectionSize() const;
    void setMinimumSectionSize(int size);

    SCS::Alignment defaultAlignment() const;
    void setDefaultAlignment(SCS::Alignment alignment);

    void doItemsLayout();
    bool sectionsMoved() const;
    bool sectionsHidden() const;

    void reset();

SLOTS:
    void setOffset(int offset);
    void setOffsetToSectionPosition(int visualIndex);
    void setOffsetToLastSection();
    void headerDataChanged(SCS::Orientation orientation, int logicalFirst, int logicalLast);

SIGNALS:
    void sectionMoved(int logicalIndex, int oldVisualIndex, int newVisualIndex){}
    void sectionResized(int logicalIndex, int oldSize, int newSize){}
    void sectionPressed(int logicalIndex){}
    void sectionClicked(int logicalIndex){}
    void sectionEntered(int logicalIndex){}
    void sectionDoubleClicked(int logicalIndex){}
    void sectionCountChanged(int oldCount, int newCount){}
    void sectionHandleDoubleClicked(int logicalIndex){}
    void sectionAutoResize(int logicalIndex, CscsHeaderView::ResizeMode mode){}
    void geometriesChanged(){}
    void sortIndicatorChanged(int logicalIndex, SCS::SortOrder order){}

protected:
    void updateSection(int logicalIndex);
    void resizeSections();
    void sectionsInserted(const CscsModelIndex &parent, int logicalFirst, int logicalLast);
    void sectionsAboutToBeRemoved(const CscsModelIndex &parent, int logicalFirst, int logicalLast);

protected:
    CscsHeaderView(CscsHeaderViewPrivate* dd, SCS::Orientation orientation, CscsWidget *parent = nullptr);
    void initialize();

    void initializeSections();
    void initializeSections(int start, int end);
    void currentChanged(const CscsModelIndex &current, const CscsModelIndex &old);

    bool event(CscsEvent *e);
    void paintEvent(CscsPaintEvent *e);
    void mousePressEvent(CscsMouseEvent *e);
    void mouseMoveEvent(CscsMouseEvent *e);
    void mouseReleaseEvent(CscsMouseEvent *e);
    void mouseDoubleClickEvent(CscsMouseEvent *e);
    bool viewportEvent(CscsEvent *e);

    virtual void paintSection(CscsPainter *painter, const CscsRect &rect, int logicalIndex) const;
    virtual CscsSize sectionSizeFromContents(int logicalIndex) const;

    int horizontalOffset() const;
    int verticalOffset() const;
    void updateGeometries();
    void scrollContentsBy(int dx, int dy);

    void dataChanged(const CscsModelIndex &topLeft, const CscsModelIndex &bottomRight);
    void rowsInserted(const CscsModelIndex &parent, int start, int end);

    CscsRect visualRect(const CscsModelIndex &index) const;
    void scrollTo(const CscsModelIndex &index, ScrollHint hint);

    CscsModelIndex indexAt(const CscsPoint &p) const;
    bool isIndexHidden(const CscsModelIndex &index) const;

    CscsModelIndex moveCursor(CursorAction, SCS::KeyboardModifiers);
    void setSelection(const CscsRect&, CscsItemSelectionModel::SelectionFlags);
    CscsRegion visualRegionForSelection(const CscsItemSelection &selection) const;

    void initStyleOption(CscsStyleOptionHeader *option) const;

private:
    CscsHeaderViewPrivate* d_func()const;
    friend class CscsHeaderViewPrivate;
    friend class CscsTableView;
    friend class CscsTreeView;
    BEGIN_PROPERTY(CscsHeaderView,CscsAbstractItemView)
	    META_PROPERTY(bool, showSortIndicator, READ, isSortIndicatorShown, WRITE, setSortIndicatorShown)
	    META_PROPERTY(bool, highlightSections, READ, highlightSections, WRITE, setHighlightSections)
	    META_PROPERTY(bool, stretchLastSection, READ, stretchLastSection, WRITE, setStretchLastSection)
        META_PROPERTY(bool, cascadingSectionResizes, READ, cascadingSectionResizes, WRITE, setCascadingSectionResizes)
        META_PROPERTY(int, defaultSectionSize, READ, defaultSectionSize, WRITE, setDefaultSectionSize)
        META_PROPERTY(int, minimumSectionSize, READ, minimumSectionSize, WRITE, setMinimumSectionSize)
        META_PROPERTY(SCS::Alignment, defaultAlignment, READ, defaultAlignment, WRITE, setDefaultAlignment)
    END_PROPERTY
};

inline int CscsHeaderView::logicalIndexAt(int ax, int ay) const
{ return orientation() == SCS::Horizontal ? logicalIndexAt(ax) : logicalIndexAt(ay); }

inline int CscsHeaderView::logicalIndexAt(const CscsPoint &apos) const
{ return logicalIndexAt(apos.x(), apos.y()); }

inline void CscsHeaderView::hideSection(int alogicalIndex)
{ setSectionHidden(alogicalIndex, true); }
inline void CscsHeaderView::showSection(int alogicalIndex)
{ setSectionHidden(alogicalIndex, false); }

END_NAMESPACE

#endif