#ifndef SCSABSTRACTANIMATION_H
#define SCSABSTRACTANIMATION_H

#include <kernel/scsobject.h>

BEGIN_NAMESPACE(Gemini)

class CscsAbstractAnimationPrivate;
class CscsAnimationGroup;

class CscsAbstractAnimation:public CscsObject
{
	public:
		enum Direction{
			Forward,
			Backward
		};
		
		enum State{
			Stopped,
			Paused,
			Running
		};
		
		enum DeletionPolicy{
			KeepWhenStopped,
			DeleteWhenStopped
		};
		
		CscsAbstractAnimation(CscsObject* parent=nullptr);
		virtual ~CscsAbstractAnimation();
		State state()const;
		CscsAnimationGroup* group()const;
		Direction direction()const;
		void setDirection(Direction direction);
		
		int currentTime()const;
		int currentLoopTime()const;
		
		int loopCount() const;
		void setLoopCount(int loopCount);
		int currentLoop() const;
	
		virtual int duration()const=0;
		int totalDuration()const;
	SIGNALS:
		void finished(){}
		void stateChanged(CscsAbstractAnimation::State newState, CscsAbstractAnimation::State oldState){}
		void currentLoopChanged(int currentLoop){}
		void directionChanged(CscsAbstractAnimation::Direction dir){}
	SLOTS:
		void start(CscsAbstractAnimation::DeletionPolicy policy=KeepWhenStopped);
		void pause();
		void resume();
		void setPaused(bool pause);
		void stop();
		void setCurrentTime(int msecs);
	
	protected:
		CscsAbstractAnimation(CscsAbstractAnimationPrivate* dd, CscsObject* parent=nullptr);
		bool event(CscsEvent* e);
		virtual void updateCurrentTime(int currentTime)=0;
		virtual void updateState(CscsAbstractAnimation::State newState, CscsAbstractAnimation::State oldState);
		virtual void updateDirection(CscsAbstractAnimation::Direction direction);
		
	private:
		CscsAbstractAnimationPrivate* d_func()const;
		friend class CscsAbstractAnimationPrivate;
};


class CscsAnimationDriverPrivate;
class CscsAnimationDriver:public CscsObject
{
	public:
		CscsAnimationDriver(CscsObject* parent=nullptr);
		~CscsAnimationDriver();
		virtual void advance();
		void install();
		void uninstall();
		bool isRunning()const;
		virtual int64 elapsed()const;
		void setStartTime(int64 startTime);
		int64 startTime()const;
	
	SIGNALS:
		void started(){}
		void stopped(){}
		
	protected:
		void advanceAnimation(int64 timeStep=-1);
		virtual void start();
		virtual void stop();
		CscsAnimationDriver(CscsAnimationDriverPrivate* dd, CscsObject* parent=nullptr);
	private:
		friend class CscsUnifiedTimer;
		CscsAnimationDriverPrivate* d_func()const;
};

END_NAMESPACE

#endif