 /*Created by J.Wong 2018/10/30
 version:    version 1.0,
 dependency: base on  or greater than c++11
 function: type erase
 gcc4.9+
 */

#ifndef SCSDISPLAY_H
#define SCSDISPLAY_H
#include <string>
#include <kernel/scstypes.h>
#include <painting/scspoint.h>
#include <painting/scssize.h>
#include <painting/scsrect.h>
#include <painting/scsregion.h>
#include "scsplatformscreencursor.h"

BEGIN_NAMESPACE(Gemini)

class CscsScreenCursor;
class CscsImage;


class CscsScreenCursor:public CscsPlatformScreenCursor{
    public:
        CscsScreenCursor();
        virtual ~CscsScreenCursor();

        void init(SWCursorData* da, bool init=false);
        void set(const CscsImage& image, int hotx, int hoty);
        void move(int x, int y);
        void show();
        void hide();
        bool restoreUnder(const CscsRect& r);
        void saveUnder();
        void drawCursor();
        inline int width()const{
            if(data) return data->width;
            return 0;
        }
        inline int height()const{
            if(data) return data->height;
            return 0;
        }

        virtual bool supportAlphaCursor();
        static bool enabled(){
            return scs_sw_cursor;
        }

    protected:
        CscsImage* imgunder;
        CscsImage* cursor;

        uint8* fb_start;
        uint8* fb_end;
        bool save_under;
        SWCursorData* data;
        int clipWidth;
        int clipHeight;
        int myoffset;
};

class CscsPoolEntry
{
public:
    unsigned int start;
    unsigned int end;
    int clientId;
};

class CscsDisplay;
typedef void(*ClearCacheFunc)(CscsDisplay *obj, int);

class CscsDisplay{
public:
	explicit CscsDisplay();
    virtual ~CscsDisplay();
    virtual bool init() = 0;
    virtual bool connect(const std::string& display) = 0;
    virtual void disconnect() = 0;
    virtual int initCursor(void*, bool=false);
    virtual void shutdown();
    virtual void setMode(int nw,int nh, int reserved=0) = 0;
    virtual bool supportsDepth(int depth) const;
    


    virtual void save();
    virtual void restore();
    virtual void blank(bool on);

    virtual int pixmapOffsetAlignment() { return 64; }
    virtual int pixmapLinestepAlignment() { return 64; }
    virtual int sharedRamSize(void* ) { return 0; }

    virtual bool onCard(const uint8* ) const;
    virtual bool onCard(const uint8*, unsigned long& out_offset) const;

    enum PixelType { NormalPixel, BGRPixel };

    // sets a single color in the colormap
    virtual void set(unsigned int,unsigned int,unsigned int,unsigned int);
    // allocates a color
    virtual int alloc(unsigned int,unsigned int,unsigned int);

    int width() const { return w; }
    int height() const { return h; }
    int depth() const { return d; }
    virtual int pixmapDepth() const;
    PixelType pixelType() const { return pixeltype; }
    int linestep() const { return lstep; }
    int deviceWidth() const { return dw; }
    int deviceHeight() const { return dh; }
    uint8 * base() const { return data; }

    virtual uint8 * cache(int) { return 0; }
    virtual void uncache(uint8* ) {}

    int screenSize() const { return size; }
    int totalSize() const { return mapsize; }

    int* clut() { return screenclut; }
    int  numCols() { return screencols; }

    virtual CscsSize mapToDevice(const CscsSize &) const;
    virtual CscsSize mapFromDevice(const CscsSize &) const;
    virtual CscsPoint mapToDevice(const CscsPoint &, const CscsSize &) const;
    virtual CscsPoint mapFromDevice(const CscsPoint &, const CscsSize &) const;
    virtual CscsRect mapToDevice(const CscsRect &, const CscsSize &) const;
    virtual CscsRect mapFromDevice(const CscsRect &, const CscsSize &) const;
    //virtual CscsImage mapToDevice(const CscsImage &) const;
    //virtual CscsImage mapFromDevice(const CscsImage &) const;
    virtual CscsRegion mapToDevice(const CscsRegion &, const CscsSize &) const;
    virtual CscsRegion mapFromDevice(const CscsRegion &, const CscsSize &) const;
    virtual int transformOrientation() const;
    virtual bool isTransformed() const;

    virtual void setDirty(const CscsRect&);

    virtual int memoryNeeded(const std::string&);

    int * opType() { return screen_optype; }
    int * lastOp() { return screen_lastop; }

    virtual void haltUpdates();
    virtual void resumeUpdates();

protected:

    int * screen_optype;
    int * screen_lastop;

    int screenclut[256];
    int screencols;

    bool initted;

    uint8 * data;

    CscsPoolEntry * entries;
    int * entryp;
    unsigned int * lowest;

    int w;
    int lstep;
    int h;
    int d;
    PixelType pixeltype;
    bool grayscale;

    int dw;
    int dh;

    int hotx;
    int hoty;
    //CscsImage cursor;

    int size;               // Screen size
    int mapsize;       		// Total mapped memory

    //int displayId;

    static ClearCacheFunc clearCacheFunc;

};

END_NAMESPACE

#endif
