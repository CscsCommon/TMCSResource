#ifndef SCSFOCUSFRAMEPRIV_H
#define SCSFOCUSFRAMEPRIV_H
#include "../scswidget_p.h"
#include "../styles/scsstyleoption.h"

BEGIN_NAMESPACE(Gemini)

class CscsWidget;
class CscsFocusFrame;
class CscsFocusFramePrivate:public CscsWidgetPrivate{
	public:
		CscsFocusFramePrivate(){
			widget=0;
			sendChildEvents=false;
		}
		void updateSize();
		void update();
		CscsFocusFrame* mm_func()const;
		CscsStyleOption getStyleOption()const;
		CscsWidget* widget;
};

END_NAMESPACE

#endif
