#ifndef SCSLABEL_H
#define SCSLABEL_H
#include "scsframe.h"
#include <kernel/scsmetaproperty.h>

BEGIN_NAMESPACE(Gemini)

class CscsLabelPrivate;
class CscsMovie;
class WIDGET_EXPORT CscsLabel:public CscsFrame{
public:
	explicit CscsLabel(CscsWidget* parent=0, SCS::WindowFlags f=0);
	explicit CscsLabel(const std::string& text, CscsWidget* parent=0, SCS::WindowFlags f=0);
	~CscsLabel();
	std::string text()const;
	const CscsImage* pixmap()const;
	SCS::Alignment alignment()const;
	void setAlignment(SCS::Alignment);
	CscsLabelPrivate* d_func()const;
	int margin()const;
	void setMargin(int m);
	bool hasScaledContents()const;
	void setScaledContents(bool scaled);
	CscsSize sizeHint()const;
	CscsSize minimumSizeHint()const;

	CscsMovie* movie()const;
	void setMovie(CscsMovie* movie);

	int indent() const;
    void setIndent(int);


	int heightForWidth(int h)const;
SLOTS:
	void setText(const std::string& text);
	void setPixmap(const CscsImage& image);
	void clear();
	void setNum(int);
	void setNum(double);

protected:
	bool event(CscsEvent* e);
	void paintEvent(CscsPaintEvent* e);
	void changeEvent(CscsEvent* e);

BEGIN_PROPERTY(CscsLabel,CscsFrame)
	META_PROPERTY(std::string, text, READ, text, WRITE, setText)
    META_WRITE_PROPERTY(CscsImage, pixmap, WRITE, setPixmap)
    META_PROPERTY(bool, scaledContents, READ, hasScaledContents, WRITE, setScaledContents)
    META_PROPERTY(SCS::Alignment, alignment, READ, alignment, WRITE, setAlignment)
    META_PROPERTY(int, margin, READ, margin, WRITE, setMargin)
    META_PROPERTY(int, indent, READ, indent, WRITE, setIndent)
END_PROPERTY

};

END_NAMESPACE
#endif
