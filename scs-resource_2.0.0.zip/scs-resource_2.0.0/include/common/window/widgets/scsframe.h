#ifndef SCSFRAME_H
#define SCSFRAME_H
#include "../scswidget.h"

BEGIN_NAMESPACE(Gemini)

class CscsFramePrivate;
class CscsPainter;

class WIDGET_EXPORT CscsFrame:public CscsWidget{
	
	CONTAINER_WIDGET
	public:
		explicit CscsFrame(CscsWidget* parent=0, SCS::WindowFlags f=0);
		~CscsFrame();
		enum Shape{
			NoFrame =0x00,
			Box=0x01,
			Panel=0x02,
			WinPanel=0x03,
			HLine=0x04,
			VLine=0x05,
			StyledPanel=0x06,
			Shape_Mask=0x0f,
		};
		enum Shadow
		{
			Plain=0x10,
			Raised=0x20,
			Sunken=0x30,
			Shadow_Mask=0xf0
		};

		int frameStyle()const;
		void setFrameStyle(int);
		int frameWidth()const;
		CscsSize sizeHint()const;
		Shape frameShape()const;
		void setFrameShape(Shape);
		Shadow frameShadow()const;
		void setFrameShadow(Shadow);
		int lineWidth()const;
		void setLineWidth(int);
		int midLineWidth()const;
		void setMidLineWidth(int);
		CscsRect frameRect()const;
		void setFrameRect(const CscsRect& r);

		
		CscsFramePrivate* d_func()const;
	protected:
		void paintEvent(CscsPaintEvent* e);
		void changeEvent(CscsEvent* e);
		void drawFrame(CscsPainter* p);

		CscsFrame(CscsFramePrivate* dd, CscsWidget* parent=0, SCS::WindowFlags f=0);
	private:

BEGIN_PROPERTY(CscsFrame,CscsWidget)
    META_PROPERTY(Shape, frameShape, READ, frameShape, WRITE, setFrameShape)
    META_PROPERTY(Shadow, frameShadow, READ, frameShadow, WRITE, setFrameShadow)
    META_PROPERTY(int, lineWidth, READ, lineWidth, WRITE, setLineWidth)
    META_PROPERTY(int, midLineWidth, READ, midLineWidth, WRITE, setMidLineWidth)
    META_READ_PROPERTY(int, frameWidth, READ, frameWidth)
END_PROPERTY

};
END_NAMESPACE

#endif