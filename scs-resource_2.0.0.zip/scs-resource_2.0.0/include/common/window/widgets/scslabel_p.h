#ifndef SCSLABELPRIVATE_H
#define SCSLABELPRIVATE_H
#include "scsframe_p.h"
#include <memory>
#include <kernel/scspointer.h>
#include "scsmovie.h"

BEGIN_NAMESPACE(Gemini)

class CscsImage;
class CscsLabel;

class CscsLabelPrivate:public CscsFramePrivate{
	public:
		CscsLabelPrivate();
		CscsLabel* mm_func()const;

		void init();
		void clearContents();
		void updateLabel();
		CscsSize sizeForWidth(int w)const;

		CscsImage* img;
		CscsImage* pix;
		mutable CscsSize sh;
		mutable CscsSize msh;
		mutable bool valid_hints;
		int margin;
		std::string text;
		CscsImage *lpixmap;

		uint16 align;
		int16 extraMargin;
		bool scaledcontents;
		CscsPointer<CscsMovie> movie;
    	void _s_movieUpdated(const CscsRect&);
    	void _s_movieResized(const CscsSize&);


};

END_NAMESPACE

#endif