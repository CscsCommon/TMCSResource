#ifndef SCSICONENGINE_H
#define SCSICONENGINE_H
#include <painting/scsrect.h>
#include <painting/scsimage.h>
#include "scsicon.h"

BEGIN_NAMESPACE(Gemini)

class CscsPainter;

class  CscsIconEngine
{
public:
    virtual ~CscsIconEngine();
    virtual void paint(CscsPainter *painter, const CscsRect &rect, CscsIcon::Mode mode, CscsIcon::State state) = 0;
    virtual CscsSize actualSize(const CscsSize &size, CscsIcon::Mode mode, CscsIcon::State state);
    virtual CscsImage pixmap(const CscsSize &size, CscsIcon::Mode mode, CscsIcon::State state);

    virtual void addPixmap(const CscsImage &pixmap, CscsIcon::Mode mode, CscsIcon::State state);
    virtual void addFile(const std::string &fileName, const CscsSize &size, CscsIcon::Mode mode, CscsIcon::State state);

};

END_NAMESPACE

#endif