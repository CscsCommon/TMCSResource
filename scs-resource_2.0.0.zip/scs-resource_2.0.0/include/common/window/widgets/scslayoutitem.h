#ifndef SCSLAYOUTITEM_H
#define SCSLAYOUTITEM_H
#include "../scsenum.h"
#include "scssizepolicy.h"
#include <painting/scsrect.h>

BEGIN_NAMESPACE(Gemini)

static const int MAX_LAYOUTSIZE=65535;
class CscsLayout;
class CscsWidget;

class CscsSpacerItem;


class  CscsLayoutItem
{
public:
    inline explicit CscsLayoutItem(SCS::Alignment alignment = 0);
    virtual ~CscsLayoutItem();
    virtual CscsSize sizeHint() const = 0;
    virtual CscsSize minimumSize() const = 0;
    virtual CscsSize maximumSize() const = 0;
    virtual SCS::Orientations expandingDirections() const = 0;
    virtual void setGeometry(const CscsRect&) = 0;
    virtual CscsRect geometry() const = 0;
    virtual bool isEmpty() const = 0;
    virtual bool hasHeightForWidth() const;
    virtual int heightForWidth(int) const;
    virtual int minimumHeightForWidth(int) const;
    virtual void invalidate();

    virtual CscsWidget *widget();
    virtual CscsLayout *layout();
    virtual CscsSpacerItem *spacerItem();

    SCS::Alignment alignment() const { return align; }
    void setAlignment(SCS::Alignment a);

protected:
    SCS::Alignment align;
};

inline CscsLayoutItem::CscsLayoutItem(SCS::Alignment alignment)
    : align(alignment) { }


class  CscsSpacerItem : public CscsLayoutItem
{
public:
    CscsSpacerItem(int w, int h,
                 CscsSizePolicy::Policy hData = CscsSizePolicy::Minimum,
                 CscsSizePolicy::Policy vData = CscsSizePolicy::Minimum)
        :width(w),height(h),sizeP(hData, vData){ }
    void changeSize(int w, int h,
                     CscsSizePolicy::Policy hData = CscsSizePolicy::Minimum,
                     CscsSizePolicy::Policy vData = CscsSizePolicy::Minimum);
    CscsSize sizeHint() const;
    CscsSize minimumSize() const;
    CscsSize maximumSize() const;
    SCS::Orientations expandingDirections() const;
    bool isEmpty() const;
    void setGeometry(const CscsRect&);
    CscsRect geometry() const;
    CscsSpacerItem *spacerItem();

private:
    int width;
    int height;
    CscsSizePolicy sizeP;
    CscsRect rect;
};


class  CscsWidgetItem : public CscsLayoutItem
{
public:
    explicit CscsWidgetItem(CscsWidget *w) : wid(w) { }
    CscsSize sizeHint() const;
    CscsSize minimumSize() const;
    CscsSize maximumSize() const;
    SCS::Orientations expandingDirections() const;
    bool isEmpty() const;
    void setGeometry(const CscsRect&);
    CscsRect geometry() const;
    virtual CscsWidget *widget();

    bool hasHeightForWidth() const;
    int heightForWidth(int) const;

private:
    CscsWidget *wid;
};

END_NAMESPACE

#endif