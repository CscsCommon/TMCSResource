#ifndef SCSDOCKWIDGETSEPARATOR_H
#define SCSDOCKWIDGETSEPARATOR_H
#include <window/scswidget.h>

BEGIN_NAMESPACE(Gemini)

class CscsDockWidget;
class CscsDockWidgetLayout;
class CscsPainter;

class CscsDockWidgetSeparator : public CscsWidget
{
public:
    CscsDockWidgetSeparator(CscsDockWidgetLayout *l, CscsWidget *parent);

    CscsRect calcRect(const CscsPoint &point);

    void mousePressEvent(CscsMouseEvent *event);
    void mouseReleaseEvent(CscsMouseEvent *event);
    void mouseMoveEvent(CscsMouseEvent *event);
    void paintEvent(CscsPaintEvent *event);
    bool event(CscsEvent *event);

    CscsDockWidgetLayout *layout;

    struct DragState {
	CscsPoint origin, last;
	CscsWidget *prevFocus;
    } *state;

    bool hover;
};

END_NAMESPACE

#endif