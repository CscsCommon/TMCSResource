#ifndef SCSSPINBOX_H
#define SCSSPINBOX_H
#include "scsabstractspinbox.h"

BEGIN_NAMESPACE(Gemini)

class CscsSpinBoxPrivate;
class  WIDGET_EXPORT CscsSpinBox : public CscsAbstractSpinBox
{

public:
    explicit CscsSpinBox(CscsWidget *parent = 0);

    virtual void stepBy(int steps);
    
    int value() const;

    std::string prefix() const;
    void setPrefix(const std::string &p);

    std::string suffix() const;
    void setSuffix(const std::string &s);

    std::string cleanText() const;

    int singleStep() const;
    void setSingleStep(int val);

    int minimum() const;
    void setMinimum(int min);

    int maximum() const;
    void setMaximum(int max);

    void setRange(int min, int max);

protected:
    virtual CscsValidator::State validate(std::string &input, int &pos) const;
    virtual int valueFromText(const std::string &text) const;
    virtual std::string textFromValue(int v) const;
    virtual void fixup(std::string &str) const;
    virtual StepEnabled stepEnabled() const;

SLOTS:
    virtual void setValue(int val);

SIGNALS:
    void valueChanged(int);
    void valueChanged(const std::string &);

private:
    CscsSpinBoxPrivate* d_func()const;
    friend class CscsSpinBoxPrivate;

BEGIN_PROPERTY(CscsSpinBox,CscsAbstractSpinBox)
    META_PROPERTY(std::string, suffix, READ, suffix, WRITE, setSuffix)
    META_PROPERTY(std::string, prefix, READ, prefix, WRITE, setPrefix)
    META_READ_PROPERTY(std::string, cleanText, READ, cleanText)
    META_PROPERTY(int, maximum, READ, maximum, WRITE, setMaximum)
    META_PROPERTY(int, minimum, READ, minimum, WRITE, setMinimum)
    META_PROPERTY(int, singleStep, READ, singleStep, WRITE, setSingleStep)
    META_PROPERTY(int, value, READ, value, WRITE, setValue)
END_PROPERTY

};

class CscsDoubleSpinBoxPrivate;
class  WIDGET_EXPORT CscsDoubleSpinBox : public CscsAbstractSpinBox
{

public:
    explicit CscsDoubleSpinBox(CscsWidget *parent = 0);

    virtual void stepBy(int steps);
    double value() const;

    std::string prefix() const;
    void setPrefix(const std::string &p);

    std::string suffix() const;
    void setSuffix(const std::string &s);

    std::string cleanText() const;

    double singleStep() const;
    void setSingleStep(double val);

    double minimum() const;
    void setMinimum(double min);

    double maximum() const;
    void setMaximum(double max);

    void setRange(double min, double max);

    int decimals() const;
    void setDecimals(int prec);

    virtual CscsValidator::State validate(std::string &input, int &pos) const;
    virtual double valueFromText(const std::string &text) const;
    virtual std::string textFromValue(double v) const;
    virtual void fixup(std::string &str) const;
    virtual StepEnabled stepEnabled() const;

SLOTS:
    virtual void setValue(double val);

SIGNALS:
    void valueChanged(double){}
    void valueChanged(const std::string&){}

private:
    CscsDoubleSpinBoxPrivate* d_func()const;
    friend class CscsDoubleSpinBoxPrivate;

BEGIN_PROPERTY(CscsDoubleSpinBox,CscsAbstractSpinBox)
    META_PROPERTY(std::string, prefix, READ, prefix, WRITE, setPrefix)
    META_PROPERTY(std::string, suffix, READ, suffix, WRITE, setSuffix)
    META_READ_PROPERTY(std::string, cleanText, READ, cleanText)
    META_PROPERTY(int, decimals, READ, decimals, WRITE, setDecimals)
    META_PROPERTY(double, maximum, READ, maximum, WRITE, setMaximum)
    META_PROPERTY(double, minimum, READ, minimum, WRITE, setMinimum)
    META_PROPERTY(double, singleStep, READ, singleStep, WRITE, setSingleStep)
    META_PROPERTY(double, value, READ, value, WRITE, setValue)
END_PROPERTY

};

END_NAMESPACE

#endif