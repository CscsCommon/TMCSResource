#ifndef SCSSTACKEDWIDGET_H
#define SCSSTACKEDWIDGET_H
#include "scsframe.h"

BEGIN_NAMESPACE(Gemini)

class CscsStackedWidgetPrivate;

class  WIDGET_EXPORT CscsStackedWidget : public CscsFrame
{
    CONTAINER_WIDGET
public:
    explicit CscsStackedWidget(CscsWidget *parent=0);
    ~CscsStackedWidget();

    int addWidget(CscsWidget *w);
    int insertWidget(int index, CscsWidget *w);
    void removeWidget(CscsWidget *w);

    CscsWidget *currentWidget() const;
    int currentIndex() const;

    int indexOf(CscsWidget *) const;
    CscsWidget *widget(int) const;
    int count() const;

SLOTS:
    void setCurrentIndex(int index);
    void setCurrentWidget(CscsWidget *w);

SIGNALS:
    void currentChanged(int){}
    void widgetRemoved(int index){}

protected:
	void transferCurrentChanged(int);
	void transferWidgetRemove(int);

private:
    CscsStackedWidgetPrivate* d_func()const;

BEGIN_PROPERTY(CscsStackedWidget,CscsFrame)
    META_PROPERTY(int, currentIndex, READ, currentIndex, WRITE, setCurrentIndex)
    META_READ_PROPERTY(int, count, READ, count)
END_PROPERTY

};

END_NAMESPACE

#endif
