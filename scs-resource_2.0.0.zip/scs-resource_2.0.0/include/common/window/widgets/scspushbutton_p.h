#ifndef SCSPUSHBUTTONPRIVATE_H
#define SCSPUSHBUTTONPRIVATE_H
#include "scsabstractbutton_p.h"

BEGIN_NAMESPACE(Gemini)

class CscsPushButton;

class CscsPushButtonPrivate:public CscsAbstractButtonPrivate
{
public:
	enum AutoDefaultValue{Off = 0, On = 1, Auto = 2};
	CscsPushButtonPrivate()
		: CscsAbstractButtonPrivate(),autoDefault(Auto),defaultButton(false),
		flat(false),menuOpen(false),laseAutoDefalut(false){}

	static CscsPushButtonPrivate* get(CscsPushButton *b){ return b->d_func(); }
	inline void init() { resetLayoutItemMargins(); }

	void resetLayoutItemMargins();
	void _q_popupPressed();

	uint autoDefault : 2;
	uint defaultButton : 1;
	uint flat : 1;
	uint menuOpen : 1;
	mutable uint laseAutoDefalut : 1;

	CscsPushButton* mm_func() const;
};

END_NAMESPACE

#endif
