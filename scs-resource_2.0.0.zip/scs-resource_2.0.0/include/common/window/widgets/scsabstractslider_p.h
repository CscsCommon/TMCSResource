#ifndef SCSABSTRACTSLIDERPRIV_H
#define SCSABSTRACTSLIDERPRIV_H

#include "../scswidget_p.h"
#include <painting/scsmath.h>
#include <kernel/scsbasictimer.h>

BEGIN_NAMESPACE(Gemini)

class CscsAbstractSlider;
class CscsAbstractSliderPrivate : public CscsWidgetPrivate
{
public:
    CscsAbstractSliderPrivate();
    ~CscsAbstractSliderPrivate();
    CscsAbstractSlider* mm_func()const;
    void setSteps(int single, int page);

    int minimum, maximum, singleStep, pageStep, value, position;
    uint tracking : 1;
    uint blocktracking :1;
    uint pressed : 1;
    uint invertedAppearance : 1;
    uint invertedControls : 1;
    SCS::Orientation orientation;

    CscsBasicTimer repeatActionTimer;
    int repeatActionTime;
    CscsAbstractSlider::SliderAction repeatAction;

    inline int bound(int val) const { return scsMax(minimum, scsMin(maximum, val)); }
};

END_NAMESPACE

#endif