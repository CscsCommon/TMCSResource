#ifndef SCSLAYOUTUTILS_H
#define SCSLAYOUTUTILS_H
#include "scslayoutitem.h"
#include <painting/scsmath.h>
#include <vector>

BEGIN_NAMESPACE(Gemini)

struct CscsLayoutStruct
{
    inline void init(int stretchFactor = 0, int spacing = 0) {
        stretch = stretchFactor;
        minimumSize = sizeHint = spacing;
        maximumSize = MAX_LAYOUTSIZE;
        expansive = false;
        empty = true;
    }

    int smartSizeHint() {
        return (stretch > 0) ? minimumSize : sizeHint;
    }

    // parameters
    int stretch;
    int sizeHint;
    int maximumSize;
    int minimumSize;
    bool expansive;
    bool empty;

    // temporary storage
    bool done;

    // result
    int pos;
    int size;
};


void scsGeomCalc(std::vector<CscsLayoutStruct> &chain, int start, int count,
                         int pos, int space, int spacer);
CscsSize scsSmartMinSize(const CscsWidgetItem *i);
CscsSize scsSmartMinSize(const CscsWidget *w);
CscsSize scsSmartMaxSize(const CscsWidgetItem *i, SCS::Alignment align = 0);
CscsSize scsSmartMaxSize(const CscsWidget *w, SCS::Alignment align = 0);



static inline void scsMaxExpCalc(int & max, bool &exp,
                               int boxmax, bool boxexp)
{
    if (exp) {
        if (boxexp)
            max = scsMax(max, boxmax);
    } else {
        if (boxexp)
            max = boxmax;
        else
            max = scsMin(max, boxmax);
    }
    exp = exp || boxexp;
}

END_NAMESPACE

#endif