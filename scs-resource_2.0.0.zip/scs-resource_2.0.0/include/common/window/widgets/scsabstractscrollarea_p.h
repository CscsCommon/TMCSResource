#ifndef SCSABSTRACTSCROLLAREA_PRIVATE_H
#define SCSABSTRACTSCROLLAREA_PRIVATE_H
#include <window/widgets/scsframe_p.h>

BEGIN_NAMESPACE(Gemini)

class CscsScrollBar;
class CscsAbstractScrollArea;
class CscsAbstractScrollAreaPrivate:public CscsFramePrivate
{
public:
	CscsAbstractScrollAreaPrivate();
	CscsScrollBar *hbar, *vbar;
	SCS::ScrollBarPolicy vbarpolicy, hbarpolicy;

	CscsWidget *viewport;
	int left, top, right, bottom;

	int xoffset, yoffset;

	bool vend, hend;

	void init();
	void layoutChildren();
	bool viewportEvent(CscsEvent *);

	void hslide(int);
	void vslide(int);
	void showOrHideScrollBars();

	CscsAbstractScrollArea *mm_func() const;

};

END_NAMESPACE

#endif