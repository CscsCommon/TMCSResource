#ifndef SCSDOCKWIDGET_H
#define SCSDOCKWIDGET_H
#include <window/scswidget.h>
#include <kernel/scsflags.h>

BEGIN_NAMESPACE(Gemini)

class CscsDockWidgetLayout;
class CscsDockWidgetPrivate;
class CscsMainWindow;

class WIDGET_EXPORT CscsDockWidget : public CscsWidget
{

    CONTAINER_WIDGET
public:
    explicit CscsDockWidget(const std::string &title, CscsWidget *parent = 0, SCS::WindowFlags flags = 0);
    explicit CscsDockWidget(CscsWidget *parent = 0, SCS::WindowFlags flags = 0);
    ~CscsDockWidget();

    CscsWidget *widget() const;
    void setWidget(CscsWidget *widget);

    enum DockWidgetFeature {
        DockWidgetClosable    = 0x01,
        DockWidgetMovable     = 0x02,
        DockWidgetFloatable   = 0x04,

        DockWidgetFeatureMask = 0x07,
        AllDockWidgetFeatures = DockWidgetFeatureMask,
        NoDockWidgetFeatures  = 0x00,

        Reserved              = 0xff
    };
    SCS_DECLARE_FLAGS(DockWidgetFeatures, DockWidgetFeature)

    void setFeatures(DockWidgetFeatures features);
    DockWidgetFeatures features() const;

    void setFloating(bool floating);
    inline bool isFloating() const { return isWindow(); }

    void setAllowedAreas(SCS::DockWidgetAreas areas);
    SCS::DockWidgetAreas allowedAreas() const;

    inline bool isAreaAllowed(SCS::DockWidgetArea area) const
    { return (allowedAreas() & area) == area; }


SIGNALS:
    void featuresChanged(CscsDockWidget::DockWidgetFeatures features);
    void topLevelChanged(bool topLevel);
    void allowedAreasChanged(SCS::DockWidgetAreas allowedAreas);

protected:
    void changeEvent(CscsEvent *event);
    void closeEvent(CscsCloseEvent *event);
    void paintEvent(CscsPaintEvent *event);
    bool event(CscsEvent *event);

private:
    CscsDockWidgetPrivate* d_func()const;
    friend class CscsDockWidgetLayout;
BEGIN_PROPERTY(CscsDockWidget,CscsWidget)
    META_PROPERTY(bool, floating, READ, isFloating, WRITE, setFloating)
    META_PROPERTY(DockWidgetFeatures, features, READ, features, WRITE, setFeatures)
    META_PROPERTY(SCS::DockWidgetAreas, allowedAreas, READ, allowedAreas,
               WRITE, setAllowedAreas)
END_PROPERTY

};

SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsDockWidget::DockWidgetFeatures)

END_NAMESPACE

#endif