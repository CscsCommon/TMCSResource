#ifndef SCSSPLITTER_H
#define SCSSPLITTER_H
#include "scsframe.h"
#include "scssizepolicy.h"
#include <kernel/scsbytearray.h>
#include <kernel/scsany.hpp>
#include <kernel/scsvector.h>

BEGIN_NAMESPACE(Gemini)

class CscsSplitterPrivate;
template <typename T> class CscsList;

class CscsSplitterHandle;

class  WIDGET_EXPORT CscsSplitter : public CscsFrame
{

public:
    explicit CscsSplitter(CscsWidget* parent = 0);
    explicit CscsSplitter(SCS::Orientation, CscsWidget* parent = 0);
    ~CscsSplitter();

    void addWidget(CscsWidget *widget);
    void insertWidget(int index, CscsWidget *widget);

    void setOrientation(SCS::Orientation);
    SCS::Orientation orientation() const;

    void setChildrenCollapsible(bool);
    bool childrenCollapsible() const;

    void setCollapsible(int index, bool);
    bool isCollapsible(int index) const;
    void setOpaqueResize(bool opaque = true);
    bool opaqueResize() const;
    void refresh();

    CscsSize sizeHint() const;
    CscsSize minimumSizeHint() const;

    CscsList<int> sizes() const;
    void setSizes(const CscsList<int> &list);

    CscsVector<CscsAny> saveState() const;
    bool restoreState(const CscsVector<CscsAny> &state);

    int handleWidth() const;
    void setHandleWidth(int);

    int indexOf(CscsWidget *w) const;
    CscsWidget *widget(int index) const;
    int count() const;

    void getRange(int index, int *, int *) const;
    CscsSplitterHandle *handle(int index) const;

    void setStretchFactor(int index, int stretch);

SIGNALS:
    void splitterMoved(int pos, int index){}

protected:
    virtual CscsSplitterHandle *createHandle();

    void childEvent(CscsChildEvent *);

    bool event(CscsEvent *);
    void resizeEvent(CscsResizeEvent *);

    void changeEvent(CscsEvent *);
    void moveSplitter(int pos, int index);
    void setRubberBand(int position);
    int closestLegalPosition(int, int);

private:
    CscsSplitterPrivate* d_func()const;
private:
    friend class CscsSplitterHandle;
    friend class CscsSplitterPrivate;

BEGIN_PROPERTY(CscsSplitter,CscsFrame)
    META_PROPERTY(SCS::Orientation, orientation, READ, orientation, WRITE, setOrientation)
    META_PROPERTY(bool, opaqueResize, READ, opaqueResize, WRITE, setOpaqueResize)
    META_PROPERTY(int, handleWidth, READ, handleWidth, WRITE, setHandleWidth)
    META_PROPERTY(bool, childrenCollapsible, READ, childrenCollapsible, WRITE, setChildrenCollapsible)
END_PROPERTY
};


class CscsSplitterHandlePrivate;
class  CscsSplitterHandle : public CscsWidget
{
public:
    CscsSplitterHandle(SCS::Orientation o, CscsSplitter *parent);
    void setOrientation(SCS::Orientation o);
    SCS::Orientation orientation() const;
    bool opaqueResize() const;
    CscsSplitter *splitter() const;

    CscsSize sizeHint() const;

protected:
    void paintEvent(CscsPaintEvent *);
    void mouseMoveEvent(CscsMouseEvent *);
    void mousePressEvent(CscsMouseEvent *);
    void mouseReleaseEvent(CscsMouseEvent *);
    bool event(CscsEvent *);

    void moveSplitter(int p);
    int closestLegalPosition(int p);

private:
    CscsSplitterHandlePrivate* d_func()const;
};

END_NAMESPACE
#endif