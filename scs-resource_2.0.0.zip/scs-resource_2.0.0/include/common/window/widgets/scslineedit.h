#ifndef SCSLINEEDIT_H
#define SCSLINEEDIT_H
#include "scsframe.h"

BEGIN_NAMESPACE(Gemini)

class CscsLineEditPrivate;
class CscsValidator;
struct CscsCharAttributes;

class WIDGET_EXPORT CscsLineEdit:public CscsWidget{

public:
    // struct CscsCharAttributes {
    // uint8 softBreak      :1;     // Potential linebreak point _before_ this character
    // uint8 whiteSpace     :1;     // A unicode whitespace character, except NBSP, ZWNBSP
    // uint8 charStop       :1;     // Valid cursor position (for left/right arrow)
    // uint8 wordStop       :1;     // Valid cursor position (for ctrl + left/right arrow)
    // uint8 invalid        :1;
    // uint8 reserved       :3;
    // };

	enum CursorPosition{
		CursorBetweenCharacters,
		CursorOnCharacter
	};

    enum CursorMode {
        SkipCharacters,
        SkipWords
    };

	explicit CscsLineEdit(CscsWidget* parent=0);
    explicit CscsLineEdit(const std::string& , CscsWidget* parent=0);
    ~CscsLineEdit();

    std::string text() const;

    std::string displayText() const;

    int maxLength() const;
    void setMaxLength(int);

    void setFrame(bool);
    bool hasFrame() const;

    enum EchoMode { Normal, NoEcho, Password, PasswordOnEdit};
    EchoMode echoMode() const;
    void setEchoMode(EchoMode);

    bool isReadOnly() const;
    void setReadOnly(bool);

    void setValidator(const CscsValidator* );
    const CscsValidator* validator() const;
    
    CscsSize sizeHint() const;
    CscsSize minimumSizeHint() const;

    int cursorPosition() const;
    void setCursorPosition(int);
    int cursorPositionAt(const CscsPoint &pos);

    void setAlignment(SCS::Alignment flag);
    SCS::Alignment alignment() const;

    void cursorForward(bool mark, int steps = 1);
    void cursorBackward(bool mark, int steps = 1);
    void cursorWordForward(bool mark);
    void cursorWordBackward(bool mark);
    void backspace();
    void del();
    void home(bool mark);
    void end(bool mark);

    bool isModified() const;
    void setModified(bool);

    void setSelection(int, int);
    bool hasSelectedText() const;
    std::string selectedText() const;
    int selectionStart() const;

    bool isUndoAvailable() const;
    bool isRedoAvailable() const;

    void setDragEnabled(bool b);
    bool dragEnabled() const;

    std::string inputMask() const;
    void setInputMask(const std::string &inputMask);
    bool hasAcceptableInput() const;

SLOTS:
    void setText(const std::string& );
    void clear();
    void selectAll();
    void undo();
    void redo();

public:
    void deselect();
    void insert(const std::string &);
    
SIGNALS:
    void textChanged(const std::string& );
    void textEdited(const std::string& );
    void cursorPositionChanged(int, int);
    void returnPressed();
    void editingFinished();
    void selectionChanged();

protected:
    void mousePressEvent(CscsMouseEvent *);
    void mouseMoveEvent(CscsMouseEvent *);
    void mouseReleaseEvent(CscsMouseEvent *);
    void mouseDoubleClickEvent(CscsMouseEvent *);
    void keyPressEvent(CscsKeyEvent *);
    void focusInEvent(CscsFocusEvent *);
    void focusOutEvent(CscsFocusEvent *);
    void paintEvent(CscsPaintEvent *);

    void changeEvent(CscsEvent *);
public:
    bool event(CscsEvent *);

private:
    CscsLineEditPrivate* d_func()const;
    const CscsCharAttributes* attributes();
    CscsCharAttributes* charAttributes;
    int length;
    friend class CscsLineEditPrivate;

BEGIN_PROPERTY(CscsLineEdit,CscsWidget)
    META_PROPERTY(std::string, inputMask, READ, inputMask, WRITE, setInputMask)
    META_PROPERTY(std::string, text, READ, text, WRITE, setText)
    META_PROPERTY(int, maxLength, READ, maxLength, WRITE, setMaxLength)
    META_PROPERTY(bool, frame, READ, hasFrame, WRITE, setFrame)
    META_PROPERTY(EchoMode, echoMode, READ, echoMode, WRITE, setEchoMode)
    META_READ_PROPERTY(std::string, displayText, READ, displayText)
    META_PROPERTY(int, cursorPosition, READ, cursorPosition, WRITE, setCursorPosition)
    META_PROPERTY(SCS::Alignment, alignment, READ, alignment, WRITE, setAlignment)
    META_READ_PROPERTY(bool, hasSelectedText, READ, hasSelectedText)
    META_READ_PROPERTY(std::string, selectedText, READ, selectedText)
    META_PROPERTY(bool, readOnly, READ, isReadOnly, WRITE, setReadOnly)
    META_READ_PROPERTY(bool, undoAvailable, READ, isUndoAvailable)
    META_READ_PROPERTY(bool, redoAvailable, READ, isRedoAvailable)
    META_READ_PROPERTY(bool, acceptableInput, READ, hasAcceptableInput)
END_PROPERTY

};

END_NAMESPACE

#endif