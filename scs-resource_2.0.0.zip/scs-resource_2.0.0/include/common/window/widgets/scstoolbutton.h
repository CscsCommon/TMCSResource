#ifndef SCSTOOLBUTTON_H
#define SCSTOOLBUTTON_H
#include "scsabstractbutton.h"
#include "../styles/scscommonstyle.h"
#include "../styles/scsstyleoption.h"

BEGIN_NAMESPACE(Gemini)

class CscsToolButtonPrivate;
class CscsStyleOptionToolButton;

class WIDGET_EXPORT CscsToolButton:public CscsAbstractButton
{

public:
	enum ToolButtonPopupMode{
		DelayedPopup,
		MenuButtonPopup,
		InstantPopup
	};

	explicit CscsToolButton(CscsWidget *parent = nullptr);
	~CscsToolButton();

	CscsSize sizeHint() const override;
	CscsSize minimumSizeHint() const override;

	SCS::ArrowType arrowType() const;
	void setArrowType(SCS::ArrowType type);

	void setAutoRaise(bool enable);
	bool autoRaise() const;

	//slots:
	void setToolButtonStyle(SCS::ToolButtonStyle style);
	SCS::ToolButtonStyle toolButtonStyle() const;

	void setPopupMode(ToolButtonPopupMode mode);
	CscsToolButton::ToolButtonPopupMode popmode() const;

	void initStyleOption(CscsStyleOptionToolButton *option) const;
	CscsToolButtonPrivate *d_func() const;


protected:
	bool event(CscsEvent *e) override;
	void mousePressEvent(CscsMouseEvent *) override;
	void mouseReleaseEvent(CscsMouseEvent *) override;
	void paintEvent(CscsPaintEvent *) override;

	void enterEvent(CscsEvent *) override;
	void leaveEvent(CscsEvent *) override;
	void timerEvent(CscsTimerEvent *) override;
	void changeEvent(CscsEvent *) override;

	bool hitButton(const CscsPoint &pos) const override;
	void nextCheckState() override;

private:

BEGIN_PROPERTY(CscsToolButton,CscsAbstractButton)
	META_PROPERTY(SCS::ToolButtonStyle, toolButtonStyle, READ, toolButtonStyle, WRITE, setToolButtonStyle)
    META_PROPERTY(bool, autoRaise, READ, autoRaise, WRITE, setAutoRaise)
    META_PROPERTY(SCS::ArrowType, arrowType, READ, arrowType, WRITE, setArrowType)
END_PROPERTY

};

END_NAMESPACE

#endif
