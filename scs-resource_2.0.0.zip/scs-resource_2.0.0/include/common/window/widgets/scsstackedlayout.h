#ifndef SCSSTACKEDLAYOUT_H
#define SCSSTACKEDLAYOUT_H
#include "scslayout.h"

BEGIN_NAMESPACE(Gemini)

class CscsStackedLayoutPrivate;
class CscsWidget;
class  CscsStackedLayout : public CscsLayout
{
public:
    CscsStackedLayout();
    explicit CscsStackedLayout(CscsWidget *parent);
    explicit CscsStackedLayout(CscsLayout *parentLayout);
    ~CscsStackedLayout();

    int addWidget(CscsWidget *w);
    int insertWidget(int index, CscsWidget *w);

    CscsWidget *currentWidget() const;
    int currentIndex() const;
    using CscsLayout::widget;
    CscsWidget *widget(int) const;
    int count() const;

    // abstract virtual functions:
    void addItem(CscsLayoutItem *item);
    CscsSize sizeHint() const;
    CscsSize minimumSize() const;
    CscsLayoutItem *itemAt(int) const;
    CscsLayoutItem *takeAt(int);
    void setGeometry(const CscsRect &rect);

SIGNALS:
    void widgetRemoved(int index){}
    void currentChanged(int index){}

SLOTS:
    void setCurrentIndex(int index);
    void setCurrentWidget(CscsWidget *w);

private:
  	CscsStackedLayoutPrivate* d_func()const;
};

END_NAMESPACE

#endif