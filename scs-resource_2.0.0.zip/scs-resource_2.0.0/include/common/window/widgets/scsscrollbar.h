#ifndef SCSSCROLLBAR_H
#define SCSSCROLLBAR_H

#include <window/scswidget.h>
#include <window/scswindowevent.h>
#include <window/widgets/scsabstractslider.h>

BEGIN_NAMESPACE(Gemini)

class CscsScrollBarPrivate;

class  WIDGET_EXPORT CscsScrollBar : public CscsAbstractSlider
{
public:
    explicit CscsScrollBar(CscsWidget *parent=0);
    explicit CscsScrollBar(SCS::Orientation, CscsWidget *parent=0);
    ~CscsScrollBar();

    CscsSize sizeHint() const;
    bool event(CscsEvent *event);

    CscsScrollBarPrivate *d_func() const;

protected:
    void paintEvent(CscsPaintEvent *);
    void mousePressEvent(CscsMouseEvent *);
    void mouseReleaseEvent(CscsMouseEvent *);
    void mouseMoveEvent(CscsMouseEvent *);
    void hideEvent(CscsHideEvent*);
    void sliderChange(SliderChange change);

    friend class CscsScrollBarPrivate;

};

END_NAMESPACE

#endif