#ifndef SCSFONTMETRICS_H
#define SCSFONTMETRICS_H
#include <painting/scsfont.h>

BEGIN_NAMESPACE(Gemini)

class CscsRect;
class CscsFontMetricsData;

class CscsFontMetrics{
public:
	CscsFontMetrics(const CscsFont& f);
	CscsFontMetrics(const CscsFontMetrics& fm);
	CscsFontMetrics& operator=(const CscsFontMetrics& fm);
	~CscsFontMetrics();
	int ascent()const;
	int descent()const;
	int height()const;
	int leading()const;
	int lineSpacing()const;
	int minLeftBearing()const;
	int minRightBearing()const;
	int maxWidth()const;

	int leftBearing(CscsChar c)const;
	int rightBearing(CscsChar c)const;
	int width(const CscsString& str, int len=-1)const;
	int width(CscsChar )const;
	int charWidth(const CscsString& str, int pos)const;
	CscsRect boundingRect(const CscsString& str)const;
	CscsRect boundingRect(CscsChar ch)const;
	CscsRect boundingRect(const CscsRect& r, int flags, const CscsString& str, int tabStops=0,int* tabArray=0)const;
	inline CscsRect boundingRect(int x, int y, int w, int h, int flags,
	 	const CscsString& str,int tabStops=0, int* tabArray=0)const{
		
		return boundingRect(CscsRect(x, y, w, h),flags,str,tabStops,tabArray);
	}

	CscsSize size(int flags, const CscsString& str, int tabStops=0, int* tabArray=0)const;

	int lineWidth()const;

	bool operator==(const CscsFontMetrics& o);
	inline bool operator!=(const CscsFontMetrics& o){
		return !operator==(o);
	}

private:
	CscsFontMetricsData* d;
};

END_NAMESPACE

#endif