#ifndef SCSABSTRACTTEXTDOCUMENTLAYOUT_H
#define SCSABSTRACTTEXTDOCUMENTLAYOUT_H

#include <kernel/scsobject.h>
#include "scstextlayout.h"
#include "scstextdocument.h"
#include "scstextcursor.h"
#include <window/styles/scspalette.h>

BEGIN_NAMESPACE(Gemini)

class CscsAbstractTextDocumentLayoutPrivate;
class CscsTextBlock;
class CscsTextObjectInterface;
class CscsTextFrame;

class  CscsAbstractTextDocumentLayout : public CscsObject
{
    CscsAbstractTextDocumentLayoutPrivate* d_func()const;

public:
    explicit CscsAbstractTextDocumentLayout(CscsTextDocument *doc);
    ~CscsAbstractTextDocumentLayout();

    struct Selection
    {
        CscsTextCursor cursor;
        CscsTextCharFormat format;
    };

    struct PaintContext
    {
        PaintContext()
            : cursorPosition(-1)
            {}
        int cursorPosition;
        CscsPalette palette;
        CscsRectF clip;
        CscsVector<Selection> selections;
    };

    virtual void draw(CscsPainter *painter, const PaintContext &context) = 0;
    virtual int hitTest(const CscsPointF &point, SCS::HitTestAccuracy accuracy) const = 0;
    CscsString anchorAt(const CscsPointF& pos) const;

    virtual int pageCount() const = 0;
    virtual CscsSizeF documentSize() const = 0;

    virtual CscsRectF frameBoundingRect(CscsTextFrame *frame) const = 0;
    virtual CscsRectF blockBoundingRect(const CscsTextBlock &block) const = 0;


    CscsTextDocument *document() const;

    void registerHandler(int objectType, CscsObject *component);
    CscsTextObjectInterface *handlerForObject(int objectType) const;

SIGNALS:
    void update(const CscsRectF & = CscsRectF(0., 0., 1000000000., 1000000000.)){}
    void updateBlock(const CscsTextBlock &block){}
    void documentSizeChanged(const CscsSizeF &newSize){}
    void pageCountChanged(int newPages){}

protected:
    CscsAbstractTextDocumentLayout(CscsAbstractTextDocumentLayoutPrivate* dd, CscsTextDocument *);

    virtual void documentChanged(int from, int charsRemoved, int charsAdded) = 0;

    virtual void resizeInlineObject(CscsTextInlineObject item, int posInDocument, const CscsTextFormat &format);
    virtual void positionInlineObject(CscsTextInlineObject item, int posInDocument, const CscsTextFormat &format);
    virtual void drawInlineObject(CscsPainter *painter, const CscsRectF &rect, CscsTextInlineObject object, int posInDocument, const CscsTextFormat &format);

    int formatIndex(int pos);
    CscsTextCharFormat format(int pos);

private:
    friend class CscsTextDocument;
    friend class CscsTextDocumentPrivate;
    friend class CscsTextEngine;
    friend class CscsTextLayout;
    friend class CscsTextLine;
};

class  CscsTextObjectInterface:public CscsObject
{
public:
	CscsTextObjectInterface(CscsObject* parent=nullptr);
    virtual ~CscsTextObjectInterface() {}
    virtual CscsSizeF intrinsicSize(CscsTextDocument *doc, int posInDocument, const CscsTextFormat &format) = 0;
    virtual void drawObject(CscsPainter *painter, const CscsRectF &rect, CscsTextDocument *doc, int posInDocument, const CscsTextFormat &format) = 0;
};

END_NAMESPACE
#endif