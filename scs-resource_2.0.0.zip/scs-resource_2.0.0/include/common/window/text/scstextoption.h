#ifndef SCSTEXTOPTION_H
#define SCSTEXTOPTION_H
#include <kernel/scschar.h>
#include <painting/scsmath.h>
#include <window/scsenum.h>
#include <kernel/scstypeinfo.h>

BEGIN_NAMESPACE(Gemini)

template <typename T> class CscsList;

struct CscsTextOptionPrivate;

class CscsTextOption{
	public:
		enum TabType {
	        LeftTab,
	        RightTab,
	        CenterTab,
	        DelimiterTab
    	};

    	struct  Tab {
	        inline Tab() : position(80), type(CscsTextOption::LeftTab) { }
	        inline Tab(double pos, TabType tabType, CscsChar delim = CscsChar())
	            : position(pos), type(tabType), delimiter(delim) {}

	        inline bool operator==(const Tab &other) const {
	            return type == other.type
	                   && scsFuzzyCompare(position, other.position)
	                   && delimiter == other.delimiter;
	        }

	        inline bool operator!=(const Tab &other) const {
	            return !operator==(other);
	        }

	        double position;
	        TabType type;
	        CscsChar delimiter;
    	};

		CscsTextOption();
		CscsTextOption(SCS::Alignment alignment);
		~CscsTextOption();

		CscsTextOption(const CscsTextOption& o);
		CscsTextOption& operator=(const CscsTextOption& o);

		inline void setAlignment(SCS::Alignment aalignment);
		inline SCS::Alignment alignment()const{
			return SCS::Alignment(align);
		}

		inline void setTextDirection(SCS::LayoutDirection dir){
			 direction = dir;
		}

		 inline SCS::LayoutDirection textDirection() const { return SCS::LayoutDirection(direction); }

		enum WrapMode{
			NoWrap,
			WordWrap,
			ManualWrap,
			WrapAnywhere,
			WrapAtWordBoundaryOrAnywhere
		};

		inline void setWrapMode(WrapMode wrap){
			wordWrap=wrap;
		}
		
		inline WrapMode wrapMode()const{
			return static_cast<WrapMode>(wordWrap);
		}
		enum Flag{
			IncludeTrailingSpaces=0x80000000
		};
		SCS_DECLARE_FLAGS(Flags,Flag)

		inline void setFlags(Flags aflags);
		inline Flags flags()const{
			return Flags(f);
		}

		inline void setTabStop(double atabStop);
		inline double tabStop()const{
			return tab;
		}

		void setTabArray(const CscsList<double>& tabStops);
		CscsList<double> tabArray()const;

		void setTabs(const CscsList<Tab> &tabStops);
   		CscsList<Tab> tabs() const;

		void setUseDesignMetrics(bool b){
			design=b;
		}
		bool useDesignMetrics()const{
			return design;
		}
	private:
		uint align:8;
		uint wordWrap:4;
		uint design:1;
		uint direction:1;
		uint unused:19;
		uint f;
		double tab;
		CscsTextOptionPrivate* d;

};

SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsTextOption::Flags)

inline void CscsTextOption::setAlignment(SCS::Alignment aalignment){
	align=aalignment;
}

inline void CscsTextOption::setFlags(Flags aflags){
	f=aflags;
}

inline void CscsTextOption::setTabStop(double atabStop){
	tab=atabStop;
}

END_NAMESPACE


#endif