#ifndef SCSTEXTFORMAT_H
#define SCSTEXTFORMAT_H

#include <kernel/scsvariant.h>
#include <painting/scsrgba.h>
#include <painting/scsfont.h>
#include <kernel/scsvector.h>
#include <painting/scspen.h>
#include <painting/scsbrush.h>
#include <painting/scsmath.h>
#include <kernel/scslist.h>
#include <kernel/scsmap.h>
#include <kernel/scsvector.h>
#include <kernel/scsstringlist.h>
#include <kernel/scsshareddata.h>

#include "scstextoption.h"

BEGIN_NAMESPACE(Gemini)

class CscsVariant;
class CscsString;
class CscsFont;
class CscsTextFormatCollection;
class CscsTextFormatPrivate;
class CscsTextBlockFormat;
class CscsTextCharFormat;
class CscsTextListFormat;
class CscsTextTableFormat;
class CscsTextFrameFormat;
class CscsTextImageFormat;
class CscsTextTableCellFormat;
class CscsTextFormat;
class CscsTextObject;
class CscsTextCursor;
class CscsTextDocument;
class CscsTextLength;

class  CscsTextLength
{
public:
    enum Type { VariableLength = 0, FixedLength, PercentageLength };

    inline CscsTextLength() : lengthType(VariableLength), fixedValueOrPercentage(0) {}

    inline explicit CscsTextLength(Type type, double value);

    inline Type type() const { return lengthType; }
    inline double value(double maximumLength) const
    {
        switch (lengthType) {
            case FixedLength: return fixedValueOrPercentage;
            case VariableLength: return maximumLength;
            case PercentageLength: return fixedValueOrPercentage * maximumLength / double(100);
        }
        return -1;
    }

    inline double rawValue() const { return fixedValueOrPercentage; }

    inline bool operator==(const CscsTextLength &other) const
    { return lengthType == other.lengthType
             && scsFuzzyCompare(fixedValueOrPercentage, other.fixedValueOrPercentage); }
    inline bool operator!=(const CscsTextLength &other) const
    { return lengthType != other.lengthType
             || !scsFuzzyCompare(fixedValueOrPercentage, other.fixedValueOrPercentage); }
    operator CscsVariant() const;

private:
    Type lengthType;
    double fixedValueOrPercentage;
};
inline CscsTextLength::CscsTextLength(Type atype, double avalue)
    : lengthType(atype), fixedValueOrPercentage(avalue) {}


class  CscsTextFormat
{

public:
    enum FormatType {
        InvalidFormat = -1,
        BlockFormat = 1,
        CharFormat = 2,
        ListFormat = 3,
        TableFormat = 4,
        FrameFormat = 5,

        UserFormat = 100
    };

    enum Property {
        ObjectIndex = 0x0,

        // paragraph and char
        CssFloat = 0x0800,
        LayoutDirection = 0x0801,

        OutlinePen = 0x810,
        BackgroundBrush = 0x820,
        ForegroundBrush = 0x821,
        BackgroundImageUrl = 0x823,

        // paragraph
        BlockAlignment = 0x1010,
        BlockTopMargin = 0x1030,
        BlockBottomMargin = 0x1031,
        BlockLeftMargin = 0x1032,
        BlockRightMargin = 0x1033,
        TextIndent = 0x1034,
        TabPositions = 0x1035,
        BlockIndent = 0x1040,
        BlockNonBreakableLines = 0x1050,
        BlockTrailingHorizontalRulerWidth = 0x1060,

        // character properties
        FirstFontProperty = 0x1FE0,
        FontCapitalization = FirstFontProperty,
        FontLetterSpacing = 0x1FE1,
        FontWordSpacing = 0x1FE2,
        FontFamily = 0x2000,
        FontPointSize = 0x2001,
        FontSizeAdjustment = 0x2002,
        FontSizeIncrement = FontSizeAdjustment, // old name, compat
        FontWeight = 0x2003,
        FontItalic = 0x2004,
        FontUnderline = 0x2005, // deprecated, use TextUnderlineStyle instead
        FontOverline = 0x2006,
        FontStrikeOut = 0x2007,
        FontFixedPitch = 0x2008,
        FontPixelSize = 0x2009,
        LastFontProperty = FontPixelSize,

        TextUnderlineColor = 0x2010,
        TextVerticalAlignment = 0x2021,
        TextOutline = 0x2022,
        TextUnderlineStyle = 0x2023,
        TextToolTip = 0x2024,

        IsAnchor = 0x2030,
        AnchorHref = 0x2031,
        AnchorName = 0x2032,

        ObjectType = 0x2f00,

        // list properties
        ListStyle = 0x3000,
        ListIndent = 0x3001,

        // table and frame properties
        FrameBorder = 0x4000,
        FrameMargin = 0x4001,
        FramePadding = 0x4002,
        FrameWidth = 0x4003,
        FrameHeight = 0x4004,
        FrameTopMargin    = 0x4005,
        FrameBottomMargin = 0x4006,
        FrameLeftMargin   = 0x4007,
        FrameRightMargin  = 0x4008,
        FrameBorderBrush = 0x4009,
        FrameBorderStyle = 0x4010,

        TableColumns = 0x4100,
        TableColumnWidthConstraints = 0x4101,
        TableCellSpacing = 0x4102,
        TableCellPadding = 0x4103,
        TableHeaderRowCount = 0x4104,

        // table cell properties
        TableCellRowSpan = 0x4810,
        TableCellColumnSpan = 0x4811,

        TableCellTopPadding = 0x4812,
        TableCellBottomPadding = 0x4813,
        TableCellLeftPadding = 0x4814,
        TableCellRightPadding = 0x4815,

        // image properties
        ImageName = 0x5000,
        ImageWidth = 0x5010,
        ImageHeight = 0x5011,

        // selection properties
        FullWidthSelection = 0x06000,

        // page break properties
        PageBreakPolicy = 0x7000,

        // --
        UserProperty = 0x100000
    };

    enum ObjectTypes {
        NoObject,
        ImageObject,
        TableObject,
        TableCellObject,

        UserObject = 0x1000
    };

    enum PageBreakFlag {
        PageBreak_Auto = 0,
        PageBreak_AlwaysBefore = 0x001,
        PageBreak_AlwaysAfter  = 0x010
    };
    SCS_DECLARE_FLAGS(PageBreakFlags, PageBreakFlag)

    CscsTextFormat();

    explicit CscsTextFormat(int type);

    CscsTextFormat(const CscsTextFormat &rhs);
    CscsTextFormat &operator=(const CscsTextFormat &rhs);
    ~CscsTextFormat();

    void merge(const CscsTextFormat &other);

    inline bool isValid() const { return type() != InvalidFormat; }

    int type() const;

    int objectIndex() const;
    void setObjectIndex(int object);

    CscsVariant property(int propertyId) const;
    void setProperty(int propertyId, const CscsVariant &value);
    void clearProperty(int propertyId);
    bool hasProperty(int propertyId) const;

    bool boolProperty(int propertyId) const;
    int intProperty(int propertyId) const;
    double doubleProperty(int propertyId) const;
    CscsString stringProperty(int propertyId) const;
    CscsRgba colorProperty(int propertyId) const;
    CscsPen penProperty(int propertyId) const;
    CscsBrush brushProperty(int propertyId) const;
    CscsTextLength lengthProperty(int propertyId) const;
    CscsVector<CscsTextLength> lengthVectorProperty(int propertyId) const;

    void setProperty(int propertyId, const CscsVector<CscsTextLength> &lengths);

    CscsMap<int, CscsVariant> properties() const;
    int propertyCount() const;

    inline void setObjectType(int type);
    inline int objectType() const
    { return intProperty(ObjectType); }

    inline bool isCharFormat() const { return type() == CharFormat; }
    inline bool isBlockFormat() const { return type() == BlockFormat; }
    inline bool isListFormat() const { return type() == ListFormat; }
    inline bool isFrameFormat() const { return type() == FrameFormat; }
    inline bool isImageFormat() const { return type() == CharFormat && objectType() == ImageObject; }
    inline bool isTableFormat() const { return type() == FrameFormat && objectType() == TableObject; }
    inline bool isTableCellFormat() const { return type() == CharFormat && objectType() == TableCellObject; }

    CscsTextBlockFormat toBlockFormat() const;
    CscsTextCharFormat toCharFormat() const;
    CscsTextListFormat toListFormat() const;
    CscsTextTableFormat toTableFormat() const;
    CscsTextFrameFormat toFrameFormat() const;
    CscsTextImageFormat toImageFormat() const;
    CscsTextTableCellFormat toTableCellFormat() const;

    bool operator==(const CscsTextFormat &rhs) const;
    inline bool operator!=(const CscsTextFormat &rhs) const { return !operator==(rhs); }
    operator CscsVariant() const;

    inline void setLayoutDirection(SCS::LayoutDirection direction)
        { setProperty(CscsTextFormat::LayoutDirection, direction); }
    inline SCS::LayoutDirection layoutDirection() const
        { return SCS::LayoutDirection(intProperty(CscsTextFormat::LayoutDirection)); }

    inline void setBackground(const CscsBrush &brush)
    { setProperty(BackgroundBrush, brush); }
    inline CscsBrush background() const
    { return brushProperty(BackgroundBrush); }
    inline void clearBackground()
    { clearProperty(BackgroundBrush); }

    inline void setForeground(const CscsBrush &brush)
    { setProperty(ForegroundBrush, brush); }
    inline CscsBrush foreground() const
    { return brushProperty(ForegroundBrush); }
    inline void clearForeground()
    { clearProperty(ForegroundBrush); }

private:
    CscsSharedDataPointer<CscsTextFormatPrivate> d;
    int format_type;

    friend class CscsTextFormatCollection;
    friend class CscsTextCharFormat;
};

inline void CscsTextFormat::setObjectType(int atype)
{ setProperty(ObjectType, atype); }

SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsTextFormat::PageBreakFlags)

class  CscsTextCharFormat : public CscsTextFormat
{
public:
    enum VerticalAlignment {
        AlignNormal = 0,
        AlignSuperScript,
        AlignSubScript,
        AlignMiddle,
        AlignTop,
        AlignBottom
    };
    enum UnderlineStyle { // keep in sync with SCS::PenStyle!
        NoUnderline,
        SingleUnderline,
        DashUnderline,
        DotLine,
        DashDotLine,
        DashDotDotLine,
        WaveUnderline,
        SpellCheckUnderline
    };

    CscsTextCharFormat();

    bool isValid() const { return isCharFormat(); }
    void setFont(const CscsFont &font);
    CscsFont font() const;

    inline void setFontFamily(const CscsString &family)
    { setProperty(FontFamily, family); }
    inline CscsString fontFamily() const
    { return stringProperty(FontFamily); }

    inline void setFontPointSize(double size)
    { setProperty(FontPointSize, size); }
    inline double fontPointSize() const
    { return doubleProperty(FontPointSize); }

    inline void setFontWeight(bool weight)
    { setProperty(FontWeight, weight); }
    inline int fontWeight() const
    { bool weight = boolProperty(FontWeight); return weight; }
    inline void setFontItalic(bool italic)
    { setProperty(FontItalic, italic); }
    inline bool fontItalic() const
    { return boolProperty(FontItalic); }
    inline void setFontCapitalization(int cap)
    { setProperty(FontCapitalization, cap); }
    inline int fontCapitalization() const
    { return intProperty(FontCapitalization); }
    inline void setFontLetterSpacing(double spacing)
    { setProperty(FontLetterSpacing, spacing); }
    inline double fontLetterSpacing() const
    { return doubleProperty(FontLetterSpacing); }
    inline void setFontWordSpacing(double spacing)
    { setProperty(FontWordSpacing, spacing); }
    inline double fontWordSpacing() const
    { return doubleProperty(FontWordSpacing); }

    inline void setFontUnderline(bool underline)
    { setProperty(TextUnderlineStyle, underline ? SingleUnderline : NoUnderline); }
    bool fontUnderline() const;

    inline void setFontOverline(bool overline)
    { setProperty(FontOverline, overline); }
    inline bool fontOverline() const
    { return boolProperty(FontOverline); }

    inline void setFontStrikeOut(bool strikeOut)
    { setProperty(FontStrikeOut, strikeOut); }
    inline bool fontStrikeOut() const
    { return boolProperty(FontStrikeOut); }

    inline void setUnderlineColor(const CscsRgba &color)
    { setProperty(TextUnderlineColor, color); }
    inline CscsRgba underlineColor() const
    { return colorProperty(TextUnderlineColor); }

    inline void setFontFixedPitch(bool fixedPitch)
    { setProperty(FontFixedPitch, fixedPitch); }
    inline bool fontFixedPitch() const
    { return boolProperty(FontFixedPitch); }

    void setUnderlineStyle(UnderlineStyle style);
    inline UnderlineStyle underlineStyle() const
    { return static_cast<UnderlineStyle>(intProperty(TextUnderlineStyle)); }

    inline void setVerticalAlignment(VerticalAlignment alignment)
    { setProperty(TextVerticalAlignment, alignment); }
    inline VerticalAlignment verticalAlignment() const
    { return static_cast<VerticalAlignment>(intProperty(TextVerticalAlignment)); }

    inline void setTextOutline(const CscsPen &pen)
    { setProperty(TextOutline, pen); }
    inline CscsPen textOutline() const
    { return penProperty(TextOutline); }

    inline void setToolTip(const CscsString &tip)
    { setProperty(TextToolTip, tip); }
    inline CscsString toolTip() const
    { return stringProperty(TextToolTip); }

    inline void setAnchor(bool anchor)
    { setProperty(IsAnchor, anchor); }
    inline bool isAnchor() const
    { return boolProperty(IsAnchor); }

    inline void setAnchorHref(const CscsString &value)
    { setProperty(AnchorHref, value); }
    inline CscsString anchorHref() const
    { return stringProperty(AnchorHref); }

    inline void setAnchorName(const CscsString &name)
    { setAnchorNames(CscsStringList(name)); }
    CscsString anchorName() const;

    inline void setAnchorNames(const CscsStringList &names)
    { setProperty(AnchorName, names); }
    CscsStringList anchorNames() const;

    inline void setTableCellRowSpan(int tableCellRowSpan);
    inline int tableCellRowSpan() const
    { int s = intProperty(TableCellRowSpan); if (s == 0) s = 1; return s; }
    inline void setTableCellColumnSpan(int tableCellColumnSpan);
    inline int tableCellColumnSpan() const
    { int s = intProperty(TableCellColumnSpan); if (s == 0) s = 1; return s; }

protected:
    explicit CscsTextCharFormat(const CscsTextFormat &fmt);
    friend class CscsTextFormat;
};

inline void CscsTextCharFormat::setTableCellRowSpan(int atableCellRowSpan)
{
    if (atableCellRowSpan == 1)
	atableCellRowSpan = 0;
    setProperty(TableCellRowSpan, atableCellRowSpan);
}

inline void CscsTextCharFormat::setTableCellColumnSpan(int atableCellColumnSpan)
{
    if (atableCellColumnSpan == 1)
	atableCellColumnSpan = 0;
    setProperty(TableCellColumnSpan, atableCellColumnSpan);
}

class  CscsTextBlockFormat : public CscsTextFormat
{
public:
    CscsTextBlockFormat();

    bool isValid() const { return isBlockFormat(); }

    inline void setAlignment(SCS::Alignment alignment);
    inline SCS::Alignment alignment() const
    { int a = intProperty(BlockAlignment); if (a == 0) a = SCS::AlignLeft; return CscsFlag(a); }

    inline void setTopMargin(double margin)
    { setProperty(BlockTopMargin, margin); }
    inline double topMargin() const
    { return doubleProperty(BlockTopMargin); }

    inline void setBottomMargin(double margin)
    { setProperty(BlockBottomMargin, margin); }
    inline double bottomMargin() const
    { return doubleProperty(BlockBottomMargin); }

    inline void setLeftMargin(double margin)
    { setProperty(BlockLeftMargin, margin); }
    inline double leftMargin() const
    { return doubleProperty(BlockLeftMargin); }

    inline void setRightMargin(double margin)
    { setProperty(BlockRightMargin, margin); }
    inline double rightMargin() const
    { return doubleProperty(BlockRightMargin); }

    inline void setTextIndent(double margin)
    { setProperty(TextIndent, margin); }
    inline double textIndent() const
    { return doubleProperty(TextIndent); }

    inline void setIndent(int indent);
    inline int indent() const
    { return intProperty(BlockIndent); }

    inline void setNonBreakableLines(bool b)
    { setProperty(BlockNonBreakableLines, b); }
    inline bool nonBreakableLines() const
    { return boolProperty(BlockNonBreakableLines); }

    inline void setPageBreakPolicy(PageBreakFlags flags)
    { setProperty(PageBreakPolicy, int(flags)); }
    inline PageBreakFlags pageBreakPolicy() const
    { return PageBreakFlags(intProperty(PageBreakPolicy)); }

    void setTabPositions(const CscsList<CscsTextOption::Tab> &tabs);
    CscsList<CscsTextOption::Tab> tabPositions() const;

protected:
    explicit CscsTextBlockFormat(const CscsTextFormat &fmt);
    friend class CscsTextFormat;
};

inline void CscsTextBlockFormat::setAlignment(SCS::Alignment aalignment)
{ setProperty(BlockAlignment, int(aalignment)); }

inline void CscsTextBlockFormat::setIndent(int aindent)
{ setProperty(BlockIndent, aindent); }

class  CscsTextListFormat : public CscsTextFormat
{
public:
    CscsTextListFormat();

    bool isValid() const { return isListFormat(); }

    enum Style {
        ListDisc = -1,
        ListCircle = -2,
        ListSquare = -3,
        ListDecimal = -4,
        ListLowerAlpha = -5,
        ListUpperAlpha = -6,
        ListStyleUndefined = 0
    };

    inline void setStyle(Style style);
    inline Style style() const
    { return static_cast<Style>(intProperty(ListStyle)); }

    inline void setIndent(int indent);
    inline int indent() const
    { return intProperty(ListIndent); }

protected:
    explicit CscsTextListFormat(const CscsTextFormat &fmt);
    friend class CscsTextFormat;
};

inline void CscsTextListFormat::setStyle(Style astyle)
{ setProperty(ListStyle, astyle); }

inline void CscsTextListFormat::setIndent(int aindent)
{ setProperty(ListIndent, aindent); }

class  CscsTextImageFormat : public CscsTextCharFormat
{
public:
    CscsTextImageFormat();

    bool isValid() const { return isImageFormat(); }

    inline void setName(const CscsString &name);
    inline CscsString name() const
    { return stringProperty(ImageName); }

    inline void setWidth(double width);
    inline double width() const
    { return doubleProperty(ImageWidth); }

    inline void setHeight(double height);
    inline double height() const
    { return doubleProperty(ImageHeight); }

protected:
    explicit CscsTextImageFormat(const CscsTextFormat &format);
    friend class CscsTextFormat;
};

inline void CscsTextImageFormat::setName(const CscsString &aname)
{ setProperty(ImageName, aname); }

inline void CscsTextImageFormat::setWidth(double awidth)
{ setProperty(ImageWidth, awidth); }

inline void CscsTextImageFormat::setHeight(double aheight)
{ setProperty(ImageHeight, aheight); }

class  CscsTextFrameFormat : public CscsTextFormat
{
public:
    CscsTextFrameFormat();

    bool isValid() const { return isFrameFormat(); }

    enum Position {
        InFlow,
        FloatLeft,
        FloatRight
    };

    enum BorderStyle {
        BorderStyle_None,
        BorderStyle_Dotted,
        BorderStyle_Dashed,
        BorderStyle_Solid,
        BorderStyle_Double,
        BorderStyle_DotDash,
        BorderStyle_DotDotDash,
        BorderStyle_Groove,
        BorderStyle_Ridge,
        BorderStyle_Inset,
        BorderStyle_Outset
    };

    inline void setPosition(Position f)
    { setProperty(CssFloat, f); }
    inline Position position() const
    { return static_cast<Position>(intProperty(CssFloat)); }

    inline void setBorder(double border);
    inline double border() const
    { return doubleProperty(FrameBorder); }

    inline void setBorderBrush(const CscsBrush &brush)
    { setProperty(FrameBorderBrush, brush); }
    inline CscsBrush borderBrush() const
    { return brushProperty(FrameBorderBrush); }

    inline void setBorderStyle(BorderStyle style)
    { setProperty(FrameBorderStyle, style); }
    inline BorderStyle borderStyle() const
    { return static_cast<BorderStyle>(intProperty(FrameBorderStyle)); }

    void setMargin(double margin);
    inline double margin() const
    { return doubleProperty(FrameMargin); }

    inline void setTopMargin(double margin);
    double topMargin() const;

    inline void setBottomMargin(double margin);
    double bottomMargin() const;

    inline void setLeftMargin(double margin);
    double leftMargin() const;

    inline void setRightMargin(double margin);
    double rightMargin() const;

    inline void setPadding(double padding);
    inline double padding() const
    { return doubleProperty(FramePadding); }

    inline void setWidth(double width);
    inline void setWidth(const CscsTextLength &length)
    { setProperty(FrameWidth, CscsVariant(length)); }
    inline CscsTextLength width() const
    { return lengthProperty(FrameWidth); }

    inline void setHeight(double height);
    inline void setHeight(const CscsTextLength &height);
    inline CscsTextLength height() const
    { return lengthProperty(FrameHeight); }

    inline void setPageBreakPolicy(PageBreakFlags flags)
    { setProperty(PageBreakPolicy, int(flags)); }
    inline PageBreakFlags pageBreakPolicy() const
    { return PageBreakFlags(intProperty(PageBreakPolicy)); }

protected:
    explicit CscsTextFrameFormat(const CscsTextFormat &fmt);
    friend class CscsTextFormat;
};

inline void CscsTextFrameFormat::setBorder(double aborder)
{ setProperty(FrameBorder, aborder); }

inline void CscsTextFrameFormat::setPadding(double apadding)
{ setProperty(FramePadding, apadding); }

inline void CscsTextFrameFormat::setWidth(double awidth)
{ setProperty(FrameWidth, CscsTextLength(CscsTextLength::FixedLength, awidth)); }

inline void CscsTextFrameFormat::setHeight(double aheight)
{ setProperty(FrameHeight, CscsTextLength(CscsTextLength::FixedLength, aheight)); }
inline void CscsTextFrameFormat::setHeight(const CscsTextLength &aheight)
{ setProperty(FrameHeight, CscsVariant(aheight)); }

inline void CscsTextFrameFormat::setTopMargin(double amargin)
{ setProperty(FrameTopMargin, amargin); }

inline void CscsTextFrameFormat::setBottomMargin(double amargin)
{ setProperty(FrameBottomMargin, amargin); }

inline void CscsTextFrameFormat::setLeftMargin(double amargin)
{ setProperty(FrameLeftMargin, amargin); }

inline void CscsTextFrameFormat::setRightMargin(double amargin)
{ setProperty(FrameRightMargin, amargin); }

class CscsTextTableFormat : public CscsTextFrameFormat
{
public:
    CscsTextTableFormat();

    inline bool isValid() const { return isTableFormat(); }

    inline int columns() const
    { int cols = intProperty(TableColumns); if (cols == 0) cols = 1; return cols; }
    inline void setColumns(int columns);

    inline void setColumnWidthConstraints(const CscsVector<CscsTextLength> &constraints)
    { setProperty(TableColumnWidthConstraints, constraints); }

    inline CscsVector<CscsTextLength> columnWidthConstraints() const
    { return lengthVectorProperty(TableColumnWidthConstraints); }

    inline void clearColumnWidthConstraints()
    { clearProperty(TableColumnWidthConstraints); }

    inline double cellSpacing() const
    { return doubleProperty(TableCellSpacing); }
    inline void setCellSpacing(double spacing)
    { setProperty(TableCellSpacing, spacing); }

    inline double cellPadding() const
    { return doubleProperty(TableCellPadding); }
    inline void setCellPadding(double padding);

    inline void setAlignment(SCS::Alignment alignment);
    inline SCS::Alignment alignment() const
    { return CscsFlag(intProperty(BlockAlignment)); }

    inline void setHeaderRowCount(int count)
    { setProperty(TableHeaderRowCount, count); }
    inline int headerRowCount() const
    { return intProperty(TableHeaderRowCount); }

protected:
    explicit CscsTextTableFormat(const CscsTextFormat &fmt);
    friend class CscsTextFormat;
};

inline void CscsTextTableFormat::setColumns(int acolumns)
{
    if (acolumns == 1)
        acolumns = 0;
    setProperty(TableColumns, acolumns);
}

inline void CscsTextTableFormat::setCellPadding(double apadding)
{ setProperty(TableCellPadding, apadding); }

inline void CscsTextTableFormat::setAlignment(SCS::Alignment aalignment)
{ setProperty(BlockAlignment, int(aalignment)); }

class  CscsTextTableCellFormat : public CscsTextCharFormat
{
public:
    CscsTextTableCellFormat();

    inline bool isValid() const { return isTableCellFormat(); }

    inline void setTopPadding(double padding);
    inline double topPadding() const;

    inline void setBottomPadding(double padding);
    inline double bottomPadding() const;

    inline void setLeftPadding(double padding);
    inline double leftPadding() const;

    inline void setRightPadding(double padding);
    inline double rightPadding() const;

    inline void setPadding(double padding);

protected:
    explicit CscsTextTableCellFormat(const CscsTextFormat &fmt);
    friend class CscsTextFormat;
};

inline void CscsTextTableCellFormat::setTopPadding(double padding)
{
    setProperty(TableCellTopPadding, padding);
}

inline double CscsTextTableCellFormat::topPadding() const
{
    return doubleProperty(TableCellTopPadding);
}

inline void CscsTextTableCellFormat::setBottomPadding(double padding)
{
    setProperty(TableCellBottomPadding, padding);
}

inline double CscsTextTableCellFormat::bottomPadding() const
{
    return doubleProperty(TableCellBottomPadding);
}

inline void CscsTextTableCellFormat::setLeftPadding(double padding)
{
    setProperty(TableCellLeftPadding, padding);
}

inline double CscsTextTableCellFormat::leftPadding() const
{
    return doubleProperty(TableCellLeftPadding);
}

inline void CscsTextTableCellFormat::setRightPadding(double padding)
{
    setProperty(TableCellRightPadding, padding);
}

inline double CscsTextTableCellFormat::rightPadding() const
{
    return doubleProperty(TableCellRightPadding);
}

inline void CscsTextTableCellFormat::setPadding(double padding)
{
    setTopPadding(padding);
    setBottomPadding(padding);
    setLeftPadding(padding);
    setRightPadding(padding);
}


SCS_DECLARE_TYPEINFO(CscsTextLength)
SCS_DECLARE_TYPEINFO(CscsTextFormat)

END_NAMESPACE


#endif