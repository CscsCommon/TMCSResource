 /*Created by J.Wong 2018/10/29
 version:    version 1.0,
 dependency: base on  or greater than c++11
 function: type erase
 gcc4.9+
 */

#ifndef SCSWINDOWSYSTEMSERVER_H
#define SCSWINDOWSYSTEMSERVER_H
#include <kernel/scsobject.h>
#include <kernel/scstime.h>
#include <string>
#include <map>
#include "scsplatformwindowsystemserver.h"

BEGIN_NAMESPACE(Gemini)

class CscsImage;
class CscsRect;
class CscsPoint;
class CscsRegion;
class CscsRegionMoveCommand;
class CscsChangeAltitudeCommand;
class CscsSetOpacityCommand;
class CscsRequestFocusCommand;
class CscsRegionNameCommand;
class CscsRegionDestroyCommand;
class CscsIdentifyCommand;
class CscsRepaintRegionCommand;
class CscsCommandInfo;
class CscsRegionCommand;
class CscsCreateCommand;
class CscsEventData;
class CscsWindowCommand;
class CscsWindowStorage;
class CscsWindowSystemServerData;
class CscsCursorWrapper;
class CscsDefineCursorCommand;
class CscsSelectCursorCommand;
class CscsPositionCursorCommand;
class CscsGrabMouseCommand;
class CscsBrush;
class CscsPainter;

class CscsInternalWindowInfo{
public:
	int winid;
	uint clientid;
	std::string name;

};
class CscsWindowSystemServer:public CscsPlatformWindowSystemServer{
	friend class CscsScreen;
	friend class CscsWindowStorage;
public:
	CscsWindowSystemServer(int flags,CscsObject* parent=0);
	~CscsWindowSystemServer();
	void initServer(int flags);

	void sendKeyEvent(int unicode, int keycode, int modifiers, bool isPress, bool autoRepeat);
	void processKeyEvent(int unicode, int keycode, int modifiers, bool isPress, bool autoRepeat);

	void setMaxWindowRect(const CscsRect& r);
	void sendMouseEvent(const CscsPoint& pos, int state, int wheel);
	void setBackground(const CscsBrush& brush);

	
	CscsWindowStorage* windowAt(const CscsPoint& pt);

	#ifdef D_WIN32
	static HCURSOR currentCursor();
	#endif

	void refresh();
	void refresh(CscsRegion& r);

	void enablePainting(bool);

	void processEventQueue();
	static std::list<CscsInternalWindowInfo*>* windowList();

	static void startup(int flags);
	static void closedown();

	static void setCursorVisible(bool);
	static bool isCursorVisible();


	
    bool isNeededRotate()const{
            return rotate!=0;
    }
    int rotated()const{
        return rotate;
    }


//signals
public:
	void windowEvent(CscsWindowStorage* w, CscsWindowSystemServer::WindowEvent e){

	}

private:
	void move_region(const CscsRegionMoveCommand *);
	void set_altitude(const CscsChangeAltitudeCommand* );
	void set_opacity(const CscsSetOpacityCommand* );
	void request_focus(const CscsRequestFocusCommand* );
	void request_region(int winId, int shmid, bool opaque, CscsRegion r);
	void repaint_region(int winId, bool opaque, CscsRegion r);
    void repaint_region(int winId, const CscsRegion& r);

	void destroy_region(const CscsRegionDestroyCommand* );
	void name_region(const CscsRegionNameCommand* );
	void set_identity(const CscsIdentifyCommand* );
	void compose(int level, CscsRegion exposed, CscsRegion& blend, 
                                     CscsImage& blendBuffer, int changing_level);

	void sendMaxWindowRectEvents();
	void invokeIdentify(const CscsIdentifyCommand* cmd, CscsPlatformWindowSystemClient* client);
	void invokeCreate(CscsCreateCommand* cmd, CscsPlatformWindowSystemClient* client);
    void invokeRegionName(const CscsRegionNameCommand* cmd, CscsPlatformWindowSystemClient* client);
    void invokeRegion(CscsRegionCommand* cmd, CscsPlatformWindowSystemClient* client);
    void invokeRegionMove(const CscsRegionMoveCommand* cmd, CscsPlatformWindowSystemClient* client);
    void invokeRegionDestroy(const CscsRegionDestroyCommand* cmd, CscsPlatformWindowSystemClient* client);
    void invokeSetAltitude(const CscsChangeAltitudeCommand* cmd, CscsPlatformWindowSystemClient* client);
    void invokeSetOpacity(const CscsSetOpacityCommand* cmd, CscsPlatformWindowSystemClient* client);
    void invokeSetFocus(const CscsRequestFocusCommand* cmd, CscsPlatformWindowSystemClient* client);
    void invokeDefineCursor(CscsDefineCursorCommand* cmd, CscsPlatformWindowSystemClient* client);
    void invokeSelectCursor(CscsSelectCursorCommand* cmd, CscsPlatformWindowSystemClient* client);
    void invokePositionCursor(CscsPositionCursorCommand* cmd, CscsPlatformWindowSystemClient* client);
    void invokeGrabMouse(CscsGrabMouseCommand* cmd, CscsPlatformWindowSystemClient* client);

    void handleWindowClose(CscsWindowStorage *w);
    void setFocus(CscsWindowStorage* , bool gain);

    void invokeRepaintRegion(CscsRepaintRegionCommand* cmd, CscsPlatformWindowSystemClient* client);



    void openScreen();
    void closeScreen();

    void setCursor(CscsCursorWrapper* cursor);
    void showCursor();
    void hideCursor();
    void initializeCursor();

    void releaseMouse(CscsWindowStorage* w);

    void refreshBackground();

    void doClient(CscsPlatformWindowSystemClient* );

    CscsTime timer;
    CscsWindowStorage* focusw;
    CscsWindowStorage* mouseGrabber;
    bool mouseGrabbing;
    int swidth, sheight, sdepth;
    int rotate;

    static CscsBrush* bgBrush;
    bool haveviscurs;
    CscsCursorWrapper* cursor;
    CscsCursorWrapper* nextCursor;
    std::list<CscsCommandInfo*> commandQueue;
    std::list<CscsWindowStorage*> windows;

    CscsPainter* winPainter;
    CscsImage* 	 winCanvas;
    CscsWindowStorage* newWindow(int id, CscsPlatformWindowSystemClient* client);
    CscsWindowStorage* findWindow(int id, CscsPlatformWindowSystemClient* client);



    void moveWindowRegion(CscsWindowStorage* window, int dx, int dy);
    void setWindowRegion(CscsWindowStorage* window, CscsRegion r, bool destroyed=false);
    void raiseWindow(CscsWindowStorage* window, int i=0);
    void lowerWindow(CscsWindowStorage* window, int i=-1);

    void exposeRegion_helper(CscsRegion r, int i=0);
    void exposeRegion(CscsRegion r, int i=0, CscsWidget* w=nullptr, bool destroyed=false);

    void composeRegion();

    void paintBackground(const CscsRegion& r);

    static CscsPoint mousePos;
    static CscsPlatformWindowSystemClient* client;
    CscsWindowSystemServerData* d;

    CscsImage* bltscreen;

};


END_NAMESPACE
#endif
