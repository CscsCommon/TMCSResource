#ifndef SCSDESKTOPWIDGET_H
#define SCSDESKTOPWIDGET_H
#include "scswidget.h"

BEGIN_NAMESPACE(Gemini)

class CscsApplication;
class CscsDesktopWidgetPrivate;

class CscsDesktopWidget : public CscsWidget
{
public:
    CscsDesktopWidget();
    ~CscsDesktopWidget();

    bool isVirtualDesktop() const;

    int numScreens() const;
    int primaryScreen() const;

    int screenNumber(const CscsWidget *widget = 0) const;
    int screenNumber(const CscsPoint &) const;

    CscsWidget *screen(int screen = -1);
    
    const CscsDesktopWidgetPrivate* d_func()const;

    const CscsRect screenGeometry(int screen = -1) const;
    const CscsRect screenGeometry(const CscsWidget *widget) const
    { return screenGeometry(screenNumber(widget)); }
    const CscsRect screenGeometry(const CscsPoint &point) const
    { return screenGeometry(screenNumber(point)); }

    const CscsRect availableGeometry(int screen = -1) const;
    const CscsRect availableGeometry(const CscsWidget *widget) const
    { return availableGeometry(screenNumber(widget)); }
    const CscsRect availableGeometry(const CscsPoint &point) const
    { return availableGeometry(screenNumber(point)); }

public:
    void resized(int){}
    void workAreaResized(int){}

protected:
    void resizeEvent(CscsResizeEvent *e);

private:

    friend class CscsApplication;
    friend class CscsScreen;

};

END_NAMESPACE

#endif