#ifndef SCSABSTRACTITEMMODEL_H
#define SCSABSTRACTITEMMODEL_H

#include <kernel/scsvariant.h>
#include <kernel/scsobject.h>
#include <window/scsenum.h>
#include <kernel/scsstringlist.h>

BEGIN_NAMESPACE(Gemini)

class CscsAbstractItemModel;
class CscsPersistentModelIndex;

class CscsModelIndex
{
    friend class CscsAbstractItemModel;
    friend class CscsProxyModel;
public:
    inline CscsModelIndex() : r(-1), c(-1), p(0), m(0) {}
    inline CscsModelIndex(const CscsModelIndex &other)
        : r(other.r), c(other.c), p(other.p), m(other.m) {}
    inline ~CscsModelIndex() { p = 0; m = 0; }
    inline int row() const { return r; }
    inline int column() const { return c; }
    inline void *internalPointer() const { return p; }
    inline int64 internalId() const { return reinterpret_cast<int64>(p); }
    inline CscsModelIndex parent() const;
    inline CscsModelIndex sibling(int row, int column) const;
    inline CscsModelIndex child(int row, int column) const;
    inline CscsVariant data(int role = SCS::DisplayRole) const;
    inline SCS::ItemFlags flags() const;
    inline const CscsAbstractItemModel *model() const { return m; }
    inline bool isValid() const { return (r >= 0) && (c >= 0) && (m != 0); }
    inline bool operator==(const CscsModelIndex &other) const
        { return (other.r == r) && (other.p == p) && (other.c == c) && (other.m == m); }
    inline bool operator!=(const CscsModelIndex &other) const
        { return !(*this == other); }
    inline bool operator<(const CscsModelIndex &other) const
        {
          if (r < other.r) return true;
          if (r == other.r) {
              if (c < other.c) return true;
              if (c == other.c) {
                  if (p < other.p) return true;
                  if (p == other.p) return m < other.m;
              }
          }
          return false; }
private:
    inline CscsModelIndex(int row, int column, void *ptr, const CscsAbstractItemModel *model);
    int r, c;
    void *p;
    const CscsAbstractItemModel *m;
};

SCS_DECLARE_TYPENAME_INFO(CscsModelIndex,SCS_MOVABLE_TYPE)

class CscsPersistentModelIndexData;

class  CscsPersistentModelIndex
{
public:
    CscsPersistentModelIndex();
    CscsPersistentModelIndex(const CscsModelIndex &index);
    CscsPersistentModelIndex(const CscsPersistentModelIndex &other);
    ~CscsPersistentModelIndex();
    bool operator<(const CscsPersistentModelIndex &other) const;
    bool operator==(const CscsPersistentModelIndex &other) const;
    inline bool operator!=(const CscsPersistentModelIndex &other) const
    { return !operator==(other); }
    CscsPersistentModelIndex &operator=(const CscsPersistentModelIndex &other);
    bool operator==(const CscsModelIndex &other) const;
    bool operator!=(const CscsModelIndex &other) const;
    CscsPersistentModelIndex &operator=(const CscsModelIndex &other);
    operator const CscsModelIndex&() const;
    int row() const;
    int column() const;
    void *internalPointer() const;
    int64 internalId() const;
    CscsModelIndex parent() const;
    CscsModelIndex sibling(int row, int column) const;
    CscsModelIndex child(int row, int column) const;
    CscsVariant data(int role = SCS::DisplayRole) const;
    SCS::ItemFlags flags() const;
    const CscsAbstractItemModel *model() const;
    bool isValid() const;
private:
    CscsPersistentModelIndexData *d;
    friend class CscsAbstractItemViewPrivate;
};
SCS_DECLARE_TYPENAME_INFO(CscsPersistentModelIndex,SCS_MOVABLE_TYPE)

template<typename T> class CscsList;
typedef CscsList<CscsModelIndex> CscsModelIndexList;

//class CscsMimeData;
class CscsAbstractItemModelPrivate;
template <class Key, class T> class CscsMap;


class  CscsAbstractItemModel : public CscsObject
{
    friend class CscsPersistentModelIndexData;
public:

    explicit CscsAbstractItemModel(CscsObject *parent = 0);
    virtual ~CscsAbstractItemModel();

    bool hasIndex(int row, int column, const CscsModelIndex &parent = CscsModelIndex()) const;
    virtual CscsModelIndex index(int row, int column,
                              const CscsModelIndex &parent = CscsModelIndex()) const = 0;
    virtual CscsModelIndex parent(const CscsModelIndex &child) const = 0;

    inline CscsModelIndex sibling(int row, int column, const CscsModelIndex &idx) const
        { return index(row, column, parent(idx)); }

    virtual int rowCount(const CscsModelIndex &parent = CscsModelIndex()) const = 0;
    virtual int columnCount(const CscsModelIndex &parent = CscsModelIndex()) const = 0;
    virtual bool hasChildren(const CscsModelIndex &parent = CscsModelIndex()) const;

    virtual CscsVariant data(const CscsModelIndex &index, int role = SCS::DisplayRole) const = 0;
    virtual bool setData(const CscsModelIndex &index, const CscsVariant &value, int role = SCS::EditRole);

    virtual CscsVariant headerData(int section, SCS::Orientation orientation,
                                int role = SCS::DisplayRole) const;
    virtual bool setHeaderData(int section, SCS::Orientation orientation, const CscsVariant &value,
                               int role = SCS::EditRole);

    virtual CscsMap<int, CscsVariant> itemData(const CscsModelIndex &index) const;
    virtual bool setItemData(const CscsModelIndex &index, const CscsMap<int, CscsVariant> &roles);



    virtual bool insertRows(int row, int count, const CscsModelIndex &parent = CscsModelIndex());
    virtual bool insertColumns(int column, int count, const CscsModelIndex &parent = CscsModelIndex());
    virtual bool removeRows(int row, int count, const CscsModelIndex &parent = CscsModelIndex());
    virtual bool removeColumns(int column, int count, const CscsModelIndex &parent = CscsModelIndex());

    inline bool insertRow(int row, const CscsModelIndex &parent = CscsModelIndex());
    inline bool insertColumn(int column, const CscsModelIndex &parent = CscsModelIndex());
    inline bool removeRow(int row, const CscsModelIndex &parent = CscsModelIndex());
    inline bool removeColumn(int column, const CscsModelIndex &parent = CscsModelIndex());

    virtual void fetchMore(const CscsModelIndex &parent);
    virtual bool canFetchMore(const CscsModelIndex &parent) const;
    virtual SCS::ItemFlags flags(const CscsModelIndex &index) const;
    virtual void sort(int column, SCS::SortOrder order = SCS::AscendingOrder);
    virtual CscsModelIndex buddy(const CscsModelIndex &index) const;
    virtual CscsModelIndexList match(const CscsModelIndex &start, int role,
                                  const CscsVariant &value, int hits = 1,
                                  SCS::MatchFlags flags =
                                  SCS::MatchFlags(SCS::MatchStartsWith|SCS::MatchWrap)) const;
    virtual CscsSize span(const CscsModelIndex &index) const;

    using CscsObject::parent;

SIGNALS:
    void dataChanged(const CscsModelIndex &topLeft, const CscsModelIndex &bottomRight){}
    void headerDataChanged(SCS::Orientation orientation, int first, int last){}
    void layoutChanged(){}
    void layoutAboutToBeChanged(){}

    void rowsAboutToBeInserted(const CscsModelIndex &parent, int first, int last){}
    void rowsInserted(const CscsModelIndex &parent, int first, int last){}

    void rowsAboutToBeRemoved(const CscsModelIndex &parent, int first, int last){}
    void rowsRemoved(const CscsModelIndex &parent, int first, int last){}

    void columnsAboutToBeInserted(const CscsModelIndex &parent, int first, int last){}
    void columnsInserted(const CscsModelIndex &parent, int first, int last){}

    void columnsAboutToBeRemoved(const CscsModelIndex &parent, int first, int last){}
    void columnsRemoved(const CscsModelIndex &parent, int first, int last){}

    void modelAboutToBeReset(){}
    void modelReset(){}

SLOTS:
    virtual bool submit();
    virtual void revert();

protected:
    CscsAbstractItemModel(CscsAbstractItemModelPrivate* dd, CscsObject *parent = 0);

    inline CscsModelIndex createIndex(int row, int column, void *data = 0) const;
    inline CscsModelIndex createIndex(int row, int column, int id) const;
    inline CscsModelIndex createIndex(int row, int column, uint32 id) const;

    void beginInsertRows(const CscsModelIndex &parent, int first, int last);
    void endInsertRows();

    void beginRemoveRows(const CscsModelIndex &parent, int first, int last);
    void endRemoveRows();

    void beginInsertColumns(const CscsModelIndex &parent, int first, int last);
    void endInsertColumns();

    void beginRemoveColumns(const CscsModelIndex &parent, int first, int last);
    void endRemoveColumns();

    void reset();

    void changePersistentIndex(const CscsModelIndex &from, const CscsModelIndex &to);
    void changePersistentIndexList(const CscsModelIndexList &from, const CscsModelIndexList &to);
    CscsModelIndexList persistentIndexList() const;

private:
    CscsAbstractItemModelPrivate* d_func()const;
    friend class CscsAbstractItemModelPrivate;
    friend class CscsCommonItemModel;
    friend class CscsCommonItemModelPrivate;
    friend class CscsAbstractItemViewPrivate;
};

inline bool CscsAbstractItemModel::insertRow(int arow, const CscsModelIndex &aparent)
{ return insertRows(arow, 1, aparent); }
inline bool CscsAbstractItemModel::insertColumn(int acolumn, const CscsModelIndex &aparent)
{ return insertColumns(acolumn, 1, aparent); }
inline bool CscsAbstractItemModel::removeRow(int arow, const CscsModelIndex &aparent)
{ return removeRows(arow, 1, aparent); }
inline bool CscsAbstractItemModel::removeColumn(int acolumn, const CscsModelIndex &aparent)
{ return removeColumns(acolumn, 1, aparent); }
inline CscsModelIndex CscsAbstractItemModel::createIndex(int arow, int acolumn, void *adata) const
{ return CscsModelIndex(arow, acolumn, adata, this); }
inline CscsModelIndex CscsAbstractItemModel::createIndex(int arow, int acolumn, int aid) const
{ return CscsModelIndex(arow, acolumn, reinterpret_cast<void*>(aid), this); }
inline CscsModelIndex CscsAbstractItemModel::createIndex(int arow, int acolumn, uint32 aid) const
{ return CscsModelIndex(arow, acolumn, reinterpret_cast<void*>(aid), this); }


class  CscsAbstractTableModel : public CscsAbstractItemModel
{
public:
    explicit CscsAbstractTableModel(CscsObject *parent = 0);
    ~CscsAbstractTableModel();

    CscsModelIndex index(int row, int column, const CscsModelIndex &parent = CscsModelIndex()) const;
protected:
    CscsAbstractTableModel(CscsAbstractItemModelPrivate* dd, CscsObject *parent);

private:
    CscsModelIndex parent(const CscsModelIndex &child) const;
    bool hasChildren(const CscsModelIndex &parent) const;
};

class  CscsAbstractListModel : public CscsAbstractItemModel
{
public:
    explicit CscsAbstractListModel(CscsObject *parent = 0);
    ~CscsAbstractListModel();

    CscsModelIndex index(int row, int column = 0, const CscsModelIndex &parent = CscsModelIndex()) const;
protected:
    CscsAbstractListModel(CscsAbstractItemModelPrivate* dd, CscsObject *parent);

private:
    CscsModelIndex parent(const CscsModelIndex &child) const;
    int columnCount(const CscsModelIndex &parent) const;
    bool hasChildren(const CscsModelIndex &parent) const;
};


inline CscsModelIndex::CscsModelIndex(int arow, int acolumn, void *adata,
                                const CscsAbstractItemModel *amodel)
    : r(arow), c(acolumn), p(adata), m(amodel) {}

inline CscsModelIndex CscsModelIndex::parent() const
{ return m ? m->parent(*this) : CscsModelIndex(); }

inline CscsModelIndex CscsModelIndex::sibling(int arow, int acolumn) const
{ return m ? (r == arow && c == acolumn) ? *this : m->index(arow, acolumn, m->parent(*this)) : CscsModelIndex(); }

inline CscsModelIndex CscsModelIndex::child(int arow, int acolumn) const
{ return m ? m->index(arow, acolumn, *this) : CscsModelIndex(); }

inline CscsVariant CscsModelIndex::data(int arole) const
{ return m ? m->data(*this, arole) : CscsVariant(); }

inline SCS::ItemFlags CscsModelIndex::flags() const
{ return m ? m->flags(*this) : SCS::ItemFlags(0); }

inline uint scsHash(const CscsModelIndex &index)
{ return uint((index.row() << 4) + index.column() + index.internalId()); }

END_NAMESPACE

#endif
