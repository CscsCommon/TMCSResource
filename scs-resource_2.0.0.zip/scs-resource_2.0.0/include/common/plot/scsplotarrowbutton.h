#ifndef SCSPLOTARROWBUTTON_H
#define SCSPLOTARROWBUTTON_H
#include <window/widgets/scspushbutton.h>

BEGIN_NAMESPACE(Gemini)

class CscsPainter;

class  WIDGET_EXPORT CscsPlotArrowButton : public CscsPushButton
{
public:
    explicit CscsPlotArrowButton (CscsWidget *parent = nullptr );
    explicit CscsPlotArrowButton ( int num, SCS::ArrowType, CscsWidget *parent=nullptr);
    virtual ~CscsPlotArrowButton();

    SCS::ArrowType arrowType() const;
    int num() const;

    void setNum(int n);
    void setArrowType(SCS::ArrowType type);

    virtual CscsSize sizeHint() const;
    virtual CscsSize minimumSizeHint() const;

protected:
    virtual void paintEvent( CscsPaintEvent *event );

    virtual void drawButtonLabel( CscsPainter *p );
    virtual void drawArrow( CscsPainter *,
        const CscsRect &, SCS::ArrowType ) const;
    virtual CscsRect labelRect() const;
    virtual CscsSize arrowSize( SCS::ArrowType,
        const CscsSize &boundingSize ) const;

    virtual void keyPressEvent( CscsKeyEvent * );

private:
    class PrivateData;
    PrivateData *d_data;

    BEGIN_PROPERTY(CscsPlotArrowButton,CscsPushButton)
    META_PROPERTY(SCS::ArrowType,arrowType,READ,arrowType,WRITE,setArrowType)
    META_PROPERTY(int, num, READ, num, WRITE, setNum)
    END_PROPERTY
};

END_NAMESPACE

#endif