#ifndef SCSPLOTLEGENDDATA_H
#define SCSPLOTLEGENDDATA_H
#include "scsplottext.h"
#include <kernel/scsvariant.h>
#include <painting/scsimage.h>
#include <kernel/scsmap.h>

BEGIN_NAMESPACE(Gemini)

class  CscsPlotLegendData
{
public:
    enum Mode
    {
        ReadOnly,
        Clickable,
        Checkable
    };

    enum Role
    {
        ModeRole, 
        TitleRole, 
        IconRole, 
        UserRole  = 32
    };

    CscsPlotLegendData();
    ~CscsPlotLegendData();

    void setValues( const CscsMap<int, CscsVariant> & );
    const CscsMap<int, CscsVariant> &values() const;

    void setValue( int role, const CscsVariant & );
    CscsVariant value( int role ) const;

    bool hasRole( int role ) const;
    bool isValid() const;

    CscsImage icon() const;
    CscsPlotText title() const;
    Mode mode() const;

private:
    CscsMap<int, CscsVariant> d_map;
};

END_NAMESPACE

#endif