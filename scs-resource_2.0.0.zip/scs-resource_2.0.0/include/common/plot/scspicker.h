#ifndef SCSPICKER_H
#define SCSPICKER_H
#include "scsplottext.h"
#include "scsploteventpattern.h"
#include <kernel/scsobject.h>
#include <painting/scspen.h>
#include <painting/scsfont.h>
#include <painting/scsrect.h>
#include <painting/scspath.h>

BEGIN_NAMESPACE(Gemini)

class CscsWidget;
class CscsMouseEvent;
class CscsKeyEvent;
class CscsPlotPickerMachine;
class CscsPlotWidgetOverlay;

class   CscsPicker: public CscsObject, public CscsPlotEventPattern
{

public:
    enum RubberBand
    {
        NoRubberBand = 0,
        HLineRubberBand,
        VLineRubberBand,
        CrossRubberBand,
        RectRubberBand,
        EllipseRubberBand,
        PolygonRubberBand,
        UserRubberBand = 100
    };

    enum DisplayMode
    {
        AlwaysOff,
        AlwaysOn,
        ActiveOnly
    };


    enum ResizeMode
    {
        Stretch,
        KeepSize
    };

    explicit CscsPicker( CscsWidget *parent );
    explicit CscsPicker( RubberBand rubberBand,
                        DisplayMode trackerMode, CscsWidget * );

    virtual ~CscsPicker();

    void setStateMachine( CscsPlotPickerMachine * );
    const CscsPlotPickerMachine *stateMachine() const;
    CscsPlotPickerMachine *stateMachine();

    void setRubberBand( RubberBand );
    RubberBand rubberBand() const;

    void setTrackerMode( DisplayMode );
    DisplayMode trackerMode() const;

    void setResizeMode( ResizeMode );
    ResizeMode resizeMode() const;

    void setRubberBandPen( const CscsPen & );
    CscsPen rubberBandPen() const;

    void setTrackerPen( const CscsPen & );
    CscsPen trackerPen() const;

    void setTrackerFont( const CscsFont & );
    CscsFont trackerFont() const;

    bool isEnabled() const;
    bool isActive() const;

    virtual bool eventFilter( CscsObject *, CscsEvent * );

    CscsWidget *parentWidget();
    const CscsWidget *parentWidget() const;

    virtual CscsPath pickArea() const;

    virtual void drawRubberBand( CscsPainter * ) const;
    virtual void drawTracker( CscsPainter * ) const;

    virtual CscsRegion rubberBandMask() const;

    virtual CscsPlotText trackerText( const CscsPoint &pos ) const;
    CscsPoint trackerPosition() const;
    virtual CscsRect trackerRect( const CscsFont & ) const;

    CscsPolygon selection() const;

SLOTS:
    void setEnabled( bool );

SIGNALS:
    void activated( bool on ){}
    void selected( const CscsPolygon &polygon ){}
    void appended( const CscsPoint &pos ){}
    void moved( const CscsPoint &pos ){}
    void removed( const CscsPoint &pos ){}
    void changed( const CscsPolygon &selection ){}

protected:
    virtual CscsPolygon adjustedPoints( const CscsPolygon & ) const;

    virtual void transition( const CscsEvent * );

    virtual void begin();
    virtual void append( const CscsPoint & );
    virtual void move( const CscsPoint & );
    virtual void remove();
    virtual bool end( bool ok = true );

    virtual bool accept( CscsPolygon & ) const;
    virtual void reset();

    virtual void widgetMousePressEvent( CscsMouseEvent * );
    virtual void widgetMouseReleaseEvent( CscsMouseEvent * );
    virtual void widgetMouseDoubleClickEvent( CscsMouseEvent * );
    virtual void widgetMouseMoveEvent( CscsMouseEvent * );
    virtual void widgetKeyPressEvent( CscsKeyEvent * );
    virtual void widgetKeyReleaseEvent( CscsKeyEvent * );
    virtual void widgetEnterEvent( CscsEvent * );
    virtual void widgetLeaveEvent( CscsEvent * );

    virtual void stretchSelection(
        const CscsSize &oldSize, const CscsSize &newSize );

    virtual void updateDisplay();

    const CscsPlotWidgetOverlay *rubberBandOverlay() const;
    const CscsPlotWidgetOverlay *trackerOverlay() const;

    const CscsPolygon &pickedPoints() const;

private:
    void init( CscsWidget *, RubberBand rubberBand, DisplayMode trackerMode );

    void setMouseTracking( bool );

    class PrivateData;
    PrivateData *d_data;

BEGIN_PROPERTY(CscsPicker,CscsObject)
    META_PROPERTY( bool, isEnabled, READ, isEnabled, WRITE, setEnabled )
    META_PROPERTY( ResizeMode, resizeMode, READ, resizeMode, WRITE, setResizeMode )
    META_PROPERTY( DisplayMode, trackerMode, READ, trackerMode, WRITE, setTrackerMode )
    META_PROPERTY( CscsPen, trackerPen, READ, trackerPen, WRITE, setTrackerPen )
    META_PROPERTY( CscsFont, trackerFont, READ, trackerFont, WRITE, setTrackerFont )
    META_PROPERTY( RubberBand, rubberBand, READ, rubberBand, WRITE, setRubberBand )
    META_PROPERTY( CscsPen, rubberBandPen, READ, rubberBandPen, WRITE, setRubberBandPen )
END_PROPERTY

};

END_NAMESPACE

#endif