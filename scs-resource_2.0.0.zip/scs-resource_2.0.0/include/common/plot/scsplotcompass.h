#ifndef SCSPLOTCOMPASS_H
#define SCSPLOTCOMPASS_H
#include "scsplotdial.h"
#include "scsplotroundscaledraw.h"
#include <kernel/scsstring.h>
#include <kernel/scsmap.h>

BEGIN_NAMESPACE(Gemini)

class CscsPlotCompassRose;

class  CscsPlotCompassScaleDraw: public CscsPlotRoundScaleDraw
{
public:
    explicit CscsPlotCompassScaleDraw();
    explicit CscsPlotCompassScaleDraw( const CscsMap<double, CscsString> &map );

    void setLabelMap( const CscsMap<double, CscsString> &map );
    CscsMap<double, CscsString> labelMap() const;

    virtual CscsPlotText label( double value ) const;

private:
    CscsMap<double, CscsString> d_labelMap;
};



class  WIDGET_EXPORT CscsPlotCompass: public CscsPlotDial
{

public:
    explicit CscsPlotCompass( CscsWidget* parent = nullptr );
    virtual ~CscsPlotCompass();

    void setRose( CscsPlotCompassRose *rose );
    const CscsPlotCompassRose *rose() const;
    CscsPlotCompassRose *rose();

protected:
    virtual void drawRose( CscsPainter *, const CscsPointF &center,
        double radius, double north, CscsPalette::ColorGroup ) const;

    virtual void drawScaleContents( CscsPainter *,
        const CscsPointF &center, double radius ) const;

    virtual void keyPressEvent( CscsKeyEvent * );

private:
    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE

#endif