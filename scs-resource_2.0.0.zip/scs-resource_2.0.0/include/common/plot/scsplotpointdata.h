#ifndef SCSPLOTPOINTDATA_H
#define SCSPLOTPOINTDATA_H

#include "scsplotseriesdata.h"

BEGIN_NAMESPACE(Gemini)

class  CscsPlotPointArrayData: public CscsPlotSeriesData<CscsPointF>
{
public:
    CscsPlotPointArrayData( const CscsVector<double> &x, const CscsVector<double> &y );
    CscsPlotPointArrayData( const double *x, const double *y, uint size );

    virtual CscsRectF boundingRect() const;

    virtual uint size() const;
    virtual CscsPointF sample( uint i ) const;

    const CscsVector<double> &xData() const;
    const CscsVector<double> &yData() const;

private:
    CscsVector<double> d_x;
    CscsVector<double> d_y;
};


class  CscsPlotCPointerData: public CscsPlotSeriesData<CscsPointF>
{
public:
    CscsPlotCPointerData( const double *x, const double *y, uint size );

    virtual CscsRectF boundingRect() const;
    virtual uint size() const;
    virtual CscsPointF sample( uint i ) const;

    const double *xData() const;
    const double *yData() const;

private:
    const double *d_x;
    const double *d_y;
    uint d_size;
};

class  CscsPlotSyntheticPointData: public CscsPlotSeriesData<CscsPointF>
{
public:
    CscsPlotSyntheticPointData( uint size,
        const CscsPlotInterval & = CscsPlotInterval() );

    void setSize( uint size );
    virtual uint size() const;

    void setInterval( const CscsPlotInterval& );
    CscsPlotInterval interval() const;

    virtual CscsRectF boundingRect() const;
    virtual CscsPointF sample( uint i ) const;

    virtual double y( double x ) const = 0;
    virtual double x( uint index ) const;

    virtual void setRectOfInterest( const CscsRectF & );
    CscsRectF rectOfInterest() const;

private:
    uint d_size;
    CscsPlotInterval d_interval;
    CscsRectF d_rectOfInterest;
    CscsPlotInterval d_intervalOfInterest;
};

END_NAMESPACE

#endif