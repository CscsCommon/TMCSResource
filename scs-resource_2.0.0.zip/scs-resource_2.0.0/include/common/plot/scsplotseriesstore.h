#ifndef SCSPLOTSERIESSTORE_H
#define SCSPLOTSERIESSTORE_H
#include "scsplotseriesdata.h"

BEGIN_NAMESPACE(Gemini)

class CscsPlotAbstractSeriesStore
{
protected:
    virtual ~CscsPlotAbstractSeriesStore() {}
    virtual void dataChanged() = 0;
    virtual void setRectOfInterest( const CscsRectF & ) = 0;
    virtual CscsRectF dataRect() const = 0;
    virtual uint dataSize() const = 0;
};

template <typename T>
class CscsPlotSeriesStore: public virtual CscsPlotAbstractSeriesStore
{
public:
    explicit CscsPlotSeriesStore<T>();

    ~CscsPlotSeriesStore<T>();
    void setData( CscsPlotSeriesData<T> *series );

    CscsPlotSeriesData<T> *data();
    const CscsPlotSeriesData<T> *data() const;

    T sample( int index ) const;
    virtual uint dataSize() const;
    virtual CscsRectF dataRect() const;
    virtual void setRectOfInterest( const CscsRectF &rect );
    CscsPlotSeriesData<T> *swapData( CscsPlotSeriesData<T> *series );

private:
    CscsPlotSeriesData<T> *d_series;
};

template <typename T>
CscsPlotSeriesStore<T>::CscsPlotSeriesStore():
    d_series( nullptr )
{
}

template <typename T>
CscsPlotSeriesStore<T>::~CscsPlotSeriesStore()
{
    delete d_series;
}

template <typename T>
inline CscsPlotSeriesData<T> *CscsPlotSeriesStore<T>::data()
{
    return d_series;
}

template <typename T>
inline const CscsPlotSeriesData<T> *CscsPlotSeriesStore<T>::data() const
{
    return d_series;
}

template <typename T>
inline T CscsPlotSeriesStore<T>::sample( int index ) const
{
    return d_series ? d_series->sample( index ) : T();
}

template <typename T>
void CscsPlotSeriesStore<T>::setData( CscsPlotSeriesData<T> *series )
{
    if ( d_series != series )
    {
        delete d_series;
        d_series = series;
        dataChanged();
    }
}

template <typename T>
uint CscsPlotSeriesStore<T>::dataSize() const
{
    if ( d_series == nullptr )
        return 0;

    return d_series->size();
}

template <typename T>
CscsRectF CscsPlotSeriesStore<T>::dataRect() const
{
    if ( d_series == nullptr )
        return CscsRectF( 1.0, 1.0, -2.0, -2.0 ); // invalid

    return d_series->boundingRect();
}

template <typename T>
void CscsPlotSeriesStore<T>::setRectOfInterest( const CscsRectF &rect )
{
    if ( d_series )
        d_series->setRectOfInterest( rect );
}

template <typename T>
CscsPlotSeriesData<T>* CscsPlotSeriesStore<T>::swapData( CscsPlotSeriesData<T> *series )
{
    CscsPlotSeriesData<T> * swappedSeries = d_series;
    d_series = series;

    return swappedSeries;
}

END_NAMESPACE

#endif