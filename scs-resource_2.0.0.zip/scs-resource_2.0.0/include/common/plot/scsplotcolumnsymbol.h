#ifndef SCSPLOTCOLUMNSYMBOL_H
#define SCSPLOTCOLUMNSYMBOL_H

#include "scsplotinterval.h"
#include <painting/scspen.h>
#include <painting/scssize.h>
#include <painting/scsrect.h>
#include <window/scsenum.h>

BEGIN_NAMESPACE(Gemini)

class CscsPainter;
class CscsPalette;
class CscsPlotText;

class  CscsPlotColumnRect
{
public:
    enum Direction
    {
        LeftToRight,
        RightToLeft,
        BottomToTop,
        TopToBottom
    };
    CscsPlotColumnRect():
        direction( BottomToTop )
    {
    }

    CscsRectF toRect() const
    {
        CscsRectF r( hInterval.minValue(), vInterval.minValue(),
            hInterval.maxValue() - hInterval.minValue(),
            vInterval.maxValue() - vInterval.minValue() );
        r = r.normalized();

        if ( hInterval.borderFlags() & CscsPlotInterval::ExcludeMinimum )
            r.adjust( 1, 0, 0, 0 );
        if ( hInterval.borderFlags() & CscsPlotInterval::ExcludeMaximum )
            r.adjust( 0, 0, -1, 0 );
        if ( vInterval.borderFlags() & CscsPlotInterval::ExcludeMinimum )
            r.adjust( 0, 1, 0, 0 );
        if ( vInterval.borderFlags() & CscsPlotInterval::ExcludeMaximum )
            r.adjust( 0, 0, 0, -1 );

        return r;
    }

    SCS::Orientation orientation() const
    {
        if ( direction == LeftToRight || direction == RightToLeft )
            return SCS::Horizontal;

        return SCS::Vertical;
    }

    CscsPlotInterval hInterval;
    CscsPlotInterval vInterval;
    Direction direction;
};

class  CscsPlotColumnSymbol
{
public:
    enum Style
    {
        NoStyle = -1,
        Box,
        UserStyle = 1000
    };

    enum FrameStyle
    {
        NoFrame,
        Plain,
        Raised
    };

public:
    CscsPlotColumnSymbol( Style = NoStyle );
    virtual ~CscsPlotColumnSymbol();

    void setFrameStyle( FrameStyle style );
    FrameStyle frameStyle() const;

    void setLineWidth( int width );
    int lineWidth() const;

    void setPalette( const CscsPalette & );
    const CscsPalette &palette() const;

    void setStyle( Style );
    Style style() const;

    virtual void draw( CscsPainter *, const CscsPlotColumnRect & ) const;

protected:
    void drawBox( CscsPainter *, const CscsPlotColumnRect & ) const;

private:
    class PrivateData;
    PrivateData* d_data;
};

END_NAMESPACE

#endif