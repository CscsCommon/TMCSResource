#ifndef SCSPLOTSLIDER_H
#define SCSPLOTSLIDER_H
#include "scsplotabstractslider.h"
#include <window/scsenum.h>

BEGIN_NAMESPACE(Gemini)

class CscsPlotScaleDraw;
class CscsPainter;

class  WIDGET_EXPORT CscsPlotSlider: public CscsPlotAbstractSlider
{

public:
    enum ScalePosition
    {
        NoScale,
        LeadingScale,
        TrailingScale
    };

    explicit CscsPlotSlider( CscsWidget *parent = nullptr );
    explicit CscsPlotSlider( SCS::Orientation, CscsWidget *parent = nullptr );

    virtual ~CscsPlotSlider();

    void setOrientation( SCS::Orientation );
    SCS::Orientation orientation() const;

    void setScalePosition( ScalePosition );
    ScalePosition scalePosition() const;

    void setTrough( bool );
    bool hasTrough() const;

    void setGroove( bool );
    bool hasGroove() const;

    void setHandleSize( const CscsSize & );
    CscsSize handleSize() const;

    void setBorderWidth( int bw );
    int borderWidth() const;

    void setSpacing( int );
    int spacing() const;

    virtual CscsSize sizeHint() const;
    virtual CscsSize minimumSizeHint() const;

    void setScaleDraw( CscsPlotScaleDraw * );
    const CscsPlotScaleDraw *scaleDraw() const;

    void setUpdateInterval( int );
    int updateInterval() const;

protected:
    virtual double scrolledTo( const CscsPoint & ) const;
    virtual bool isScrollPosition( const CscsPoint & ) const;

    virtual void drawSlider ( CscsPainter *, const CscsRect & ) const;
    virtual void drawHandle( CscsPainter *, const CscsRect &, int pos ) const;

    virtual void mousePressEvent( CscsMouseEvent * );
    virtual void mouseReleaseEvent( CscsMouseEvent * );
    virtual void resizeEvent( CscsResizeEvent * );
    virtual void paintEvent ( CscsPaintEvent * );
    virtual void changeEvent( CscsEvent * );
    virtual void timerEvent( CscsTimerEvent * );

    virtual void scaleChange();

    CscsRect sliderRect() const;
    CscsRect handleRect() const;

private:
    CscsPlotScaleDraw *scaleDraw();

    void layoutSlider( bool );
    void initSlider( SCS::Orientation );

    class PrivateData;
    PrivateData *d_data;

BEGIN_PROPERTY(CscsPlotSlider,CscsPlotAbstractSlider)

    META_PROPERTY(SCS::Orientation, orientation,
                READ, orientation, WRITE, setOrientation )
    META_PROPERTY( ScalePosition, scalePosition, READ, scalePosition,
        WRITE, setScalePosition )
    META_PROPERTY( bool, trough, READ, hasTrough, WRITE, setTrough )
    META_PROPERTY( bool, groove, READ, hasGroove, WRITE, setGroove )
    META_PROPERTY( CscsSize, handleSize, READ, handleSize, WRITE, setHandleSize )
    META_PROPERTY( int, borderWidth, READ, borderWidth, WRITE, setBorderWidth )
    META_PROPERTY( int, spacing, READ, spacing, WRITE, setSpacing )
END_PROPERTY

};

END_NAMESPACE

#endif