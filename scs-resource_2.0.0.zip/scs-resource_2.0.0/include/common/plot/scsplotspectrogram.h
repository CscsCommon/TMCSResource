#ifndef SCSPLOTSPECTROGRAM_H
#define SCSPLOTSPECTROGRAM_H
#include "scsplotrasterdata.h"
#include "scsplotrasteritem.h"
#include <kernel/scslist.h>
#include <window/scsenum.h>
#include <painting/scspen.h>

BEGIN_NAMESPACE(Gemini)

class CscsPlotColorMap;

class  CscsPlotSpectrogram: public CscsPlotRasterItem
{
public:
    enum DisplayMode
    {
        ImageMode = 0x01,
        ContourMode = 0x02
    };
    typedef CscsFlags<DisplayMode> DisplayModes;

    explicit CscsPlotSpectrogram( const std::string &title = std::string() );
    virtual ~CscsPlotSpectrogram();

    void setDisplayMode( DisplayMode, bool on = true );
    bool testDisplayMode( DisplayMode ) const;

    void setData( CscsPlotRasterData *data );
    const CscsPlotRasterData *data() const;
    CscsPlotRasterData *data();

    void setColorMap( CscsPlotColorMap * );
    const CscsPlotColorMap *colorMap() const;

    virtual CscsPlotInterval interval(SCS::Axis) const;
    virtual CscsRectF pixelHint( const CscsRectF & ) const;

    void setDefaultContourPen( const CscsRgba &,
        double width = 0.0, CscsPen::PenType = CscsPen::SolidPen );
    void setDefaultContourPen( const CscsPen & );
    CscsPen defaultContourPen() const;

    virtual CscsPen contourPen( double level ) const;

    void setConrecFlag( CscsPlotRasterData::ConrecFlag, bool on );
    bool testConrecFlag( CscsPlotRasterData::ConrecFlag ) const;

    void setContourLevels( const CscsList<double> & );
    CscsList<double> contourLevels() const;

    virtual int rtti() const;

    virtual void draw( CscsPainter *,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect ) const;

protected:
    virtual CscsImage renderImage(
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &area, const CscsSize &imageSize ) const;

    virtual CscsSize contourRasterSize(
        const CscsRectF &, const CscsRect & ) const;

    virtual CscsPlotRasterData::ContourLines renderContourLines(
        const CscsRectF &rect, const CscsSize &raster ) const;

    virtual void drawContourLines( CscsPainter *,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsPlotRasterData::ContourLines& ) const;

    void renderTile( const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRect &tile, CscsImage * ) const;

private:
    class PrivateData;
    PrivateData *d_data;
};

SCS_DECLARE_OPERATORS_FOR_FLAGS( CscsPlotSpectrogram::DisplayModes )

END_NAMESPACE

#endif