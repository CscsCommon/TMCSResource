#ifndef SCSPLOTINTERVALSYMBOL_H
#define SCSPLOTINTERVALSYMBOL_H
#include <painting/scspen.h>
#include <painting/scssize.h>
#include <window/scsenum.h>

BEGIN_NAMESPACE(Gemini)

class CscsPainter;
class CscsRect;
class CscsPointF;

class  CscsPlotIntervalSymbol
{
public:
    //! Symbol style
    enum Style
    {
        NoSymbol = -1,
        Bar,
        Box,
        UserSymbol = 1000
    };

public:
    CscsPlotIntervalSymbol( Style = NoSymbol );
    CscsPlotIntervalSymbol( const CscsPlotIntervalSymbol & );
    virtual ~CscsPlotIntervalSymbol();

    CscsPlotIntervalSymbol &operator=( const CscsPlotIntervalSymbol & );
    bool operator==( const CscsPlotIntervalSymbol & ) const;
    bool operator!=( const CscsPlotIntervalSymbol & ) const;

    void setWidth( int );
    int width() const;

    void setBrush( const CscsBrush& b );
    const CscsBrush& brush() const;

    void setPen( const CscsRgba &, int width = 0, CscsPen::PenType = CscsPen::SolidPen);
    void setPen( const CscsPen & );
    const CscsPen& pen() const;

    void setStyle( Style );
    Style style() const;

    virtual void draw( CscsPainter *, SCS::Orientation,
        const CscsPointF& from, const CscsPointF& to ) const;

private:

    class PrivateData;
    PrivateData* d_data;
};

END_NAMESPACE

#endif