#ifndef SCSPLOTGRID_H
#define SCSPLOTGRID_H
#include "scsplotitem.h"
#include "scsplotscalediv.h"
#include <painting/scspen.h>
#include <window/scsenum.h>

BEGIN_NAMESPACE(Gemini)

class CscsPainter;
class CscsPlotScaleMap;

class  CscsPlotGrid: public CscsPlotItem
{
public:
    explicit CscsPlotGrid();
    virtual ~CscsPlotGrid();

    virtual int rtti() const;

    void enableX( bool tf );
    bool xEnabled() const;

    void enableY( bool tf );
    bool yEnabled() const;

    void enableXMin( bool tf );
    bool xMinEnabled() const;

    void enableYMin( bool tf );
    bool yMinEnabled() const;

    void setXDiv( const CscsPlotScaleDiv &sx );
    const CscsPlotScaleDiv &xScaleDiv() const;

    void setYDiv( const CscsPlotScaleDiv &sy );
    const CscsPlotScaleDiv &yScaleDiv() const;

    void setPen( const CscsRgba &, double width = 0.0, CscsPen::PenType = CscsPen::SolidPen );
    void setPen( const CscsPen & );

    void setMajorPen( const CscsRgba &, double width = 0.0, CscsPen::PenType = CscsPen::SolidPen );
    void setMajorPen( const CscsPen & );
    const CscsPen& majorPen() const;

    void setMinorPen( const CscsRgba &, double width = 0.0, CscsPen::PenType = CscsPen::SolidPen );
    void setMinorPen( const CscsPen &p );
    const CscsPen& minorPen() const;

    virtual void draw( CscsPainter *p,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &rect ) const;

    virtual void updateScaleDiv( 
        const CscsPlotScaleDiv &xMap, const CscsPlotScaleDiv &yMap );

private:
    void drawLines( CscsPainter *painter, const CscsRectF &,
        SCS::Orientation orientation, const CscsPlotScaleMap &,
        const CscsList<double> & ) const;

    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE

#endif