#ifndef SCSPLOT_H
#define SCSPLOT_H
#include "scsplottext.h"
#include "scsplotdict.h"
#include "scsplotscalemap.h"
#include "scsplotinterval.h"
#include <window/widgets/scsframe.h>
#include <kernel/scslist.h>
#include <kernel/scsvariant.h>

BEGIN_NAMESPACE(Gemini)

class CscsPlotLayout;
class CscsPlotAbstractLegend;
class CscsPlotScaleWidget;
class CscsPlotScaleEngine;
class CscsPlotScaleDiv;
class CscsPlotScaleDraw;
class CscsPlotTextLabel;

class  WIDGET_EXPORT CscsPlot: public CscsFrame, public CscsPlotDict
{


public:
    enum Axis
    {
        yLeft,
        yRight,
        xBottom,
        xTop,
        axisCnt
    };

    enum LegendPosition
    {
        LeftLegend,
        RightLegend,
        BottomLegend,
        TopLegend
    };

    explicit CscsPlot( CscsWidget * = nullptr );
    explicit CscsPlot( const CscsPlotText &title, CscsWidget * = nullptr );

    virtual ~CscsPlot();

    // void applyProperties( const std::string & );
    // std::string grabProperties() const;

    void setAutoReplot( bool = true );
    bool autoReplot() const;

    // Layout

    void setPlotLayout( CscsPlotLayout * );

    CscsPlotLayout *plotLayout();
    const CscsPlotLayout *plotLayout() const;

    // Title

    void setTitle( const std::string & );
    void setTitle( const CscsPlotText &t );
    CscsPlotText title() const;

    CscsPlotTextLabel *titleLabel();
    const CscsPlotTextLabel *titleLabel() const;

    // Footer

    void setFooter( const std::string & );
    void setFooter( const CscsPlotText &t );
    CscsPlotText footer() const;

    CscsPlotTextLabel *footerLabel();
    const CscsPlotTextLabel *footerLabel() const;

    // Canvas

    void setCanvas( CscsWidget * );

    CscsWidget *canvas();
    const CscsWidget *canvas() const;

    void setCanvasBackground( const CscsBrush & );
    CscsBrush canvasBackground() const;

    virtual CscsPlotScaleMap canvasMap( int axisId ) const;

    double invTransform( int axisId, int pos ) const;
    double transform( int axisId, double value ) const;

    // Axes

    CscsPlotScaleEngine *axisScaleEngine( int axisId );
    const CscsPlotScaleEngine *axisScaleEngine( int axisId ) const;
    void setAxisScaleEngine( int axisId, CscsPlotScaleEngine * );

    void setAxisAutoScale( int axisId, bool on = true );
    bool axisAutoScale( int axisId ) const;

    void enableAxis( int axisId, bool tf = true );
    bool axisEnabled( int axisId ) const;

    void setAxisFont( int axisId, const CscsFont &f );
    CscsFont axisFont( int axisId ) const;

    void setAxisScale( int axisId, double min, double max, double step = 0 );
    void setAxisScaleDiv( int axisId, const CscsPlotScaleDiv & );
    void setAxisScaleDraw( int axisId, CscsPlotScaleDraw * );

    double axisStepSize( int axisId ) const;
    CscsPlotInterval axisInterval( int axisId ) const;

    const CscsPlotScaleDiv &axisScaleDiv( int axisId ) const;

    const CscsPlotScaleDraw *axisScaleDraw( int axisId ) const;
    CscsPlotScaleDraw *axisScaleDraw( int axisId );

    const CscsPlotScaleWidget *axisWidget( int axisId ) const;
    CscsPlotScaleWidget *axisWidget( int axisId );

    void setAxisLabelAlignment( int axisId, SCS::Alignment );
    void setAxisLabelRotation( int axisId, double rotation );

    void setAxisTitle( int axisId, const std::string & );
    void setAxisTitle( int axisId, const CscsPlotText & );
    CscsPlotText axisTitle( int axisId ) const;

    void setAxisMaxMinor( int axisId, int maxMinor );
    int axisMaxMinor( int axisId ) const;

    void setAxisMaxMajor( int axisId, int maxMajor );
    int axisMaxMajor( int axisId ) const;

    // Legend

    void insertLegend( CscsPlotAbstractLegend *, 
        LegendPosition = CscsPlot::RightLegend, double ratio = -1.0 );

    CscsPlotAbstractLegend *legend();
    const CscsPlotAbstractLegend *legend() const;

    void updateLegend();
    void updateLegend( const CscsPlotItem * );

    // Misc

    virtual CscsSize sizeHint() const;
    virtual CscsSize minimumSizeHint() const;

    virtual void updateLayout();
    virtual void drawCanvas( CscsPainter * );

    void updateAxes();
    void updateCanvasMargins();

    virtual void getCanvasMarginsHint( 
        const CscsPlotScaleMap maps[], const CscsRectF &canvasRect,
        double &left, double &top, double &right, double &bottom) const;

    virtual bool event( CscsEvent * );
    virtual bool eventFilter( CscsObject *, CscsEvent * );

    virtual void drawItems( CscsPainter *, const CscsRectF &,
        const CscsPlotScaleMap maps[axisCnt] ) const;

    virtual CscsVariant itemToInfo( CscsPlotItem * ) const;
    virtual CscsPlotItem *infoToItem( const CscsVariant & ) const;

SIGNALS:
    void itemAttached( CscsPlotItem *plotItem, bool on ){}
    void legendDataChanged( const CscsVariant &itemInfo, 
        const CscsList<CscsPlotLegendData> &data ){}

SLOTS:
    virtual void replot();
    void autoRefresh();

protected:
    static bool axisValid( int axisId );

    virtual void resizeEvent( CscsResizeEvent *e );

SLOTS:
    void updateLegendItems( const CscsVariant &itemInfo,
        const CscsList<CscsPlotLegendData> &data );

private:
    friend class CscsPlotItem;
    void attachItem( CscsPlotItem *, bool );

    void initAxesData();
    void deleteAxesData();
    void updateScaleDiv();

    void initPlot( const CscsPlotText &title );

    class AxisData;
    AxisData *d_axisData[axisCnt];

    class PrivateData;
    PrivateData *d_data;

BEGIN_PROPERTY(CscsPlot, CscsFrame)
    META_PROPERTY( CscsBrush, canvasBackground,
        READ, canvasBackground, WRITE, setCanvasBackground )
    META_PROPERTY( bool, autoReplot, READ, autoReplot, WRITE, setAutoReplot )
END_PROPERTY

};

END_NAMESPACE

#endif