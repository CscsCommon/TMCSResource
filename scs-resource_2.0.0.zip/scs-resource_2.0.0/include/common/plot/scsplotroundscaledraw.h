#ifndef SCSPLOTROUNDSCALEDRAW_H
#define SCSPLOTROUNDSCALEDRAW_H
#include "scsplotabstractscaledraw.h"

BEGIN_NAMESPACE(Gemini)

class  CscsPlotRoundScaleDraw: public CscsPlotAbstractScaleDraw
{
public:
    CscsPlotRoundScaleDraw();
    virtual ~CscsPlotRoundScaleDraw();

    void setRadius( double radius );
    double radius() const;

    void moveCenter( double x, double y );
    void moveCenter( const CscsPointF & );
    CscsPointF center() const;

    void setAngleRange( double angle1, double angle2 );

    virtual double extent( const CscsFont & ) const;

protected:
    virtual void drawTick( CscsPainter *, double val, double len ) const;
    virtual void drawBackbone( CscsPainter * ) const;
    virtual void drawLabel( CscsPainter *, double val ) const;

private:
    CscsPlotRoundScaleDraw( const CscsPlotRoundScaleDraw & );
    CscsPlotRoundScaleDraw &operator=( const CscsPlotRoundScaleDraw &other );

    class PrivateData;
    PrivateData *d_data;
};

//! Move the center of the scale draw, leaving the radius unchanged
inline void CscsPlotRoundScaleDraw::moveCenter( double x, double y )
{
    moveCenter( CscsPointF( x, y ) );
}

END_NAMESPACE

#endif