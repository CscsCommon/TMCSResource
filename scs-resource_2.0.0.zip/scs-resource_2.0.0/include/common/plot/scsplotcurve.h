#ifndef SCSPLOTCURVE_H
#define SCSPLOTCURVE_H
#include "scsplotseriesitem.h"
#include "scsplotseriesdata.h"
#include "scsplottext.h"
#include <painting/scspen.h>

BEGIN_NAMESPACE(Gemini)

class CscsPainter;
class CscsPolygonF;
class CscsPlotScaleMap;
class CscsPlotSymbol;
class CscsPlotCurveFitter;

class  CscsPlotCurve:
    public CscsPlotSeriesItem, public CscsPlotSeriesStore<CscsPointF>
{
public:
    enum CurveStyle
    {
        NoCurve = -1,
        Lines,
        Sticks,
        Steps,
        Dots,
        UserCurve = 100
    };

    enum CurveAttribute
    {
        Inverted = 0x01,
        Fitted = 0x02
    };
    typedef CscsFlags<CurveAttribute> CurveAttributes;

    enum LegendAttribute
    {
        LegendNoAttribute = 0x00,
        LegendShowLine = 0x01,
        LegendShowSymbol = 0x02,
        LegendShowBrush = 0x04
    };
    typedef CscsFlags<LegendAttribute> LegendAttributes;

    enum PaintAttribute
    {
        ClipPolygons = 0x01,
        FilterPoints = 0x02,
        MinimizeMemory = 0x04,
        ImageBuffer = 0x08
    };
    typedef CscsFlags<PaintAttribute> PaintAttributes;

    explicit CscsPlotCurve( const std::string &title = std::string() );
    explicit CscsPlotCurve( const CscsPlotText &title );

    virtual ~CscsPlotCurve();

    virtual int rtti() const;

    void setPaintAttribute( PaintAttribute, bool on = true );
    bool testPaintAttribute( PaintAttribute ) const;

    void setLegendAttribute( LegendAttribute, bool on = true );
    bool testLegendAttribute( LegendAttribute ) const;

    void setSamples( const double *xData, const double *yData, int size );
    void setSamples( const CscsVector<double> &xData, const CscsVector<double> &yData );

    void setSamples( const CscsVector<CscsPointF> & );
    void setSamples( CscsPlotSeriesData<CscsPointF> * );

    int closestPoint( const CscsPoint &pos, double *dist = nullptr ) const;

    double minXValue() const;
    double maxXValue() const;
    double minYValue() const;
    double maxYValue() const;

    void setCurveAttribute( CurveAttribute, bool on = true );
    bool testCurveAttribute( CurveAttribute ) const;

    void setPen( const CscsRgba &, double width = 0.0, CscsPen::PenType =CscsPen::SolidPen);
    void setPen( const CscsPen & );
    const CscsPen &pen() const;

    void setBrush( const CscsBrush & );
    const CscsBrush &brush() const;

    void setBaseline( double );
    double baseline() const;

    void setStyle( CurveStyle style );
    CurveStyle style() const;

    void setSymbol( CscsPlotSymbol * );
    const CscsPlotSymbol *symbol() const;

    void setCurveFitter( CscsPlotCurveFitter * );
    CscsPlotCurveFitter *curveFitter() const;

    virtual void drawSeries( CscsPainter *,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect, int from, int to ) const;

    virtual CscsImage legendIcon( int index, const CscsSizeF & ) const;

protected:

    void init();

    virtual void drawCurve( CscsPainter *, int style,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect, int from, int to ) const;

    virtual void drawSymbols( CscsPainter *, const CscsPlotSymbol &,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect, int from, int to ) const;

    virtual void drawLines( CscsPainter *,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect, int from, int to ) const;

    virtual void drawSticks( CscsPainter *,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect, int from, int to ) const;

    virtual void drawDots( CscsPainter *,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect, int from, int to ) const;

    virtual void drawSteps( CscsPainter *,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect, int from, int to ) const;

    virtual void fillCurve( CscsPainter *,
        const CscsPlotScaleMap &, const CscsPlotScaleMap &,
        const CscsRectF &canvasRect, CscsPolygonF & ) const;

    void closePolyline( CscsPainter *,
        const CscsPlotScaleMap &, const CscsPlotScaleMap &, CscsPolygonF & ) const;

private:
    class PrivateData;
    PrivateData *d_data;
};

inline double CscsPlotCurve::minXValue() const
{
    return boundingRect().left();
}

inline double CscsPlotCurve::maxXValue() const
{
    return boundingRect().right();
}

inline double CscsPlotCurve::minYValue() const
{
    return boundingRect().top();
}

inline double CscsPlotCurve::maxYValue() const
{
    return boundingRect().bottom();
}

SCS_DECLARE_OPERATORS_FOR_FLAGS( CscsPlotCurve::PaintAttributes )
SCS_DECLARE_OPERATORS_FOR_FLAGS( CscsPlotCurve::LegendAttributes )
SCS_DECLARE_OPERATORS_FOR_FLAGS( CscsPlotCurve::CurveAttributes )

END_NAMESPACE

#endif