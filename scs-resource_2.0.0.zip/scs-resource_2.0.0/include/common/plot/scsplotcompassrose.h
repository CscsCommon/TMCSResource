#ifndef SCSPLOTCOMPASSROSE_H
#define SCSPLOTCOMPASSROSE_H
#include <window/styles/scspalette.h>

BEGIN_NAMESPACE(Gemini)

class CscsPainter;
class CscsPointF;

class  CscsPlotCompassRose
{
public:
    virtual ~CscsPlotCompassRose() {};
    virtual void setPalette( const CscsPalette &p )
    {
        d_palette = p;
    }

    const CscsPalette &palette() const
    {
        return d_palette;
    }
    virtual void draw( CscsPainter *painter, 
        const CscsPointF &center, double radius, double north,
        CscsPalette::ColorGroup colorGroup = CscsPalette::Active ) const = 0;

private:
    CscsPalette d_palette;
};


class  CscsPlotSimpleCompassRose: public CscsPlotCompassRose
{
public:
    CscsPlotSimpleCompassRose( int numThorns = 8, int numThornLevels = -1 );
    virtual ~CscsPlotSimpleCompassRose();

    void setWidth( double w );
    double width() const;

    void setNumThorns( int count );
    int numThorns() const;

    void setNumThornLevels( int count );
    int numThornLevels() const;

    void setShrinkFactor( double factor );
    double shrinkFactor() const;

    virtual void draw( CscsPainter *, const CscsPointF &center, double radius,
        double north, CscsPalette::ColorGroup = CscsPalette::Active ) const;

    static void drawRose( CscsPainter *, const CscsPalette &,
        const CscsPointF &center, double radius, double origin, double width,
        int numThorns, int numThornLevels, double shrinkFactor );

private:
    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE

#endif