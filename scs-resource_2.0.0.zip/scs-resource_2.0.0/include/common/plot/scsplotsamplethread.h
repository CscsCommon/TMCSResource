#ifndef SCSPLOTSAMPLETHREAD_H
#define SCSPLOTSAMPLETHREAD_H
#include <kernel/scsthread.h>

BEGIN_NAMESPACE(Gemini)

class  CscsPlotSampleThread: public CscsThread
{
public:
    virtual ~CscsPlotSampleThread();

    double interval() const;
    double elapsed() const;

SLOTS:
    void setInterval( double interval );
    void stop();

protected:
    explicit CscsPlotSampleThread( CscsObject *parent = NULL );
    virtual void run();
    virtual void sample( double elapsed ) = 0;

private:
    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE
#endif