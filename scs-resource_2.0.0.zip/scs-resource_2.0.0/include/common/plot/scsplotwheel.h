#ifndef SCSPLOTWHEEL_H
#define SCSPLOTWHEEL_H
#include <window/scswidget.h>

BEGIN_NAMESPACE(Gemini)

class CscsPainter;
class WIDGET_EXPORT CscsPlotWheel:public CscsWidget{

public:
    explicit CscsPlotWheel( CscsWidget *parent = nullptr );
    virtual ~CscsPlotWheel();

    double value() const;

    void setOrientation( SCS::Orientation );
    SCS::Orientation orientation() const;

    double totalAngle() const;
    double viewAngle() const;

    void setTickCount( int );
    int tickCount() const;

    void setWheelWidth( int );
    int wheelWidth() const;

    void setWheelBorderWidth( int );
    int wheelBorderWidth() const;

    void setBorderWidth( int );
    int borderWidth() const;

    void setInverted( bool tf );
    bool isInverted() const;

    void setWrapping( bool tf );
    bool wrapping() const;

    void setSingleStep( double );
    double singleStep() const;

    void setPageStepCount( int );
    int pageStepCount() const;

    void setStepAlignment( bool on );
    bool stepAlignment() const;

    void setRange( double vmin, double vmax );

    void setMinimum( double min );
    double minimum() const;

    void setMaximum( double max );
    double maximum() const;

    void setUpdateInterval( int );
    int updateInterval() const;

    void setTracking( bool enable );
    bool isTracking() const;

    double mass() const;

SLOTS:
    void setValue( double );
    void setTotalAngle ( double );
    void setViewAngle( double );
    void setMass( double );

SIGNALS:

    void valueChanged( double value ){}
    void wheelPressed(){}
    void wheelReleased(){}
    void wheelMoved( double value ){}

protected:
    virtual void paintEvent( CscsPaintEvent * );
    virtual void mousePressEvent( CscsMouseEvent * );
    virtual void mouseReleaseEvent( CscsMouseEvent * );
    virtual void mouseMoveEvent( CscsMouseEvent * );
    virtual void keyPressEvent( CscsKeyEvent * );
    virtual void timerEvent( CscsTimerEvent * );

    void stopFlying();

    CscsRect wheelRect() const;

    virtual CscsSize sizeHint() const;
    virtual CscsSize minimumSizeHint() const;

    virtual void drawTicks( CscsPainter *, const CscsRectF & );
    virtual void drawWheelBackground( CscsPainter *, const CscsRectF & );

    virtual double valueAt( const CscsPoint & ) const;

private:
    double alignedValue( double ) const;
    double boundedValue( double ) const;

    class PrivateData;
    PrivateData *d_data;

BEGIN_PROPERTY(CscsPlotWheel, CscsWidget)
    META_PROPERTY( SCS::Orientation, orientation,
                READ, orientation, WRITE, setOrientation )
    META_PROPERTY( double, value, READ, value, WRITE, setValue )
    META_PROPERTY( double, minimum, READ, minimum, WRITE, setMinimum )
    META_PROPERTY( double, maximum, READ, maximum, WRITE, setMaximum )
    META_PROPERTY( double, singleStep, READ, singleStep, WRITE, setSingleStep )
    META_PROPERTY( int, pageStepCount, READ, pageStepCount, WRITE, setPageStepCount )
    META_PROPERTY( bool, stepAlignment, READ, stepAlignment, WRITE, setStepAlignment )
    META_PROPERTY( bool, tracking, READ, isTracking, WRITE, setTracking )
    META_PROPERTY( bool, wrapping, READ, wrapping, WRITE, setWrapping )
    META_PROPERTY( bool, inverted, READ, isInverted, WRITE, setInverted )
    META_PROPERTY( double, mass, READ, mass, WRITE, setMass )
    META_PROPERTY( int, updateInterval, READ, updateInterval, WRITE, setUpdateInterval )
    META_PROPERTY( double, totalAngle, READ, totalAngle, WRITE, setTotalAngle )
    META_PROPERTY( double, viewAngle, READ, viewAngle, WRITE, setViewAngle )
    META_PROPERTY( int, tickCount, READ, tickCount, WRITE, setTickCount )
    META_PROPERTY( int, wheelWidth, READ, wheelWidth, WRITE, setWheelWidth )
    META_PROPERTY( int, borderWidth, READ, borderWidth, WRITE, setBorderWidth )
    META_PROPERTY( int, wheelBorderWidth, READ, wheelBorderWidth, WRITE, setWheelBorderWidth )
END_PROPERTY

};

END_NAMESPACE

#endif