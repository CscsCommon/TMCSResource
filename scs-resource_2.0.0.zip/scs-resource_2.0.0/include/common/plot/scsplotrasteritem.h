#ifndef SCSPLOTRASTERITEM_H
#define SCSPLOTRASTERITEM_H

#include "scsplotitem.h"
#include "scsplotinterval.h"
#include <kernel/scsstring.h>
#include <painting/scsimage.h>
#include <kernel/scsflags.h>
#include <window/scsenum.h>


BEGIN_NAMESPACE(Gemini)

class  CscsPlotRasterItem: public CscsPlotItem
{
public:
    enum CachePolicy
    {
        NoCache,
        PaintCache
    };

    enum PaintAttribute
    {
        PaintInDeviceResolution = 1
    };

    //! Paint attributes
    typedef CscsFlags<PaintAttribute> PaintAttributes;

    explicit CscsPlotRasterItem( const std::string& title = std::string() );
    explicit CscsPlotRasterItem( const CscsPlotText& title );
    virtual ~CscsPlotRasterItem();

    void setPaintAttribute( PaintAttribute, bool on = true );
    bool testPaintAttribute( PaintAttribute ) const;

    void setAlpha( int alpha );
    int alpha() const;

    void setCachePolicy( CachePolicy );
    CachePolicy cachePolicy() const;

    void invalidateCache();

    virtual void draw( CscsPainter *p,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &rect ) const;

    virtual CscsRectF pixelHint( const CscsRectF & ) const;

    virtual CscsPlotInterval interval(SCS::Axis) const;
    virtual CscsRectF boundingRect() const;

protected:
    virtual CscsImage renderImage( const CscsPlotScaleMap &xMap,
        const CscsPlotScaleMap &yMap, const CscsRectF &area,
        const CscsSize &imageSize ) const = 0;

    virtual CscsPlotScaleMap imageMap( SCS::Orientation,
        const CscsPlotScaleMap &map, const CscsRectF &area,
        const CscsSize &imageSize, double pixelSize) const;

private:
    CscsPlotRasterItem( const CscsPlotRasterItem & );
    CscsPlotRasterItem &operator=( const CscsPlotRasterItem & );

    void init();

    CscsImage compose( const CscsPlotScaleMap &, const CscsPlotScaleMap &,
        const CscsRectF &imageArea, const CscsRectF &paintRect,
        const CscsSize &imageSize, bool doCache) const;


    class PrivateData;
    PrivateData *d_data;
};
SCS_DECLARE_OPERATORS_FOR_FLAGS( CscsPlotRasterItem::PaintAttributes )

END_NAMESPACE
#endif