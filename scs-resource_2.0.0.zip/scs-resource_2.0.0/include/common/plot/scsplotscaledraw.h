#ifndef SCSPLOTSCALEDRAW_H
#define SCSPLOTSCALEDRAW_H
#include "scsplotabstractscaledraw.h"
#include <painting/scspoint.h>
#include <painting/scsrect.h>
#include <painting/scsmatrix.h>
#include <window/scsenum.h>

BEGIN_NAMESPACE(Gemini)

class  CscsPlotScaleDraw: public CscsPlotAbstractScaleDraw
{
public:
    enum Alignment 
    { 
        BottomScale, 
        TopScale, 
        LeftScale, 
        RightScale 
    };

    CscsPlotScaleDraw();
    virtual ~CscsPlotScaleDraw();

    void getBorderDistHint( const CscsFont &, int &start, int &end ) const;
    int minLabelDist( const CscsFont & ) const;

    int minLength( const CscsFont & ) const;
    virtual double extent( const CscsFont & ) const;

    void move( double x, double y );
    void move( const CscsPointF & );
    void setLength( double length );

    Alignment alignment() const;
    void setAlignment( Alignment );

    SCS::Orientation orientation() const;

    CscsPointF pos() const;
    double length() const;

    void setLabelAlignment( SCS::Alignment );
    SCS::Alignment labelAlignment() const;

    void setLabelRotation( double rotation );
    double labelRotation() const;

    int maxLabelHeight( const CscsFont & ) const;
    int maxLabelWidth( const CscsFont & ) const;

    CscsPointF labelPosition( double val ) const;

    CscsRectF labelRect( const CscsFont &, double val ) const;
    CscsSizeF labelSize( const CscsFont &, double val ) const;

    CscsRect boundingLabelRect( const CscsFont &, double val ) const;

protected:
    CscsMatrix labelTransformation( const CscsPointF &, const CscsSizeF & ) const;

    virtual void drawTick( CscsPainter *, double val, double len ) const;
    virtual void drawBackbone( CscsPainter * ) const;
    virtual void drawLabel( CscsPainter *, double val ) const;

private:
    CscsPlotScaleDraw( const CscsPlotScaleDraw & );
    CscsPlotScaleDraw &operator=( const CscsPlotScaleDraw &other );

    void updateMap();

    class PrivateData;
    PrivateData *d_data;
};

inline void CscsPlotScaleDraw::move( double x, double y )
{
    move( CscsPointF( x, y ) );
}

END_NAMESPACE

#endif