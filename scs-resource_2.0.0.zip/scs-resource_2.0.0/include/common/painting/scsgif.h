#ifndef SCSGIF_H
#define SCSGIF_H
#include <kernel/scsdevice.h>
#include <painting/scsimage.h>

BEGIN_NAMESPACE(Gemini)

class CscsImage;
class CscsVariant;
class CscsGifFormat;

class CscsGif:public CscsNoCopyable{
public:
	 enum ImageOption {
        Size,
        ClipRect,
        Description,
        ScaledClipRect,
        ScaledSize,
        CompressionRatio,
        Gamma,
        Quality,
        Name,
        SubType,
        IncrementalReading,
        Endianness,
        Animation,
        BackgroundColor,
        ImageFormat,
        SupportedSubTypes,
        OptimizedWrite,
        ProgressiveScanWrite,
        ImageTransformation,
        TransformedByDefault
    };

	CscsGif();
	CscsGif(const CscsString& fileName,const CscsByteArray& format);
	CscsGif(CscsDevice* device, const CscsByteArray& format);
	~CscsGif();
	void setDevice(CscsDevice* device);
	CscsDevice* device()const;

	void setFormat(const CscsByteArray& format);
	void setFormat(const CscsByteArray& format)const;
	void setScaledSize(const CscsSize& size);
	CscsSize scaledSize()const;
	CscsByteArray format()const;
	CscsByteArray name()const;
	bool canRead()const;
	bool read(CscsImage* image);
	bool write(const CscsImage& image);

	static bool canRead(CscsDevice* deivce);
	CscsVariant option(ImageOption option)const;
	void setOption(ImageOption option, const CscsVariant& value);
	bool supportsOption(ImageOption option)const;

	int imageCount()const;
	int loopCount()const;
	int nextImageDelay()const;
	int currentImageNumber()const;

	inline bool jumpToImage(int imageNumber){
		return false;
	}

	inline bool jumpToNextImage(){
    	return false;
	}

	CscsString fileName()const;

	void setFileName(const CscsString& fileName);
private:
	bool imageIsComing()const;
	CscsGifFormat* gifFormat;
	CscsDevice* dev;
	mutable CscsByteArray fmt;
	mutable CscsByteArray buffer;
	mutable CscsImage lastImage;
	mutable int nextDelay;
	mutable int loopCnt;
	int frameNumber;
	mutable CscsSize nextSize;
	bool deleteDevice;
	CscsSize scaledSz;
};

END_NAMESPACE
#endif