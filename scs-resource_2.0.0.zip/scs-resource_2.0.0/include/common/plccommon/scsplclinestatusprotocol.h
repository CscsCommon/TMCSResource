#ifndef SCSPLCLINESTATUSPROTOCOL_H
#define SCSPLCLINESTATUSPROTOCOL_H
#include "scsplcprotocol.h"

/*
 * Created By J.Wong
 * 连线握手协议
 */
BEGIN_NAMESPACE(Gemini)

class CscsPlcLineStatusProtocol:public CscsAbstractPlcCommonProtocol{

public:
	CscsPlcLineStatusProtocol();
	virtual ~CscsPlcLineStatusProtocol();

	int composeProtocol(CscsByteArray& out, const CscsByteArray& in , void* ex=nullptr);
	int parseProtocol(const CscsByteArray& in);

};
END_NAMESPACE
#endif