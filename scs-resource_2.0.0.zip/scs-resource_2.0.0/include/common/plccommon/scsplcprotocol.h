#ifndef SCSPLCPROTOCOL_H
#define SCSPLCPROTOCOL_H
#include <protocol/scsabstractprotocol.h>

/*
 * Created By J.Wong
 * PLC&HMI通信协议
 */

BEGIN_NAMESPACE(Gemini)

class CscsAbstractPlcProtocolPrivate;
class CscsAbstractPlcCommonProtocolPrivate;

class CscsAbstractPlcProtocol:public CscsAbstractProtocol{
public:
	CscsAbstractPlcProtocol();
	virtual ~CscsAbstractPlcProtocol();
	
protected:	
	virtual void initSend();
	virtual void initReceive();
	
	void setSendType(int type);
	void setReceiveType(int type);
	static uint16 packNumberFetchAndAdd();
	static uint16 packNumberFetchAndSub();
	static void packNumberReset();

protected:	
	CscsAbstractPlcProtocol(CscsAbstractProtocolPrivate* data);
	CscsAbstractPlcProtocolPrivate* d_func()const;

};


/*
 * 一般协议
 */
class CscsAbstractPlcCommonProtocol:public CscsAbstractPlcProtocol{
public:
	CscsAbstractPlcCommonProtocol();
	virtual ~CscsAbstractPlcCommonProtocol();
	
protected:	
	virtual void initSend();
	virtual void initReceive();

protected:
	CscsAbstractPlcCommonProtocolPrivate* d_func()const;
};

/*
 *触发器协议
 */
class CscsAbstractPlcTriggerProtocol:public CscsAbstractPlcProtocol{
public:
	CscsAbstractPlcTriggerProtocol();
	virtual ~CscsAbstractPlcTriggerProtocol();
	
protected:	
	virtual void initSend();
	virtual void initReceive();
};

END_NAMESPACE

#endif