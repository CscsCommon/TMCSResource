#ifndef SCSPLCMOLDSETSTATUSPROTOCOL_H
#define SCSPLCMOLDSETSTATUSPROTOCOL_H
#include "scsplcprotocol.h"

/*
 * Created By J.Wong
 * 模组资料更新状态协议
 */
BEGIN_NAMESPACE(Gemini)

class CscsPlcMoldSetStatusProtocol:public CscsAbstractPlcCommonProtocol{
public:
	CscsPlcMoldSetStatusProtocol();
	virtual ~CscsPlcMoldSetStatusProtocol();

	int composeProtocol(CscsByteArray& out, const CscsByteArray& in , void* ex=nullptr);
	int parseProtocol(const CscsByteArray& in);
};

END_NAMESPACE

#endif