#ifndef SCSPLCCANTRANSMITPROTOCOL_H
#define SCSPLCCANTRANSMITPROTOCOL_H
#include "scsplcprotocol.h"
/*
 * Created By J.Wong
 * CAN 数据转发协议
 */
BEGIN_NAMESPACE(Gemini)


class CscsPlcCANTransmitProtocol:public CscsAbstractPlcCommonProtocol{

public:
	enum CANDevice{
		ELECTRIC,
		OTHERDEV
	};

	explicit CscsPlcCANTransmitProtocol(int type=ELECTRIC);
	virtual ~CscsPlcCANTransmitProtocol();
	int composeProtocol(CscsByteArray& out, const CscsByteArray& in, void* ex=nullptr);
	int parseProtocol(const CscsByteArray& in);
};

END_NAMESPACE
#endif