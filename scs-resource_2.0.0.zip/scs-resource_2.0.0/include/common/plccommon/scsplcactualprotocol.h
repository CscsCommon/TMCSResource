#ifndef SCSPLCACTUALPROTOCOL_H
#define SCSPLCACTUALPROTOCOL_H
#include "scsplcprotocol.h"

/*
 * Created By J.Wong
 * 即时资料协议
 */
BEGIN_NAMESPACE(Gemini)
class CscsPlcActualProtocol:public CscsAbstractPlcCommonProtocol{
public:
	CscsPlcActualProtocol();
	virtual ~CscsPlcActualProtocol();

	int composeProtocol(CscsByteArray& out, const CscsByteArray& in, void* ex=nullptr);
	int parseProtocol(const CscsByteArray& in);

protected:
	int writeToDataBase(const CscsByteArray& data);
};

END_NAMESPACE
#endif