#ifndef SCSABSTRACTSOCKETP_H
#define SCSABSTRACTSOCKETP_H

#include "scsaddress.h"
#include "scssocketlayer.h"
#include "scsabstractsocket.h"
#include <kernel/scsringbuffer.h>
#include <list>

BEGIN_NAMESPACE(Gemini)

class CscsSocketNotifier;

class CscsAbstractSocketPrivate{
public:
    CscsAbstractSocketPrivate(CscsAbstractSocket* socket=nullptr);
    virtual ~CscsAbstractSocketPrivate();
    void connectToNextAddress();
    void startConnecting(const std::list<CscsAddress>& addrs);
    void testConnection();
    bool canReadNotification(int);
    bool canWriteNotification(int);
    void abortConnectionAttempt();
    void resetSocketLayer();
    bool flush();
    bool initSocketLayer(CscsAbstractSocket::SocketType type, CscsAbstractSocket::NetWorkProtocol protocol);
    void setupSocketNotifiers();
    bool readFromSocket();
    #ifdef D_UNIX
    int64 addToBytesAvailable;
    #endif
    bool readSocketNotifierCalled;
    bool readSocketNotifierState;
    bool readSocketNotifierStateSet;

    bool transmittedReadyRead;
    bool transmittedBytesWritten;

    bool closeCalled;
    std::string hostName;
    CscsAddress host;
    uint16 port;
    std::list<CscsAddress> addresses;
    CscsSocketLayer socketLayer;

    CscsSocketNotifier* readSocketNotifier;
    CscsSocketNotifier* writeSocketNotifier;

    int64 readBufferMaxSize;
    CscsRingBuffer readBuffer;
    CscsRingBuffer writeBuffer;



    bool isBuffered;
    int blockingTimeout;

    int connectTimeElapsed;
    int hostLookupId;
    CscsAbstractSocket::SocketType socketType;
    CscsAbstractSocket::SocketState state;
    CscsAbstractSocket::SocketError socketError;
    CscsAbstractSocket* mm;
};

END_NAMESPACE

#endif