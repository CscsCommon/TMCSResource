#ifndef SCSTCPSERVER_H
#define SCSTCPSERVER_H
#include "scsabstractsocket.h"
#include "scsaddress.h"
#include "scstcp.h"
#include <kernel/scsobject.h>
#include <kernel/scstypes.h>

BEGIN_NAMESPACE(Gemini)

class CscsTcpServerPrivate;

class CscsTcpServer:public CscsObject{
public:
	CscsTcpServer(CscsObject* parent=nullptr);
	virtual ~CscsTcpServer();

	bool listen(const CscsAddress& addr=CscsAddress::Any, uint16 port=0);
	void close();

	bool isListening()const;
	void setMaxPendingConnections(int nums);
	int  maxPendingConnections()const;

	uint16 serverPort()const;
	CscsAddress serverAddress()const;

	int socketDescriptor()const;
	bool setSocketDescriptor(int socketDescriptor);
	bool waitForNewConnection(int msecs=0, bool* timedOut=0);

	virtual bool hasPendingConnections()const;
	virtual CscsTcp* nextPendingConnection();

	CscsAbstractSocket::SocketError serverError()const;
	std::string errorString()const;

public:
	 void newConnection(){

	 }

protected:
	virtual void incomingConnection(int handle);

private:
	CscsTcpServerPrivate* d;
	friend class CscsTcpServerPrivate;
};


END_NAMESPACE

#endif