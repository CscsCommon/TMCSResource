#ifndef SCSABSTRACTPROTOCOL_H
#define SCSABSTRACTPROTOCOL_H
#include <kernel/scsbytearray.h>

/*
 * Created By J.Wong
 * 协议抽象类
 */
BEGIN_NAMESPACE(Gemini)

struct  CscsAbstractPartProtocolPrivate;

class 	CscsAbstractPartProtocol{
public:
	CscsAbstractPartProtocol(int size=1);
	virtual ~CscsAbstractPartProtocol();
	
	//设置数据
	virtual int setPartValue(int pos, void* data, int len);
	//获取数据
	virtual CscsByteArray partValue(int pos, int len)const;
	//获取当前位置
	virtual int position()const;
	//设置当前位置
	virtual void setPosition(int pos);
	//追加数据
	virtual int append(void* data, int len);
	//获取size
	virtual int fixedSize()const;
	//设置size
	virtual void setFixedSize(int sz);
	//获取数据buffer
	CscsByteArray buffer()const;
	
protected:
	CscsAbstractPartProtocolPrivate* d;
};

class	CscsAbstractProtocolPrivate;

class 	CscsAbstractProtocol{
public:
	CscsAbstractProtocol();
	virtual ~CscsAbstractProtocol();
	//组包和解包
	virtual int composeProtocol(CscsByteArray& out, const CscsByteArray& in,void* ex=nullptr);
	virtual int parseProtocol(const CscsByteArray& data);
	
	//写数据到资料库
	virtual int writeToDataBase(const CscsByteArray& data);
	
	CscsAbstractProtocolPrivate* d_func()const;
protected:

	CscsAbstractProtocol(CscsAbstractProtocolPrivate* data);
	CscsAbstractProtocolPrivate* d;
};

END_NAMESPACE

#endif