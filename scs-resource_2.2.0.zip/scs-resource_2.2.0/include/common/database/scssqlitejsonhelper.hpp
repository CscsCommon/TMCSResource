/*
 * Created by J.W 2019/05/26
 */

#ifndef SCSSQLITEJSONHELPER_HPP
#define SCSSQLITEJSONHELPER_HPP

#include <kernel/rapidjson/writer.h>
#include <kernel/rapidjson/stringbuffer.h>
#include <kernel/rapidjson/document.h>
#include <kernel/rapidjson/rapidjson.h>
#include <kernel/scsnamespace.h>
#include <unordered_map>
#include <functional>
#include <stdexcept>

BEGIN_NAMESPACE(Gemini)


using JsonBuilder = rapidjson::Writer<rapidjson::StringBuffer>;
class CscsSqliteJsonHelper
{
	public:
		CscsSqliteJsonHelper(rapidjson::StringBuffer& buf, int code) : m_code(code), m_jsonBuilder(buf)
		{

		}

		bool executeJson(sqlite3_stmt *stmt, const rapidjson::Value& val)
		{
			auto p=val.MemberBegin();
			size_t i=0;
			while(p!=val.MemberEnd()){
				const char* key = p->name.GetString();
				auto& t = val[key];
				if (SQLITE_OK != bindJsonValue(stmt, t, i + 1))
					return false;
				++p;
				++i;
			}
			m_code = sqlite3_step(stmt);
			sqlite3_reset(stmt);
			return SQLITE_DONE == m_code;
		}

		void buildJsonObject(sqlite3_stmt *stmt)
		{
			int colCount = sqlite3_column_count(stmt);

			m_jsonBuilder.StartArray();
			while (true)
			{
				m_code = sqlite3_step(stmt);
				if (m_code == SQLITE_DONE)
				{
					break;
				}

				buildJsonArray(stmt, colCount);
			}

			m_jsonBuilder.EndArray();
			sqlite3_reset(stmt);
		}

	private:
		int bindJsonValue(sqlite3_stmt *stmt, const rapidjson::Value& t, int index)
		{
			auto type = t.GetType();
			if (type == rapidjson::kNullType)
			{
				m_code = sqlite3_bind_null(stmt, index);
			}
			else if (type == rapidjson::kStringType)
			{
				m_code = sqlite3_bind_text(stmt, index, t.GetString(), -1, SQLITE_STATIC);
			}
			else if (type == rapidjson::kNumberType)
			{
				bindNumber(stmt, t, index);
			}
			else
			{
				throw std::invalid_argument("can not find this type.");
			}

			return m_code;
		}

		void bindNumber(sqlite3_stmt *stmt, const rapidjson::Value& t, int index)
		{
			if (t.IsInt() || t.IsUint())
				m_code = sqlite3_bind_int(stmt, index, t.GetInt());
			else if (t.IsInt64() || t.IsUint64())
				m_code = sqlite3_bind_int64(stmt, index, t.GetInt64());
			else
				m_code = sqlite3_bind_double(stmt, index, t.GetDouble());
		}

		//查询到json中
		void toUpper(char* s)
		{
			size_t len = strlen(s);
			for (size_t i = 0; i < len; i++)
			{
				s[i] = std::toupper(s[i]);
			}
		}

		void buildJsonArray(sqlite3_stmt *stmt, int colCount)
		{
			m_jsonBuilder.StartObject();

			for (int i = 0; i < colCount; ++i)
			{
				char* name = (char*) sqlite3_column_name(stmt, i);
				toUpper(name);

				m_jsonBuilder.String(name);  //写字段名
				buildJsonValue(stmt, i);
			}

			m_jsonBuilder.EndObject();
		}

		void buildJsonValue(sqlite3_stmt *stmt, int index)
		{
			int type = sqlite3_column_type(stmt, index);
			auto it = m_builderMap.find(type);
			if (it == m_builderMap.end())
				throw std::invalid_argument("can not find this type");

			it->second(stmt, index, m_jsonBuilder);
		}

		int& m_code;
		JsonBuilder m_jsonBuilder;  //写json串
		static std::unordered_map<int, std::function<void(sqlite3_stmt *stmt, int index, JsonBuilder&)>> m_builderMap;
	};

END_NAMESPACE

#endif