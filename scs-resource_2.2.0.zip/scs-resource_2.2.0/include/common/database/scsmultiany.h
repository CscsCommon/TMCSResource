/*
 * Created by J.W 2019/05/26
 */
#ifndef SCSMULTIANY_H
#define SCSMULTIANY_H
#include <kernel/scsnamespace.h>
#include <tuple>
#include <functional>
#include <typeindex>
#include <iostream>
#include <type_traits>

using namespace std;

BEGIN_NAMESPACE(Gemini)

template <typename T>
struct Function_Traits
	: public Function_Traits<decltype(&T::operator())>
{

};
// For generic types, directly use the result of the signature of its 'operator()'

template <typename ClassType, typename ReturnType, typename... Args>
struct Function_Traits<ReturnType(ClassType::*)(Args...) const>
	// we specialize for pointers to member function
{
	enum { arity = sizeof...(Args) };
	// arity is the number of arguments.

	typedef ReturnType result_type;

	template <size_t i>
	struct params
	{
		typedef typename std::tuple_element<i, std::tuple<Args...> >::type type;
		// the i-th argument is equivalent to the i-th tuple element of a tuple
		// composed of those arguments.
	};

	typedef std::function<ReturnType(Args...)> FunType;
	typedef std::tuple<Args...> ArgTupleType;
};

//获取最大的整数
template <size_t arg, size_t... rest>
struct IntegerMax;

template <size_t arg>
struct IntegerMax<arg> : std::integral_constant<size_t, arg>
{

};

//获取最大的align
template <size_t arg1, size_t arg2, size_t... rest>
struct IntegerMax<arg1, arg2, rest...> : std::integral_constant<size_t, arg1 >= arg2 ? IntegerMax<arg1, rest...>::value :
	IntegerMax<arg2, rest...>::value >
{

};

template<typename T, typename... Args>
struct MaxAlign : std::integral_constant<int,
	(std::alignment_of<T>::value >MaxAlign<Args...>::value ? std::alignment_of<T>::value : MaxAlign<Args...>::value) >
{};

template<typename T>
struct MaxAlign<T> : std::integral_constant<int, std::alignment_of<T>::value >{};

//是否包含某个类型
template < typename T, typename... List >
struct Contains : std::true_type {};

template < typename T, typename Head, typename... Rest >
struct Contains<T, Head, Rest...>
	: std::conditional< std::is_same<T, Head>::value, std::true_type, Contains<T,Rest... >> ::type{};

template < typename T >
struct Contains<T> : std::false_type{};

//获取第一个T的索引位置
// Forward
template<typename Type, typename... Types>
struct GetLeftSize;

// Declaration
template<typename Type, typename First, typename... Types>
struct GetLeftSize<Type, First, Types...> : GetLeftSize<Type, Types...>
{
};

// Specialized
template<typename Type, typename... Types>
struct GetLeftSize<Type, Type, Types...> : std::integral_constant<int, sizeof...(Types)>
{
	//static const int ID = sizeof...(Types);
};

template<typename Type>
struct GetLeftSize<Type> : std::integral_constant<int, -1>
{
	//static const int ID = -1;
};

template<typename T, typename... Types>
struct Index : std::integral_constant<int, sizeof...(Types) - GetLeftSize<T, Types...>::value - 1>{};

//根据索引获取索引位置的类型
// Forward declaration
template<int index, typename... Types>
struct IndexType;

// Declaration
template<int index, typename First, typename... Types>
struct IndexType<index, First, Types...> : IndexType<index - 1, Types...>
{
};

// Specialized
template<typename First, typename... Types>
struct IndexType<0, First, Types...>
{
	typedef First DataType;
};

template<typename... Args>
struct CscsAnyHelper;

template<typename T, typename... Args>
struct CscsAnyHelper<T, Args...> {
	inline static void Destroy(type_index id, void * data)
	{
		if (id == type_index(typeid(T)))
			reinterpret_cast<T*>(data)->~T();
		else
			CscsAnyHelper<Args...>::Destroy(id, data);
	}

	inline static void move(type_index old_t, void * old_v, void * new_v)
	{
		if (old_t == type_index(typeid(T)))
			new (new_v) T(std::move(*reinterpret_cast<T*>(old_v)));
		else
			CscsAnyHelper<Args...>::move(old_t, old_v, new_v);
	}

	inline static void copy(type_index old_t, const void * old_v, void * new_v)
	{
		if (old_t == type_index(typeid(T)))
			new (new_v) T(*reinterpret_cast<const T*>(old_v));
		else
			CscsAnyHelper<Args...>::copy(old_t, old_v, new_v);
	}
};

template<> struct CscsAnyHelper<>  {
	inline static void Destroy(type_index id, void * data) {  }
	inline static void move(type_index old_t, void * old_v, void * new_v) { }
	inline static void copy(type_index old_t, const void * old_v, void * new_v) { }
};

template<typename... Types>
class CscsMultiAny
{
	typedef CscsAnyHelper<Types...> Helper_t;

	enum
	{
		data_size = IntegerMax<sizeof(Types)...>::value,
		//align_size = IntegerMax<alignof(Types)...>::value
		align_size = MaxAlign<Types...>::value //ctp才有alignof, 为了兼容用此版本
	};
	using data_t = typename std::aligned_storage<data_size, align_size>::type;
public:
	template<int index>
	using IndexType = typename IndexType<index, Types...>::DataType;

	CscsMultiAny(void) :m_typeIndex(typeid(void))
	{
	}

	~CscsMultiAny()
	{
		Helper_t::Destroy(m_typeIndex, &m_data);
	}

	CscsMultiAny(CscsMultiAny<Types...>&& old) : m_typeIndex(old.m_typeIndex)
	{
		Helper_t::move(old.m_typeIndex, &old.m_data, &m_data);
	}

	CscsMultiAny(const CscsMultiAny<Types...>& old) : m_typeIndex(old.m_typeIndex)
	{
		Helper_t::copy(old.m_typeIndex, &old.m_data, &m_data);
	}

	CscsMultiAny& operator=(const CscsMultiAny<Types...>& old){
		m_typeIndex=old.m_typeIndex;
		Helper_t::copy(old.m_typeIndex, &old.m_data, &m_data);
		return *this;
	}

	template <class T,
	class = typename std::enable_if<Contains<typename std::remove_reference<T>::type, Types...>::value>::type>
		CscsMultiAny(T&& value) : m_typeIndex(typeid(void))
	{
			Helper_t::Destroy(m_typeIndex, &m_data);
			typedef typename std::remove_reference<T>::type U;
			new(&m_data) U(std::forward<T>(value));
			m_typeIndex = type_index(typeid(T));
	}

	template<typename T>
	bool is() const
	{
		return (m_typeIndex == type_index(typeid(T)));
	}

	bool empty() const
	{
		return m_typeIndex == type_index(typeid(void));
	}

	bool isNull()const{
		return (m_typeIndex == type_index(typeid(nullptr_t)));
	}

	type_index type() const
	{
		return m_typeIndex;
	}

	template<typename T>
	T& get()
	{
		if (!is<T>())
		{
			cout << typeid(T).name() << " is not defined. " << "current type is " <<
				m_typeIndex.name() << endl;
			throw std::bad_cast();
		}

		return *(T*) (&m_data);
	}

	template<typename T>
	int getIndexOf()
	{
		return Index<T, Types...>::value;
	}

	// template<typename F>
	// void visit(F&& f)
	// {
	// 	using T = typename Function_Traits<F>::params<0>::type;
	// 	if (is<T>())
	// 		f(get<T>());
	// }

	// template<typename F, typename... Rest>
	// void visit(F&& f, Rest&&... rest)
	// {
	// 	using T = typename Function_Traits<F>::params<0>::type;
	// 	if (is<T>())
	// 		visit(std::forward<F>(f));
	// 	else 
	// 		visit(std::forward<Rest>(rest)...);
	// }

	bool operator==(const CscsMultiAny& rhs) const
	{
		return m_typeIndex == rhs.m_typeIndex;
	}

	bool operator<(const CscsMultiAny& rhs) const
	{
		return m_typeIndex < rhs.m_typeIndex;
	}

private:
	data_t m_data;
	std::type_index m_typeIndex;//类型ID
};

END_NAMESPACE
#endif