#ifndef SCSABSTRACTDATAOPERATOR_H
#define SCSABSTRACTDATAOPERATOR_H
#include <kernel/scsdatasensorevent.h>
#include <kernel/scsobject.h>
#include <kernel/scsany.hpp>

BEGIN_NAMESPACE(Gemini)

class CscsByteArray;
class CscsAbstractDataOperator:public CscsObject{
	public:
		enum DataOperatorType{
			LocaleStorageFile,
			Memory,
			SqlLite,
			MySql,
			UserType=128,
			MaxType=255
		};

		CscsAbstractDataOperator(DataOperatorType type,CscsObject* parent=nullptr);
		virtual ~CscsAbstractDataOperator();

		inline DataOperatorType dataOperatorType()const{
			return opType;
		}

		virtual int castUIDFromStringKey(const std::string& key)=0;
		virtual std::string castStringKeyFromUID(int uid)=0;

		virtual void writeAsBool(int uid, bool value,
				CscsDataSensorEvent::DataMerge merge=CscsDataSensorEvent::Enable);

		virtual void writeAsInt(int uid, int value,
				CscsDataSensorEvent::DataMerge merge=CscsDataSensorEvent::Enable);

		virtual void writeAsDouble(int uid, double value,
				CscsDataSensorEvent::DataMerge merge=CscsDataSensorEvent::Enable);

		virtual void writeAsByteArray(int uid, const CscsByteArray& value,
				CscsDataSensorEvent::DataMerge merge=CscsDataSensorEvent::Enable);

		virtual void writeAsAny(int uid,const CscsVariant& value,CscsDataSensorEvent::SensorType type, CscsDataSensorEvent::DataMerge merge=CscsDataSensorEvent::Enable);

		virtual bool      readAsBool(int uid)const;
		virtual double    readAsDouble(int uid)const;
		virtual int    	  readAsInt(int uid)const;
		virtual CscsByteArray readAsByteArray(int uid)const;
		virtual CscsVariant   readAsAny(int uid)const;

		virtual void notify(int uid,CscsDataSensorEvent::DataMerge merge=CscsDataSensorEvent::Enable);


	private:
		DataOperatorType opType;
};

END_NAMESPACE

#endif