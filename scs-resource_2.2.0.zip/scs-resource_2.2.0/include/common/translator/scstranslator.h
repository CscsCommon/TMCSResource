#ifndef SCSTRANSLATOR_H
#define SCSTRANSLATOR_H
#include "kernel/scstypes.h"

BEGIN_NAMESPACE(Gemini)

class CscsParseTranslator;
class CscsParseLanString;
class CscsEncode;

class CscsTranslator{
public:
	explicit CscsTranslator(const std::string& script);
	~CscsTranslator();
	void setCurrentLanKey(const std::string& key);
	//设置阿拉伯语系标记
	void setArabics(bool arabics);
	bool isArabics()const;
	std::string currentLanKey()const;
	std::string value(const std::string key);

private:
	CscsParseTranslator* _translator;
	CscsParseLanString* _lanString;
	CscsEncode*	_encode;
	std::string _lanKey;
	bool _arabics;
};

END_NAMESPACE


#endif