#ifndef SCSPARSETRANSLATOR_H
#define SCSPARSETRANSLATOR_H
#include <kernel/rapidjson/writer.h>
#include <kernel/rapidjson/stringbuffer.h>
#include <kernel/rapidjson/document.h>
#include <kernel/scsnamespace.h>
#include <vector>
#include <map>
#include <unordered_map>


/*
 * 多国语言字串解析
 */
BEGIN_NAMESPACE(Gemini)

class CscsParseLanString;
typedef std::unordered_map<std::string,std::string> CscsLanMap;
typedef std::unordered_map<std::string, CscsParseLanString*> CscsLanMaps;

class CscsParseLanString{
public:
	CscsParseLanString();
	CscsParseLanString(const rapidjson::Value& val);
	~CscsParseLanString();
	void parse(const rapidjson::Value& val);
	std::string value(const std::string& lanKey)const;
	bool isValid()const;
private:
	CscsLanMap* _lanMap;
	bool _valid;
};

class CscsParseTranslator{
public:
	CscsParseTranslator();
	CscsParseTranslator(const std::string& filename);
	~CscsParseTranslator();
	void parse(const std::string& filename);
	CscsParseLanString* value(const std::string& strKey)const;
	bool isValid()const;
private:
	CscsLanMaps* _lanMaps;
	bool _valid;
};

END_NAMESPACE


#endif