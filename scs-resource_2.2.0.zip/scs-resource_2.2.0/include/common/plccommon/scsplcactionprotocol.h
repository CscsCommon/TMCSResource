#ifndef SCSPLCACTIONPROTOCOL_H
#define SCSPLCACTIONPROTOCOL_H
#include "scsplcprotocol.h"

/*
 * Created By J.Wong
 * 动作命令协议
 */
BEGIN_NAMESPACE(Gemini)

class CscsPlcActionProtocol:public CscsAbstractPlcCommonProtocol{
public:
	CscsPlcActionProtocol();
	virtual ~CscsPlcActionProtocol();
	int composeProtocol(CscsByteArray& out, const CscsByteArray& in, void* ex=nullptr);
	int parseProtocol(const CscsByteArray& in);

};
END_NAMESPACE
#endif