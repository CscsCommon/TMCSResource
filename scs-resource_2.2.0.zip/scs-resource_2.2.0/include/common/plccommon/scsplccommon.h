#ifndef SCSPLCCOMMON_H
#define SCSPLCCOMMON_H
#include <protocol/scsabstractcommsource.h>

/*
 * Created By J.Wong
 * PLC 通信主程
 */

BEGIN_NAMESPACE(Gemini)

class CscsParseTrigger;
class CscsParseMoldBlock;
class CscsPlcCommonPrivate;


class CscsPlcCommon:public CscsAbstractCommSource{
public:
	CscsPlcCommon(CscsObject* parent=nullptr);
	~CscsPlcCommon();

	//准备通信数据文件
	void setCommonFile(const std::string file);

	//读资料参数
	int  uploadParam(const std::vector<std::string>& ids);
	int  uploadParam(const std::string& id);
	int  uploadParam(const std::vector<uint>& ids);
	int  uploadParam(uint id);
	int  uploadParam(const CscsByteArray& data);
	


	//写资料参数
	int  downloadParam(const std::map<std::string,CscsVariant>& params);
	int  downloadParam(const std::string& id, const CscsVariant& value);
	int  downloadParam(const std::map<uint,CscsVariant>& params);
	int  downloadParam(uint id, const CscsVariant& value);
	int  downloadParam(const CscsByteArray& data);


	//写动作指令
	int  downloadAction(const std::vector<uint>& ids);
	int  downloadAction(uint id);
	int  downloadAction(const CscsByteArray& data);

	//下载触发器配置
	int  downloadTrigger(const CscsParseTrigger& trigger);

	//下载模组资料
	int  downloadMoldSet(const CscsParseMoldBlock& block);
	int	 downloadMoldSet();

	const std::vector<uint32>& moldIDList()const;
	//协议不完善,暂不实现
	//请求曲线
	//int	 uploadCurve(const CscsPlcCurveData& curve);
	
	//连线状态
	uint  lineStatus()const;
protected:
	void processReceive();
	void checkOnLine();
	void receiveData(const CscsByteArray& data);
	void sendData(const CscsByteArray& data);
	void prepareData(const CscsByteArray& data);
	void run();
private:
	CscsPlcCommonPrivate* data;
	//线程终止标记,清理线程资源
	bool terminate;
	
	int ID(const CscsByteArray& in);
	void checkLineStatus(int code);
	void checkMoldSet(int code);
	void checkMoldSetStatus(int code);
	void checkActual(int code);
	void checkTrigger(int code);
	void checkTriggerConfirm(int code);
	void checkAlarm(int code, uint8 msgType);
	void packMoldSetData();
	void requestMoldSetStatus();
	void requestActual();
	void requestTrigger();
	void requestTriggerConfirm(uint groupID);
	void requestAlarm(uint ID, uint8 msgType);

};

END_NAMESPACE
#endif