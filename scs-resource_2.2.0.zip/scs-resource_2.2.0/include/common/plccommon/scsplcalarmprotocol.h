#ifndef SCSPLCALARMPROTOCOL_H
#define SCSPLCALARMPROTOCOL_H
#include "scsplcprotocol.h"

/*
 * Created By J.Wong
 * 警报协议
 */
BEGIN_NAMESPACE(Gemini)

class CscsPlcAlarmProtocol:public CscsAbstractPlcCommonProtocol{
public:
	CscsPlcAlarmProtocol();
	virtual ~CscsPlcAlarmProtocol();
	int composeProtocol(CscsByteArray& out, const CscsByteArray& in, void* ex);
	int parseProtocol(const CscsByteArray& in);
};

END_NAMESPACE

#endif