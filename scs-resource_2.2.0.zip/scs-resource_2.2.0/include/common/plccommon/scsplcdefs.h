#ifndef SCSPLCDEFS_H
#define SCSPLCDEFS_H
#include <kernel/scstypes.h>
#include <kernel/scsnamespace.h>

BEGIN_NAMESPACE(Gemini)


#define		PLC_TYPE_UNKNOWN	0
#define		PLC_TYPE_CHAR		1
#define		PLC_TYPE_BYTE		2
#define		PLC_TYPE_SHORT		3
#define		PLC_TYPE_WORD		4
#define		PLC_TYPE_INT		5
#define		PLC_TYPE_DWORD		6
#define		PLC_TYPE_FLOAT		7
#define		PLC_TYPE_DOUBLE		8
#define		PLC_TYPE_BOOL		9

//即时请求资料和回复标识ID
const int PLC_REQ_ACTUAL_ID =1;
const int PLC_RES_ACTUAL_ID =1001;

//参数资料读写请求和回复ID
const int PLC_REQ_READPARAM_ID=2;
const int PLC_RES_READPARAM_ID=1002;
const int PLC_REQ_WRITEPARAM_ID=3;
const int PLC_RES_WRITEPARAM_ID=1003;

//警报资料请求和回复ID
const int PLC_REQ_ALARM_ID=2004;
const int PLC_RES_ALARM_ID=1004;

//曲线资料请求和回复ID
const int PLC_REQ_CURVE_ID=5;
const int PLC_RES_CURVE_ID=1005;

//动作命令请求和回复ID
const int PLC_REQ_ACTION_ID=6;
const int PLC_RES_ACTION_ID=1006;
	//ACTION CMD ID
	const int PLC_DRIVER_ENABLE=0x00000001;
	const int PLC_DRIVER_STOP=0x00000002;
	const int PLC_DRIVER_CLS_ALARM=0x00000003;
	const int PLC_DRIVER_AUTO_ZERO=0x00000004;
	const int PLC_DRIVER_SAVE_E2PROM=0x00000005;
	const int PLC_DRIVER_READ_E2PROM=0x00000006;
	const int PLC_DRIVER_DB_RESET=0x00000007;
	const int PLC_DRIVER_TEST=0x00000008;
	const int PLC_DRIVER_AUTO_PID=0x00000009;
	const int PLC_DRIVER_BUARD_DRAW=0x0000000A;
	const int PLC_DRIVER_AD_CURRENT_ADJ=0x0000000B;
	const int PLC_DRIVER_AD_VOL_ADJ=0x0000000C;
	const int PLC_DRIVER_AD_COMM_GAIN_ADJ=0x0000000D;
	const int PLC_DRIVER_LIMIT_GAIN_ADJ=0x0000000E;
	const int PLC_DRIVER_PRESSURE_GAIN_ADJ=0x0000000F;
	const int PLC_DRIVER_HARDWARE_TEST_ENABLE=0x00000010;
	const int PLC_DRIVER_HARDWARE_TEST_STOP=0x00000011;
	const int PLC_DRIVER_BURN=0x00000012;


	//ACTION CMD  ECHO (SUCESS CODE)
	const int PLC_DRIVER_ENABLE_ECHO=0x80000001;
	const int PLC_DRIVER_STOP_ECHO=0x80000002;
	const int PLC_DRIVER_CLS_ALARM_ECHO=0x80000003;
	const int PLC_DRIVER_AUTO_ZERO_ECHO=0x80000004;
	const int PLC_DRIVER_SAVE_E2PROM_ECHO=0x80000005;
	const int PLC_DRIVER_READ_E2PROM_ECHO=0x80000006;
	const int PLC_DRIVER_DB_RESET_ECHO=0x80000007;
	const int PLC_DRIVER_TEST_ECHO=0x80000008;
	const int PLC_DRIVER_AUTO_PID_ECHO=0x80000009;
	const int PLC_DRIVER_BUARD_DRAW_ECHO=0x8000000A;
	const int PLC_DRIVER_AD_CURRENT_ADJ_ECHO=0x8000000B;
	const int PLC_DRIVER_AD_VOL_ADJ_ECHO=0x8000000C;
	const int PLC_DRIVER_AD_COMM_GAIN_ADJ_ECHO=0x8000000D;
	const int PLC_DRIVER_LIMIT_GAIN_ADJ_ECHO=0x8000000E;
	const int PLC_DRIVER_PRESSURE_GAIN_ADJ_ECHO=0x8000000F;
	const int PLC_DRIVER_HARDWARE_TEST_ENABLE_ECHO=0x80000010;
	const int PLC_DRIVER_HARDWARE_TEST_STOP_ECHO=0x80000011;
	const int PLC_DRIVER_BURN_ECHO=0x80000012;
//连线状态请求和回复标识ID
const int PLC_REQ_ONLINE_ID=7;
const int PLC_RES_ONLINE_ID=1007;

//模具资料设定状态请求和回复标识ID
const int PLC_REQ_MOLDSETSTATUS_ID=8;
const int PLC_RES_MOLDSETSTATUS_ID=1008;

//模具资料设定请求和回复标识ID
const int PLC_REQ_MOLDSET_ID=9;
const int PLC_RES_MOLDSET_ID=1009;


//CAN通信资料转发读写请求和回复ID
const int PLC_CAN_REQ_TRANSMIT_ELECTRIC_ID=15;
const int PLC_CAN_REQ_TRANSMIT_OTHERDEV_ID=16;
const int PLC_CAN_RES_TRANSMIT_ELECTRIC_ID=1015;
const int PLC_CAN_RES_TRANSMIT_OTHERDEV_ID=1016;

	//参数资料读请求
	const int PLC_CAN_REQ_READ_DATA=1;
	//参数资料写请求
	const int PLC_CAN_REQ_WRITE_DATA=2;
	//即时资料请求
	const int PLC_CAN_REQ_ACTUAL_DATA=3; 
	//PDO资料请求
	const int PLC_CAN_REQ_PDO_DATA=4;

	//参数资料读请求
	const int PLC_CAN_RES_READ_DATA=1001;
	//参数资料写请求
	const int PLC_CAN_RES_WRITE_DATA=1002;
	//即时资料请求
	const int PLC_CAN_RES_ACTION_DATA=1003; 
	//PDO资料请求
	const int PLC_CAN_RES_PDO_DATA=1004;
	

//分组触发器资料请求和回复标识ID
const int PLC_REQ_TRIGGER_ID =17;
const int PLC_RES_TRIGGER_ID=1017;

//分组触发器资料确认请求和回复标识ID
const int PLC_REQ_TRIGGER_CONFIRM_ID=2018;
const int PLC_RES_TRIGGER_CONFIRM_ID=1018;

//触发器触发类型
const int PLC_TRIGGER_TYPE_CLEAR=0;
const int PLC_TRIGGER_TYPE_SYNCDATA=1;
const int PLC_TRIGGER_TYPE_TIMER=2;
const int PLC_TRIGGER_TYPE_RISING=3;
const int PLC_TRIGGER_TYPE_FALLING=4;
const int PLC_TRIGGER_TYPE_DOUBLE_EDGE=5;



//版本错误
const int PLC_PROTOCOL_VER_ERROR =0xffff;

//首次连线
const int PLC_PROTOCOL_FIRST_ONLINE =0x01;

//mold set资料同步
const int PLC_PROTOCOL_MOLDSET_SYNCING=0x02;

//连线成功
const int PLC_PROTOCOL_ONLINE_OK=0x03;


//协议固定信息
//协议头固定大小
const int PLC_COMMON_HEADER_SIZE=12;
const int PLC_COMMON_TRIGGER_HEADER_SIZE=8;
//协议尾固定大小
const int PLC_COMMON_FOOTER_SIZE=2;
//协议头标识
const int PLC_COMMON_HEADER_CONTEXT=0x8899;
//协议尾标识
const int PLC_COMMON_FOOTER_CONTEXT=0x6688;

//回复协议头标识
const int PLC_COMMON_ECHO_HEADER_CONTEXT=0x5588;

const int PLC_COMMON_CURVE_ID_MAXCOUNT=4;
//曲线协议请求数据结构
typedef struct tagCscsPlcCurveData
{
	uint16 _wCycleTime;
	uint16 _IDCount;
	uint _ID[PLC_COMMON_CURVE_ID_MAXCOUNT];
}CscsPlcCurveData;

END_NAMESPACE

#endif