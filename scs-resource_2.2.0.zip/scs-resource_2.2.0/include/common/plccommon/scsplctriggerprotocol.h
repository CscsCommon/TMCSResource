#ifndef SCSPLCTRIGGERPROTOCOL_H
#define SCSPLCTRIGGERPROTOCOL_H
#include "scsplcprotocol.h"

/*
 * Created By J.Wong
 * 触发器资料配置协议
 */
BEGIN_NAMESPACE(Gemini)

class CscsParseTriggerFeature;
class CscsPlcTriggerProtocol:public CscsAbstractPlcTriggerProtocol{
public:
	CscsPlcTriggerProtocol();
	virtual ~CscsPlcTriggerProtocol();

	int composeProtocol(CscsByteArray& out, const CscsByteArray& in,void* ex=nullptr);
	int parseProtocol(const CscsByteArray& data);

private:
	int composeTriggerFeature(void* out, CscsParseTriggerFeature* feature);

};

END_NAMESPACE
#endif