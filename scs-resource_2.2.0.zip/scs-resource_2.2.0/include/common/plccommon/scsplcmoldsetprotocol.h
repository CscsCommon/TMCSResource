#ifndef SCSPLCMOLDSETPROTOCOL_H
#define SCSPLCMOLDSETPROTOCOL_H
#include "scsplcprotocol.h"

/*
 * Created By J.Wong
 * 模组资料更新协议
 */
BEGIN_NAMESPACE(Gemini)

class CscsPlcMoldSetProtocol:public CscsAbstractPlcCommonProtocol{
public:
	CscsPlcMoldSetProtocol();
	virtual ~CscsPlcMoldSetProtocol();

	int composeProtocol(CscsByteArray& out, const CscsByteArray& in, void* ex=nullptr);
	int parseProtocol(const CscsByteArray& in);
};
END_NAMESPACE

#endif