#ifndef SCSPLCWRITEPARAMPROTOCOL_H
#define SCSPLCWRITEPARAMPROTOCOL_H
#include "scsplcprotocol.h"

BEGIN_NAMESPACE(Gemini)
class CscsPlcWriteParamProtocol:public CscsAbstractPlcCommonProtocol{
public:
	CscsPlcWriteParamProtocol();
	virtual ~CscsPlcWriteParamProtocol();

	int composeProtocol(CscsByteArray& out, const CscsByteArray& in, void* ex=nullptr);
	int parseProtocol(const CscsByteArray& in);

protected:
	int writeToDataBase(const CscsByteArray& data);	
};
END_NAMESPACE
#endif