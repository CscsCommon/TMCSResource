#ifndef SCSCUSTOMWIDGETSINFO_H
#define SCSCUSTOMWIDGETSINFO_H
#include "scstreewalker.h"
#include <kernel/scsstringlist.h>
#include <kernel/scsmap.h>

BEGIN_NAMESPACE(Gemini)

class CscsUIDriver;

class CscsCustomWidgetsInfo : public CscsTreeWalker
{
public:
    CscsCustomWidgetsInfo(CscsUIDriver *driver);

    void acceptUI(CscsDomUI *node);

    void acceptCustomWidgets(CscsDomCustomWidgets *node);
    void acceptCustomWidget(CscsDomCustomWidget *node);

    inline CscsStringList customWidgets() const
    { return m_customWidgets.keys(); }

    inline bool hasCustomWidget(const CscsString &name) const
    { return m_customWidgets.contains(name); }

    inline CscsDomCustomWidget *customWidget(const CscsString &name) const
    { return m_customWidgets.value(name); }

    CscsString realClassName(const CscsString &className) const;

    bool extends(const CscsString &className, const CscsString &baseClassName) const;

private:
    CscsUIDriver *driver;
    CscsMap<CscsString, CscsDomCustomWidget*> m_customWidgets;
};

END_NAMESPACE

#endif