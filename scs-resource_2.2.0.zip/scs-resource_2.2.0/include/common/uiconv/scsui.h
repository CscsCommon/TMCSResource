#ifndef SCSUI_H
#define SCSUI_H
#include <kernel/scslist.h>
#include <kernel/scsstring.h>
#include <kernel/scsstringlist.h>

BEGIN_NAMESPACE(Gemini)

class CscsDomDocument;
class CscsDomElement;
class CscsDomUI;
class CscsDomIncludes;
class CscsDomInclude;
class CscsDomResources;
class CscsDomResource;
class CscsActionGroup;
class CscsDomAction;
class CscsDomActionRef;
class CscsDomImages;
class CscsDomImage;
class CscsDomImageData;
class CscsDomCustomWidgets;
class CscsDomCustomWidget;
class CscsDomHeader;
class CscsDomProperties;
class CscsDomPropertyData;
class CscsDomSizePolicyData;
class CscsDomLayoutDefault;
class CscsDomLayoutFunction;
class CscsDomTabStops;
class CscsDomLayout;
class CscsDomLayoutItem;
class CscsDomRow;
class CscsDomColumn;
class CscsDomItem;
class CscsDomWidget;
class CscsDomSpacer;
class CscsDomColorRole;
class CscsDomColor;
class CscsDomColorGroup;
class CscsDomPalette;
class CscsDomFont;
class CscsDomPoint;
class CscsDomRect;
class CscsDomSizePolicy;
class CscsDomSize;
class CscsDomDate;
class CscsDomTime;
class CscsDomDateTime;
class CscsDomStringList;
class CscsDomResourcePixmap;
class CscsDomString;
class CscsDomProperty;
class CscsDomConnections;
class CscsDomConnection;
class CscsDomConnectionHints;
class CscsDomConnectionHint;
class CscsDomResourceIcon;


class CscsDomUI{
public:
	CscsDomUI();
	~CscsDomUI();

	void read(const CscsDomElement& node);
	CscsDomElement write(CscsDomDocument& doc, const CscsString& tagName=CscsString());
	inline CscsString text()const{return m_text;}
	inline void setText(const CscsString& s){ m_text=s;}
	inline bool hasAttributeVersion(){
		return m_has_attr_version;
	}
	inline CscsString attributeVersion(){
		return m_attr_version;
	}
	inline void setAttributeVersion(const CscsString& a){
		m_attr_version=a;
		m_has_attr_version=true;
	}
	inline void clearAttributeVersion(){
		m_has_attr_version=false;
	}

	inline bool hasAttributeStdSetDef(){
		return m_has_attr_stdSetDef;
	}
	inline int attributeStdSetDef(){
		return m_attr_stdSetDef;
	}
	inline void setAttributeStdSetDef(int a){
		m_attr_stdSetDef=a;
		m_has_attr_stdSetDef=true;
	}

	inline void clearAttributeStdSetDef(){
		m_has_attr_stdSetDef=false;
	}

	inline CscsString elementAuthor(){
		return m_author;
	}
	void setElementAuthor(const CscsString& a);
	inline CscsString elementComment(){
		return m_comment;
	}
	void setElementComment(const CscsString& a);

	inline CscsString elementExportMacro(){
		return m_exportMacro;
	}
	void setElementExportMacro(const CscsString& a);

	inline CscsString elementClass(){
		return m_class;
	}
	void setElementClass(const CscsString& a);

	inline CscsDomWidget* elementWidget(){
		return m_widget;
	}
	void setElementWidget(CscsDomWidget* a);


	inline CscsDomLayoutDefault* elementLayoutDefault(){
		return m_layoutDefault;
	}
	void setElementLayoutDefault(CscsDomLayoutDefault* a);

	inline CscsDomLayoutFunction* elementLayoutFunction(){
		return m_layoutFunction;
	}
	void setElementLayoutFunction(CscsDomLayoutFunction* a);

	inline CscsString elementPixmapFunction(){
		return m_pixmapFunction;
	}
	void setElementPixmapFunction(const CscsString& a);

	inline CscsDomCustomWidgets* elementCustomWidgets(){
		return m_customWidgets;
	}
	void setElementCustomWidgets(CscsDomCustomWidgets* a);

	inline CscsDomTabStops* elementTabStops(){
		return m_tabStops;
	}
	void setElementTabStops(CscsDomTabStops* a);

	inline CscsDomImages* elementImages(){
		return m_images;
	}
	void setElementImages(CscsDomImages* a);

	inline CscsDomIncludes* elementIncludes(){
		return m_includes;
	}
	void setElementIncludes(CscsDomIncludes* a);

	inline CscsDomResources* elementResources(){
		return m_resources;
	}
	void setElementResources(CscsDomResources* a);

	inline CscsDomConnections* elementConnections(){
		return m_connections;
	}
	void setElementConnections(CscsDomConnections* a);

private:
	CscsString m_text;
	void clear(bool clear_all=true);

	CscsString m_attr_version;
	bool m_has_attr_version;

	int m_attr_stdSetDef;
	bool m_has_attr_stdSetDef;

	CscsString m_author;
	CscsString m_comment;
	CscsString m_exportMacro;
	CscsString m_class;
	CscsDomWidget* m_widget;
	CscsDomLayoutDefault* m_layoutDefault;
	CscsDomLayoutFunction* m_layoutFunction;
	CscsString m_pixmapFunction;
	CscsDomCustomWidgets* m_customWidgets;
	CscsDomTabStops* m_tabStops;
	CscsDomImages* m_images;
	CscsDomIncludes* m_includes;
	CscsDomResources* m_resources;
	CscsDomConnections* m_connections;

	CscsDomUI(const CscsDomUI& o);
	void operator=(const CscsDomUI& o);
};

class CscsDomIncludes{
public:
	CscsDomIncludes();
	~CscsDomIncludes();

	void read(const CscsDomElement& node);
	CscsDomElement write(CscsDomDocument& doc, const CscsString& tagName=CscsString());
	inline CscsString text()const{
		return m_text;
	}
	inline void setText(const CscsString& s){
		m_text=s;
	}

	inline CscsList<CscsDomInclude*> elementInclude(){
		return m_includes;
	}
	void setElementInclude(const CscsList<CscsDomInclude*>& a);

private:
	CscsString m_text;
	void clear(bool clear_all=true);
	CscsList<CscsDomInclude*> m_includes;
	CscsDomIncludes(const CscsDomIncludes& o);
	void operator=(const CscsDomIncludes& o);
};

class CscsDomInclude{
public:
	CscsDomInclude();
	~CscsDomInclude();
	void read(const CscsDomElement& node);
	CscsDomElement write(CscsDomDocument& doc, const CscsString& tagName=CscsString());
	inline CscsString text()const{
		return m_text;
	}
	inline void setText(const CscsString& s){
		m_text=s;
	}

	inline bool hasAttributeLocation(){
		return m_has_attr_location;
	}

	inline CscsString attributeLocation(){
		return m_attr_location;
	}
	inline void setAttributeLocation(const CscsString& a){
		m_attr_location=a;
		m_has_attr_location=true;
	}
	inline void clearAttributeLocation(){
		m_has_attr_location=false;
	}
	inline bool hasAttributeImpldecl(){
		return m_has_attr_impldecl;
	}
	inline CscsString attributeImpldecl(){
		return m_attr_impldecl;
	}
	inline void setAttributeImpldecl(const CscsString& a){
		m_attr_impldecl=a;
		m_has_attr_impldecl=true;
	}
	inline void clearAttributeImpldecl(){
		m_has_attr_impldecl=false;
	}

private:
	CscsString m_text;
	void clear(bool clear_all=true);
	CscsString m_attr_location;
	bool m_has_attr_location;
    CscsString m_attr_impldecl;
    bool m_has_attr_impldecl;
	CscsDomInclude(const CscsDomInclude& o);
	void operator=(const CscsDomInclude& o);
};

class CscsDomResources{
public:
	CscsDomResources();
	~CscsDomResources();
	void read(const CscsDomElement& node);
	CscsDomElement write(CscsDomDocument& doc, const CscsString& tagName=CscsString());
	inline CscsString text()const{
		return m_text;
	}
	inline void setText(const CscsString& s){
		m_text=s;
	}

	inline bool hasAttributeName(){
		return m_has_attr_name;
	}
	inline CscsString attributeName(){
		return m_attr_name;
	}
	inline void setAttributeName(const CscsString& a){
		m_attr_name=a;
		m_has_attr_name=true;
	}
	inline void clearAttributeName(){
		m_has_attr_name=false;
	}

	inline CscsList<CscsDomResource*> elementInclude(){
		return m_include;
	}
	void setElementInclude(const CscsList<CscsDomResource*>& a);

private:
	CscsString m_text;
	void clear(bool clear_all=true);

	CscsString m_attr_name;
	bool m_has_attr_name;

	CscsList<CscsDomResource*> m_include;

	CscsDomResources(const CscsDomResources& o);
	void operator=(const CscsDomResources& o);
};

class CscsDomResource{
public:
	CscsDomResource();
	~CscsDomResource();

	void read(const CscsDomElement& node);
	CscsDomElement write(CscsDomDocument& doc, const CscsString& tagName=CscsString());
	inline CscsString text()const{
		return m_text;
	}
	inline void setText(const CscsString& s){
		m_text=s;
	}
	inline bool hasAttributeLocation(){
		return m_has_attr_location;
	}
	inline CscsString attributeLocation(){
		return m_attr_location;
	}
	inline void setAttributeLocation(const CscsString& a){
		m_attr_location=a;
		m_has_attr_location=true;
	}
	inline void clearAttributeLocation(){
		m_has_attr_location=false;
	}

private:
	CscsString m_text;
	void clear(bool clear_all=true);
	CscsString m_attr_location;
	bool m_has_attr_location;
	CscsDomResource(const CscsDomResource& o);
	void operator=(const CscsDomResource& o);
};

class CscsDomActionGroup{
public:
	CscsDomActionGroup();
	~CscsDomActionGroup();

	void read(const CscsDomElement& node);
	CscsDomElement write(CscsDomDocument& doc, const CscsString& tagName=CscsString());
	inline CscsString text()const{
		return m_text;
	}
	inline void setText(const CscsString& s){
		m_text=s;
	}

	inline bool hasAttributeName(){
		return m_has_attr_name;
	}
	inline CscsString attributeName(){
		return m_attr_name;
	}
	inline void setAttributeName(const CscsString& a){
		m_attr_name=a;
		m_has_attr_name=true;
	}
	inline void clearAttributeName(){
		m_has_attr_name=false;
	}

	inline CscsList<CscsDomAction*> elementAction(){
		return m_action;
	}
	void setElementAction(const CscsList<CscsDomAction*>& a);
	inline CscsList<CscsDomActionGroup*> elementActionGroup(){
		return m_actionGroup;
	}
	void setElementActionGroup(const CscsList<CscsDomActionGroup*>& a);

	inline CscsList<CscsDomProperty*> elementProperty(){
		return m_property;
	}
	void setElementProperty(const CscsList<CscsDomProperty*>& a);

	inline CscsList<CscsDomProperty*> elementAttribute(){
		return m_attribute;
	}

	void setElementAttribute(const CscsList<CscsDomProperty*>& a);

private:
	CscsString m_text;
	void clear(bool clear_all=true);

	CscsString m_attr_name;
	bool m_has_attr_name;

	CscsList<CscsDomAction*> m_action;
	CscsList<CscsDomActionGroup*> m_actionGroup;
	CscsList<CscsDomProperty*> m_property;
	CscsList<CscsDomProperty*> m_attribute;
};

class CscsDomAction{
public:
	CscsDomAction();
	~CscsDomAction();

	void read(const CscsDomElement& node);
	CscsDomElement write(CscsDomDocument& doc, const CscsString& tagName=CscsString());
	inline CscsString text()const{
		return m_text;
	}
	inline void setText(const CscsString& s){
		m_text=s;
	}

	inline bool hasAttributeName(){
		return m_has_attr_name;
	}
	inline CscsString attributeName(){
		return m_attr_name;
	}
	inline void setAttributeName(const CscsString& a){
		m_attr_name=a;
		m_has_attr_name=true;
	}
	inline void clearAttributeName(){
		 m_has_attr_name=false;
	}

	inline bool hasAttributeMenu(){
		return m_has_attr_menu;
	}
	inline CscsString attributeMenu(){
		return m_attr_menu;
	}
	inline void setAttributeMenu(const CscsString& a){
		m_attr_menu=a;
		m_has_attr_menu=true;
	}
	inline void clearAttributeMenu(){
		m_has_attr_menu=false;
	}

	inline CscsList<CscsDomProperty*> elementProperty(){
		return m_property;
	}
	void setElementProperty(const CscsList<CscsDomProperty*>& a);

	inline CscsList<CscsDomProperty*> elementAttribute(){
		return m_attribute;
	}
	void setElementAttribute(const CscsList<CscsDomProperty*>& a);

private:
	CscsString m_text;
	void clear(bool clear_all=true);

	CscsString m_attr_name;
	bool m_has_attr_name;

	CscsString m_attr_menu;
	bool m_has_attr_menu;

	CscsList<CscsDomProperty*> m_property;
	CscsList<CscsDomProperty*> m_attribute;

	CscsDomAction(const CscsDomAction& o);
	void operator=(const CscsDomAction& o);
};

class CscsDomActionRef{
public:
	CscsDomActionRef();
	~CscsDomActionRef();

	void read(const CscsDomElement& node);
	CscsDomElement write(CscsDomDocument& doc, const CscsString& tagName=CscsString());
	inline CscsString text()const{
		return m_text;
	}
	inline void setText(const CscsString& s){
		m_text=s;
	}

	inline bool hasAttributeName(){
		return m_has_attr_name;
	}
	inline CscsString attributeName(){
		return m_attr_name;
	}
	inline void setAttributeName(const CscsString& a){
		m_attr_name=a;
		m_has_attr_name=true;
	}
	inline void clearAttributeName(){
		m_has_attr_name=false;
	}

private:
	CscsString m_text;
	void clear(bool clear_all=true);

	CscsString m_attr_name;
	bool m_has_attr_name;

	CscsDomActionRef(const CscsDomActionRef& o);
	void operator=(const CscsDomActionRef& o);
};

class CscsDomImages{
public:
	CscsDomImages();
	~CscsDomImages();

	void read(const CscsDomElement& node);
	CscsDomElement write(CscsDomDocument& doc, const CscsString& tagName=CscsString());

	inline CscsString text()const{
		return m_text;
	}
	inline void setText(const CscsString& s){
		m_text=s;
	}

	inline CscsList<CscsDomImage*> elementImage(){
		return m_image;
	}

	void setElementImage(const CscsList<CscsDomImage*>& a);

private:
	CscsString m_text;
	void clear(bool clear_all=true);

	CscsList<CscsDomImage*> m_image;
	CscsDomImages(const CscsDomImages& o);
	void operator=(const CscsDomImages& o);
};

class CscsDomImage{
public:
	CscsDomImage();
	~CscsDomImage();

	void read(CscsDomElement& node);
	CscsDomElement write(CscsDomDocument& doc, const CscsString& tagName=CscsString());
	inline CscsString text()const{
		return m_text;
	}
	inline void setText(const CscsString& s){
		m_text=s;
	}

	inline bool hasAttributeName(){
		return m_has_attr_name;
	}
	inline CscsString attributeName(){
		return m_attr_name;
	}
	inline void setAttributeName(const CscsString& a){
		m_attr_name=a;
		m_has_attr_name=true;
	}
	inline void clearAttributeName(){
		m_has_attr_name=false;
	}

	inline CscsDomImageData* elementData(){
		return m_data;
	}
	void setElementData(CscsDomImageData* a);

private:
	CscsString m_text;
	void clear(bool clear_all=true);
	CscsString m_attr_name;
	bool m_has_attr_name;
	CscsDomImageData* m_data;
	CscsDomImage(const CscsDomImage& o);
	void operator=(const CscsDomImage& o);
};

class CscsDomImageData{
public:
	CscsDomImageData();
	~CscsDomImageData();

	void read(const CscsDomElement& node);
	CscsDomElement write(CscsDomDocument& doc, const CscsString& tagName=CscsString());
	inline CscsString text()const{
		return m_text;
	}
	inline void setText(const CscsString& s){
		m_text=s;
	}

	inline bool hasAttributeFormat(){
		return m_has_attr_format;
	}

	inline CscsString attributeFormat(){
		return m_attr_format;
	}

	inline void setAttributeFormat(const CscsString& a){
		m_attr_format=a;
		m_has_attr_format=true;
	}

	inline void clearAttributeFormat(){
		m_has_attr_format=false;
	}

	inline bool hasAttributeLength(){
		return m_has_attr_length;
	}
	inline int attributeLength(){
		return m_attr_length;
	}

	inline void setAttributeLength(int a){
		m_attr_length=a;
		m_has_attr_length=true;
	}
	inline void clearAttributeLength(){
		m_has_attr_length=false;
	}

private:
	CscsString m_text;
	void clear(bool clear_all=true);

	CscsString m_attr_format;
	bool m_has_attr_format;

	int m_attr_length;
	bool m_has_attr_length;

	CscsDomImageData(const CscsDomImageData& o);
	void operator=(const CscsDomImageData& o);
};

class CscsDomCustomWidgets{
public:
	CscsDomCustomWidgets();
	~CscsDomCustomWidgets();

	void read(const CscsDomElement& node);
	CscsDomElement write(CscsDomDocument& doc, const CscsString& tagName=CscsString());
	inline CscsString text()const{
		return m_text;
	}
	inline void setText(const CscsString& s){
		m_text=s;
	}

	inline CscsList<CscsDomCustomWidget*> elementCustomWidgets(){
		return m_customWidget;
	}
	void setElementCustomWidget(const CscsList<CscsDomCustomWidget*>& a);

private:
	CscsString m_text;
	void clear(bool clear_all=true);

	CscsList<CscsDomCustomWidget*> m_customWidget;
	CscsDomCustomWidgets(const CscsDomCustomWidgets& o);
	void operator=(const CscsDomCustomWidgets& o);
};

class CscsDomHeader{
public:
	CscsDomHeader();
	~CscsDomHeader();

	void read(const CscsDomElement& node);
	CscsDomElement write(CscsDomDocument& doc, const CscsString& tagName=CscsString());
	inline CscsString text()const{
		return m_text;
	}
	inline void setText(const CscsString& s){
		m_text=s;
	}

	inline bool hasAttributeLocation(){
		return m_has_attr_location;
	}
	inline CscsString attributeLocation(){
		return m_attr_location;
	}
	inline void setAttributeLocation(const CscsString& a){
		m_attr_location=a;
		m_has_attr_location=true;
	}
	inline void clearAttributeLocation(){
		m_has_attr_location=false;
	}

private:
	CscsString m_text;
	void clear(bool clear_all=true);

	CscsString m_attr_location;
	bool m_has_attr_location;

	CscsDomHeader(const CscsDomHeader& o);
	void operator=(const CscsDomHeader& o);
};

class CscsDomCustomWidget{
public:
	CscsDomCustomWidget();
	~CscsDomCustomWidget();

	void read(const CscsDomElement& node);
	CscsDomElement write(CscsDomDocument& doc, const CscsString& tagName=CscsString());
	inline CscsString text()const{
		return m_text;
	}
	inline void setText(const CscsString& s){
		m_text=s;
	}

	inline CscsString elementClass(){
		return m_class;
	}
	void setElementClass(const CscsString& a);

	inline CscsString elementExtends(){
		return m_extends;
	}
	void setElementExtends(const CscsString& a);

	inline CscsDomHeader* elementHeader(){
		return m_header;
	}
	void setElementHeader(CscsDomHeader* a);
	inline CscsDomSize* elementSizeHint(){
		return m_sizeHint;
	}
	void setElementSizeHint(CscsDomSize* a);

	inline int elementContainer(){
		return m_container;
	}
	void setElementContainer(int a);

	inline CscsDomSizePolicyData* elementSizePolicy(){
		return m_sizePolicy;
	}
    void setElementSizePolicy(CscsDomSizePolicyData* a);

	inline CscsString elementPixmap(){
		return m_pixmap;
	}
	void setElementPixmap(const CscsString& a);
	inline CscsDomProperties* elementProperties(){
		return m_properties;
	}
	void setElementProperties(CscsDomProperties* a);

private:
	CscsString m_text;
	void clear(bool clear_all=true);

	CscsString m_class;
	CscsString m_extends;
	CscsDomHeader* m_header;
	CscsDomSize* m_sizeHint;
	int m_container;
	CscsDomSizePolicyData* m_sizePolicy;
	CscsString m_pixmap;
	CscsDomProperties* m_properties;

	CscsDomCustomWidget(const CscsDomCustomWidget& o);
	void operator=(const CscsDomCustomWidget& o);

};

class CscsDomProperties{
public:
	CscsDomProperties();
	~CscsDomProperties();

	void read(const CscsDomElement& node);
	CscsDomElement write(CscsDomDocument& doc, const CscsString& tagName=CscsString());
	inline CscsString text()const{
		return m_text;
	}
	inline void setText(const CscsString& s){
		m_text=s;
	}

	inline CscsList<CscsDomPropertyData*> elementProperty(){
		return m_property;
	}
	void setElementProperty(const CscsList<CscsDomPropertyData*>& a);
private:
	CscsString m_text;
	void clear(bool clear_all=true);

	CscsList<CscsDomPropertyData*> m_property;
	CscsDomProperties(const CscsDomProperties& o);
	void operator=(const CscsDomProperties& o);
};

class CscsDomPropertyData{
public:
	CscsDomPropertyData();
	~CscsDomPropertyData();

	void read(const CscsDomElement& node);
	CscsDomElement write(CscsDomDocument& doc, const CscsString& tagName=CscsString());
	inline CscsString text()const{
		return m_text;
	}
	inline void setText(const CscsString& s){
		m_text=s;
	}

	inline bool hasAttributeType(){
		return m_has_attr_type;
	}
	inline CscsString attributeType(){
		return m_attr_type;
	}

	inline void setAttributeType(const CscsString& a){
		m_attr_type=a;
		m_has_attr_type=true;
	}
	inline void clearAttributeType(){
		m_has_attr_type=false;
	}

private:
	CscsString m_text;
	void clear(bool clear_all=true);

	CscsString m_attr_type;
	bool m_has_attr_type;

	CscsDomPropertyData(const CscsDomPropertyData& o);
	void operator=(const CscsDomPropertyData& o);
};

class CscsDomSizePolicyData {
public:
    CscsDomSizePolicyData();
    ~CscsDomSizePolicyData();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    // child element accessors
    inline int elementHorData() { return m_horData; }
    void setElementHorData(int a);

    inline int elementVerData() { return m_verData; }
    void setElementVerData(int a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    // child element data
    int m_horData;
    int m_verData;

    CscsDomSizePolicyData(const CscsDomSizePolicyData& other);
    void operator = (const CscsDomSizePolicyData& other);
};

class  CscsDomLayoutDefault {
public:
    CscsDomLayoutDefault();
    ~CscsDomLayoutDefault();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    inline bool hasAttributeSpacing() { return m_has_attr_spacing; }
    inline int attributeSpacing() { return m_attr_spacing; }
    inline void setAttributeSpacing(int a) { m_attr_spacing = a; m_has_attr_spacing = true; }
    inline void clearAttributeSpacing() { m_has_attr_spacing = false; }

    inline bool hasAttributeMargin() { return m_has_attr_margin; }
    inline int attributeMargin() { return m_attr_margin; }
    inline void setAttributeMargin(int a) { m_attr_margin = a; m_has_attr_margin = true; }
    inline void clearAttributeMargin() { m_has_attr_margin = false; }

    // child element accessors
private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    int m_attr_spacing;
    bool m_has_attr_spacing;

    int m_attr_margin;
    bool m_has_attr_margin;

    // child element data

    CscsDomLayoutDefault(const CscsDomLayoutDefault& other);
    void operator = (const CscsDomLayoutDefault& other);
};

class  CscsDomLayoutFunction {
public:
    CscsDomLayoutFunction();
    ~CscsDomLayoutFunction();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    inline bool hasAttributeSpacing() { return m_has_attr_spacing; }
    inline CscsString attributeSpacing() { return m_attr_spacing; }
    inline void setAttributeSpacing(const CscsString& a) { m_attr_spacing = a; m_has_attr_spacing = true; }
    inline void clearAttributeSpacing() { m_has_attr_spacing = false; }

    inline bool hasAttributeMargin() { return m_has_attr_margin; }
    inline CscsString attributeMargin() { return m_attr_margin; }
    inline void setAttributeMargin(const CscsString& a) { m_attr_margin = a; m_has_attr_margin = true; }
    inline void clearAttributeMargin() { m_has_attr_margin = false; }

    // child element accessors
private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    CscsString m_attr_spacing;
    bool m_has_attr_spacing;

    CscsString m_attr_margin;
    bool m_has_attr_margin;

    // child element data

    CscsDomLayoutFunction(const CscsDomLayoutFunction&	other);
    void operator = (const CscsDomLayoutFunction& other);
};

class  CscsDomTabStops {
public:
    CscsDomTabStops();
    ~CscsDomTabStops();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    // child element accessors
    inline CscsStringList elementTabStop() { return m_tabStop; }
    void setElementTabStop(const CscsStringList& a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    // child element data
    CscsStringList m_tabStop;

    CscsDomTabStops(const CscsDomTabStops& other);
    void operator = (const CscsDomTabStops& other);
};


class  CscsDomLayout {
public:
    CscsDomLayout();
    ~CscsDomLayout();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    inline bool hasAttributeClass() { return m_has_attr_class; }
    inline CscsString attributeClass() { return m_attr_class; }
    inline void setAttributeClass(const CscsString& a) { m_attr_class = a; m_has_attr_class = true; }
    inline void clearAttributeClass() { m_has_attr_class = false; }

     inline bool hasAttributeName() const { return m_has_attr_name; }
    inline CscsString attributeName() const { return m_attr_name; }
    inline void setAttributeName(const CscsString& a) { m_attr_name = a; m_has_attr_name = true; }
    inline void clearAttributeName() { m_has_attr_name = false; }

    inline bool hasAttributeStretch() const { return m_has_attr_stretch; }
    inline CscsString attributeStretch() const { return m_attr_stretch; }
    inline void setAttributeStretch(const CscsString& a) { m_attr_stretch = a; m_has_attr_stretch = true; }
    inline void clearAttributeStretch() { m_has_attr_stretch = false; }

    inline bool hasAttributeRowStretch() const { return m_has_attr_rowStretch; }
    inline CscsString attributeRowStretch() const { return m_attr_rowStretch; }
    inline void setAttributeRowStretch(const CscsString& a) { m_attr_rowStretch = a; m_has_attr_rowStretch = true; }
    inline void clearAttributeRowStretch() { m_has_attr_rowStretch = false; }

    inline bool hasAttributeColumnStretch() const { return m_has_attr_columnStretch; }
    inline CscsString attributeColumnStretch() const { return m_attr_columnStretch; }
    inline void setAttributeColumnStretch(const CscsString& a) { m_attr_columnStretch = a; m_has_attr_columnStretch = true; }
    inline void clearAttributeColumnStretch() { m_has_attr_columnStretch = false; }

    inline bool hasAttributeRowMinimumHeight() const { return m_has_attr_rowMinimumHeight; }
    inline CscsString attributeRowMinimumHeight() const { return m_attr_rowMinimumHeight; }
    inline void setAttributeRowMinimumHeight(const CscsString& a) { m_attr_rowMinimumHeight = a; m_has_attr_rowMinimumHeight = true; }
    inline void clearAttributeRowMinimumHeight() { m_has_attr_rowMinimumHeight = false; }

    inline bool hasAttributeColumnMinimumWidth() const { return m_has_attr_columnMinimumWidth; }
    inline CscsString attributeColumnMinimumWidth() const { return m_attr_columnMinimumWidth; }
    inline void setAttributeColumnMinimumWidth(const CscsString& a) { m_attr_columnMinimumWidth = a; m_has_attr_columnMinimumWidth = true; }
    inline void clearAttributeColumnMinimumWidth() { m_has_attr_columnMinimumWidth = false; }

    // child element accessors
    inline CscsList<CscsDomProperty*> elementProperty() { return m_property; }
    void setElementProperty(const CscsList<CscsDomProperty*>& a);

    inline CscsList<CscsDomProperty*> elementAttribute() { return m_attribute; }
    void setElementAttribute(const CscsList<CscsDomProperty*>& a);

    inline CscsList<CscsDomLayoutItem*> elementItem() { return m_item; }
    void setElementItem(const CscsList<CscsDomLayoutItem*>& a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    CscsString m_attr_class;
    bool m_has_attr_class;

    CscsString m_attr_name;
    bool m_has_attr_name;

    CscsString m_attr_stretch;
    bool m_has_attr_stretch;
    
    CscsString m_attr_rowStretch;
    bool m_has_attr_rowStretch;

    CscsString m_attr_columnStretch;
    bool m_has_attr_columnStretch;

    CscsString m_attr_rowMinimumHeight;
    bool m_has_attr_rowMinimumHeight;

    CscsString m_attr_columnMinimumWidth;
    bool m_has_attr_columnMinimumWidth;

    // child element data
    uint m_children;
    CscsList<CscsDomProperty*> m_property;
    CscsList<CscsDomProperty*> m_attribute;
    CscsList<CscsDomLayoutItem*> m_item;

    enum Child {
        Property = 1,
        Attribute = 2,
        Item = 4
    };


    CscsDomLayout(const CscsDomLayout& other);
    void operator = (const CscsDomLayout& other);
};

class  CscsDomLayoutItem {
public:
    CscsDomLayoutItem();
    ~CscsDomLayoutItem();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    inline bool hasAttributeRow() { return m_has_attr_row; }
    inline int attributeRow() { return m_attr_row; }
    inline void setAttributeRow(int a) { m_attr_row = a; m_has_attr_row = true; }
    inline void clearAttributeRow() { m_has_attr_row = false; }

    inline bool hasAttributeColumn() { return m_has_attr_column; }
    inline int attributeColumn() { return m_attr_column; }
    inline void setAttributeColumn(int a) { m_attr_column = a; m_has_attr_column = true; }
    inline void clearAttributeColumn() { m_has_attr_column = false; }

    inline bool hasAttributeRowSpan() { return m_has_attr_rowSpan; }
    inline int attributeRowSpan() { return m_attr_rowSpan; }
    inline void setAttributeRowSpan(int a) { m_attr_rowSpan = a; m_has_attr_rowSpan = true; }
    inline void clearAttributeRowSpan() { m_has_attr_rowSpan = false; }

    inline bool hasAttributeColSpan() { return m_has_attr_colSpan; }
    inline int attributeColSpan() { return m_attr_colSpan; }
    inline void setAttributeColSpan(int a) { m_attr_colSpan = a; m_has_attr_colSpan = true; }
    inline void clearAttributeColSpan() { m_has_attr_colSpan = false; }

    // child element accessors
    enum Kind { Unknown = 0, Widget, Layout, Spacer };
    inline Kind kind() const { return m_kind; }

    inline CscsDomWidget* elementWidget() { return m_widget; }
    void setElementWidget(CscsDomWidget* a);

    inline CscsDomLayout* elementLayout() { return m_layout; }
    void setElementLayout(CscsDomLayout* a);

    inline CscsDomSpacer* elementSpacer() { return m_spacer; }
    void setElementSpacer(CscsDomSpacer* a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    int m_attr_row;
    bool m_has_attr_row;

    int m_attr_column;
    bool m_has_attr_column;

    int m_attr_rowSpan;
    bool m_has_attr_rowSpan;

    int m_attr_colSpan;
    bool m_has_attr_colSpan;

    // child element data
    Kind m_kind;
    CscsDomWidget* m_widget;
    CscsDomLayout* m_layout;
    CscsDomSpacer* m_spacer;

    CscsDomLayoutItem(const CscsDomLayoutItem& other);
    void operator = (const CscsDomLayoutItem& other);
};

class  CscsDomRow {
public:
    CscsDomRow();
    ~CscsDomRow();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    // child element accessors
    inline CscsList<CscsDomProperty*> elementProperty() { return m_property; }
    void setElementProperty(const CscsList<CscsDomProperty*>& a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    // child element data
    CscsList<CscsDomProperty*> m_property;

    CscsDomRow(const CscsDomRow& other);
    void operator = (const CscsDomRow& other);
};

class  CscsDomColumn {
public:
    CscsDomColumn();
    ~CscsDomColumn();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    // child element accessors
    inline CscsList<CscsDomProperty*> elementProperty() { return m_property; }
    void setElementProperty(const CscsList<CscsDomProperty*>& a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    // child element data
    CscsList<CscsDomProperty*> m_property;

    CscsDomColumn(const CscsDomColumn& other);
    void operator = (const CscsDomColumn& other);
};

class  CscsDomItem {
public:
    CscsDomItem();
    ~CscsDomItem();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    // child element accessors
    inline CscsList<CscsDomProperty*> elementProperty() { return m_property; }
    void setElementProperty(const CscsList<CscsDomProperty*>& a);

    inline CscsList<CscsDomItem*> elementItem() { return m_item; }
    void setElementItem(const CscsList<CscsDomItem*>& a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    // child element data
    CscsList<CscsDomProperty*> m_property;
    CscsList<CscsDomItem*> m_item;

    CscsDomItem(const CscsDomItem& other);
    void operator = (const CscsDomItem& other);
};

class  CscsDomWidget {
public:
    CscsDomWidget();
    ~CscsDomWidget();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    inline bool hasAttributeClass() { return m_has_attr_class; }
    inline CscsString attributeClass() { return m_attr_class; }
    inline void setAttributeClass(const CscsString& a) { m_attr_class = a; m_has_attr_class = true; }
    inline void clearAttributeClass() { m_has_attr_class = false; }

    inline bool hasAttributeName() { return m_has_attr_name; }
    inline CscsString attributeName() { return m_attr_name; }
    inline void setAttributeName(const CscsString& a) { m_attr_name = a; m_has_attr_name = true; }
    inline void clearAttributeName() { m_has_attr_name = false; }

    // child element accessors
    inline CscsStringList elementClass() { return m_class; }
    void setElementClass(const CscsStringList& a);

    inline CscsList<CscsDomProperty*> elementProperty() { return m_property; }
    void setElementProperty(const CscsList<CscsDomProperty*>& a);

    inline CscsList<CscsDomProperty*> elementAttribute() { return m_attribute; }
    void setElementAttribute(const CscsList<CscsDomProperty*>& a);

    inline CscsList<CscsDomRow*> elementRow() { return m_row; }
    void setElementRow(const CscsList<CscsDomRow*>& a);

    inline CscsList<CscsDomColumn*> elementColumn() { return m_column; }
    void setElementColumn(const CscsList<CscsDomColumn*>& a);

    inline CscsList<CscsDomItem*> elementItem() { return m_item; }
    void setElementItem(const CscsList<CscsDomItem*>& a);

    inline CscsList<CscsDomLayout*> elementLayout() { return m_layout; }
    void setElementLayout(const CscsList<CscsDomLayout*>& a);

    inline CscsList<CscsDomWidget*> elementWidget() { return m_widget; }
    void setElementWidget(const CscsList<CscsDomWidget*>& a);

    inline CscsList<CscsDomAction*> elementAction() { return m_action; }
    void setElementAction(const CscsList<CscsDomAction*>& a);

    inline CscsList<CscsDomActionGroup*> elementActionGroup() { return m_actionGroup; }
    void setElementActionGroup(const CscsList<CscsDomActionGroup*>& a);

    inline CscsList<CscsDomActionRef*> elementAddAction() { return m_addAction; }
    void setElementAddAction(const CscsList<CscsDomActionRef*>& a);

    inline CscsStringList elementZOrder() const { return m_zOrder; }
    void setElementZOrder(const CscsStringList& a);


private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    CscsString m_attr_class;
    bool m_has_attr_class;

    CscsString m_attr_name;
    bool m_has_attr_name;

    // child element data
    CscsStringList m_class;
    CscsList<CscsDomProperty*> m_property;
    CscsList<CscsDomProperty*> m_attribute;
    CscsList<CscsDomRow*> m_row;
    CscsList<CscsDomColumn*> m_column;
    CscsList<CscsDomItem*> m_item;
    CscsList<CscsDomLayout*> m_layout;
    CscsList<CscsDomWidget*> m_widget;
    CscsList<CscsDomAction*> m_action;
    CscsList<CscsDomActionGroup*> m_actionGroup;
    CscsList<CscsDomActionRef*> m_addAction;
    CscsStringList m_zOrder;

    CscsDomWidget(const CscsDomWidget&	other);
    void operator = (const CscsDomWidget& other);
};

class  CscsDomSpacer {
public:
    CscsDomSpacer();
    ~CscsDomSpacer();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    inline bool hasAttributeName() { return m_has_attr_name; }
    inline CscsString attributeName() { return m_attr_name; }
    inline void setAttributeName(const CscsString& a) { m_attr_name = a; m_has_attr_name = true; }
    inline void clearAttributeName() { m_has_attr_name = false; }

    // child element accessors
    inline CscsList<CscsDomProperty*> elementProperty() { return m_property; }
    void setElementProperty(const CscsList<CscsDomProperty*>& a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    CscsString m_attr_name;
    bool m_has_attr_name;

    // child element data
    CscsList<CscsDomProperty*> m_property;

    CscsDomSpacer(const CscsDomSpacer& other);
    void operator = (const CscsDomSpacer& other);
};


class  CscsDomColor {
public:
    CscsDomColor();
    ~CscsDomColor();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

	inline bool hasAttributeAlpha()const{return m_has_attr_alpha;}
	inline int attributeAlpha()const{return m_attr_alpha;}
	inline void setAttributteAlpha(int a){ m_attr_alpha=a;m_has_attr_alpha=true;}
    // attribute accessors
    // child element accessors
    inline int elementRed() { return m_red; }
    void setElementRed(int a);

    inline int elementGreen() { return m_green; }
    void setElementGreen(int a);

    inline int elementBlue() { return m_blue; }
    void setElementBlue(int a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    // child element data
	uint32 m_children;
	int m_attr_alpha;
    bool m_has_attr_alpha;
    int m_red;
    int m_green;
    int m_blue;
	enum Child {
        Red = 1,
        Green = 2,
        Blue = 4
    };

    CscsDomColor(const CscsDomColor &other);
    void operator = (const CscsDomColor&other);
};

class  CscsDomGradientStop {
public:
    CscsDomGradientStop();
    ~CscsDomGradientStop();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString()) const;
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    inline bool hasAttributePosition() const { return m_has_attr_position; }
    inline double attributePosition() const { return m_attr_position; }
    inline void setAttributePosition(double a) { m_attr_position = a; m_has_attr_position = true; }
    inline void clearAttributePosition() { m_has_attr_position = false; }

    // child element accessors
    inline CscsDomColor* elementColor() const { return m_color; }
    CscsDomColor* takeElementColor();
    void setElementColor(CscsDomColor* a);
    inline bool hasElementColor() const { return m_children & Color; }
    void clearElementColor();

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    double m_attr_position;
    bool m_has_attr_position;

    // child element data
    uint32 m_children;
    CscsDomColor* m_color;
    enum Child {
        Color = 1
    };

    CscsDomGradientStop(const CscsDomGradientStop &other);
    void operator = (const CscsDomGradientStop&other);
};

class  CscsDomGradient {
public:
    CscsDomGradient();
    ~CscsDomGradient();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString()) const;
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    inline bool hasAttributeStartX() const { return m_has_attr_startX; }
    inline double attributeStartX() const { return m_attr_startX; }
    inline void setAttributeStartX(double a) { m_attr_startX = a; m_has_attr_startX = true; }
    inline void clearAttributeStartX() { m_has_attr_startX = false; }

    inline bool hasAttributeStartY() const { return m_has_attr_startY; }
    inline double attributeStartY() const { return m_attr_startY; }
    inline void setAttributeStartY(double a) { m_attr_startY = a; m_has_attr_startY = true; }
    inline void clearAttributeStartY() { m_has_attr_startY = false; }

    inline bool hasAttributeEndX() const { return m_has_attr_endX; }
    inline double attributeEndX() const { return m_attr_endX; }
    inline void setAttributeEndX(double a) { m_attr_endX = a; m_has_attr_endX = true; }
    inline void clearAttributeEndX() { m_has_attr_endX = false; }

    inline bool hasAttributeEndY() const { return m_has_attr_endY; }
    inline double attributeEndY() const { return m_attr_endY; }
    inline void setAttributeEndY(double a) { m_attr_endY = a; m_has_attr_endY = true; }
    inline void clearAttributeEndY() { m_has_attr_endY = false; }

    inline bool hasAttributeCentralX() const { return m_has_attr_centralX; }
    inline double attributeCentralX() const { return m_attr_centralX; }
    inline void setAttributeCentralX(double a) { m_attr_centralX = a; m_has_attr_centralX = true; }
    inline void clearAttributeCentralX() { m_has_attr_centralX = false; }

    inline bool hasAttributeCentralY() const { return m_has_attr_centralY; }
    inline double attributeCentralY() const { return m_attr_centralY; }
    inline void setAttributeCentralY(double a) { m_attr_centralY = a; m_has_attr_centralY = true; }
    inline void clearAttributeCentralY() { m_has_attr_centralY = false; }

    inline bool hasAttributeFocalX() const { return m_has_attr_focalX; }
    inline double attributeFocalX() const { return m_attr_focalX; }
    inline void setAttributeFocalX(double a) { m_attr_focalX = a; m_has_attr_focalX = true; }
    inline void clearAttributeFocalX() { m_has_attr_focalX = false; }

    inline bool hasAttributeFocalY() const { return m_has_attr_focalY; }
    inline double attributeFocalY() const { return m_attr_focalY; }
    inline void setAttributeFocalY(double a) { m_attr_focalY = a; m_has_attr_focalY = true; }
    inline void clearAttributeFocalY() { m_has_attr_focalY = false; }

    inline bool hasAttributeRadius() const { return m_has_attr_radius; }
    inline double attributeRadius() const { return m_attr_radius; }
    inline void setAttributeRadius(double a) { m_attr_radius = a; m_has_attr_radius = true; }
    inline void clearAttributeRadius() { m_has_attr_radius = false; }

    inline bool hasAttributeAngle() const { return m_has_attr_angle; }
    inline double attributeAngle() const { return m_attr_angle; }
    inline void setAttributeAngle(double a) { m_attr_angle = a; m_has_attr_angle = true; }
    inline void clearAttributeAngle() { m_has_attr_angle = false; }

    inline bool hasAttributeType() const { return m_has_attr_type; }
    inline CscsString attributeType() const { return m_attr_type; }
    inline void setAttributeType(const CscsString& a) { m_attr_type = a; m_has_attr_type = true; }
    inline void clearAttributeType() { m_has_attr_type = false; }

    inline bool hasAttributeSpread() const { return m_has_attr_spread; }
    inline CscsString attributeSpread() const { return m_attr_spread; }
    inline void setAttributeSpread(const CscsString& a) { m_attr_spread = a; m_has_attr_spread = true; }
    inline void clearAttributeSpread() { m_has_attr_spread = false; }

    inline bool hasAttributeCoordinateMode() const { return m_has_attr_coordinateMode; }
    inline CscsString attributeCoordinateMode() const { return m_attr_coordinateMode; }
    inline void setAttributeCoordinateMode(const CscsString& a) { m_attr_coordinateMode = a; m_has_attr_coordinateMode = true; }
    inline void clearAttributeCoordinateMode() { m_has_attr_coordinateMode = false; }

    // child element accessors
    inline CscsList<CscsDomGradientStop*> elementGradientStop() const { return m_gradientStop; }
    void setElementGradientStop(const CscsList<CscsDomGradientStop*>& a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    double m_attr_startX;
    bool m_has_attr_startX;

    double m_attr_startY;
    bool m_has_attr_startY;

    double m_attr_endX;
    bool m_has_attr_endX;

    double m_attr_endY;
    bool m_has_attr_endY;

    double m_attr_centralX;
    bool m_has_attr_centralX;

    double m_attr_centralY;
    bool m_has_attr_centralY;

    double m_attr_focalX;
    bool m_has_attr_focalX;

    double m_attr_focalY;
    bool m_has_attr_focalY;

    double m_attr_radius;
    bool m_has_attr_radius;

    double m_attr_angle;
    bool m_has_attr_angle;

    CscsString m_attr_type;
    bool m_has_attr_type;

    CscsString m_attr_spread;
    bool m_has_attr_spread;

    CscsString m_attr_coordinateMode;
    bool m_has_attr_coordinateMode;

    // child element data
    uint32 m_children;
    CscsList<CscsDomGradientStop*> m_gradientStop;
    enum Child {
        GradientStop = 1
    };

    CscsDomGradient(const CscsDomGradient &other);
    void operator = (const CscsDomGradient&other);
};


class  CscsDomBrush {
public:
    CscsDomBrush();
    ~CscsDomBrush();

    void read(CscsDomElement& node);
    CscsDomElement write(CscsDomDocument& doc, const CscsString &tagName = CscsString()) const;
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    inline bool hasAttributeBrushStyle() const { return m_has_attr_brushStyle; }
    inline CscsString attributeBrushStyle() const { return m_attr_brushStyle; }
    inline void setAttributeBrushStyle(const CscsString& a) { m_attr_brushStyle = a; m_has_attr_brushStyle = true; }
    inline void clearAttributeBrushStyle() { m_has_attr_brushStyle = false; }

    // child element accessors
    enum Kind { Unknown = 0, Color, Texture, Gradient };
    inline Kind kind() const { return m_kind; }

    inline CscsDomColor* elementColor() const { return m_color; }
    CscsDomColor* takeElementColor();
    void setElementColor(CscsDomColor* a);

    inline CscsDomProperty* elementTexture() const { return m_texture; }
    CscsDomProperty* takeElementTexture();
    void setElementTexture(CscsDomProperty* a);

    inline CscsDomGradient* elementGradient() const { return m_gradient; }
    CscsDomGradient *takeElementGradient();
    void setElementGradient(CscsDomGradient* a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    CscsString m_attr_brushStyle;
    bool m_has_attr_brushStyle;

    // child element data
    Kind m_kind;
    CscsDomColor* m_color;
    CscsDomProperty* m_texture;
    CscsDomGradient* m_gradient;

    CscsDomBrush(const CscsDomBrush& other);
    void operator = (const CscsDomBrush& other);
};

class  CscsDomColorRole {
public:
    CscsDomColorRole();
    ~CscsDomColorRole();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString()) const;
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    inline bool hasAttributeRole() const { return m_has_attr_role; }
    inline CscsString attributeRole() const { return m_attr_role; }
    inline void setAttributeRole(const CscsString& a) { m_attr_role = a; m_has_attr_role = true; }
    inline void clearAttributeRole() { m_has_attr_role = false; }

    // child element accessors
    inline CscsDomBrush* elementBrush() const { return m_brush; }
    CscsDomBrush* takeElementBrush();
    void setElementBrush(CscsDomBrush* a);
    inline bool hasElementBrush() const { return m_children & Brush; }
    void clearElementBrush();

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    CscsString m_attr_role;
    bool m_has_attr_role;

    // child element data
    uint32 m_children;
    CscsDomBrush* m_brush;
    enum Child {
        Brush = 1
    };

    CscsDomColorRole(const CscsDomColorRole& other);
    void operator = (const CscsDomColorRole& other);
};

class  CscsDomColorGroup {
public:
    CscsDomColorGroup();
    ~CscsDomColorGroup();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    // child element accessors
	inline CscsList<CscsDomColorRole*> elementColorRole() const { return m_colorRole; }
    void setElementColorRole(const CscsList<CscsDomColorRole*>& a);
    inline CscsList<CscsDomColor*> elementColor() { return m_color; }
    void setElementColor(const CscsList<CscsDomColor*>& a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    // child element data
	uint32 m_children;
	CscsList<CscsDomColorRole*> m_colorRole;
    CscsList<CscsDomColor*> m_color;
	
	enum Child {
        ColorRole = 1,
        Color = 2
    };
    CscsDomColorGroup(const CscsDomColorGroup& other);
    void operator= (const CscsDomColorGroup& other);
};

class  CscsDomPalette {
public:
    CscsDomPalette();
    ~CscsDomPalette();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    // child element accessors
    inline CscsDomColorGroup* elementActive() { return m_active; }
    void setElementActive(CscsDomColorGroup* a);

    inline CscsDomColorGroup* elementInactive() { return m_inactive; }
    void setElementInactive(CscsDomColorGroup* a);

    inline CscsDomColorGroup* elementDisabled() { return m_disabled; }
    void setElementDisabled(CscsDomColorGroup* a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    // child element data
    CscsDomColorGroup* m_active;
    CscsDomColorGroup* m_inactive;
    CscsDomColorGroup* m_disabled;

    CscsDomPalette(const CscsDomPalette& other);
    void operator = (const CscsDomPalette& other);
};


class  CscsDomFont {
public:
    CscsDomFont();
    ~CscsDomFont();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    // child element accessors
    inline CscsString elementFamily() { return m_family; }
    void setElementFamily(const CscsString& a);

    inline int elementPointSize() { return m_pointSize; }
    void setElementPointSize(int a);

    inline int elementWeight() { return m_weight; }
    void setElementWeight(int a);

    inline bool elementItalic() { return m_italic; }
    void setElementItalic(bool a);

    inline bool elementBold() { return m_bold; }
    void setElementBold(bool a);

    inline bool elementUnderline() { return m_underline; }
    void setElementUnderline(bool a);

    inline bool elementStrikeOut() { return m_strikeOut; }
    void setElementStrikeOut(bool a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    // child element data
    CscsString m_family;
    int m_pointSize;
    int m_weight;
    bool m_italic;
    bool m_bold;
    bool m_underline;
    bool m_strikeOut;

    CscsDomFont(const CscsDomFont& other);
    void operator = (const CscsDomFont& other);
};


class  CscsDomPoint {
public:
    CscsDomPoint();
    ~CscsDomPoint();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    // child element accessors
    inline int elementX() { return m_x; }
    void setElementX(int a);

    inline int elementY() { return m_y; }
    void setElementY(int a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    // child element data
    int m_x;
    int m_y;

    CscsDomPoint(const CscsDomPoint &other);
    void operator = (const CscsDomPoint&other);
};

class  CscsDomRect {
public:
    CscsDomRect();
    ~CscsDomRect();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    // child element accessors
    inline int elementX() { return m_x; }
    void setElementX(int a);

    inline int elementY() { return m_y; }
    void setElementY(int a);

    inline int elementWidth() { return m_width; }
    void setElementWidth(int a);

    inline int elementHeight() { return m_height; }
    void setElementHeight(int a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    // child element data
    int m_x;
    int m_y;
    int m_width;
    int m_height;

    CscsDomRect(const CscsDomRect& other);
    void operator = (const CscsDomRect& other);
};

class  CscsDomSizePolicy {
public:
    CscsDomSizePolicy();
    ~CscsDomSizePolicy();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    inline bool hasAttributeHSizeType() const { return m_has_attr_hSizeType; }
    inline CscsString attributeHSizeType() const { return m_attr_hSizeType; }
    inline void setAttributeHSizeType(const CscsString& a) { m_attr_hSizeType = a; m_has_attr_hSizeType = true; }
    inline void clearAttributeHSizeType() { m_has_attr_hSizeType = false; }

    inline bool hasAttributeVSizeType() const { return m_has_attr_vSizeType; }
    inline CscsString attributeVSizeType() const { return m_attr_vSizeType; }
    inline void setAttributeVSizeType(const CscsString& a) { m_attr_vSizeType = a; m_has_attr_vSizeType = true; }
    inline void clearAttributeVSizeType() { m_has_attr_vSizeType = false; }
    // child element accessors
    inline int elementHSizeType() { return m_hSizeType; }
    inline bool hasElementHSizeType() const { return m_children & HSizeType; }
    void setElementHSizeType(int a);
    

    inline int elementVSizeType() { return m_vSizeType; }
    inline bool hasElementVSizeType() const { return m_children & VSizeType; }
    void setElementVSizeType(int a);

    inline int elementHorStretch() { return m_horStretch; }
    inline bool hasElementHorStretch() const { return m_children & HorStretch; }
    void setElementHorStretch(int a);

    inline int elementVerStretch() { return m_verStretch; }
       inline bool hasElementVerStretch() const { return m_children & VerStretch; }
    void setElementVerStretch(int a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    CscsString m_attr_hSizeType;
    bool m_has_attr_hSizeType;

    CscsString m_attr_vSizeType;
    bool m_has_attr_vSizeType;
    // child element data
    uint m_children;
    int m_hSizeType;
    int m_vSizeType;
    int m_horStretch;
    int m_verStretch;

    enum Child {
        HSizeType = 1,
        VSizeType = 2,
        HorStretch = 4,
        VerStretch = 8
    };


    CscsDomSizePolicy(const CscsDomSizePolicy& other);
    void operator = (const CscsDomSizePolicy& other);
};

class  CscsDomSize {
public:
    CscsDomSize();
    ~CscsDomSize();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    // child element accessors
    inline int elementWidth() { return m_width; }
    void setElementWidth(int a);

    inline int elementHeight() { return m_height; }
    void setElementHeight(int a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    // child element data
    int m_width;
    int m_height;

    CscsDomSize(const CscsDomSize& other);
    void operator = (const CscsDomSize& other);
};

class  CscsDomDate {
public:
    CscsDomDate();
    ~CscsDomDate();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    // child element accessors
    inline int elementYear() { return m_year; }
    void setElementYear(int a);

    inline int elementMonth() { return m_month; }
    void setElementMonth(int a);

    inline int elementDay() { return m_day; }
    void setElementDay(int a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    // child element data
    int m_year;
    int m_month;
    int m_day;

    CscsDomDate(const CscsDomDate& other);
    void operator = (const CscsDomDate& other);
};

class  CscsDomTime {
public:
    CscsDomTime();
    ~CscsDomTime();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    // child element accessors
    inline int elementHour() { return m_hour; }
    void setElementHour(int a);

    inline int elementMinute() { return m_minute; }
    void setElementMinute(int a);

    inline int elementSecond() { return m_second; }
    void setElementSecond(int a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    // child element data
    int m_hour;
    int m_minute;
    int m_second;

    CscsDomTime(const CscsDomTime& other);
    void operator = (const CscsDomTime& other);
};


class  CscsDomDateTime {
public:
    CscsDomDateTime();
    ~CscsDomDateTime();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    // child element accessors
    inline int elementHour() { return m_hour; }
    void setElementHour(int a);

    inline int elementMinute() { return m_minute; }
    void setElementMinute(int a);

    inline int elementSecond() { return m_second; }
    void setElementSecond(int a);

    inline int elementYear() { return m_year; }
    void setElementYear(int a);

    inline int elementMonth() { return m_month; }
    void setElementMonth(int a);

    inline int elementDay() { return m_day; }
    void setElementDay(int a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    // child element data
    int m_hour;
    int m_minute;
    int m_second;
    int m_year;
    int m_month;
    int m_day;

    CscsDomDateTime(const CscsDomDateTime& other);
    void operator = (const CscsDomDateTime& other);
};

class  CscsDomStringList {
public:
    CscsDomStringList();
    ~CscsDomStringList();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    // child element accessors
    inline CscsStringList elementString() { return m_string; }
    void setElementString(const CscsStringList& a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    // child element data
    CscsStringList m_string;

    CscsDomStringList(const CscsDomStringList& other);
    void operator = (const CscsDomStringList& other);
};


class  CscsDomResourcePixmap {
public:
    CscsDomResourcePixmap();
    ~CscsDomResourcePixmap();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    inline bool hasAttributeResource() { return m_has_attr_resource; }
    inline CscsString attributeResource() { return m_attr_resource; }
    inline void setAttributeResource(const CscsString& a) { m_attr_resource = a; m_has_attr_resource = true; }
    inline void clearAttributeResource() { m_has_attr_resource = false; }

    // child element accessors
private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    CscsString m_attr_resource;
    bool m_has_attr_resource;

    // child element data

    CscsDomResourcePixmap(const CscsDomResourcePixmap &other);
    void operator = (const CscsDomResourcePixmap&other);
};


class  CscsDomResourceIcon {
public:
    CscsDomResourceIcon();
    ~CscsDomResourceIcon();

    void read(CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString()) const;
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    inline bool hasAttributeTheme() const { return m_has_attr_theme; }
    inline CscsString attributeTheme() const { return m_attr_theme; }
    inline void setAttributeTheme(const CscsString& a) { m_attr_theme = a; m_has_attr_theme = true; }
    inline void clearAttributeTheme() { m_has_attr_theme = false; }

    inline bool hasAttributeResource() const { return m_has_attr_resource; }
    inline CscsString attributeResource() const { return m_attr_resource; }
    inline void setAttributeResource(const CscsString& a) { m_attr_resource = a; m_has_attr_resource = true; }
    inline void clearAttributeResource() { m_has_attr_resource = false; }

    // child element accessors
    inline CscsDomResourcePixmap* elementNormalOff() const { return m_normalOff; }
    void setElementNormalOff(CscsDomResourcePixmap* a);
    inline bool hasElementNormalOff() const { return m_children & NormalOff; }
    void clearElementNormalOff();

    inline CscsDomResourcePixmap* elementNormalOn() const { return m_normalOn; }
    void setElementNormalOn(CscsDomResourcePixmap* a);
    inline bool hasElementNormalOn() const { return m_children & NormalOn; }
    void clearElementNormalOn();

    inline CscsDomResourcePixmap* elementDisabledOff() const { return m_disabledOff; }
    void setElementDisabledOff(CscsDomResourcePixmap* a);
    inline bool hasElementDisabledOff() const { return m_children & DisabledOff; }
    void clearElementDisabledOff();

    inline CscsDomResourcePixmap* elementDisabledOn() const { return m_disabledOn; }
    void setElementDisabledOn(CscsDomResourcePixmap* a);
    inline bool hasElementDisabledOn() const { return m_children & DisabledOn; }
    void clearElementDisabledOn();

    inline CscsDomResourcePixmap* elementActiveOff() const { return m_activeOff; }
    void setElementActiveOff(CscsDomResourcePixmap* a);
    inline bool hasElementActiveOff() const { return m_children & ActiveOff; }
    void clearElementActiveOff();

    inline CscsDomResourcePixmap* elementActiveOn() const { return m_activeOn; }
    void setElementActiveOn(CscsDomResourcePixmap* a);
    inline bool hasElementActiveOn() const { return m_children & ActiveOn; }
    void clearElementActiveOn();

    inline CscsDomResourcePixmap* elementSelectedOff() const { return m_selectedOff; }
    void setElementSelectedOff(CscsDomResourcePixmap* a);
    inline bool hasElementSelectedOff() const { return m_children & SelectedOff; }
    void clearElementSelectedOff();

    inline CscsDomResourcePixmap* elementSelectedOn() const { return m_selectedOn; }
    void setElementSelectedOn(CscsDomResourcePixmap* a);
    inline bool hasElementSelectedOn() const { return m_children & SelectedOn; }
    void clearElementSelectedOn();

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    CscsString m_attr_theme;
    bool m_has_attr_theme;

    CscsString m_attr_resource;
    bool m_has_attr_resource;

    // child element data
    uint m_children;
    CscsDomResourcePixmap* m_normalOff;
    CscsDomResourcePixmap* m_normalOn;
    CscsDomResourcePixmap* m_disabledOff;
    CscsDomResourcePixmap* m_disabledOn;
    CscsDomResourcePixmap* m_activeOff;
    CscsDomResourcePixmap* m_activeOn;
    CscsDomResourcePixmap* m_selectedOff;
    CscsDomResourcePixmap* m_selectedOn;
    enum Child {
        NormalOff = 1,
        NormalOn = 2,
        DisabledOff = 4,
        DisabledOn = 8,
        ActiveOff = 16,
        ActiveOn = 32,
        SelectedOff = 64,
        SelectedOn = 128
    };

    CscsDomResourceIcon(const CscsDomResourceIcon& other);
    void operator = (const CscsDomResourceIcon& other);
};

class  CscsDomString {
public:
    CscsDomString();
    ~CscsDomString();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    inline bool hasAttributeNotr() { return m_has_attr_notr; }
    inline CscsString attributeNotr() { return m_attr_notr; }
    inline void setAttributeNotr(const CscsString& a) { m_attr_notr = a; m_has_attr_notr = true; }
    inline void clearAttributeNotr() { m_has_attr_notr = false; }

    // child element accessors
private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    CscsString m_attr_notr;
    bool m_has_attr_notr;

    // child element data

    CscsDomString(const CscsDomString& other);
    void operator = (const CscsDomString& other);
};


class  CscsDomProperty {
public:
    CscsDomProperty();
    ~CscsDomProperty();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    inline bool hasAttributeName() { return m_has_attr_name; }
    inline CscsString attributeName() { return m_attr_name; }
    inline void setAttributeName(const CscsString& a) { m_attr_name = a; m_has_attr_name = true; }
    inline void clearAttributeName() { m_has_attr_name = false; }

    inline bool hasAttributeStdset() { return m_has_attr_stdset; }
    inline int attributeStdset() { return m_attr_stdset; }
    inline void setAttributeStdset(int a) { m_attr_stdset = a; m_has_attr_stdset = true; }
    inline void clearAttributeStdset() { m_has_attr_stdset = false; }

    // child element accessors
    enum Kind { Unknown = 0, Bool, Color, Cstring, Cursor,CursorShape,Enum, Font, IconSet, Pixmap, Palette, Point, Rect, Set, SizePolicy, Size, String, StringList, Number, Float, Double, Date, Time, DateTime };
    inline Kind kind()const { return m_kind; }

    inline CscsString elementBool() { return m_bool; }
    void setElementBool(const CscsString& a);

    inline CscsDomColor* elementColor() { return m_color; }
    void setElementColor(CscsDomColor* a);

    inline CscsString elementCstring() { return m_cstring; }
    void setElementCstring(const CscsString& a);

    inline int elementCursor() { return m_cursor; }
    void setElementCursor(int a);

    inline CscsString elementCursorShape(){return m_cursorShape;}
    void setElementCursorShape(const CscsString& a);

    inline CscsString elementEnum() { return m_enum; }
    void setElementEnum(const CscsString& a);

    inline CscsDomFont* elementFont() { return m_font; }
    void setElementFont(CscsDomFont* a);

    inline CscsDomResourceIcon* elementIconSet()const { return m_iconSet; }
    void setElementIconSet(CscsDomResourceIcon* a);

    inline CscsDomResourcePixmap* elementPixmap() { return m_pixmap; }
    void setElementPixmap(CscsDomResourcePixmap* a);

    inline CscsDomPalette* elementPalette() { return m_palette; }
    void setElementPalette(CscsDomPalette* a);

    inline CscsDomPoint* elementPoint() { return m_point; }
    void setElementPoint(CscsDomPoint* a);

    inline CscsDomRect* elementRect() { return m_rect; }
    void setElementRect(CscsDomRect* a);

    inline CscsString elementSet() { return m_set; }
    void setElementSet(const CscsString& a);

    inline CscsDomSizePolicy* elementSizePolicy() { return m_sizePolicy; }
    void setElementSizePolicy(CscsDomSizePolicy* a);

    inline CscsDomSize* elementSize() { return m_size; }
    void setElementSize(CscsDomSize* a);

    inline CscsDomString* elementString() { return m_string; }
    void setElementString(CscsDomString* a);

    inline CscsDomStringList* elementStringList() { return m_stringList; }
    void setElementStringList(CscsDomStringList* a);

    inline int elementNumber() { return m_number; }
    void setElementNumber(int a);

    inline float elementFloat() { return m_float; }
    void setElementFloat(float a);

    inline double elementDouble() { return m_double; }
    void setElementDouble(double a);

    inline CscsDomDate* elementDate() { return m_date; }
    void setElementDate(CscsDomDate* a);

    inline CscsDomTime* elementTime() { return m_time; }
    void setElementTime(CscsDomTime* a);

    inline CscsDomDateTime* elementDateTime() { return m_dateTime; }
    void setElementDateTime(CscsDomDateTime* a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    CscsString m_attr_name;
    bool m_has_attr_name;

    int m_attr_stdset;
    bool m_has_attr_stdset;

    // child element data
    Kind m_kind;
    CscsString m_bool;
    CscsDomColor* m_color;
    CscsString m_cstring;
    int m_cursor;
    CscsString m_cursorShape;
    CscsString m_enum;
    CscsDomFont* m_font;
    CscsDomResourceIcon* m_iconSet;
    CscsDomResourcePixmap* m_pixmap;
    CscsDomPalette* m_palette;
    CscsDomPoint* m_point;
    CscsDomRect* m_rect;
    CscsString m_set;
    CscsDomSizePolicy* m_sizePolicy;
    CscsDomSize* m_size;
    CscsDomString* m_string;
    CscsDomStringList* m_stringList;
    int m_number;
    float m_float;
    double m_double;
    CscsDomDate* m_date;
    CscsDomTime* m_time;
    CscsDomDateTime* m_dateTime;

    CscsDomProperty(const CscsDomProperty&	other);
    void operator = (const CscsDomProperty&	other);
};


class  CscsDomConnections {
public:
    CscsDomConnections();
    ~CscsDomConnections();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    // child element accessors
    inline CscsList<CscsDomConnection*> elementConnection() { return m_connection; }
    void setElementConnection(const CscsList<CscsDomConnection*>& a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    // child element data
    CscsList<CscsDomConnection*> m_connection;

    CscsDomConnections(const CscsDomConnections& other);
    void operator = (const CscsDomConnections& other);
};

class  CscsDomConnection {
public:
    CscsDomConnection();
    ~CscsDomConnection();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    // child element accessors
    inline CscsString elementSender() { return m_sender; }
    void setElementSender(const CscsString& a);

    inline CscsString elementSignal() { return m_signal; }
    void setElementSignal(const CscsString& a);

    inline CscsString elementReceiver() { return m_receiver; }
    void setElementReceiver(const CscsString& a);

    inline CscsString elementSlot() { return m_slot; }
    void setElementSlot(const CscsString& a);

    inline CscsDomConnectionHints* elementHints() { return m_hints; }
    void setElementHints(CscsDomConnectionHints* a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    // child element data
    CscsString m_sender;
    CscsString m_signal;
    CscsString m_receiver;
    CscsString m_slot;
    CscsDomConnectionHints* m_hints;

    CscsDomConnection(const CscsDomConnection& other);
    void operator = (const CscsDomConnection& other);
};

class  CscsDomConnectionHints {
public:
    CscsDomConnectionHints();
    ~CscsDomConnectionHints();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    // child element accessors
    inline CscsList<CscsDomConnectionHint*> elementHint() { return m_hint; }
    void setElementHint(const CscsList<CscsDomConnectionHint*>& a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    // child element data
    CscsList<CscsDomConnectionHint*> m_hint;

    CscsDomConnectionHints(const CscsDomConnectionHints& other);
    void operator = (const CscsDomConnectionHints& other);
};

class  CscsDomConnectionHint {
public:
    CscsDomConnectionHint();
    ~CscsDomConnectionHint();

    void read(const CscsDomElement &node);
    CscsDomElement write(CscsDomDocument &doc, const CscsString &tagName = CscsString());
    inline CscsString text() const { return m_text; }
    inline void setText(const CscsString &s) { m_text = s; }

    // attribute accessors
    inline bool hasAttributeType() { return m_has_attr_type; }
    inline CscsString attributeType() { return m_attr_type; }
    inline void setAttributeType(const CscsString& a) { m_attr_type = a; m_has_attr_type = true; }
    inline void clearAttributeType() { m_has_attr_type = false; }

    // child element accessors
    inline int elementX() { return m_x; }
    void setElementX(int a);

    inline int elementY() { return m_y; }
    void setElementY(int a);

private:
    CscsString m_text;
    void clear(bool clear_all = true);

    // attribute data
    CscsString m_attr_type;
    bool m_has_attr_type;

    // child element data
    int m_x;
    int m_y;

    CscsDomConnectionHint(const CscsDomConnectionHint& other);
    void operator = (const CscsDomConnectionHint& other);
};

END_NAMESPACE

#endif
