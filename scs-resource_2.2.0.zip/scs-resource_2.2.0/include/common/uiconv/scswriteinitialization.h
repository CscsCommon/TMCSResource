#ifndef SCSWRITEINITIALIZATION_H
#define SCSWRITEINITIALIZATION_H

#include "scstreewalker.h"
#include <kernel/scshash.h>
#include <kernel/scsstack.h>
#include <kernel/scsmap.h>
#include <kernel/file/scstextstream.h>

BEGIN_NAMESPACE(Gemini)

class CscsUIDriver;
class CscsUic;
struct CscsOption;
class CscsDomBrush;
class CscsDomSizePolicy;
class CscsDomResourceIcon;

class SizePolicyHandle {
    public:
        SizePolicyHandle(CscsDomSizePolicy *domSizePolicy);
        int compare(const SizePolicyHandle &)const;
    private:
        CscsDomSizePolicy *m_domSizePolicy;
};
inline bool operator ==(const SizePolicyHandle &f1, const SizePolicyHandle &f2) { return f1.compare(f2) == 0; }
inline bool operator  <(const SizePolicyHandle &f1, const SizePolicyHandle &f2) { return f1.compare(f2) < 0; }


 class IconHandle {
    public:
        IconHandle(const CscsDomResourceIcon *domIcon);
        int compare(const IconHandle &) const;
    private:
        const CscsDomResourceIcon *m_domIcon;
    };
inline bool operator ==(const IconHandle &i1, const IconHandle &i2) { return i1.compare(i2) == 0; }
inline bool operator  <(const IconHandle &i1, const IconHandle &i2) { return i1.compare(i2) < 0; }


struct CscsWriteInitialization : public CscsTreeWalker
{
    CscsWriteInitialization(CscsUic *uic);

//
// widgets
//
    void acceptUI(CscsDomUI *node);
    void acceptWidget(CscsDomWidget *node);
    void acceptLayout(CscsDomLayout *node);
    void acceptSpacer(CscsDomSpacer *node);
    void acceptLayoutItem(CscsDomLayoutItem *node);

//
// actions
//
    void acceptActionGroup(CscsDomActionGroup *node);
    void acceptAction(CscsDomAction *node);
    void acceptActionRef(CscsDomActionRef *node);

//
// tab stops
//
    void acceptTabStops(CscsDomTabStops *tabStops);

//
// custom widgets
//
    void acceptCustomWidgets(CscsDomCustomWidgets *node);
    void acceptCustomWidget(CscsDomCustomWidget *node);

//
// layout defaults/functions
//
    void acceptLayoutDefault(CscsDomLayoutDefault *node);
    void acceptLayoutFunction(CscsDomLayoutFunction *node);

//
// signal/slot connections
//
    void acceptConnection(CscsDomConnection *connection);

//
// images
//
    void acceptImage(CscsDomImage *image);

private:
    static CscsString domColor2String(CscsDomColor *c);
    CscsString iconCall(CscsDomProperty *prop);
    CscsString pixCall(CscsDomProperty *prop) const;
    CscsString trCall(const CscsString &str, const CscsString &className) const;
    CscsString trCall(CscsDomString *str, const CscsString &className) const;
    CscsString writeSizePolicy(CscsDomSizePolicy* sp);
    void writeProperties(const CscsString &varName, const CscsString &className,
                         const CscsList<CscsDomProperty*> &lst);
    void writeColorGroup(CscsDomColorGroup *colorGroup, const CscsString &group, const CscsString &paletteName);
	
	CscsString writeBrushInitialization(CscsDomBrush *brush);
	void writeBrush(CscsDomBrush *brush, const CscsString &brushName);

    CscsString writeIconProperties(const CscsDomResourceIcon *i);

//
// special initialization
//
    void initializeMenu(CscsDomWidget *w, const CscsString &parentWidget);
    void initializeComboBox(CscsDomWidget *w);
    void initializeListWidget(CscsDomWidget *w);
    void initializeTreeWidget(CscsDomWidget *w);
    void initializeTreeWidgetItems(const CscsString &className, const CscsString &varName, const CscsList<CscsDomItem *> &items);
    void initializeTableWidget(CscsDomWidget *w);

//
// special initialization for the Q3 support classes
//
    void initializeQ3ListBox(CscsDomWidget *w);
    void initializeQ3IconView(CscsDomWidget *w);
    void initializeQ3ListView(CscsDomWidget *w);
    void initializeQ3ListViewItems(const CscsString &className, const CscsString &varName, const CscsList<CscsDomItem*> &items);
    void initializeQ3Table(CscsDomWidget *w);
    void initializeQ3TableItems(const CscsString &className, const CscsString &varName, const CscsList<CscsDomItem*> &items);

//
// Sql
//
    void initializeSqlDataTable(CscsDomWidget *w);
    void initializeSqlDataBrowser(CscsDomWidget *w);

    CscsDomWidget *findWidget(const CscsString &widgetClass);

    CscsDomImage *findImage(const CscsString &name) const;
	

private:
    CscsUic *uic;
    CscsUIDriver *driver;
    CscsTextStream &output;
    const CscsOption &option;
    bool m_stdsetdef;

    struct Buddy
    {
        Buddy(const CscsString &oN, const CscsString &b)
            : objName(oN), buddy(b) {}
        CscsString objName;
        CscsString buddy;
    };

    CscsStack<CscsDomWidget*> m_widgetChain;
    CscsStack<CscsDomLayout*> m_layoutChain;
    CscsStack<CscsDomActionGroup*> m_actionGroupChain;
    CscsList<Buddy> m_buddies;

    CscsHash<CscsString, CscsString> m_buttonGroups;
    CscsHash<CscsString, CscsDomWidget*> m_registeredWidgets;
    CscsHash<CscsString, CscsDomImage*> m_registeredImages;
	
	typedef CscsHash<uint, CscsString> ColorBrushHash;
    ColorBrushHash m_colorBrushHash;

    typedef CscsMap<SizePolicyHandle, CscsString> SizePolicyNameMap;
    SizePolicyNameMap     m_sizePolicyNameMap;
    typedef CscsMap<IconHandle, CscsString> IconPropertiesNameMap;
    IconPropertiesNameMap m_iconPropertiesNameMap;

    // layout defaults
    int m_defaultMargin;
    int m_defaultSpacing;
    CscsString m_marginFunction;
    CscsString m_spacingFunction;

    CscsString m_generatedClass;

    CscsString m_delayedInitialization;
    CscsTextStream refreshOut;

    CscsString m_delayedActionInitialization;
    CscsTextStream actionOut;
    bool m_firstThemeIcon;
	uint m_dpi;
};

END_NAMESPACE

#endif