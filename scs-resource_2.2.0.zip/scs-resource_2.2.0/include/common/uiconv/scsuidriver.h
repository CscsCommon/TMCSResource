#ifndef SCSUIDRIVER_H
#define SCSUIDRIVER_H

#include "scsoption.h"
#include <kernel/scshash.h>
#include <kernel/scsstringlist.h>
#include <kernel/file/scstextstream.h>

BEGIN_NAMESPACE(Gemini)

class CscsDomUI;
class CscsDomWidget;
class CscsDomSpacer;
class CscsDomLayout;
class CscsDomLayoutItem;
class CscsDomActionGroup;
class CscsDomAction;

class CscsUIDriver{
public:
	CscsUIDriver();
	virtual ~CscsUIDriver();

	bool printDependencies(const CscsString& fileName);
	bool uic(const CscsString& fileName, CscsTextStream* out=0);
	bool uic(const CscsString& fileName, CscsDomUI* ui, CscsTextStream* out=0);

	inline CscsTextStream& output()const{return *m_output;}
	inline CscsOption& option(){return m_option;}

	void reset();

	inline CscsStringList problems(){return m_problems;}
	inline void addProblem(const CscsString& problem){m_problems.append(problem);}

	static CscsString headerFileName(const CscsString& fileName);
	inline CscsString headerFileName()const{
		return headerFileName(m_option.outputFile.isEmpty()?m_option.inputFile:m_option.outputFile);
	}

	static CscsString ify(const CscsString& name);
	CscsString unique(const CscsString& instanceName=CscsString(),const CscsString& className=CscsString());

	CscsString findOrInsertWidget(CscsDomWidget* widget);
	CscsString findOrInsertSpacer(CscsDomSpacer* spacer);
	CscsString findOrInsertLayout(CscsDomLayout* layout);
	CscsString findOrInsertLayoutItem(CscsDomLayoutItem* layoutItem);
	CscsString findOrInsertName(const CscsString& name);
	CscsString findOrInsertActionGroup(CscsDomActionGroup* group);
	CscsString findOrInsertAction(CscsDomAction* action);

	inline bool hasName(const CscsString& name)const{
		return m_nameRepository.contains(name);
	}
	
	CscsDomWidget* widgetByName(const CscsString& name)const;
	CscsDomSpacer* spacerByName(const CscsString& name)const;
	CscsDomLayout* layoutByName(const CscsString& name)const;
	CscsDomActionGroup* actionGroupByName(const CscsString& name)const;
	CscsDomAction* actionByName(const CscsString& name)const;

	void insertPixmap(const CscsString& pixmap);
	bool containsPixmap(const CscsString& pixmap)const;

private:
	CscsOption m_option;
	CscsTextStream m_stdout;
	CscsTextStream* m_output;
	CscsStringList m_problems;

	CscsHash<CscsDomWidget*,CscsString> m_widgets;
	CscsHash<CscsDomLayout*,CscsString> m_layouts;
	CscsHash<CscsDomSpacer*, CscsString> m_spacers;
	CscsHash<CscsDomActionGroup*,CscsString> m_actionGroups;
	CscsHash<CscsDomAction*,CscsString> m_actions;
	CscsHash<CscsString, bool> m_nameRepository;
	CscsHash<CscsString, bool> m_pixmaps;

};

END_NAMESPACE

#endif