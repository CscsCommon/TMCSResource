#ifndef SCSTREEWALKER_H
#define SCSTREEWALKER_H
#include <kernel/scsnamespace.h>

BEGIN_NAMESPACE(Gemini)

class CscsDomUI;
class CscsDomLayoutDefault;
class CscsDomLayoutFunction;
class CscsDomTabStops;
class CscsDomLayout;
class CscsDomLayoutItem;
class CscsDomWidget;
class CscsDomSpacer;
class CscsDomColor;
class CscsDomColorGroup;
class CscsDomPalette;
class CscsDomFont;
class CscsDomPoint;
class CscsDomRect;
class CscsDomSizePolicy;
class CscsDomSize;
class CscsDomDate;
class CscsDomTime;
class CscsDomDateTime;
class CscsDomProperty;
class CscsDomCustomWidgets;
class CscsDomCustomWidget;
class CscsDomAction;
class CscsDomActionGroup;
class CscsDomActionRef;
class CscsDomImages;
class CscsDomImage;
class CscsDomItem;
class CscsDomIncludes;
class CscsDomInclude;
class CscsDomString;
class CscsDomResourcePixmap;
class CscsDomResources;
class CscsDomResource;
class CscsDomConnections;
class CscsDomConnection;
class CscsDomConnectionHints;
class CscsDomConnectionHint;

struct CscsTreeWalker
{
    inline virtual ~CscsTreeWalker() {}

    virtual void acceptUI(CscsDomUI *ui);
    virtual void acceptLayoutDefault(CscsDomLayoutDefault *layoutDefault);
    virtual void acceptLayoutFunction(CscsDomLayoutFunction *layoutFunction);
    virtual void acceptTabStops(CscsDomTabStops *tabStops);
    virtual void acceptCustomWidgets(CscsDomCustomWidgets *customWidgets);
    virtual void acceptCustomWidget(CscsDomCustomWidget *customWidget);
    virtual void acceptLayout(CscsDomLayout *layout);
    virtual void acceptLayoutItem(CscsDomLayoutItem *layoutItem);
    virtual void acceptWidget(CscsDomWidget *widget);
    virtual void acceptSpacer(CscsDomSpacer *spacer);
    virtual void acceptColor(CscsDomColor *color);
    virtual void acceptColorGroup(CscsDomColorGroup *colorGroup);
    virtual void acceptPalette(CscsDomPalette *palette);
    virtual void acceptFont(CscsDomFont *font);
    virtual void acceptPoint(CscsDomPoint *point);
    virtual void acceptRect(CscsDomRect *rect);
    virtual void acceptSizePolicy(CscsDomSizePolicy *sizePolicy);
    virtual void acceptSize(CscsDomSize *size);
    virtual void acceptDate(CscsDomDate *date);
    virtual void acceptTime(CscsDomTime *time);
    virtual void acceptDateTime(CscsDomDateTime *dateTime);
    virtual void acceptProperty(CscsDomProperty *property);
    virtual void acceptImages(CscsDomImages *images);
    virtual void acceptImage(CscsDomImage *image);
    virtual void acceptIncludes(CscsDomIncludes *includes);
    virtual void acceptInclude(CscsDomInclude *incl);
    virtual void acceptAction(CscsDomAction *action);
    virtual void acceptActionGroup(CscsDomActionGroup *actionGroup);
    virtual void acceptActionRef(CscsDomActionRef *actionRef);
    virtual void acceptConnections(CscsDomConnections *connections);
    virtual void acceptConnection(CscsDomConnection *connection);
    virtual void acceptConnectionHints(CscsDomConnectionHints *connectionHints);
    virtual void acceptConnectionHint(CscsDomConnectionHint *connectionHint);
};


END_NAMESPACE

#endif