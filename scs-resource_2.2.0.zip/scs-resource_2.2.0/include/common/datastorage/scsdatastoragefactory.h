#ifndef SCSDATASTORAGEFACTORY_H
#define SCSDATASTORAGEFACTORY_H

#include "scsabstractdatastorage.h"

BEGIN_NAMESPACE(Gemini)

class CscsDBStorageFactory{
public:

    static CscsDBStorageFactory* instance();
    static void ruinInstance();
    CscsAbstractDataStorage* get(CscsAbstractDataStorage::DataOperatorType type=CscsAbstractDataStorage::SafeMemory);

private:
    CscsDBStorageFactory();
    ~CscsDBStorageFactory();

    static CscsAbstractDataStorage *m_dbstorage;
    static CscsAbstractDataStorage *f_dbstorage;
    static CscsAbstractDataStorage* sm_dbstorage;
    static CscsDBStorageFactory *m_factory;
};

END_NAMESPACE
#endif