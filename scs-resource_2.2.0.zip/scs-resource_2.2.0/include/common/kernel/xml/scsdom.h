#ifndef SCSDOM_H
#define SCSDOM_H

#include <kernel/scsstring.h>

BEGIN_NAMESPACE(Gemini)

class CscsDevice;
class CscsTextStream;

class CscsXmlInputSource;
class CscsXmlReader;

class CscsDomDocumentPrivate;
class CscsDomDocumentTypePrivate;
class CscsDomDocumentFragmentPrivate;
class CscsDomNodePrivate;
class CscsDomNodeListPrivate;
class CscsDomImplementationPrivate;
class CscsDomElementPrivate;
class CscsDomNotationPrivate;
class CscsDomEntityPrivate;
class CscsDomEntityReferencePrivate;
class CscsDomProcessingInstructionPrivate;
class CscsDomAttrPrivate;
class CscsDomCharacterDataPrivate;
class CscsDomTextPrivate;
class CscsDomCommentPrivate;
class CscsDomCDATASectionPrivate;
class CscsDomNamedNodeMapPrivate;
class CscsDomImplementationPrivate;

class CscsDomNodeList;
class CscsDomElement;
class CscsDomText;
class CscsDomComment;
class CscsDomCDATASection;
class CscsDomProcessingInstruction;
class CscsDomAttr;
class CscsDomEntityReference;
class CscsDomDocument;
class CscsDomNamedNodeMap;
class CscsDomDocument;
class CscsDomDocumentFragment;
class CscsDomDocumentType;
class CscsDomImplementation;
class CscsDomNode;
class CscsDomEntity;
class CscsDomNotation;
class CscsDomCharacterData;

class  CscsDomImplementation
{
public:
    CscsDomImplementation();
    CscsDomImplementation(const CscsDomImplementation&);
    ~CscsDomImplementation();
    CscsDomImplementation& operator= (const CscsDomImplementation&);
    bool operator== (const CscsDomImplementation&) const;
    bool operator!= (const CscsDomImplementation&) const;

    // functions
    bool hasFeature(const CscsString& feature, const CscsString& version) const;
    CscsDomDocumentType createDocumentType(const CscsString& sName, const CscsString& publicId, const CscsString& systemId);
    CscsDomDocument createDocument(const CscsString& nsURI, const CscsString& sName, const CscsDomDocumentType& doctype);

    enum InvalidDataPolicy { AcceptInvalidChars = 0, DropInvalidChars, ReturnNullNode };
    static InvalidDataPolicy invalidDataPolicy();
    static void setInvalidDataPolicy(InvalidDataPolicy policy);


    bool isNull();

private:
    CscsDomImplementationPrivate* impl;
    CscsDomImplementation(CscsDomImplementationPrivate*);

    friend class CscsDomDocument;
};

class  CscsDomNode
{
public:
    enum NodeType {
        ElementNode               = 1,
        AttributeNode             = 2,
        TextNode                  = 3,
        CDATASectionNode          = 4,
        EntityReferenceNode       = 5,
        EntityNode                = 6,
        ProcessingInstructionNode = 7,
        CommentNode               = 8,
        DocumentNode              = 9,
        DocumentTypeNode          = 10,
        DocumentFragmentNode      = 11,
        NotationNode              = 12,
        BaseNode                  = 21,// this is not in the standard
        CharacterDataNode         = 22 // this is not in the standard
    };

    enum EncodingPolicy
    {
        EncodingFromDocument      = 1,
        EncodingFromTextStream    = 2
    };

    CscsDomNode();
    CscsDomNode(const CscsDomNode&);
    CscsDomNode& operator= (const CscsDomNode&);
    bool operator== (const CscsDomNode&) const;
    bool operator!= (const CscsDomNode&) const;
    ~CscsDomNode();

    // DOM functions
    CscsDomNode insertBefore(const CscsDomNode& newChild, const CscsDomNode& refChild);
    CscsDomNode insertAfter(const CscsDomNode& newChild, const CscsDomNode& refChild);
    CscsDomNode replaceChild(const CscsDomNode& newChild, const CscsDomNode& oldChild);
    CscsDomNode removeChild(const CscsDomNode& oldChild);
    CscsDomNode appendChild(const CscsDomNode& newChild);
    bool hasChildNodes() const;
    CscsDomNode cloneNode(bool deep = true) const;
    void normalize();
    bool isSupported(const CscsString& feature, const CscsString& version) const;

    // DOM read-only attributes
    CscsString nodeName() const;
    NodeType nodeType() const;
    CscsDomNode parentNode() const;
    CscsDomNodeList childNodes() const;
    CscsDomNode firstChild() const;
    CscsDomNode lastChild() const;
    CscsDomNode previousSibling() const;
    CscsDomNode nextSibling() const;
    CscsDomNamedNodeMap attributes() const;
    CscsDomDocument ownerDocument() const;
    CscsString namespaceURI() const;
    CscsString localName() const;
    bool hasAttributes() const;

    // DOM attributes
    CscsString nodeValue() const;
    void setNodeValue(const CscsString&);
    CscsString prefix() const;
    void setPrefix(const CscsString& pre);

    // SCS extensions
    bool isAttr() const;
    bool isCDATASection() const;
    bool isDocumentFragment() const;
    bool isDocument() const;
    bool isDocumentType() const;
    bool isElement() const;
    bool isEntityReference() const;
    bool isText() const;
    bool isEntity() const;
    bool isNotation() const;
    bool isProcessingInstruction() const;
    bool isCharacterData() const;
    bool isComment() const;

    /**
     * Shortcut to avoid dealing with CscsDomNodeList
     * all the time.
     */
    CscsDomNode namedItem(const CscsString& name) const;

    bool isNull() const;
    void clear();

    CscsDomAttr toAttr() const;
    CscsDomCDATASection toCDATASection() const;
    CscsDomDocumentFragment toDocumentFragment() const;
    CscsDomDocument toDocument() const;
    CscsDomDocumentType toDocumentType() const;
    CscsDomElement toElement() const;
    CscsDomEntityReference toEntityReference() const;
    CscsDomText toText() const;
    CscsDomEntity toEntity() const;
    CscsDomNotation toNotation() const;
    CscsDomProcessingInstruction toProcessingInstruction() const;
    CscsDomCharacterData toCharacterData() const;
    CscsDomComment toComment() const;

    void save(CscsTextStream&, int) const;
    void save(CscsTextStream&, int, EncodingPolicy) const; // ### SCS 5: Merge overload(if we at all keep this)

    CscsDomElement firstChildElement(const CscsString &tagName = CscsString()) const;
    CscsDomElement lastChildElement(const CscsString &tagName = CscsString()) const;
    CscsDomElement previousSiblingElement(const CscsString &tagName = CscsString()) const;
    CscsDomElement nextSiblingElement(const CscsString &taName = CscsString()) const;

    int lineNumber() const;
    int columnNumber() const;

protected:
    CscsDomNodePrivate* impl;
    CscsDomNode(CscsDomNodePrivate*);

private:
    friend class CscsDomDocument;
    friend class CscsDomDocumentType;
    friend class CscsDomNodeList;
    friend class CscsDomNamedNodeMap;
};

class  CscsDomNodeList
{
public:
    CscsDomNodeList();
    CscsDomNodeList(const CscsDomNodeList&);
    CscsDomNodeList& operator= (const CscsDomNodeList&);
    bool operator== (const CscsDomNodeList&) const;
    bool operator!= (const CscsDomNodeList&) const;
    ~CscsDomNodeList();

    // DOM functions
    CscsDomNode item(int index) const;
    inline CscsDomNode at(int index) const { return item(index); } // SCS API consistency

    // DOM read only attributes
    uint length() const;
    inline int count() const { return length(); } // SCS API consitancy
    inline int size() const { return length(); } // SCS API consistency
    inline bool isEmpty() const { return length() == 0; } // SCS API consistency

private:
    CscsDomNodeListPrivate* impl;
    CscsDomNodeList(CscsDomNodeListPrivate*);

    friend class CscsDomNode;
    friend class CscsDomElement;
    friend class CscsDomDocument;
};

class  CscsDomDocumentType : public CscsDomNode
{
public:
    CscsDomDocumentType();
    CscsDomDocumentType(const CscsDomDocumentType& x);
    CscsDomDocumentType& operator= (const CscsDomDocumentType&);

    // DOM read only attributes
    CscsString name() const;
    CscsDomNamedNodeMap entities() const;
    CscsDomNamedNodeMap notations() const;
    CscsString publicId() const;
    CscsString systemId() const;
    CscsString internalSubset() const;

    // Overridden from CscsDomNode
    inline CscsDomNode::NodeType nodeType() const { return DocumentTypeNode; }

private:
    CscsDomDocumentType(CscsDomDocumentTypePrivate*);

    friend class CscsDomImplementation;
    friend class CscsDomDocument;
    friend class CscsDomNode;
};

class  CscsDomDocument : public CscsDomNode
{
public:
    CscsDomDocument();
    explicit CscsDomDocument(const CscsString& name);
    explicit CscsDomDocument(const CscsDomDocumentType& doctype);
    CscsDomDocument(const CscsDomDocument& x);
    CscsDomDocument& operator= (const CscsDomDocument&);
    ~CscsDomDocument();

    // DOM functions
    CscsDomElement createElement(const CscsString& tagName);
    CscsDomDocumentFragment createDocumentFragment();
    CscsDomText createTextNode(const CscsString& data);
    CscsDomComment createComment(const CscsString& data);
    CscsDomCDATASection createCDATASection(const CscsString& data);
    CscsDomProcessingInstruction createProcessingInstruction(const CscsString& target, const CscsString& data);
    CscsDomAttr createAttribute(const CscsString& name);
    CscsDomEntityReference createEntityReference(const CscsString& name);
    CscsDomNodeList elementsByTagName(const CscsString& tagname) const;
    CscsDomNode importNode(const CscsDomNode& importedNode, bool deep);
    CscsDomElement createElementNS(const CscsString& nsURI, const CscsString& sName);
    CscsDomAttr createAttributeNS(const CscsString& nsURI, const CscsString& sName);
    CscsDomNodeList elementsByTagNameNS(const CscsString& nsURI, const CscsString& localName);
    CscsDomElement elementById(const CscsString& elementId);

    // DOM read only attributes
    CscsDomDocumentType doctype() const;
    CscsDomImplementation implementation() const;
    CscsDomElement documentElement() const;

    // Overridden from CscsDomNode
    inline CscsDomNode::NodeType nodeType() const { return DocumentNode; }

    // SCS extensions
    bool setContent(const CscsByteArray& text, bool namespaceProcessing, CscsString *errorMsg=0, int *errorLine=0, int *errorColumn=0 );
    bool setContent(const CscsString& text, bool namespaceProcessing, CscsString *errorMsg=0, int *errorLine=0, int *errorColumn=0 );
    bool setContent(CscsDevice* dev, bool namespaceProcessing, CscsString *errorMsg=0, int *errorLine=0, int *errorColumn=0 );
    bool setContent(const CscsByteArray& text, CscsString *errorMsg=0, int *errorLine=0, int *errorColumn=0 );
    bool setContent(const CscsString& text, CscsString *errorMsg=0, int *errorLine=0, int *errorColumn=0 );
    bool setContent(CscsDevice* dev, CscsString *errorMsg=0, int *errorLine=0, int *errorColumn=0 );
    bool setContent(CscsXmlInputSource *source, CscsXmlReader *reader, CscsString *errorMsg=0, int *errorLine=0, int *errorColumn=0 );

    // SCS extensions
    CscsString toString(int = 1) const;
    CscsByteArray toByteArray(int = 1) const;

private:
    CscsDomDocument(CscsDomDocumentPrivate*);

    friend class CscsDomNode;
};

class  CscsDomNamedNodeMap
{
public:
    CscsDomNamedNodeMap();
    CscsDomNamedNodeMap(const CscsDomNamedNodeMap&);
    CscsDomNamedNodeMap& operator= (const CscsDomNamedNodeMap&);
    bool operator== (const CscsDomNamedNodeMap&) const;
    bool operator!= (const CscsDomNamedNodeMap&) const;
    ~CscsDomNamedNodeMap();

    // DOM functions
    CscsDomNode namedItem(const CscsString& name) const;
    CscsDomNode setNamedItem(const CscsDomNode& newNode);
    CscsDomNode removeNamedItem(const CscsString& name);
    CscsDomNode item(int index) const;
    CscsDomNode namedItemNS(const CscsString& nsURI, const CscsString& localName) const;
    CscsDomNode setNamedItemNS(const CscsDomNode& newNode);
    CscsDomNode removeNamedItemNS(const CscsString& nsURI, const CscsString& localName);

    // DOM read only attributes
    uint length() const;
    int count() const { return length(); } // SCS API consitancy
    inline int size() const { return length(); } // SCS API consistency
    inline bool isEmpty() const { return length() == 0; } // SCS API consistency

    // SCS extension
    bool contains(const CscsString& name) const;

private:
    CscsDomNamedNodeMapPrivate* impl;
    CscsDomNamedNodeMap(CscsDomNamedNodeMapPrivate*);

    friend class CscsDomNode;
    friend class CscsDomDocumentType;
    friend class CscsDomElement;
};

class  CscsDomDocumentFragment : public CscsDomNode
{
public:
    CscsDomDocumentFragment();
    CscsDomDocumentFragment(const CscsDomDocumentFragment& x);
    CscsDomDocumentFragment& operator= (const CscsDomDocumentFragment&);

    // Overridden from CscsDomNode
    inline CscsDomNode::NodeType nodeType() const { return DocumentFragmentNode; }

private:
    CscsDomDocumentFragment(CscsDomDocumentFragmentPrivate*);

    friend class CscsDomDocument;
    friend class CscsDomNode;
};

class  CscsDomCharacterData : public CscsDomNode
{
public:
    CscsDomCharacterData();
    CscsDomCharacterData(const CscsDomCharacterData& x);
    CscsDomCharacterData& operator= (const CscsDomCharacterData&);

    // DOM functions
    CscsString substringData(unsigned long offset, unsigned long count);
    void appendData(const CscsString& arg);
    void insertData(unsigned long offset, const CscsString& arg);
    void deleteData(unsigned long offset, unsigned long count);
    void replaceData(unsigned long offset, unsigned long count, const CscsString& arg);

    // DOM read only attributes
    uint length() const;

    // DOM attributes
    CscsString data() const;
    void setData(const CscsString&);

    // Overridden from CscsDomNode
    CscsDomNode::NodeType nodeType() const;

private:
    CscsDomCharacterData(CscsDomCharacterDataPrivate*);

    friend class CscsDomDocument;
    friend class CscsDomText;
    friend class CscsDomComment;
    friend class CscsDomNode;
};

class  CscsDomAttr : public CscsDomNode
{
public:
    CscsDomAttr();
    CscsDomAttr(const CscsDomAttr& x);
    CscsDomAttr& operator= (const CscsDomAttr&);

    // DOM read only attributes
    CscsString name() const;
    bool specified() const;
    CscsDomElement ownerElement() const;

    // DOM attributes
    CscsString value() const;
    void setValue(const CscsString&);

    // Overridden from CscsDomNode
    inline CscsDomNode::NodeType nodeType() const { return AttributeNode; }

private:
    CscsDomAttr(CscsDomAttrPrivate*);

    friend class CscsDomDocument;
    friend class CscsDomElement;
    friend class CscsDomNode;
};

class  CscsDomElement : public CscsDomNode
{
public:
    CscsDomElement();
    CscsDomElement(const CscsDomElement& x);
    CscsDomElement& operator= (const CscsDomElement&);

    // DOM functions
    CscsString attribute(const CscsString& name, const CscsString& defValue = CscsString() ) const;
    void setAttribute(const CscsString& name, const CscsString& value);
    void setAttribute(const CscsString& name, int64 value);
    void setAttribute(const CscsString& name, uint64 value);
    inline void setAttribute(const CscsString& name, int value)
        { setAttribute(name, int64(value)); }
    inline void setAttribute(const CscsString& name, uint value)
        { setAttribute(name, uint64(value)); }
    void setAttribute(const CscsString& name, float value);
    void setAttribute(const CscsString& name, double value);
    void removeAttribute(const CscsString& name);
    CscsDomAttr attributeNode(const CscsString& name);
    CscsDomAttr setAttributeNode(const CscsDomAttr& newAttr);
    CscsDomAttr removeAttributeNode(const CscsDomAttr& oldAttr);
    CscsDomNodeList elementsByTagName(const CscsString& tagname) const;
    bool hasAttribute(const CscsString& name) const;

    CscsString attributeNS(const CscsString nsURI, const CscsString& localName, const CscsString& defValue = CscsString()) const;
    void setAttributeNS(const CscsString nsURI, const CscsString& sName, const CscsString& value);
    inline void setAttributeNS(const CscsString nsURI, const CscsString& sName, int value)
        { setAttributeNS(nsURI, sName, int64(value)); }
    inline void setAttributeNS(const CscsString nsURI, const CscsString& sName, uint value)
        { setAttributeNS(nsURI, sName, uint64(value)); }
    void setAttributeNS(const CscsString nsURI, const CscsString& sName, int64 value);
    void setAttributeNS(const CscsString nsURI, const CscsString& sName, uint64 value);
    void setAttributeNS(const CscsString nsURI, const CscsString& sName, double value);
    void removeAttributeNS(const CscsString& nsURI, const CscsString& localName);
    CscsDomAttr attributeNodeNS(const CscsString& nsURI, const CscsString& localName);
    CscsDomAttr setAttributeNodeNS(const CscsDomAttr& newAttr);
    CscsDomNodeList elementsByTagNameNS(const CscsString& nsURI, const CscsString& localName) const;
    bool hasAttributeNS(const CscsString& nsURI, const CscsString& localName) const;

    // DOM read only attributes
    CscsString tagName() const;
    void setTagName(const CscsString& name); // SCS extension

    // Overridden from CscsDomNode
    CscsDomNamedNodeMap attributes() const;
    inline CscsDomNode::NodeType nodeType() const { return ElementNode; }

    CscsString text() const;

private:
    CscsDomElement(CscsDomElementPrivate*);

    friend class CscsDomDocument;
    friend class CscsDomNode;
    friend class CscsDomAttr;
};

class  CscsDomText : public CscsDomCharacterData
{
public:
    CscsDomText();
    CscsDomText(const CscsDomText& x);
    CscsDomText& operator= (const CscsDomText&);

    // DOM functions
    CscsDomText splitText(int offset);

    // Overridden from CscsDomCharacterData
    inline CscsDomNode::NodeType nodeType() const { return TextNode; }

private:
    CscsDomText(CscsDomTextPrivate*);

    friend class CscsDomCDATASection;
    friend class CscsDomDocument;
    friend class CscsDomNode;
};

class  CscsDomComment : public CscsDomCharacterData
{
public:
    CscsDomComment();
    CscsDomComment(const CscsDomComment& x);
    CscsDomComment& operator= (const CscsDomComment&);

    // Overridden from CscsDomCharacterData
    inline CscsDomNode::NodeType nodeType() const { return CommentNode; }

private:
    CscsDomComment(CscsDomCommentPrivate*);

    friend class CscsDomDocument;
    friend class CscsDomNode;
};

class  CscsDomCDATASection : public CscsDomText
{
public:
    CscsDomCDATASection();
    CscsDomCDATASection(const CscsDomCDATASection& x);
    CscsDomCDATASection& operator= (const CscsDomCDATASection&);

    // Overridden from CscsDomText
    inline CscsDomNode::NodeType nodeType() const { return CDATASectionNode; }

private:
    CscsDomCDATASection(CscsDomCDATASectionPrivate*);

    friend class CscsDomDocument;
    friend class CscsDomNode;
};

class  CscsDomNotation : public CscsDomNode
{
public:
    CscsDomNotation();
    CscsDomNotation(const CscsDomNotation& x);
    CscsDomNotation& operator= (const CscsDomNotation&);

    // DOM read only attributes
    CscsString publicId() const;
    CscsString systemId() const;

    // Overridden from CscsDomNode
    inline CscsDomNode::NodeType nodeType() const { return NotationNode; }

private:
    CscsDomNotation(CscsDomNotationPrivate*);

    friend class CscsDomDocument;
    friend class CscsDomNode;
};

class  CscsDomEntity : public CscsDomNode
{
public:
    CscsDomEntity();
    CscsDomEntity(const CscsDomEntity& x);
    CscsDomEntity& operator= (const CscsDomEntity&);

    // DOM read only attributes
    CscsString publicId() const;
    CscsString systemId() const;
    CscsString notationName() const;

    // Overridden from CscsDomNode
    inline CscsDomNode::NodeType nodeType() const { return EntityNode; }

private:
    CscsDomEntity(CscsDomEntityPrivate*);

    friend class CscsDomNode;
};

class  CscsDomEntityReference : public CscsDomNode
{
public:
    CscsDomEntityReference();
    CscsDomEntityReference(const CscsDomEntityReference& x);
    CscsDomEntityReference& operator= (const CscsDomEntityReference&);

    // Overridden from CscsDomNode
    inline CscsDomNode::NodeType nodeType() const { return EntityReferenceNode; }

private:
    CscsDomEntityReference(CscsDomEntityReferencePrivate*);

    friend class CscsDomDocument;
    friend class CscsDomNode;
};

class  CscsDomProcessingInstruction : public CscsDomNode
{
public:
    CscsDomProcessingInstruction();
    CscsDomProcessingInstruction(const CscsDomProcessingInstruction& x);
    CscsDomProcessingInstruction& operator= (const CscsDomProcessingInstruction&);

    // DOM read only attributes
    CscsString target() const;

    // DOM attributes
    CscsString data() const;
    void setData(const CscsString& d);

    // Overridden from CscsDomNode
    inline CscsDomNode::NodeType nodeType() const { return ProcessingInstructionNode; }

private:
    CscsDomProcessingInstruction(CscsDomProcessingInstructionPrivate*);

    friend class CscsDomDocument;
    friend class CscsDomNode;
};

END_NAMESPACE

#endif
