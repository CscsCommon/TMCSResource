#ifndef SCSBYTEARRAYMATCHER_H
#define SCSBYTEARRAYMATCHER_H
#include "scsbytearray.h"

BEGIN_NAMESPACE(Gemini)

class CscsByteArrayMatcherPrivate;

class  CscsByteArrayMatcher
{
public:
    CscsByteArrayMatcher();
    explicit CscsByteArrayMatcher(const CscsByteArray &pattern);
    CscsByteArrayMatcher(const CscsByteArrayMatcher &other);
    ~CscsByteArrayMatcher();

    CscsByteArrayMatcher &operator=(const CscsByteArrayMatcher &other);

    void setPattern(const CscsByteArray &pattern);

    int indexIn(const CscsByteArray &ba, int from = 0) const;
    inline CscsByteArray pattern() const { return q_pattern; }

private:
    CscsByteArrayMatcherPrivate *d;
    CscsByteArray q_pattern;
    uint q_skiptable[256];
};

END_NAMESPACE

#endif
