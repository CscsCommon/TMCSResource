#ifndef SCSSET_H
#define SCSSET_H
#include "scshash.h"


BEGIN_NAMESPACE(Gemini)

template <class T>
class CscsSet
{
    typedef CscsHash<T, CscsHashDummyValue> Hash;

public:
    inline CscsSet() {}
    inline CscsSet(const CscsSet<T> &other) : scs_hash(other.scs_hash) {}

    inline CscsSet<T> &operator=(const CscsSet<T> &other)
        { scs_hash = other.scs_hash; return *this; }

    inline bool operator==(const CscsSet<T> &other) const
        { return scs_hash == other.scs_hash; }
    inline bool operator!=(const CscsSet<T> &other) const
        { return scs_hash != other.scs_hash; }

    inline int size() const { return scs_hash.size(); }

    inline bool isEmpty() const { return scs_hash.isEmpty(); }

    inline int capacity() const { return scs_hash.capacity(); }
    inline void reserve(int size);
    inline void squeeze() { scs_hash.squeeze(); }

    inline void detach() { scs_hash.detach(); }
    inline bool isDetached() const { return scs_hash.isDetached(); }

    inline void clear() { scs_hash.clear(); }

    inline bool remove(const T &value) { return scs_hash.remove(value) != 0; }

    inline bool contains(const T &value) const { return scs_hash.contains(value); }

    class const_iterator
    {
        typedef CscsHash<T, CscsHashDummyValue> Hash;
        typename Hash::const_iterator i;

    public:
        typedef std::bidirectional_iterator_tag iterator_category;
        typedef ptrdiff_t difference_type;
        typedef T value_type;
        typedef T *pointer;
        typedef T &reference;

        inline const_iterator() {}
        inline const_iterator(typename Hash::const_iterator o) : i(o) {}
        inline const_iterator(const const_iterator &o) : i(o.i) {}
        inline const_iterator &operator=(const const_iterator &o) { i = o.i; return *this; }
        inline const T &operator*() const { return i.key(); }
        inline const T *operator->() const { return &i.key(); }
        inline bool operator==(const const_iterator &o) const { return i == o.i; }
        inline bool operator!=(const const_iterator &o) const { return i != o.i; }
        inline const_iterator &operator++() { ++i; return *this; }
        inline const_iterator operator++(int) { const_iterator r = *this; ++i; return r; }
        inline const_iterator &operator--() { --i; return *this; }
        inline const_iterator operator--(int) { const_iterator r = *this; --i; return r; }
        inline const_iterator operator+(int j) const { return i + j; }
        inline const_iterator operator-(int j) const { return i - j; }
        inline const_iterator &operator+=(int j) { i += j; return *this; }
        inline const_iterator &operator-=(int j) { i -= j; return *this; }
    };

    // STL style
    inline const_iterator begin() const { return scs_hash.begin(); }
    inline const_iterator constBegin() const { return scs_hash.constBegin(); }
    inline const_iterator end() const { return scs_hash.end(); }
    inline const_iterator constEnd() const { return scs_hash.constEnd(); }

    // more Qt
    typedef const_iterator ConstIterator;
    inline int count() const { return scs_hash.count(); }
    inline const_iterator insert(const T &value)
        { return static_cast<typename Hash::const_iterator>(scs_hash.insert(value,
                                                                          CscsHashDummyValue())); }
    CscsSet<T> &unite(const CscsSet<T> &other);
    CscsSet<T> &intersect(const CscsSet<T> &other);
    CscsSet<T> &subtract(const CscsSet<T> &other);

    // STL compatibility
    inline bool empty() const { return isEmpty(); }

    // comfort
    inline CscsSet<T> &operator<<(const T &value) { insert(value); return *this; }
    inline CscsSet<T> &operator|=(const CscsSet<T> &other) { unite(other); return *this; }
    inline CscsSet<T> &operator|=(const T &value) { insert(value); return *this; }
    inline CscsSet<T> &operator&=(const CscsSet<T> &other) { intersect(other); return *this; }
    inline CscsSet<T> &operator&=(const T &value)
        { CscsSet<T> result; if (contains(value)) result.insert(value); return (*this = result); }
    inline CscsSet<T> &operator+=(const CscsSet<T> &other) { unite(other); return *this; }
    inline CscsSet<T> &operator+=(const T &value) { insert(value); return *this; }
    inline CscsSet<T> &operator-=(const CscsSet<T> &other) { subtract(other); return *this; }
    inline CscsSet<T> &operator-=(const T &value) { subtract(value); return *this; }
    inline CscsSet<T> operator|(const CscsSet<T> &other)
        { CscsSet<T> result = *this; result |= other; return result; }
    inline CscsSet<T> operator&(const CscsSet<T> &other)
        { CscsSet<T> result = *this; result &= other; return result; }
    inline CscsSet<T> operator+(const CscsSet<T> &other)
        { CscsSet<T> result = *this; result += other; return result; }
    inline CscsSet<T> operator-(const CscsSet<T> &other)
        { CscsSet<T> result = *this; result -= other; return result; }

    CscsList<T> toList() const;
    inline CscsList<T> values() const { return toList(); }

    static CscsSet<T> fromList(const CscsList<T> &list);

private:
    Hash scs_hash;
};

template <class T>
inline void CscsSet<T>::reserve(int asize) { scs_hash.reserve(asize); }

template <class T>
inline CscsSet<T> &CscsSet<T>::unite(const CscsSet<T> &other)
{
    CscsSet<T> copy(other);
    typename CscsSet<T>::const_iterator i = copy.constEnd();
    while (i != copy.constBegin()) {
        --i;
        insert(*i);
    }
    return *this;
}

template <class T>
inline CscsSet<T> &CscsSet<T>::intersect(const CscsSet<T> &other)
{
    CscsSet<T> copy1(*this);
    CscsSet<T> copy2(other);
    typename CscsSet<T>::const_iterator i = copy1.constEnd();
    while (i != copy1.constBegin()) {
        --i;
        if (!copy2.contains(*i))
            remove(*i);
    }
    return *this;
}

template <class T>
inline CscsSet<T> &CscsSet<T>::subtract(const CscsSet<T> &other)
{
    CscsSet<T> copy1(*this);
    CscsSet<T> copy2(other);
    typename CscsSet<T>::const_iterator i = copy1.constEnd();
    while (i != copy1.constBegin()) {
        --i;
        if (copy2.contains(*i))
            remove(*i);
    }
    return *this;
}

template <typename T>
inline CscsList<T> CscsSet<T>::toList() const
{
    CscsList<T> result;
    typename CscsSet<T>::const_iterator i = constBegin();
    while (i != constEnd()) {
        result.append(*i);
        ++i;
    }
    return result;
}

template <typename T>
inline CscsSet<T> CscsList<T>::toSet() const
{
    CscsSet<T> result;
    result.reserve(size());
    for (int i = 0; i < size(); ++i)
        result.insert(at(i));
    return result;
}

template <typename T>
CscsSet<T> CscsSet<T>::fromList(const CscsList<T> &list)
{
    return list.toSet();
}

template <typename T>
CscsList<T> CscsList<T>::fromSet(const CscsSet<T> &set)
{
    return set.toList();
}

SCS_DECLARE_SEQUENTIAL_ITERATOR(Set)

END_NAMESPACE

#endif