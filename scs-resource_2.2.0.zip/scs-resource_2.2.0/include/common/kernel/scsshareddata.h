#ifndef SCSSHAREDDATA_H
#define SCSSHAREDDATA_H
#include <atomic>
#include "scsnamespace.h"

BEGIN_NAMESPACE(Gemini)

template <class T> class CscsSharedDataPointer;
class  CscsSharedData
{
public:
    std::atomic<int> ref;

    inline CscsSharedData() : ref(0) { }
    inline CscsSharedData(const CscsSharedData &) : ref(0) { }

private:
    // using the assignment operator would lead to corruption in the ref-counting
    CscsSharedData &operator=(const CscsSharedData &);
};


template <class T> class CscsSharedDataPointer
{
public:
    inline void detach() { if (d && d->ref != 1) detach_helper(); }
    inline T &operator*() { detach(); return *d; }
    inline const T &operator*() const { return *d; }
    inline T *operator->() { detach(); return d; }
    inline const T *operator->() const { return d; }
    inline operator T *() { detach(); return d; }
    inline operator const T *() const { return d; }
    inline T *data() { detach(); return d; }
    inline const T *data() const { return d; }
    inline const T *constData() const { return d; }

    inline bool operator==(const CscsSharedDataPointer<T> &other) const { return d == other.d; }
    inline bool operator!=(const CscsSharedDataPointer<T> &other) const { return d != other.d; }

    inline CscsSharedDataPointer() { d = 0; }
    inline ~CscsSharedDataPointer() { if (d && !--d->ref) delete d; }

    explicit CscsSharedDataPointer(T *data);
    inline CscsSharedDataPointer(const CscsSharedDataPointer &o) : d(o.d) { if (d) d->ref++; }
    inline CscsSharedDataPointer & operator=(const CscsSharedDataPointer &o) {
        if (o.d != d) {
            T *x = o.d;
            if (x) x->ref++;
            {
            	T* tmp=x;
            	x=d;
            	d=tmp;
            }
            if (x && !--x->ref)
                delete x;
        }
        return *this;
    }
    inline CscsSharedDataPointer &operator=(T *o) {
        if (o != d) {
            T *x = o;
            if (x) x->ref++;
            {
            	T* tmp=x;
            	x=d;
            	d=tmp;
            }
            if (x && !--x->ref)
                delete x;
        }
        return *this;
    }

    inline bool operator!() const { return !d; }

private:
    void detach_helper();

    T *d;
};

template <class T>
inline CscsSharedDataPointer<T>::CscsSharedDataPointer(T *adata) : d(adata)
{ if (d) d->ref++; }

template <class T>
 void CscsSharedDataPointer<T>::detach_helper()
{
    T *x = new T(*d);
    x->ref++;
    {
    	T* tmp=x;
    	x=d;
    	d=tmp;
    }
    if (!--x->ref)
        delete x;
}

END_NAMESPACE

#endif