#ifndef SCSPOINTER_H
#define SCSPOINTER_H
#include "scsobject.h"
#include "scshash.h"
#include "scswritereadlock.h"

BEGIN_NAMESPACE(Gemini)

typedef CscsMultiHash<CscsObject* ,CscsObject**> GuardHash;



struct CscsMetaObject{
	static void addGuard(CscsObject **ptr);
    static void removeGuard(CscsObject **ptr);
    static void changeGuard(CscsObject **ptr, CscsObject *o);
};

template <class T>
class CscsPointer
{
    CscsObject *o;
public:
    inline CscsPointer() : o(0) {}
    inline CscsPointer(T *p) : o(p)
        { CscsMetaObject::addGuard(&o); }
    inline CscsPointer(const CscsPointer<T> &p) : o(p.o)
        { CscsMetaObject::addGuard(&o); }
    inline ~CscsPointer()
        { CscsMetaObject::removeGuard(&o); }
    inline CscsPointer<T> &operator=(const CscsPointer<T> &p)
        { if (this != &p) CscsMetaObject::changeGuard(&o, p.o); return *this; }
    inline CscsPointer<T> &operator=(T* p)
        { if (o != p) CscsMetaObject::changeGuard(&o, p); return *this; }

    inline bool isNull() const
        { return !o; }
        
    inline T* data() const
    { return static_cast<T*>( const_cast<CscsObject*>(o)); }

    inline T* operator->() const
        { return static_cast<T*>(const_cast<CscsObject*>(o)); }
    inline T& operator*() const
        { return *static_cast<T*>(const_cast<CscsObject*>(o)); }
    inline operator T*() const
        { return static_cast<T*>(const_cast<CscsObject*>(o)); }
};


template <class T>
inline bool operator==(const T *o, const CscsPointer<T> &p)
{ return o == p.operator->(); }

template<class T>
inline bool operator==(const CscsPointer<T> &p, const T *o)
{ return p.operator->() == o; }

template <class T>
inline bool operator==(T *o, const CscsPointer<T> &p)
{ return o == p.operator->(); }

template<class T>
inline bool operator==(const CscsPointer<T> &p, T *o)
{ return p.operator->() == o; }

template<class T>
inline bool operator==(const CscsPointer<T> &p1, const CscsPointer<T> &p2)
{ return p1.operator->() == p2.operator->(); }


template <class T>
inline bool operator!=(const T *o, const CscsPointer<T> &p)
{ return o != p.operator->(); }

template<class T>
inline bool operator!= (const CscsPointer<T> &p, const T *o)
{ return p.operator->() != o; }

template <class T>
inline bool operator!=(T *o, const CscsPointer<T> &p)
{ return o != p.operator->(); }

template<class T>
inline bool operator!= (const CscsPointer<T> &p, T *o)
{ return p.operator->() != o; }

template<class T>
inline bool operator!= (const CscsPointer<T> &p1, const CscsPointer<T> &p2)
{ return p1.operator->() != p2.operator->() ; }


// extern GuardHash g_guardhash;
// extern CscsWriteReadLock g_guardHashLock;

END_NAMESPACE

#endif