/*Created by J.Wong 2018/10/16
version:    version 1.0,
dependency: base on  or greater than c++11
function: type erase
gcc4.9+
*/
#ifndef SCSDEVICE_H
#define SCSDEVICE_H

#include "scsobject.h"
#include "scstypes.h"
#include "scsflags.h"
#include "scsbytearray.h"
#include "scsstring.h"
#include <string>
#include <config.h>
#ifdef D_WIN32
#include <windows.h>
#endif

BEGIN_NAMESPACE(Gemini)

class CscsDevicePrivate;

class CscsDevice:public CscsObject{
public:
  enum SCSOpenModeFlag{
    NotOpen=0x00,
    ReadOnly=0x01,
    WriteOnly=0x02,
    ReadWrite=ReadOnly|WriteOnly,
    Append=0x04,
    Truncate=0x08,
    Text=0x0010,
    Unbuffered=0x0020
  };

  SCS_DECLARE_FLAGS(SCSOpenMode, SCSOpenModeFlag)

  CscsDevice(CscsObject* parent=0);
  virtual ~CscsDevice();

  SCSOpenMode openMode()const;

  void setTextModeEnable(bool enabled);
  bool isTextModeEnable()const;
  bool isOpen()const;
  bool isReadable()const;
  bool isWritable()const;

  virtual bool isSequential()const;
  virtual bool open(SCSOpenMode mode);
  virtual void close();
  
  virtual int64 pos()const;
  virtual int64 size()const;
  virtual bool seek(int64 pos);
  virtual bool atEnd()const;
  virtual bool reset();

  virtual int64 bytesAvailable()const;
  virtual int64 bytesToWrite()const;

  int64 read(char* data, int maxlen);
  CscsByteArray read(int maxlen);
  CscsByteArray readAll();
  int64 readLine(char* data, int64 maxlen);
  CscsByteArray readLine(int64 maxlen=0);

  virtual bool canReadLine()const;

  int64 write(const char* data, int64 len);
  inline int64 write(const CscsByteArray& data){

    return write(data.data(),data.size());
  }

  int64 peek(char* data, int64 maxlen);
  CscsByteArray peek(int64 maxlen);
  virtual bool waitForReadyRead(int msecs);
  virtual bool waitForBytesWritten(int msecs);
  
  void ungetChar(char c);
  
  bool putChar(char c);

  bool getChar(char* c);
  

  std::string errorString()const;


  void setOpenMode(SCSOpenMode openMode);
  void setErrorString(const std::string& error);
//signals
public:
  void readRead(){}
  void bytesWritten(int64 bytes){}
  void aboutToClose(){}

protected:
  CscsDevice(CscsDevicePrivate* dd, CscsObject *parent = 0);
  virtual int64 readData(char* data, int64 maxlen)=0;
  virtual int64 readLineData(char* data, int64 maxlen);
  virtual int64 writeData(const char* data, int64 len)=0;


private:
   CscsDevicePrivate* d_func()const;
};


SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsDevice::SCSOpenMode)

inline  CscsString scs_error_string(int errorCode)
{
    const char *s = 0;
    CscsString ret;
    if (errorCode == -1) {
    #if defined(D_WIN32)
            errorCode = GetLastError();
    #else
            errorCode = errno;
    #endif
    }
    switch (errorCode) {
        case 0:
            break;
        case EACCES:
            s = "CscsDevice: Permission denied";
            break;
        case EMFILE:
            s = "CscsDevice: Too many open files";
            break;
        case ENOENT:
            s = "CscsDevice: No such file or directory";
            break;
        case ENOSPC:
            s = "CscsDevice: No space left on device";
            break;
        default: {
            ret = CscsString::fromLocal8Bit(strerror(errorCode));
            break; 
        }
    }
    if (s)
        ret = CscsString::fromLatin1(s);
    return ret.trimmed();
}

END_NAMESPACE
#endif
