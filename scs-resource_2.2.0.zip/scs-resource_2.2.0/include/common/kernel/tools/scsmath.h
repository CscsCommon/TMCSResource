#ifndef SCSMATH_H
#define SCSMATH_H
#include <cmath>
#include <kernel/scsnamespace.h>

///////////////////////////////////////////////////////////
//  global.h
//  Defination of the Global function
//  Created on:      07-11月-2018 21:44:23
//  Original author: liwei.Meng
///////////////////////////////////////////////////////////


/*
   This function tests a double for a null value. It doesn't
   check whether the actual value is 0 or close to 0, but whether
   it is binary 0, disregarding sign.
*/

BEGIN_NAMESPACE(Gemini)

#define M_E        2.7182818284590452354
#define M_LOG2E		 1.4426950408889634074
#define M_LOG10E	 0.43429448190325182765
#define M_LN2		   0.69314718055994530942
#define M_LN10		 2.30258509299404568402
#define M_PI		   3.14159265358979323846
#define M_PI_2		 1.57079632679489661923
#define M_PI_4		 0.78539816339744830962
#define M_1_PI		 0.31830988618379067154
#define M_2_PI		 0.63661977236758134308
#define M_2_SQRTPI 1.12837916709551257390
#define M_SQRT2		 1.41421356237309504880
#define M_SQRT1_2	 0.70710678118654752440

typedef long long scsInt64;
typedef int scsInt32;

static inline bool scsIsNull(float f)
{
	union U{
		float f;
		unsigned int u;
	};
	U val;
	val.f = f;
	return (val.u & 0x7fffffff) == 0;
}

static inline bool scsIsNull(double d)
{
    union U{
        double d;
        unsigned long long u;
    };
    U val;
    val.d = d;
    return (val.u & 0x7fffffffffffffff) == 0;
}

template <typename T>
constexpr inline const T &scsMin(const T &a, const T &b) { return (a < b) ? a : b; }
template <typename T>
constexpr inline const T &scsMax(const T &a, const T &b) { return (a < b) ? b : a; }
template <typename T>
constexpr inline const T &scsBound(const T &min, const T &val, const T &max)
{ return scsMax(min, scsMin(max, val)); }

template <typename T>
constexpr inline T scsAbs(const T &t) { return t >= 0 ? t : -t; }

constexpr inline int scsRound(double d)
{ return d >= 0.0 ? int(d + 0.5) : int(d - double(int(d-1)) + 0.5) + int(d-1); }

constexpr inline int scsRound(float d)
{ return d >= 0.0f ? int(d + 0.5f) : int(d - float(int(d-1)) + 0.5f) + int(d-1); }

constexpr static inline bool scsFuzzyIsNull(float f)
{ return scsAbs(f) <= 0.00001f; }

// constexpr static inline bool scsFuzzyIsNull(double f)
// { return scsAbs(f) <= 0.000000000001; }

 constexpr static inline  bool scsFuzzyCompare(float p1, float p2)
{ return (scsAbs(p1 - p2) <= 0.00001f*scsMin(scsAbs(p1), scsAbs(p2))); }

 constexpr static inline  bool scsFuzzyCompare(double p1, double p2)
{ return (scsAbs(p1 - p2) <= 0.000000000001*scsMin(scsAbs(p1), scsAbs(p2))); }

inline int scsCeil(double v)
{
    using std::ceil;
    return int(ceil(v));
}

inline int scsFloor(double v)
{
    using std::floor;
    return int(floor(v));
}

inline double scsFabs(double v)
{
    using std::fabs;
    return fabs(v);
}

inline double scsSin(double v)
{
    using std::sin;
    return sin(v);
}

inline double scsCos(double v)
{
    using std::cos;
    return cos(v);
}

inline double scsTan(double v)
{
    using std::tan;
    return tan(v);
}

inline double scsAcos(double v)
{
    using std::acos;
    return acos(v);
}

inline double scsAsin(double v)
{
    using std::asin;
    return asin(v);
}

inline double scsAtan(double v)
{
    using std::atan;
    return atan(v);
}

inline double scsAtan2(double y, double x)
{
    using std::atan2;
    return atan2(y, x);
}

inline double scsSqrt(double v)
{
    using std::sqrt;
    return sqrt(v);
}

inline double scsLn(double v)
{
    using std::log;
    return log(v);
}

inline double scsExp(double v)
{
    using std::exp;
    return exp(v);
}

inline double scsPow(double x, double y)
{
    using std::pow;
    return pow(x, y);
}
END_NAMESPACE
#endif
