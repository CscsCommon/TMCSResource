#ifndef SCSURL_H
#define SCSURL_H

#include <utility>
#include <kernel/scsstring.h>
#include <kernel/scsflags.h>
#include <kernel/scstypeinfo.h>

BEGIN_NAMESPACE(Gemini)

class CscsByteArray;
class CscsUrlPrivate;

class CscsUrl
{
public:
    // encoding / toString values
    enum FormattingOption {
        None = 0x0,
        RemoveScheme = 0x1,
        RemovePassword = 0x2,
        RemoveUserInfo = RemovePassword | 0x4,
        RemovePort = 0x8,
        RemoveAuthority = RemoveUserInfo | RemovePort | 0x10,
        RemovePath = 0x20,
        RemoveQuery = 0x40,
        RemoveFragment = 0x80,

        StripTrailingSlash = 0x10000
    };
    SCS_DECLARE_FLAGS(FormattingOptions, FormattingOption)

    CscsUrl();
    CscsUrl(const CscsString &url);
    CscsUrl(const CscsUrl &copy);
    ~CscsUrl();
   

    void setUrl(const CscsString &url);
    void setEncodedUrl(const CscsByteArray &url);

    bool isValid() const;

    bool isEmpty() const;

    void clear();

    void setScheme(const CscsString &scheme);
    CscsString scheme() const;

    void setAuthority(const CscsString &authority);
    CscsString authority() const;

    void setUserInfo(const CscsString &userInfo);
    CscsString userInfo() const;

    void setUserName(const CscsString &userName);
    CscsString userName() const;

    void setPassword(const CscsString &password);
    CscsString password() const;

    void setHost(const CscsString &host);
    CscsString host() const;

    void setPort(int port);
    int port() const;

    void setPath(const CscsString &path);
    CscsString path() const;

    void setEncodedQuery(const CscsByteArray &query);
    CscsByteArray encodedQuery() const;

    void setQueryDelimiters(char valueDelimiter, char pairDelimiter);
    char queryValueDelimiter() const;
    char queryPairDelimiter() const;

    void setQueryItems(const CscsList<std::pair<CscsString, CscsString> > &query);
    void addQueryItem(const CscsString &key, const CscsString &value);
    CscsList<std::pair<CscsString, CscsString> > queryItems() const;
    bool hasQueryItem(const CscsString &key) const;
    CscsString queryItemValue(const CscsString &key) const;
    CscsStringList allQueryItemValues(const CscsString &key) const;
    void removeQueryItem(const CscsString &key);
    void removeAllQueryItems(const CscsString &key);


    void setFragment(const CscsString &fragment);
    CscsString fragment() const;

    CscsUrl resolved(const CscsUrl &relative) const;

    bool isRelative() const;
    bool isParentOf(const CscsUrl &url) const;

    static CscsUrl fromLocalFile(const CscsString &localfile);
    CscsString toLocalFile() const;

    CscsString toString(FormattingOptions options = None) const;

    CscsByteArray toEncoded(FormattingOptions options = None) const;
    static CscsUrl fromEncoded(const CscsByteArray &url);

    void detach();
    bool isDetached() const;

    bool operator <(const CscsUrl &url) const;
    bool operator ==(const CscsUrl &url) const;
    bool operator !=(const CscsUrl &url) const;
    CscsUrl &operator =(const CscsUrl &copy);

    static CscsString fromPercentEncoding(const CscsByteArray &);
    static CscsByteArray toPercentEncoding(const CscsString &,
                                        const CscsByteArray &exclude = CscsByteArray(),
                                        const CscsByteArray &include = CscsByteArray());
    static CscsString fromPunycode(const CscsByteArray &);
    static CscsByteArray toPunycode(const CscsString &);



protected:
    CscsUrl(CscsUrlPrivate &d);

private:
    CscsUrlPrivate *d;
};
SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsUrl::FormattingOptions)

SCS_DECLARE_TYPEINFO(CscsUrl)
SCS_DECLARE_TYPENAME_INFO(CscsUrl,SCS_MOVABLE_TYPE)

END_NAMESPACE


#endif // QURL_H