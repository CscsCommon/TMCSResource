/*Created by J.Wong 2016/09/08*/
#ifndef SCSDATABUFFER_H
#define SCSDATABUFFER_H
#include <stdlib.h>
#include <utility>
#include <assert.h>
#include <kernel/scsnamespace.h>

BEGIN_NAMESPACE(Gemini)

template <typename T>
class CscsDataBuffer{
	int m_capacity;
	int m_size;
	T* m_buffer;
	CscsDataBuffer(const CscsDataBuffer&);
	public:
		CscsDataBuffer(int res=64):m_capacity(res),m_size(0)
		{
			if(res)
			{
				m_buffer=(T*)malloc(m_capacity*sizeof(T));
			}
			else
			{
				m_buffer=0;
			}
		}
		~CscsDataBuffer()
		{
			if(m_buffer)
			{
				free(m_buffer);
			}
		}
		inline void 	reset(){ m_size=0;}
		inline bool		isEmpty()const{return m_size==0;}
		inline int 		size()const{return m_size;}
		inline T*		data()const{return m_buffer;}
		inline const	T&		at(int i)const
		{
			assert(i>=0&&i<m_size);
			return m_buffer[i];
		}
		inline	const 	T& 		last()const
		{
			assert(!isEmpty());
			return m_buffer[m_size-1];
		}
		inline	const	T&		first()const
		{
			assert(!isEmpty());
			return m_buffer[0];
		}
		inline	T&		at(int i)
		{
			assert(i>=0&&i<m_size);
			return m_buffer[i];
		}
		inline	T&		last()
		{
			assert(!isEmpty());
			return m_buffer[m_size-1];
		}
		inline	T&		first()
		{
			assert(!isEmpty());
			return m_buffer[0];
		}
		
		inline void reserve(int size)
		{
			if(size>m_capacity)
			{
				if(!m_capacity)	m_capacity=1;
				
				while(m_capacity<size)	m_capacity*=2;
				m_buffer=(T*)realloc(m_buffer,m_capacity*sizeof(T));
			}
		}
		
		inline void shrink(int size)
		{
			m_capacity=size;
			if(size)
			{
				m_buffer=(T*)realloc(m_buffer,m_capacity*sizeof(T));
			}
			else
			{
				if(m_buffer)
				{
					free(m_buffer);
					m_buffer=0;
				}	
			}
		}
		
		inline void swap(CscsDataBuffer<T>& other)
		{
			std::swap(m_capacity,other.m_capacity);
			std::swap(m_size,other.m_size);
			std::swap(m_buffer,other.m_buffer);
		}
		
		inline	void add(const T& t)
		{
			reserve(m_size+1);
			m_buffer[m_size]=t;
			++m_size;
			
		}
		inline void pop_back()
		{
			assert(m_size>0);
			--m_size;
		}
		
		inline void resize(int size)
		{
			assert(size>=0);
			reserve(size);
			m_size=size;
			
		}
		
		inline CscsDataBuffer& operator<<(const T& t)
		{
			add(t);
			return *this;
		}
		
};

END_NAMESPACE

#endif