#ifndef SCSQUEUE_H
#define SCSQUEUE_H
#include "scslist.h"

BEGIN_NAMESPACE(Gemini)
template <class T>
class CscsQueue : public CscsList<T>
{
public:
    inline CscsQueue() {}
    inline ~CscsQueue() {}
    inline void enqueue(const T &t) { CscsList<T>::append(t); }
    inline T dequeue() { return CscsList<T>::takeFirst(); }
    inline T &head() { return CscsList<T>::first(); }
    inline const T &head() const { return CscsList<T>::first(); }
};



END_NAMESPACE

#endif