#ifndef SCSTEXTUNICODETABLES_H
#define SCSTEXTUNICODETABLES_H
#include <kernel/scstypes.h>
#include "scsstring.h"

BEGIN_NAMESPACE(Gemini)

namespace CscsTextUnicodeTables {

    // see http://www.unicode.org/reports/tr14/tr14-13.html
    // we don't use the XX and AI properties and map them to AL instead.
    enum LineBreakClass {
        LineBreak_OP, LineBreak_CL, LineBreak_QU, LineBreak_GL, LineBreak_NS,
        LineBreak_EX, LineBreak_SY, LineBreak_IS, LineBreak_PR, LineBreak_PO,
        LineBreak_NU, LineBreak_AL, LineBreak_ID, LineBreak_IN, LineBreak_HY,
        LineBreak_BA, LineBreak_BB, LineBreak_B2, LineBreak_ZW, LineBreak_CM,
        LineBreak_SA, LineBreak_BK, LineBreak_CR, LineBreak_LF, LineBreak_SG,
        LineBreak_CB, LineBreak_SP
    };

    inline uint surrogateToUcs4(uint16 high, uint16 low) {
        return (high<<10) + low - 0x35fdc00;
    }
    inline uint16 highSurrogate(uint ucs4) {
        return (ucs4>>10) + 0xd7c0;
    }
    inline uint16 lowSurrogate(uint ucs4) {
        return ucs4%0x400 + 0xdc00;
    }
    inline bool isHighSurrogate(uint utf16) {
        return (utf16 >= 0xd800 && utf16 < 0xdc00);
    }
    inline bool isLowSurrogate(uint utf16) {
        return (utf16 >= 0xdc00 && utf16 < 0xe000);
    }


    CscsChar::Category   category(uint ucs4);
    unsigned char   combiningClass(uint ucs4);
    CscsChar::Direction  direction(uint ucs4);
    CscsChar::UnicodeVersion  unicodeVersion(uint ucs4);
    CscsChar::Joining  joining(uint ucs4);
    bool  mirrored(uint ucs4);
    int  mirroredChar(uint ucs4);
    LineBreakClass  lineBreakClass(uint ucs4);
    int  upper(uint ucs4);
    int  lower(uint ucs4);
    int  digitValue(uint ucs4);
    CscsString  decomposition(uint ucs4);
    CscsChar::Decomposition  decompositionTag(uint ucs4);
    uint16  ligature(uint16 u1, uint16 u2);

    CscsString normalize(const CscsString &str, CscsString::NormalizationForm mode);
    CscsString normalize(const CscsString &str, CscsString::NormalizationForm mode, CscsChar::UnicodeVersion version);

    int script(const CscsChar &ch);


    enum Script {
    Common,
    Hebrew,
    Arabic,
    Syriac,
    Thaana,
    Devanagari,
    Bengali,
    Gurmukhi,
    Gujarati,
    Oriya,
    Tamil,
    Telugu,
    Kannada,
    Malayalam,
    Sinhala,
    Thai,
    Lao,
    Tibetan,
    Myanmar,
    Hangul,
    Khmer,
    Inherited,
    ScriptCount = Inherited,
    Latin = Common,
    Greek = Common,
    Cyrillic = Common,
    Armenian = Common,
    Georgian = Common,
    Ethiopic = Common,
    Cherokee = Common,
    CanadianAboriginal = Common,
    Ogham = Common,
    Runic = Common,
    Tagalog = Common,
    Hanunoo = Common,
    Buhid = Common,
    Tagbanwa = Common,
    Mongolian = Common,
    Limbu = Common,
    TaiLe = Common,
    Braille = Common,
    Hiragana = Common,
    Katakana = Common,
    Bopomofo = Common,
    Kanbun = Common,
    Yi = Common,
    Han = Common,
    OldItalic = Common,
    Gothic = Common,
    Deseret = Common,
    LinearB = Common,
    Ugaritic = Common,
    Shavian = Common,
    Osmanya = Common,
    Cypriot = Common,
    KatakanaOrHiragana = Common
};

enum { ScriptSentinel = 32 };
}



inline CscsChar::Category category(const CscsChar &c)
{
    return CscsTextUnicodeTables::category(c.unicode());
}

inline CscsChar lower(const CscsChar &c)
{
    return CscsChar(CscsTextUnicodeTables::lower(c.unicode()));
}

inline CscsChar upper(const CscsChar &c)
{
    return CscsChar(CscsTextUnicodeTables::upper(c.unicode()));
}

inline CscsChar::Direction direction(const CscsChar &c)
{
    return CscsTextUnicodeTables::direction(c.unicode());
}

inline bool mirrored(const CscsChar &c)
{
    return CscsTextUnicodeTables::mirrored(c.unicode());
}


inline CscsChar mirroredChar(const CscsChar &c)
{
    return CscsTextUnicodeTables::mirroredChar(c.unicode());
}

inline CscsChar::Joining joining(const CscsChar &c)
{
    return CscsTextUnicodeTables::joining(c.unicode());
}

inline bool isMark(const CscsChar &ch)
{
    CscsChar::Category c = CscsTextUnicodeTables::category(ch.unicode());
    return c >= CscsChar::Mark_NonSpacing && c <= CscsChar::Mark_Enclosing;
}

inline unsigned char combiningClass(const CscsChar &ch)
{
    return CscsTextUnicodeTables::combiningClass(ch.unicode());
}

inline bool isSpace(const CscsChar &ch)
{
    if(ch.unicode() >= 9 && ch.unicode() <=13) return true;
    CscsChar::Category c = CscsTextUnicodeTables::category(ch.unicode());
    return c >= CscsChar::Separator_Space && c <= CscsChar::Separator_Paragraph;
}

inline int lineBreakClass(const CscsChar &ch)
{
    return CscsTextUnicodeTables::lineBreakClass(ch.unicode());
}

END_NAMESPACE

#endif