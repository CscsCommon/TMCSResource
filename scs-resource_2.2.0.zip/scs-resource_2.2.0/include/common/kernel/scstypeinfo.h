#ifndef SCSTYPEINFO_H
#define SCSTYPEINFO_H
#include "scsstring.h"

BEGIN_NAMESPACE(Gemini)

class CscsTypeInfo{
	public:
		enum Type{
			Void =0,
			Bool =1,
			Int =2,
			UInt =3,
			Double=6,
			CscsChar=7,
			StdString=8,
			CscsString=11,
			CscsByteArray=12,

			CscsUrl = 18,
			CscsRect = 20,
	        CscsRectF = 21,
	        CscsSize = 22,
	        CscsSizeF = 23,
	        CscsLine = 24,
	        CscsLineF = 25,
	        CscsPoint = 26,
	        CscsPointF = 27,
	        CscsFont = 64,
	        CscsBrush = 66,
	        CscsRgba = 67,
	        CscsPalette = 68,
	        CscsIcon = 69,
	        CscsImage = 70,
	        CscsPolygon = 71,
	        CscsRegion = 72,
	        CscsCursor = 74,
	        CscsSizePolicy = 75,
	        CscsPen = 77,
	        CscsTextLength=78,
	        CscsTextFormat=79,

			VoidStar=128,
			Long,
			Short,
			Char,
			ULong,
			UShort,
			UChar,
			Float,
			CscsObjectStar,
			CscsWidgetStar,
			User=256
		};

		typedef void (*Destructor)(void*);
		typedef void *(*Constructor)(const void*);

		static int registerType(const char* typeName, Destructor destructor, Constructor constructor);
		static int type(const char* typeName);
		static const char *typeName(int type);
		static bool isRegistered(int type);
		static void* construct(int type, const void* copy);
		static void destroy(int type, void* data);
};

template <typename T>
void scsTypeInfoDeleteHelper(T* t){
	delete t;
}

template <typename T>
void* scsTypeInfoConstructHelper(const T* t){
	if(!t)
		return new T;
	return new T(*static_cast<const T*>(t));
}

template<typename T>
int scsRegisterTypeInfo(const char* typeName, T* =0){
	typedef void *(*ConstructPtr)(const T*);
	ConstructPtr cptr=scsTypeInfoConstructHelper<T>;
	typedef void(*DeletePtr)(T*);
	DeletePtr dptr=scsTypeInfoDeleteHelper<T>;
	return CscsTypeInfo::registerType(typeName,reinterpret_cast<CscsTypeInfo::Destructor>(dptr),reinterpret_cast<CscsTypeInfo::Constructor>(cptr));
}

template <typename T>
struct CscsTypeId{

};

#define SCS_DECLARE_TYPEINFO(TYPE) \
template <> \
struct CscsTypeId<TYPE> \
{	\
	static int scs_type_id() \
	{ \
		static int id=scsRegisterTypeInfo<TYPE>(#TYPE); \
		return id; \
	} \
}; 

// template<> struct CscsTypeId<CscsUrl>
// { static inline int scs_type_id() { return CscsTypeInfo::CscsUrl; } };
// template<> struct CscsTypeId<CscsRect>
// { static inline int scs_type_id() { return CscsTypeInfo::CscsRect; } };
// template<> struct CscsTypeId<CscsRectF>
// { static inline int scs_type_id() { return CscsTypeInfo::CscsRectF; } };
// template<> struct CscsTypeId<CscsSize>
// { static inline int scs_type_id() { return CscsTypeInfo::CscsSize; } };
// template<> struct CscsTypeId<CscsSizeF>
// { static inline int scs_type_id() { return CscsTypeInfo::CscsSizeF; } };
// template<> struct CscsTypeId<CscsLine>
// { static inline int scs_type_id() { return CscsTypeInfo::CscsLine; } };
// template<> struct CscsTypeId<CscsLineF>
// { static inline int scs_type_id() { return CscsTypeInfo::CscsLineF; } };
// template<> struct CscsTypeId<CscsPoint>
// { static inline int scs_type_id() { return CscsTypeInfo::CscsPoint; } };
// template<> struct CscsTypeId<CscsPointF>
// { static inline int scs_type_id() { return CscsTypeInfo::CscsPointF; } };
// template<> struct CscsTypeId<CscsFont>
// { static inline int scs_type_id() { return CscsTypeInfo::CscsFont; } };
// template<> struct CscsTypeId<CscsBrush>
// { static inline int scs_type_id() { return CscsTypeInfo::CscsBrush; } };
// template<> struct CscsTypeId<CscsColor>
// { static inline int scs_type_id() { return CscsTypeInfo::CscsColor; } };
// template<> struct CscsTypeId<CscsPolygon>
// { static inline int scs_type_id() { return CscsTypeInfo::CscsPolygon; } };
// template<> struct CscsTypeId<CscsRegion>
// { static inline int scs_type_id() { return CscsTypeInfo::CscsRegion; } };
// template<> struct CscsTypeId<CscsCursor>
// { static inline int scs_type_id() { return CscsTypeInfo::CscsCursor; } };
// template<> struct CscsTypeId<CscsPen>
// { static inline int scs_type_id() { return CscsTypeInfo::CscsPen; } };

template<> struct CscsTypeId<std::string>
{ static inline int scs_type_id() { return CscsTypeInfo::StdString; } };

template<> struct CscsTypeId<CscsString>
{ static inline int scs_type_id() { return CscsTypeInfo::CscsString; } };
template<> struct CscsTypeId<int>
{ static inline int scs_type_id() { return CscsTypeInfo::Int; } };
template<> struct CscsTypeId<uint>
{ static inline int scs_type_id() { return CscsTypeInfo::UInt; } };
template<> struct CscsTypeId<bool>
{ static inline int scs_type_id() { return CscsTypeInfo::Bool; } };
template<> struct CscsTypeId<double>
{ static inline int scs_type_id() { return CscsTypeInfo::Double; } };
template<> struct CscsTypeId<CscsByteArray>
{ static inline int scs_type_id() { return CscsTypeInfo::CscsByteArray; } };
template<> struct CscsTypeId<CscsChar>
{ static inline int scs_type_id() { return CscsTypeInfo::CscsChar; } };
template<> struct CscsTypeId<void>
{ static inline int scs_type_id() { return CscsTypeInfo::Void; } };
template<> struct CscsTypeId<long>
{ static inline int scs_type_id() { return CscsTypeInfo::Long; } };
template<> struct CscsTypeId<short>
{ static inline int scs_type_id() { return CscsTypeInfo::Short; } };
template<> struct CscsTypeId<char>
{ static inline int scs_type_id() { return CscsTypeInfo::Char; } };
template<> struct CscsTypeId<ulong>
{ static inline int scs_type_id() { return CscsTypeInfo::ULong; } };
template<> struct CscsTypeId<ushort>
{ static inline int scs_type_id() { return CscsTypeInfo::UShort; } };
template<> struct CscsTypeId<uint8>
{ static inline int scs_type_id() { return CscsTypeInfo::UChar; } };
template<> struct CscsTypeId<float>
{ static inline int scs_type_id() { return CscsTypeInfo::Float; } };
class CscsObject;
template<> struct CscsTypeId<CscsObject *>
{ static inline int scs_type_id() { return CscsTypeInfo::CscsObjectStar; } };
class CscsWidget;
template<> struct CscsTypeId<CscsWidget*>
{ static inline int scs_type_id() { return CscsTypeInfo::CscsWidgetStar; } };
template<> struct CscsTypeId<void *>
{ static inline int scs_type_id() { return CscsTypeInfo::VoidStar; } };

END_NAMESPACE

#endif