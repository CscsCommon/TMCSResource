/*Created by J.Wong 2018/10/25
 version:    version 1.0,
 dependency: base on  or greater than c++11
 function: type erase
 gcc4.9+
 */
#ifndef SCSAPPLICATIONPlus_P_H
#define SCSAPPLICATIONPlus_P_H
#include "scstypes.h"
#include "scsobject_p.h"
#include "scsapplicationplus.h"

BEGIN_NAMESPACE(Gemini)

class CscsObject;
class CscsEvent;
class CscsThread;
class CscsAbstractEventDispatcher;

class CscsApplicationPlusPrivate:public CscsObjectPrivate{
public:
	CscsApplicationPlusPrivate();
	~CscsApplicationPlusPrivate();

	bool notify(CscsObject* obj, CscsEvent* e);

	virtual void createEventDispatcher();
	static void moveToMainThread(CscsObject* obj);
	static void removePostedEvent(CscsEvent* e);

	static CscsThread* mainThread();
	static bool checkInstance(const char* function);
	CscsApplicationPlus* mm_func()const;
	void checkReceiverThread(CscsObject* receiver);

	CscsApplicationPlus::EventFilter eventFilter;
	static CscsAbstractEventDispatcher* eventDispatcher;
	static CscsDataSensor* app_sensor;
	static bool app_running;
	static bool app_closing;
	uint32 application_type;
	friend class CscsApplicationPlus;


};

END_NAMESPACE
#endif