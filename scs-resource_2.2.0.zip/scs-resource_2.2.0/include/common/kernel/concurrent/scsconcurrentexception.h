#ifndef SCSCONCURRENTEXCEPTION_H
#define SCSCONCURRENTEXCEPTION_H

#include <kernel/scsatomic.h>
#include <exception>

BEGIN_NAMESPACE(Gemini)

class Exception:public std::exception{
public:
    virtual void raise() const;
    virtual Exception *clone() const;	
};

class UnhandledException : public Exception
{
public:
    void raise() const;
    Exception *clone() const;
};

class Base;
class ExceptionHolder
{
public:
    ExceptionHolder(Exception *exception = 0);
    ExceptionHolder(const ExceptionHolder &other);
    void operator=(const ExceptionHolder &other);
    ~ExceptionHolder();
    Exception *exception() const;
    Base *base;
};

class  ExceptionStore
{
public:
    void setException(const Exception &e);
    bool hasException() const;
    ExceptionHolder exception();
    void throwPossibleException();
    bool hasThrown() const;
    ExceptionHolder exceptionHolder;
};

END_NAMESPACE
#endif