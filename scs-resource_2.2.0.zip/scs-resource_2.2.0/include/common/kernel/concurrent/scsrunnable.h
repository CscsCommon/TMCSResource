#ifndef SCSRUNNABLE_H
#define SCSRUNNABLE_H
#include <kernel/scsnamespace.h>

BEGIN_NAMESPACE(Gemini)
class CscsRunnable
{
    int ref;

    friend class CscsThreadPoolPrivate;
    friend class CscsThreadPoolThread;

public:
    virtual void run() = 0;

    CscsRunnable() : ref(0) { }
    virtual ~CscsRunnable() { }

    bool autoDelete() const { return ref != -1; }
    void setAutoDelete(bool _autoDelete) { ref = _autoDelete ? 0 : -1; }
};


END_NAMESPACE

#endif