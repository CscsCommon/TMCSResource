#ifndef SCSFSFILEENGINE_H
#define SCSFSFILEENGINE_H

#include "scsfileengine.h"
#include "scsfileengine_p.h"
#include <kernel/scsplatformdefs.h>

BEGIN_NAMESPACE(Gemini)

class CscsFSFileEnginePrivate;
class CscsFSFileEngine : public CscsFileEngine
{
    CscsFSFileEnginePrivate* d_func()const;
public:
    CscsFSFileEngine();
    explicit CscsFSFileEngine(const CscsString &file);
    ~CscsFSFileEngine();

    void setFileName(const CscsString &file);

    bool open(int flags);
    bool close();
    bool flush();
    int64 size() const;
    int64 at() const;
    bool seek(int64);
    int64 read(char *data, int64 maxlen);
    int64 write(const char *data, int64 len);
    CscsFile::FileError error() const;
    CscsString errorString() const;

    bool remove();
    bool copy(const CscsString &newName);
    bool rename(const CscsString &newName);
    bool link(const CscsString &newName);

    bool isSequential() const;

    uint8 *map(int64 off, int64 len);
    void unmap(uint8 *data);

    bool mkdir(const CscsString &dirName, bool createParentDirectories) const;
    bool rmdir(const CscsString &dirName, bool recurseParentDirectories) const;

    bool setSize(int64 size);

    CscsStringList entryList(CscsDir::Filters filters, const CscsStringList &filterNames) const;

    bool caseSensitive() const;

    bool isRelativePath() const;

    FileFlags fileFlags(FileFlags type) const;

    bool chmod(uint perms);

    CscsString fileName(CscsFileEngine::FileName file) const;

    uint ownerId(CscsFileEngine::FileOwner) const;
    CscsString owner(FileOwner) const;

    CscsDateTime fileTime(FileTime time) const;

    Type type() const;

    //FS only!!
    bool open(int flags, int fd);
    int handle() const;
    static bool setCurrentPath(const CscsString &path);
    static CscsString currentPath(const CscsString &path = CscsString());
    static CscsString homePath();
    static CscsString rootPath();
    static CscsString tempPath();
    static CscsFileInfoList drives();

protected:
    CscsFSFileEngine(CscsFSFileEnginePrivate* dd);
};

class CscsFSFileEnginePrivate : public CscsFileEnginePrivate
{
    CscsFSFileEngine* mm_func()const{
    	return reinterpret_cast<CscsFSFileEngine*>(mm_ptr);
    }

public:
#ifdef D_WIN32
    static CscsString fixToSCSSlashes(const CscsString &path);
    static CscsByteArray win95Name(const CscsString &path);
#else
    static inline CscsString fixToSCSSlashes(const CscsString &path) { return path; }
#endif

    CscsString file;

    inline void resetErrors() const {
        error = CscsFile::UnspecifiedError;
        errorString.clear();
    }
    inline void setError(CscsFile::FileError err, int errorCode) const {
        error = err;
        errorString = scs_error_string(errorCode);
    }
    inline void setError(CscsFile::FileError err, CscsString errStr = CscsString()) const {
        error = err;
        errorString = errStr;
    }
    mutable CscsFile::FileError error;
    mutable CscsString errorString;

    int fd;
    mutable uint sequential : 1;
    mutable uint external_file : 1;
    CscsByteArray ungetchBuffer;

    mutable uint could_stat : 1;
    mutable uint tried_stat : 1;
#ifdef D_UNIX
    mutable uint isSymLink : 1;
#endif
    mutable SCS_STATBUF st;
    bool doStat() const;
    int sysOpen(const CscsString &, int flags);

protected:
    CscsFSFileEnginePrivate();

    void init();

#if defined(D_WIN32)
    CscsFileEngine::FileFlags getPermissions() const;
    CscsString getLink() const;
#endif
    friend class CscsFSFileEngine;
};

END_NAMESPACE
#endif