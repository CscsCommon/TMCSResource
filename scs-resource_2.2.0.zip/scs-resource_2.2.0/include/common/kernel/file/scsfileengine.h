#ifndef SCSFILEENGINE_H
#define SCSFILEENGINE_H
#include "scsdir.h"

#ifdef open
#error scsfileengine.h must be included before any system header that defines open
#endif

BEGIN_NAMESPACE(Gemini)

class CscsFileEnginePrivate;
class  CscsFileEngine
{
public:
    virtual ~CscsFileEngine();

    static CscsFileEngine *createFileEngine(const CscsString &file);
    virtual void setFileName(const CscsString &file) = 0;

    virtual bool open(int flags) = 0;
    virtual bool close() = 0;
    virtual bool flush() = 0;

    virtual int64 size() const = 0;
    virtual int64 at() const = 0;
    virtual bool seek(int64 off) = 0;

    virtual bool isSequential() const = 0;

    virtual uint8 *map(int64 off, int64 len);
    virtual void unmap(uint8 *data);

    virtual int64 read(char *data, int64 maxlen) = 0;
    virtual int64 write(const char *data, int64 len) = 0;

    virtual CscsFile::FileError error() const;
    virtual CscsString errorString() const;

    virtual bool remove() = 0;
    virtual bool copy(const CscsString &newName) = 0;
    virtual bool rename(const CscsString &newName) = 0;
    virtual bool link(const CscsString &newName) = 0;

    enum Type {
        File,
        Resource,
        BufferedFile,

        User = 50, // first user type id
        MaxUser = 100 // last user type id
    };
    virtual Type type() const = 0;

    virtual bool mkdir(const CscsString &dirName, bool createParentDirectories) const = 0;
    virtual bool rmdir(const CscsString &dirName, bool recurseParentDirectories) const = 0;

    virtual bool setSize(int64 size) = 0;

    virtual CscsStringList entryList(CscsDir::Filters filters, const CscsStringList &filterNames) const = 0;

    virtual bool caseSensitive() const = 0;

    virtual bool isRelativePath() const = 0;

    enum FileFlag {
        //perms (overlaps the CscsFile::Permission)
        ReadOwnerPerm = 0x4000, WriteOwnerPerm = 0x2000, ExeOwnerPerm = 0x1000,
        ReadUserPerm  = 0x0400, WriteUserPerm  = 0x0200, ExeUserPerm  = 0x0100,
        ReadGroupPerm = 0x0040, WriteGroupPerm = 0x0020, ExeGroupPerm = 0x0010,
        ReadOtherPerm = 0x0004, WriteOtherPerm = 0x0002, ExeOtherPerm = 0x0001,

        //types
        LinkType      = 0x10000,
        FileType      = 0x20000,
        DirectoryType = 0x40000,

        //flags
        HiddenFlag     = 0x0100000,
        LocalDiskFlag  = 0x0200000,
        ExistsFlag     = 0x0400000,
        RootFlag       = 0x0800000,

        //masks
        PermsMask  = 0x0000FFFF,
        TypesMask  = 0x000F0000,
        FlagsMask  = 0x0FF00000,
        FileInfoAll = FlagsMask | PermsMask | TypesMask
    };
    SCS_DECLARE_FLAGS(FileFlags, FileFlag)
    virtual FileFlags fileFlags(FileFlags type=FileInfoAll) const = 0;

    virtual bool chmod(uint perms) = 0;

    enum FileName { DefaultName, BaseName, PathName, AbsoluteName, AbsolutePathName, LinkName,
                    CanonicalName, CanonicalPathName };
    virtual CscsString fileName(FileName file=DefaultName) const = 0;

    enum FileOwner { OwnerUser, OwnerGroup };
    virtual uint ownerId(FileOwner) const = 0;
    virtual CscsString owner(FileOwner) const = 0;

    enum FileTime { CreationTime, ModificationTime, AccessTime };
    virtual CscsDateTime fileTime(FileTime time) const = 0;

protected:
    CscsFileEngine();
    CscsFileEngine(CscsFileEnginePrivate*);

    CscsFileEnginePrivate *d_ptr;
private:
    CscsFileEnginePrivate* d_func()const;
    friend class CscsFileEnginePrivate;
};

class  CscsFileEngineHandler
{
protected:
    CscsFileEngineHandler();
    virtual ~CscsFileEngineHandler();
    virtual CscsFileEngine *createFileEngine(const CscsString &path) = 0;

private:
    friend class CscsFileEngine;
};

SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsFileEngine::FileFlags)

END_NAMESPACE

#endif