#ifndef SCSFILE_H
#define SCSFILE_H
#include <kernel/scsstring.h>
#include <kernel/scsdevice.h>
#include <kernel/scsflags.h>

#include <stdio.h>



#ifdef open
#error scsfile.h must be included before any system header that defines open
#endif

BEGIN_NAMESPACE(Gemini)

class CscsFileEngine;
class CscsFilePrivate;
class  CscsFile : public CscsDevice
{

public:

    enum FileError {
        NoError = 0,
        ReadError = 1,
        WriteError = 2,
        FatalError = 3,
        ResourceError = 4,
        OpenError = 5,
        AbortError = 6,
        TimeOutError = 7,
        UnspecifiedError = 8,
        RemoveError = 9,
        RenameError = 10,
        PositionError = 11,
        ResizeError = 12,
        PermissionsError = 13,
        CopyError = 14
    };

    enum Permission {
        ReadOwner = 0x4000, WriteOwner = 0x2000, ExeOwner = 0x1000,
        ReadUser  = 0x0400, WriteUser  = 0x0200, ExeUser  = 0x0100,
        ReadGroup = 0x0040, WriteGroup = 0x0020, ExeGroup = 0x0010,
        ReadOther = 0x0004, WriteOther = 0x0002, ExeOther = 0x0001
    };
    SCS_DECLARE_FLAGS(Permissions, Permission)

    explicit CscsFile(CscsObject *parent=0);
    CscsFile(const CscsString &name, CscsObject *parent=0);
    ~CscsFile();

    FileError error() const;
    void unsetError();

    CscsString fileName() const;
    void setFileName(const CscsString &name);

    typedef CscsByteArray (*EncoderFn)(const CscsString &fileName);
    typedef CscsString (*DecoderFn)(const CscsByteArray &localfileName);
    static CscsByteArray encodeName(const CscsString &fileName);
    static CscsString decodeName(const CscsByteArray &localFileName);
    inline static CscsString decodeName(const char *localFileName)
        { return decodeName(CscsByteArray(localFileName)); };
    static void setEncodingFunction(EncoderFn);
    static void setDecodingFunction(DecoderFn);

    bool exists() const;
    static bool exists(const CscsString &fileName);

    CscsString readLink() const;
    static CscsString readLink(const CscsString &fileName);

    bool remove();
    static bool remove(const CscsString &fileName);

    bool rename(const CscsString &newName);
    static bool rename(const CscsString &oldName, const CscsString &newName);

    bool link(const CscsString &newName);
    static bool link(const CscsString &oldname, const CscsString &newName);

    bool copy(const CscsString &newName);
    static bool copy(const CscsString &fileName, const CscsString &newName);

    bool isSequential() const;

    bool open(SCSOpenMode flags);
    bool open(FILE *f, SCSOpenMode flags);
    bool open(int fd, SCSOpenMode flags);
    virtual void close();

    int64 size() const;
    int64 pos() const;
    bool seek(int64 offset);
    bool atEnd() const;
    bool flush();

    bool resize(int64 sz);
    static bool resize(const CscsString &filename, int64 sz);

    Permissions permissions() const;
    static Permissions permissions(const CscsString &filename);
    bool setPermissions(Permissions permissionSpec);
    static bool setPermissions(const CscsString &filename, Permissions permissionSpec);

    int handle() const;

    virtual CscsFileEngine *fileEngine() const;

protected:
    CscsFile(CscsFilePrivate* dd, CscsObject *parent = 0);

    int64 readData(char *data, int64 maxlen);
    int64 writeData(const char *data, int64 len);
    int64 readLineData(char *data, int64 maxlen);

private:
     CscsFilePrivate* d_func()const;
};

SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsFile::Permissions)
END_NAMESPACE
#endif