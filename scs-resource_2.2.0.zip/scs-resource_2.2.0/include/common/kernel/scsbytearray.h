#ifndef SCSBYTEARRAY_H
#define SCSBYTEARRAY_H
#include <kernel/scslist.h>
#include <atomic>
#include <string.h>
#include "scsnamespace.h"

BEGIN_NAMESPACE(Gemini)

class CscsString;
class CscsByteRef;
class CscsNoImplicitBoolCast;

class  CscsByteArray
{
public:
    inline CscsByteArray();
    CscsByteArray(const char *);
    CscsByteArray(const char *, int size);
    CscsByteArray(int size, char c);
    inline CscsByteArray(const CscsByteArray &);
    inline ~CscsByteArray();

    CscsByteArray &operator=(const CscsByteArray &);
    CscsByteArray &operator=(const char *str);

    inline int size() const;
    bool isEmpty() const;
    void resize(int size);

    CscsByteArray &fill(char c, int size = -1);

    int capacity() const;
    void reserve(int size);
    void squeeze();

    operator const char *() const;
    operator const void *() const;
    char *data();
    const char *data() const;
    inline const char *constData() const;
    inline void detach();
    bool isDetached() const;
    void clear();

    const char at(int i) const;
    const char operator[](int i) const;
    CscsByteRef operator[](int i);
    const char operator[](uint i) const;
    CscsByteRef operator[](uint i);

    int indexOf(char c, int from = 0) const;
    inline int indexOf(const char *c, int from = 0) const;
    int indexOf(const CscsByteArray &a, int from = 0) const;
    int lastIndexOf(char c, int from = -1) const;
    inline int lastIndexOf(const char *c, int from = -1) const;
    int lastIndexOf(const CscsByteArray &a, int from = -1) const;

    bool contains(char c) const;
    bool contains(const char *a) const;
    bool contains(const CscsByteArray &a) const;
    int count(char c) const;
    int count(const char *a) const;
    int count(const CscsByteArray &a) const;

    CscsByteArray left(int len) const;
    CscsByteArray right(int len) const;
    CscsByteArray mid(int index, int len = -1) const;

    bool startsWith(const CscsByteArray &a) const;
    bool startsWith(char c) const;
    bool startsWith(const char *c) const;

    bool endsWith(const CscsByteArray &a) const;
    bool endsWith(char c) const;
    bool endsWith(const char *c) const;

    void truncate(int pos);
    void chop(int n);

    CscsByteArray toLower() const;
    CscsByteArray toUpper() const;

    CscsByteArray trimmed() const;
    CscsByteArray simplified() const;
    CscsByteArray leftJustified(int width, char fill = ' ', bool truncate = false) const;
    CscsByteArray rightJustified(int width, char fill = ' ', bool truncate = false) const;


    CscsByteArray &prepend(char c);
    CscsByteArray &prepend(const char *s);
    CscsByteArray &prepend(const char* s, int len);
    CscsByteArray &prepend(const CscsByteArray &a);
    CscsByteArray &append(char c);
    CscsByteArray &append(const char *s);
    CscsByteArray &append(const char* s, int len);
    CscsByteArray &append(const CscsByteArray &a);
    CscsByteArray &insert(int i, char c);
    CscsByteArray &insert(int i, const char *s);
    CscsByteArray &insert(int i, const CscsByteArray &a);
    CscsByteArray &remove(int index, int len);
    CscsByteArray &replace(int index, int len, const char *s);
    CscsByteArray &replace(int index, int len, const CscsByteArray &s);
    CscsByteArray &replace(char before, const char *after);
    CscsByteArray &replace(char before, const CscsByteArray &after);
    CscsByteArray &replace(const char *before, const char *after);
    CscsByteArray &replace(const CscsByteArray &before, const CscsByteArray &after);
    CscsByteArray &replace(const CscsByteArray &before, const char *after);
    CscsByteArray &replace(const char *before, const CscsByteArray &after);
    CscsByteArray &replace(char before, char after);
    CscsByteArray &operator+=(char c);
    CscsByteArray &operator+=(const char *s);
    CscsByteArray &operator+=(const CscsByteArray &a);

    CscsList<CscsByteArray> split(char sep) const;

    CscsByteArray &append(const CscsString &s);
    CscsByteArray &insert(int i, const CscsString &s);
    CscsByteArray &replace(const CscsString &before, const char *after);
    CscsByteArray &replace(char c, const CscsString &after);
    CscsByteArray &replace(const CscsString &before, const CscsByteArray &after);

    CscsByteArray &operator+=(const CscsString &s);
    int indexOf(const CscsString &s, int from = 0) const;
    int lastIndexOf(const CscsString &s, int from = -1) const;

    inline bool operator==(const CscsString &s2) const;
    inline bool operator!=(const CscsString &s2) const;
    inline bool operator<(const CscsString &s2) const;
    inline bool operator>(const CscsString &s2) const;
    inline bool operator<=(const CscsString &s2) const;
    inline bool operator>=(const CscsString &s2) const;

    short toShort(bool *ok = 0, int base = 10) const;
    uint16 toUShort(bool *ok = 0, int base = 10) const;
    int toInt(bool *ok = 0, int base = 10) const;
    uint toUInt(bool *ok = 0, int base = 10) const;
    int64 toLongLong(bool *ok = 0, int base = 10) const;
    uint64 toULongLong(bool *ok = 0, int base = 10) const;
    float toFloat(bool *ok = 0) const;
    double toDouble(bool *ok = 0) const;
    CscsByteArray toBase64() const;

    CscsByteArray &setNum(short, int base = 10);
    CscsByteArray &setNum(uint16, int base = 10);
    CscsByteArray &setNum(int, int base = 10);
    CscsByteArray &setNum(uint, int base = 10);
    CscsByteArray &setNum(int64, int base = 10);
    CscsByteArray &setNum(uint64, int base = 10);
    CscsByteArray &setNum(float, char f = 'g', int prec = 6);
    CscsByteArray &setNum(double, char f = 'g', int prec = 6);

    static CscsByteArray number(int, int base = 10);
    static CscsByteArray number(uint, int base = 10);
    static CscsByteArray number(int64, int base = 10);
    static CscsByteArray number(uint64, int base = 10);
    static CscsByteArray number(double, char f = 'g', int prec = 6);
    static CscsByteArray fromRawData(const char *, int size);
    static CscsByteArray fromBase64(const CscsByteArray &base64);

    typedef char *iterator;
    typedef const char *const_iterator;
    typedef iterator Iterator;
    typedef const_iterator ConstIterator;
    iterator begin();
    const_iterator begin() const;
    const_iterator constBegin() const;
    iterator end();
    const_iterator end() const;
    const_iterator constEnd() const;

    // stl compatibility
    void push_back(char c);
    void push_back(const char *c);
    void push_back(const CscsByteArray &a);
    void push_front(char c);
    void push_front(const char *c);
    void push_front(const CscsByteArray &a);

    inline int count() const { return d->size; }
    int length() const { return d->size; }
    bool isNull() const;


private:
    operator CscsNoImplicitBoolCast() const;
    struct Data {
        std::atomic<int> ref;
        int alloc, size;
        char *data;
        char array[1];
    };
    static Data shared_null;
    static Data shared_empty;
    Data *d;
    CscsByteArray(Data *dd, int /*dummy*/, int /*dummy*/) : d(dd) {}
    void realloc(int alloc);
    void expand(int i);

    friend class CscsByteRef;
    friend class CscsString;
};

SCS_DECLARE_TYPENAME_INFO(CscsByteArray,SCS_MOVABLE_TYPE)

inline CscsByteArray::CscsByteArray(): d(&shared_null) { d->ref++; }
inline CscsByteArray::~CscsByteArray() { if (!--d->ref) free(d); }
inline int CscsByteArray::size() const
{ return d->size; }
inline const char CscsByteArray::at(int i) const
{ assert(i >= 0 && i < size()); return d->data[i]; }
inline const char CscsByteArray::operator[](int i) const
{ assert(i >= 0 && i < size()); return d->data[i]; }
inline const char CscsByteArray::operator[](uint i) const
{ assert(i < uint(size())); return d->data[i]; }
inline bool CscsByteArray::isEmpty() const
{ return d->size == 0; }
inline CscsByteArray::operator const char *() const
{ return d->data; }
inline CscsByteArray::operator const void *() const
{ return d->data; }
inline char *CscsByteArray::data()
{ detach(); return d->data; }
inline const char *CscsByteArray::data() const
{ return d->data; }
inline const char *CscsByteArray::constData() const
{ return d->data; }
inline void CscsByteArray::detach()
{ if (d->ref != 1 || d->data != d->array) realloc(d->size+1); }
inline bool CscsByteArray::isDetached() const
{ return d->ref == 1; }
inline CscsByteArray::CscsByteArray(const CscsByteArray &a) : d(a.d)
{ d->ref++; }

inline int CscsByteArray::capacity() const
{ return d->alloc; }

inline void CscsByteArray::reserve(int asize)
{ if (d->ref != 1 || asize+1 > d->alloc) realloc(asize+1); }

inline void CscsByteArray::squeeze()
{ if (d->size+1 < d->alloc) realloc(d->size+1); }

class  CscsByteRef {
    CscsByteArray &a;
    int i;
    inline CscsByteRef(CscsByteArray &array, int idx)
        : a(array),i(idx) {}
    friend class CscsByteArray;
public:
    inline operator const char() const
        { return i < a.d->size ? a.d->data[i] : 0; }
    inline CscsByteRef &operator=(char c)
        { if (a.d->ref != 1 || i >= a.d->size) a.expand(i);
          a.d->data[i] = c;  return *this; }
    inline CscsByteRef &operator=(const CscsByteRef &c)
        { if (a.d->ref != 1 || i >= a.d->size) a.expand(i);
          a.d->data[i] = c.a.d->data[c.i];  return *this; }
    inline bool operator==(char c) const
    { return a.d->data[i] == c; }
    inline bool operator!=(char c) const
    { return a.d->data[i] != c; }
    inline bool operator>(char c) const
    { return a.d->data[i] > c; }
    inline bool operator>=(char c) const
    { return a.d->data[i] >= c; }
    inline bool operator<(char c) const
    { return a.d->data[i] < c; }
    inline bool operator<=(char c) const
    { return a.d->data[i] <= c; }
};

inline CscsByteRef CscsByteArray::operator[](int i)
{ assert(i >= 0); return CscsByteRef(*this, i); }
inline CscsByteRef CscsByteArray::operator[](uint i)
{ return CscsByteRef(*this, i); }
inline CscsByteArray::iterator CscsByteArray::begin()
{ detach(); return d->data; }
inline CscsByteArray::const_iterator CscsByteArray::begin() const
{ return d->data; }
inline CscsByteArray::const_iterator CscsByteArray::constBegin() const
{ return d->data; }
inline CscsByteArray::iterator CscsByteArray::end()
{ detach(); return d->data + d->size; }
inline CscsByteArray::const_iterator CscsByteArray::end() const
{ return d->data + d->size; }
inline CscsByteArray::const_iterator CscsByteArray::constEnd() const
{ return d->data + d->size; }
inline CscsByteArray &CscsByteArray::operator+=(char c)
{ return append(c); }
inline CscsByteArray &CscsByteArray::operator+=(const char *s)
{ return append(s); }
inline CscsByteArray &CscsByteArray::operator+=(const CscsByteArray &a)
{ return append(a); }
inline void CscsByteArray::push_back(char c)
{ append(c); }
inline void CscsByteArray::push_back(const char *c)
{ append(c); }
inline void CscsByteArray::push_back(const CscsByteArray &a)
{ append(a); }
inline void CscsByteArray::push_front(char c)
{ prepend(c); }
inline void CscsByteArray::push_front(const char *c)
{ prepend(c); }
inline void CscsByteArray::push_front(const CscsByteArray &a)
{ prepend(a); }
inline bool CscsByteArray::contains(const CscsByteArray &a) const
{ return bool(indexOf(a) != -1); }
inline bool CscsByteArray::contains(char c) const
{ return bool(indexOf(c) != -1); }
inline bool operator==(const CscsByteArray &a1, const CscsByteArray &a2)
{ return (a1.size() == a2.size()) && (memcmp(a1, a2, a1.size())==0); }
inline bool operator==(const CscsByteArray &a1, const char *a2)
{ return a2 ? strcmp(a1,a2) == 0 : a1.isEmpty(); }
inline bool operator==(const char *a1, const CscsByteArray &a2)
{ return a1 ? strcmp(a1,a2) == 0 : a2.isEmpty(); }
inline bool operator!=(const CscsByteArray &a1, const CscsByteArray &a2)
{ return !(a1==a2); }
inline bool operator!=(const CscsByteArray &a1, const char *a2)
{ return a2 ? strcmp(a1,a2) != 0 : !a1.isEmpty(); }
inline bool operator!=(const char *a1, const CscsByteArray &a2)
{ return a1 ? strcmp(a1,a2) != 0 : !a2.isEmpty(); }
inline bool operator<(const CscsByteArray &a1, const CscsByteArray &a2)
{ return strcmp(a1, a2) < 0; }
 inline bool operator<(const CscsByteArray &a1, const char *a2)
{ return strcmp(a1, a2) < 0; }
inline bool operator<(const char *a1, const CscsByteArray &a2)
{ return strcmp(a1, a2) < 0; }
inline bool operator<=(const CscsByteArray &a1, const CscsByteArray &a2)
{ return strcmp(a1, a2) <= 0; }
inline bool operator<=(const CscsByteArray &a1, const char *a2)
{ return strcmp(a1, a2) <= 0; }
inline bool operator<=(const char *a1, const CscsByteArray &a2)
{ return strcmp(a1, a2) <= 0; }
inline bool operator>(const CscsByteArray &a1, const CscsByteArray &a2)
{ return strcmp(a1, a2) > 0; }
inline bool operator>(const CscsByteArray &a1, const char *a2)
{ return strcmp(a1, a2) > 0; }
inline bool operator>(const char *a1, const CscsByteArray &a2)
{ return strcmp(a1, a2) > 0; }
inline bool operator>=(const CscsByteArray &a1, const CscsByteArray &a2)
{ return strcmp(a1, a2) >= 0; }
inline bool operator>=(const CscsByteArray &a1, const char *a2)
{ return strcmp(a1, a2) >= 0; }
inline bool operator>=(const char *a1, const CscsByteArray &a2)
{ return strcmp(a1, a2) >= 0; }
inline const CscsByteArray operator+(const CscsByteArray &a1, const CscsByteArray &a2)
{ return CscsByteArray(a1) += a2; }
inline const CscsByteArray operator+(const CscsByteArray &a1, const char *a2)
{ return CscsByteArray(a1) += a2; }
inline const CscsByteArray operator+(const CscsByteArray &a1, char a2)
{ return CscsByteArray(a1) += a2; }
inline const CscsByteArray operator+(const char *a1, const CscsByteArray &a2)
{ return CscsByteArray(a1) += a2; }
inline const CscsByteArray operator+(char a1, const CscsByteArray &a2)
{ return CscsByteArray(&a1, 1) += a2; }
inline int CscsByteArray::indexOf(const char *c, int i) const
{ return indexOf(fromRawData(c, strlen(c)), i); }
inline int CscsByteArray::lastIndexOf(const char *c, int i) const
{ return lastIndexOf(fromRawData(c, strlen(c)), i); }
inline bool CscsByteArray::contains(const char *c) const
{ return contains(fromRawData(c, strlen(c))); }
inline CscsByteArray &CscsByteArray::replace(int index, int len, const char *c)
{ return replace(index, len, fromRawData(c, strlen(c))); }
inline CscsByteArray &CscsByteArray::replace(char before, const char *c)
{ return replace(before, fromRawData(c, strlen(c))); }
inline CscsByteArray &CscsByteArray::replace(const CscsByteArray &before, const char *c)
{ return replace(before, fromRawData(c, strlen(c))); }
inline CscsByteArray &CscsByteArray::replace(const char *c, const CscsByteArray &after)
{ return replace(fromRawData(c, strlen(c)), after); }
inline CscsByteArray &CscsByteArray::replace(const char *before, const char *after)
{ return replace(fromRawData(before, strlen(before)), fromRawData(after, strlen(after))); }

inline CscsByteArray &CscsByteArray::setNum(short n, int base)
{ return setNum(int64(n), base); }
inline CscsByteArray &CscsByteArray::setNum(uint16 n, int base)
{ return setNum(uint64(n), base); }
inline CscsByteArray &CscsByteArray::setNum(int n, int base)
{ return setNum(int64(n), base); }
inline CscsByteArray &CscsByteArray::setNum(uint n, int base)
{ return setNum(uint64(n), base); }
inline CscsByteArray &CscsByteArray::setNum(float n, char f, int prec)
{ return setNum(double(n),f,prec); }


int scsStricmp(const char *str1, const char *str2);

END_NAMESPACE

#endif