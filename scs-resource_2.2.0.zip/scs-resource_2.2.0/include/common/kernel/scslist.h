#ifndef SCSLIST_H
#define SCSLIST_H
#include <cstddef>
#include <iterator>
#include <list>
#include <atomic>
#include <algorithm>
#include <assert.h>
#include <type_traits>
#include "scstypes.h"
#include "scsutils.h"
#include "scsiterator.h"

BEGIN_NAMESPACE(Gemini)

template <typename T> class CscsVector;
template <typename T> class CscsSet;

struct  CscsListData {
    struct Data {
        std::atomic<int> ref;
        int alloc, begin, end;
        uint sharable : 1;
        void *array[1];
    };
    enum { DataHeaderSize = sizeof(Data) - sizeof(void *) };

    Data *detach();
    void realloc(int alloc);
    static Data shared_null;
    Data *d;
    void **erase(void **xi);
    void **append();
    void **append(const CscsListData &l);
    void **prepend();
    void **insert(int i);
    void remove(int i);
    void remove(int i, int n);
    void move(int from, int to);
    inline int size() const { return d->end - d->begin; }
    inline bool isEmpty() const { return d->end  == d->begin; }
    inline void **at(int i) const { return d->array + d->begin + i; }
    inline void **begin() const { return d->array + d->begin; }
    inline void **end() const { return d->array + d->end; }
};

template <typename T>
class CscsList
{
    struct Node { void *v;
    T &t()
        { return *reinterpret_cast<T*>(CscsTypeNameInfo<T>::isLarge || CscsTypeNameInfo<T>::isStatic
                                       ? v : this); }
    };

    union { CscsListData p; CscsListData::Data *d; };

public:
    inline CscsList() : d(&CscsListData::shared_null) { d->ref++; }
    inline CscsList(const CscsList &l) : d(l.d) { d->ref++; if (!d->sharable) detach_helper(); }
    ~CscsList();
    CscsList &operator=(const CscsList &l);
    bool operator==(const CscsList &l) const;
    inline bool operator!=(const CscsList &l) const { return !(*this == l); }

    inline int size() const { return p.size(); }

    inline void detach() { if (d->ref != 1) detach_helper(); }
    inline bool isDetached() const { return d->ref == 1; }
    inline void setSharable(bool sharable) { if (!sharable) detach(); d->sharable = sharable; }

    inline bool isEmpty() const { return p.isEmpty(); }

    void clear();

    const T &at(int i) const;
    const T &operator[](int i) const;
    T &operator[](int i);

    void append(const T &t);
    void prepend(const T &t);
    void insert(int i, const T &t);
    void replace(int i, const T &t);
    void removeAt(int i);
    int removeAll(const T &t);
	bool removeOne(const T& t);
    T takeAt(int i);
    T takeFirst();
    T takeLast();
    void move(int from, int to);
    void swap(int i, int j);
    int indexOf(const T &t, int from = 0) const;
    int lastIndexOf(const T &t, int from = -1) const;
    bool contains(const T &t) const;
    int count(const T &t) const;

    class const_iterator;

    class iterator {
    public:
        Node *i;
        typedef std::random_access_iterator_tag  iterator_category;
        typedef ptrdiff_t  difference_type;
        typedef T value_type;
        typedef T *pointer;
        typedef T &reference;

        inline iterator() : i(0) {}
        inline iterator(Node *n) : i(n) {}
        inline iterator(const iterator &o): i(o.i){}
        inline T &operator*() const { return i->t(); }
        inline T *operator->() const { return &i->t(); }
        inline T &operator[](int j) const { return i[j].t(); }
        inline bool operator==(const iterator &o) const { return i == o.i; }
        inline bool operator!=(const iterator &o) const { return i != o.i; }
        inline bool operator<(const iterator& other) const { return i < other.i; }
        inline bool operator<=(const iterator& other) const { return i <= other.i; }
        inline bool operator>(const iterator& other) const { return i > other.i; }
        inline bool operator>=(const iterator& other) const { return i >= other.i; }
        inline bool operator==(const const_iterator &o) const
            { return i == reinterpret_cast<const iterator &>(o).i; }
        inline bool operator!=(const const_iterator &o) const
            { return i != reinterpret_cast<const iterator &>(o).i; }
        inline bool operator<(const const_iterator& other) const
            { return i < reinterpret_cast<const iterator &>(other).i; }
        inline bool operator<=(const const_iterator& other) const
            { return i <= reinterpret_cast<const iterator &>(other).i; }
        inline bool operator>(const const_iterator& other) const
            { return i > reinterpret_cast<const iterator &>(other).i; }
        inline bool operator>=(const const_iterator& other) const
            { return i >= reinterpret_cast<const iterator &>(other).i; }
        inline iterator &operator++() { ++i; return *this; }
        inline iterator operator++(int) { Node *n = i; ++i; return n; }
        inline iterator &operator--() { i--; return *this; }
        inline iterator operator--(int) { Node *n = i; i--; return n; }
        inline iterator &operator+=(int j) { i+=j; return *this; }
        inline iterator &operator-=(int j) { i-=j; return *this; }
        inline iterator operator+(int j) const { return iterator(i+j); }
        inline iterator operator-(int j) const { return iterator(i-j); }
        inline int operator-(iterator j) const { return i - j.i; }
    };
    friend class iterator;

    class const_iterator {
    public:
        Node *i;
        typedef std::random_access_iterator_tag  iterator_category;
        typedef ptrdiff_t difference_type;
        typedef T value_type;
        typedef T *pointer;
        typedef T &reference;

        inline const_iterator() : i(0) {}
        inline const_iterator(Node *n) : i(n) {}
        inline const_iterator(const const_iterator &o): i(o.i) {}
        inline const_iterator(const iterator &o): i(o.i) {}
        inline const T &operator*() const { return i->t(); }
        inline const T *operator->() const { return &i->t(); }
        inline const T &operator[](int j) const { return i[j].t(); }
        inline bool operator==(const const_iterator &o) const { return i == o.i; }
        inline bool operator!=(const const_iterator &o) const { return i != o.i; }
        inline bool operator<(const const_iterator& other) const { return i < other.i; }
        inline bool operator<=(const const_iterator& other) const { return i <= other.i; }
        inline bool operator>(const const_iterator& other) const { return i > other.i; }
        inline bool operator>=(const const_iterator& other) const { return i >= other.i; }
        inline const_iterator &operator++() { ++i; return *this; }
        inline const_iterator operator++(int) { Node *n = i; ++i; return n; }
        inline const_iterator &operator--() { i--; return *this; }
        inline const_iterator operator--(int) { Node *n = i; i--; return n; }
        inline const_iterator &operator+=(int j) { i+=j; return *this; }
        inline const_iterator &operator-=(int j) { i+=j; return *this; }
        inline const_iterator operator+(int j) const { return const_iterator(i+j); }
        inline const_iterator operator-(int j) const { return const_iterator(i-j); }
        inline int operator-(const_iterator j) const { return i - j.i; }
    };
    friend class const_iterator;

    // stl style
    inline iterator begin() { detach(); return reinterpret_cast<Node *>(p.begin()); }
    inline const_iterator begin() const { return reinterpret_cast<Node *>(p.begin()); }
    inline const_iterator constBegin() const { return reinterpret_cast<Node *>(p.begin()); }
    inline iterator end() { detach(); return reinterpret_cast<Node *>(p.end()); }
    inline const_iterator end() const { return reinterpret_cast<Node *>(p.end()); }
    inline const_iterator constEnd() const { return reinterpret_cast<Node *>(p.end()); }
    iterator insert(iterator before, const T &t);
    iterator erase(iterator pos);
    iterator erase(iterator first, iterator last);

    // more SCS
    typedef iterator Iterator;
    typedef const_iterator ConstIterator;
    inline int count() const { return p.size(); }
    inline T& first() { if(isEmpty()) assert(false);return *begin(); }
    inline const T& first() const { if(isEmpty()) assert(false); return *begin(); }
    T& last() { if(isEmpty()) assert(false); return *(--end()); }
    const T& last() const { if(isEmpty()) assert(false); return *(--end()); }
    inline void removeFirst() { if(isEmpty()) assert(false); erase(begin()); }
    inline void removeLast() { if(isEmpty()) assert(false); erase(--end()); }
    CscsList<T> mid(int pos, int length = -1) const;

    T value(int i) const;
    T value(int i, const T &defaultValue) const;

    // stl compatibility
    inline void push_back(const T &t) { append(t); }
    inline void push_front(const T &t) { prepend(t); }
    inline T& front() { return first(); }
    inline const T& front() const { return first(); }
    inline T& back() { return last(); }
    inline const T& back() const { return last(); }
    inline void pop_front() { removeFirst(); }
    inline void pop_back() { removeLast(); }
    inline bool empty() const { return isEmpty(); }
    typedef int size_type;
    typedef T value_type;
    typedef value_type *pointer;
    typedef const value_type *const_pointer;
    typedef value_type &reference;
    typedef const value_type &const_reference;

    // comfort
    CscsList &operator+=(const CscsList &l);
    inline CscsList operator+(const CscsList &l) const
    { CscsList n = *this; n += l; return n; }
    inline CscsList &operator+=(const T &t)
    { append(t); return *this; }
    inline CscsList &operator<< (const T &t)
    { append(t); return *this; }
    inline CscsList &operator<<(const CscsList &l)
    { *this += l; return *this; }

    CscsVector<T> toVector() const;
    CscsSet<T> toSet() const;

    static CscsList<T> fromVector(const CscsVector<T> &vector);
    static CscsList<T> fromSet(const CscsSet<T> &set);
    
    static inline CscsList<T> fromStdList(const std::list<T> &list)
    { CscsList<T> tmp; std::copy(list.begin(), list.end(), std::back_inserter(tmp)); return tmp; }
    inline std::list<T> toStdList() const
    { std::list<T> tmp; std::copy(constBegin(), constEnd(), std::back_inserter(tmp)); return tmp; }

private:
    void detach_helper();
    void free(CscsListData::Data *d);

    void node_construct(Node *n, const T &t);
    void node_destruct(Node *n);
    void node_copy(Node *from, Node *to, Node *src);
    void node_destruct(Node *from, Node *to);
};


template <typename T>
void CscsList<T>::node_construct(Node *n, const T &t)
{
    if (CscsTypeNameInfo<T>::isLarge||CscsTypeNameInfo<T>::isStatic) n->v = new T(t);
    else if (CscsTypeNameInfo<T>::isComplex) new (n) T(t);
    else *reinterpret_cast<T*>(n) = t;
}

template <typename T>
void CscsList<T>::node_destruct(Node *n)
{
    if (CscsTypeNameInfo<T>::isLarge||CscsTypeNameInfo<T>::isStatic) delete reinterpret_cast<T*>(n->v);
    else if (CscsTypeNameInfo<T>::isComplex) reinterpret_cast<T*>(n)->~T();
}

template <typename T>
void CscsList<T>::node_copy(Node *from, Node *to, Node *src)
{
    if (CscsTypeNameInfo<T>::isLarge||CscsTypeNameInfo<T>::isStatic)
        while(from != to)
            (from++)->v = new T(*reinterpret_cast<T*>((src++)->v));
    else if (CscsTypeNameInfo<T>::isComplex)
        while(from != to)
            new (from++) T(*reinterpret_cast<T*>(src++));
}

template <typename T>
void CscsList<T>::node_destruct(Node *from, Node *to)
{
    if (CscsTypeNameInfo<T>::isLarge||CscsTypeNameInfo<T>::isStatic)
        while(from != to) --to, delete reinterpret_cast<T*>(to->v);
    else if (CscsTypeNameInfo<T>::isComplex)
        while (from != to) --to, reinterpret_cast<T*>(to)->~T();
}

template <typename T>
CscsList<T> &CscsList<T>::operator=(const CscsList<T> &l)
{
    if (d != l.d) {
        CscsListData::Data *x = l.d;
        x->ref++;
        {
        	CscsListData::Data* tmp=x;
        	x=d;
        	d=tmp;
        }
        if (!--x->ref)
            free(x);
        if (!d->sharable)
            detach_helper();
    }
    return *this;
}
template <typename T>
inline typename CscsList<T>::iterator CscsList<T>::insert(iterator before, const T &t)
{ Node *n = reinterpret_cast<Node *>(p.insert(before.i-reinterpret_cast<Node *>(p.begin())));
 node_construct(n,t); return n; }
template <typename T>
inline typename CscsList<T>::iterator CscsList<T>::erase(iterator it)
{ node_destruct(it.i);
 return reinterpret_cast<Node *>(p.erase(reinterpret_cast<void**>(it.i))); }
template <typename T>
inline const T &CscsList<T>::at(int i) const
{ 
  if(i<0||i>=p.size()){
  	printf("CscsList<T>::at index out of range\n");
  	assert(false);
  }
 return reinterpret_cast<Node *>(p.at(i))->t();
}
template <typename T>
inline const T &CscsList<T>::operator[](int i) const
{ 
  if(i<0||i>=p.size()){
  	printf("CscsList<T>::operator[] index out of range\n");
  	assert(false);
  }
 return reinterpret_cast<Node *>(p.at(i))->t(); 
}
template <typename T>
inline T &CscsList<T>::operator[](int i)
{ 
  if(i<0||i>=p.size()){
  	printf("CscsList<T>::operator[] index out of range\n");
  	assert(false);
  }
  detach(); return reinterpret_cast<Node *>(p.at(i))->t();
}
template <typename T>
inline void CscsList<T>::removeAt(int i)
{ if(i >= 0 && i < p.size()) { detach();
 node_destruct(reinterpret_cast<Node *>(p.at(i))); p.remove(i); } }
template <typename T>
inline T CscsList<T>::takeAt(int i)
{ 
  if(i<0||i>=p.size()){
  	printf("CscsList<T>::takeAt index out of range\n");
  	assert(false);
  }
 detach(); Node *n = reinterpret_cast<Node *>(p.at(i)); T t = n->t(); node_destruct(n);
 p.remove(i); return t;
}
template <typename T>
inline T CscsList<T>::takeFirst()
{ T t = first(); removeFirst(); return t; }
template <typename T>
inline T CscsList<T>::takeLast()
{ T t = last(); removeLast(); return t; }

template <typename T>
void CscsList<T>::append(const T &t)
{
    detach();
    if (CscsTypeNameInfo<T>::isLarge||CscsTypeNameInfo<T>::isStatic) {
        node_construct(reinterpret_cast<Node *>(p.append()), t);
    } else {
        const T cpy(t);
        node_construct(reinterpret_cast<Node *>(p.append()), cpy);
    }
}

template <typename T>
inline void CscsList<T>::prepend(const T &t)
{
    detach();
    if (CscsTypeNameInfo<T>::isLarge||CscsTypeNameInfo<T>::isStatic) {
        node_construct(reinterpret_cast<Node *>(p.prepend()), t);
    } else {
        const T cpy(t);
        node_construct(reinterpret_cast<Node *>(p.prepend()), cpy);
    }
}

template <typename T>
inline void CscsList<T>::insert(int i, const T &t)
{
    detach();
    if (CscsTypeNameInfo<T>::isLarge||CscsTypeNameInfo<T>::isStatic) {
        node_construct(reinterpret_cast<Node *>(p.insert(i)), t);
    } else {
        const T cpy(t);
        node_construct(reinterpret_cast<Node *>(p.insert(i)), cpy);
    }
}

template <typename T>
inline void CscsList<T>::replace(int i, const T &t)
{
	if(i<0||i>=p.size()){
	  printf("CscsList<T>::replace index out of range\n");
	  assert(false);
	}
    detach();
     if (CscsTypeNameInfo<T>::isLarge||CscsTypeNameInfo<T>::isStatic) {
        reinterpret_cast<Node *>(p.at(i))->t() = t;
    } else {
        const T cpy(t);
        reinterpret_cast<Node *>(p.at(i))->t() = cpy;
    }
}

template <typename T>
inline void CscsList<T>::swap(int i, int j)
{
	if(i<0||i>=p.size()||j<0||j>=p.size()){
		printf( "CscsList<T>::swap index out of range\n");
		assert(false);
	}
    detach();
    void *t = d->array[d->begin + i];
    d->array[d->begin + i] = d->array[d->begin + j];
    d->array[d->begin + j] = t;
}

template <typename T>
inline void CscsList<T>::move(int from, int to)
{
	if(from<0||from>=p.size()||to<0||to>=p.size()){
		printf( "CscsList<T>::move index out of range\n");
		assert(false);
	}
    detach();
    p.move(from, to);
}

template<typename T>
CscsList<T> CscsList<T>::mid(int pos, int length) const
{
    if (length < 0)
        length = size() - pos;
    if (pos == 0 && length == size())
        return *this;
    CscsList<T> cpy;
    if (pos + length > size())
        length = size() - pos;
    for (int i = pos; i < pos + length; ++i)
        cpy += at(i);
    return cpy;
}

template<typename T>
T CscsList<T>::value(int i) const
{
    if (i < 0 || i >= p.size()) {
        return T();
    }
    return reinterpret_cast<Node *>(p.at(i))->t();
}
template<typename T>
T CscsList<T>::value(int i, const T& defaultValue) const
{
    return ((i < 0 || i >= p.size()) ? defaultValue : reinterpret_cast<Node *>(p.at(i))->t());
}

template <typename T>
void CscsList<T>::detach_helper()
{
    Node *n = reinterpret_cast<Node *>(p.begin());
    CscsListData::Data *x = p.detach();
    if (x)
        free(x);
    node_copy(reinterpret_cast<Node *>(p.begin()), reinterpret_cast<Node *>(p.end()), n);
}

template <typename T>
CscsList<T>::~CscsList()
{
    if (!d)
        return;
    CscsListData::Data *x = &CscsListData::shared_null;
    {
    	CscsListData::Data* tmp=x;
    	x=d;
    	d=tmp;
    }
    if (!--x->ref)
        free(x);
}

template <typename T>
bool CscsList<T>::operator==(const CscsList<T> &l) const
{
    if (p.size() != l.p.size())
        return false;
    if (d == l.d)
        return true;
    Node *i = reinterpret_cast<Node *>(p.end());
    Node *b = reinterpret_cast<Node *>(p.begin());
    Node *li = reinterpret_cast<Node *>(l.p.end());
    while (i != b) {
        --i; --li;
        if (!(i->t() == li->t()))
            return false;
    }
    return true;
}


template <typename T>
void CscsList<T>::free(CscsListData::Data *data)
{
    node_destruct(reinterpret_cast<Node *>(data->array + data->begin),
                  reinterpret_cast<Node *>(data->array + data->end));
    if (data->ref == 0)
        ::free(data);
}


template <typename T>
void CscsList<T>::clear()
{
    *this = CscsList<T>();
}

template <typename T>
int CscsList<T>::removeAll(const T &_t)
{
    detach();
    const T t = _t;
    int removedCount=0, i=0;
    Node *n;
    while (i < p.size())
        if ((n = reinterpret_cast<Node *>(p.at(i)))->t() == t) {
            node_destruct(n);
            p.remove(i);
            ++removedCount;
        } else {
            ++i;
        }
    return removedCount;
}

template <typename T>
bool CscsList<T>::removeOne(const T &_t)
{
    detach();
    const T t = _t;
    int  i=0;
    Node *n;
	bool res=false;
    while (i < p.size())
        if ((n = reinterpret_cast<Node *>(p.at(i)))->t() == t) {
            node_destruct(n);
            p.remove(i);
			res=true;
			break;
        } else {
            ++i;
        }
    return res;
}

template <typename T>
typename CscsList<T>::iterator CscsList<T>::erase(typename CscsList<T>::iterator afirst,
                                                                 typename CscsList<T>::iterator alast)
{
    for (Node *n = afirst.i; n < alast.i; ++n)
        node_destruct(n);
    int idx = afirst - begin();
    p.remove(idx, alast - afirst);
    return begin() + idx;
}

template <typename T>
CscsList<T> &CscsList<T>::operator+=(const CscsList<T> &l)
{
    detach();
    Node *n = reinterpret_cast<Node *>(p.append(l.p));
    node_copy(n, reinterpret_cast<Node *>(p.end()), reinterpret_cast<Node *>(l.p.begin()));
    return *this;
}

template <typename T>
int CscsList<T>::indexOf(const T &t, int from) const
{
    if (from < 0)
        from = std::max(from + p.size(), 0);
    if (from < p.size()) {
        Node *n = reinterpret_cast<Node *>(p.at(from -1));
        Node *e = reinterpret_cast<Node *>(p.end());
        while (++n != e)
            if (n->t() == t)
                return n - reinterpret_cast<Node *>(p.begin());
    }
    return -1;
}

template <typename T>
int CscsList<T>::lastIndexOf(const T &t, int from) const
{
    if (from < 0)
        from += p.size();
    else if (from >= p.size())
        from = p.size()-1;
    if (from >= 0) {
        Node *b = reinterpret_cast<Node *>(p.begin());
        Node *n = reinterpret_cast<Node *>(p.at(from + 1));
        while (n-- != b) {
            if (n->t() == t)
                return n - b;
        }
    }
    return -1;
}

template <typename T>
bool CscsList<T>::contains(const T &t) const
{
    Node *b = reinterpret_cast<Node *>(p.begin());
    Node *i = reinterpret_cast<Node *>(p.end());
    while (i-- != b)
        if (i->t() == t)
            return true;
    return false;
}

template <typename T>
int CscsList<T>::count(const T &t) const
{
    int c = 0;
    Node *b = reinterpret_cast<Node *>(p.begin());
    Node *i = reinterpret_cast<Node *>(p.end());
    while (i-- != b)
        if (i->t() == t)
            ++c;
    return c;
}
SCS_DECLARE_SEQUENTIAL_ITERATOR(List)
SCS_DECLARE_MUTABLE_SEQUENTIAL_ITERATOR(List)

END_NAMESPACE

#endif