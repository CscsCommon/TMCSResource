#ifndef SCSOBJECT_P_H
#define SCSOBJECT_P_H
#include "scswritereadlock.h"
#include "scslist.h"
#include "scsset.h"
#include "scspointer.h"
#include <string>
#include <list>
#include <set>
#include <unordered_map>
#include "scsvariant.h"

#ifdef D_WIN32
#include <windows.h>
#endif

BEGIN_NAMESPACE(Gemini)

class CscsObject;
class CscsThread;
class CscsThreadInfo;


// typedef std::list<CscsObject* > CscsObjectList;
// typedef std::list<CscsObject* >::iterator CscsObjectListIt;
typedef CscsSet<CscsObject* > CscsObjectSet;

class CscsObjectPrivate{
public:
	CscsObjectPrivate();
	virtual ~CscsObjectPrivate();

	static CscsWriteReadLock* writeReadLock();

	static bool isValidObject(CscsObject* object);
	static void addObjects(CscsObject* object);
	static void removeObjects(CscsObject* object);
	static CscsObjectSet* obtainObjects();

	CscsObject* mm_func()const;

	int m_thread;

	void moveToThread(CscsThread* target);
	void setThreadId(CscsThreadInfo* data, CscsThreadInfo* target, int id);
	void reregisterTimers(void *pointer);
	
	void setParent(CscsObject* parent);
//members
	CscsObject* mm;
	CscsObject* parent;
	CscsObjectList	children;
	bool isWidget;
	bool wasDeleted;
	bool hasPendingTimer;
	bool sendChildEvents;
	bool receiveChildEvents;
	int  postedEvents;
	int  bus_id;
	static std::atomic<int> bus_gen;
	#ifdef D_WIN32
	HWND handle;
	#endif
	std::string objectName;
	CscsList<CscsPointer<CscsObject> > eventFilters;
	std::unordered_map<std::string,CscsVariant> properties;
};

END_NAMESPACE

#endif