 /*Created by J.Wong 2018/09/19
 version:    version 1.0,
 dependency: base on  or greater than c++11
 function: type erase
 gcc4.9+
 */

#ifndef CSCSSOCKETNOTIFIER_H
#define CSCSSOCKETNOTIFIER_H

#include "scsevent.h"
#include "scsutils.h"
#include "scsobject.h"
#include "scsabstracteventdispatcher.h"

BEGIN_NAMESPACE(Gemini)

class CscsSocketNotifier:public CscsObject
{

public:

	enum Type{
		Read,
		Write,
		Exception
	};

	CscsSocketNotifier(int socket, Type type, CscsObject* parent=0)
	:CscsObject(parent)
	{
		classname="CscsSocketNotifier";
		storeherits(classname);
		m_sockfd=socket;
		m_sntype=type;
		m_snenable=true;
		CscsAbstractEventDispatcher* eventDispatcher=CscsAbstractEventDispatcher::instance(thread());
		if(eventDispatcher){
			eventDispatcher->registerSocketNotifier(this);
		}
		//scs_set_socket_handler(m_sockfd, m_sntype, this, true);

	}

	virtual ~CscsSocketNotifier(){
		setEnabled(false);
	}

	int socket()const{

		return m_sockfd;
	}

	Type type()const{

		return m_sntype;
	}

	bool isEnabled()const{

		return m_snenable;
	}

	virtual void setEnabled(bool enable){
			if(m_sockfd<0)
				return ;
			if(m_snenable==enable)
				return;
			m_snenable=enable;
			//scs_set_socket_handler(m_sockfd, m_sntype, this, m_snenable);
			CscsAbstractEventDispatcher* eventDispatcher=CscsAbstractEventDispatcher::instance(thread());
			if(!eventDispatcher) return ;
			if(m_snenable)
				eventDispatcher->registerSocketNotifier(this);
			else
				eventDispatcher->unregisterSocketNotifier(this);
	}

	void activated(int socket){

	}


	const CscsSender& sender()const{

		return m_sender;
	}



protected:
	struct CscsInputevent{
		unsigned int dummy1;
		unsigned int dummy2;
		unsigned short type;
		unsigned short code;
		unsigned int value;
	};

	bool event(CscsEvent* e){
		if (e->type() == CscsEvent::ThreadChange) {
	        if (m_snenable) {
	            CscsObject::invokeMethod(this, "enabled",
	                                      CscsVariant(m_snenable));
	            setEnabled(false);
	        }
    	}

		CscsObject::event(e);
		if(e->type()==CscsEvent::SockActive){
			transmit<void, int>(m_sockfd,"activated");
		}
		return true;
	}

private:
	int m_sockfd;
	Type m_sntype;
	bool m_snenable;

BEGIN_PROPERTY(CscsSocketNotifier, CscsObject)
META_WRITE_PROPERTY(bool,enabled, WRITE, setEnabled)
END_PROPERTY

};

END_NAMESPACE

#endif
