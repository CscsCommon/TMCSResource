 /*Created by J.Wong 2018/10/24
 version:    version 1.0,
 dependency: base on  or greater than c++11
 function: type erase
 gcc4.9+
 */
#ifndef SCSTHREAD_H
#define SCSTHREAD_H

#include "scsobject.h"
#include <limits>


BEGIN_NAMESPACE(Gemini)

class CscsThreadInfo;
class CscsThreadPrivate;

class CscsThread:public CscsObject{
public:
	CscsThread(CscsObject* parent =0);
	~CscsThread();

	enum Priority{
		IdlePriority,

		LowestPriority,
        LowPriority,
        NormalPriority,
        HighPriority,
        HighestPriority,

        TimeCriticalPriority,

        InheritPriority
	};


	static int currentThreadId();
	static CscsThread* currentThread();
	static int idealThreadCount();
	
	void setPriority(Priority priority);
    Priority priority() const;

	bool isFinished()const;
	bool isRunning()const;

	void setStackSize(int stackSize);
	int stackSize()const;


	void exit(int retcode=0);
	bool wait(uint32 mecs=std::numeric_limits<uint32>::max());

SLOTS:
	void start(CscsThread::Priority=InheritPriority);
	void terminate();
	void quit();

SIGNALS:
	void started(){}
	void finished(){}
	void terminated(){}

protected:
	CscsThread(CscsThreadPrivate* dd, CscsObject *parent = 0);

	virtual void run()=0;
	int exec();
	static void setTerminationEnabled(bool enable=true);

	static void sleep(uint32);
	static void msleep(uint32);
	static void usleep(uint32);

private:

	static void initialize();
	static void cleanup();
	CscsThreadPrivate* d_func()const;

	friend class CscsThreadPrivate;
	friend class CscsApplicationPlus;
	friend class CscsApplicationThreadPlus;
	friend class CscsThreadInfo;
};

END_NAMESPACE

#endif