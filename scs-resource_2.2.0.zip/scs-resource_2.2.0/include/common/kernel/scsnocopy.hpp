 /*Created by J.Wong 2018/09/18
 version:    version 1.0,
 dependency: base on  or greater than c++11
 function: forbidden copy
 gcc4.9+
 */

#ifndef CSCSNOCOPYABLE_H
#define CSCSNOCOPYABLE_H
#include "scsnamespace.h"

/*! \class CscsNoCopyable scsnocopy.hpp "kernel/scsnocopy.hpp"
 *  \brief 		禁止拷贝和赋值操作类.
 * 	\brief		CscsNoCopyable类：从该类继承,拷贝和赋值操作被禁止.
 * 	\author 	J.Wong
 *	\date  		2018/09/18 
 * 	\version 	1.0
 * 	
 */
BEGIN_NAMESPACE(Gemini)

class CscsNoCopyable{
public:
	CscsNoCopyable(const CscsNoCopyable&)=delete;
	CscsNoCopyable& operator=(const CscsNoCopyable&)=delete;
	CscsNoCopyable()=default;
};

END_NAMESPACE
#endif
