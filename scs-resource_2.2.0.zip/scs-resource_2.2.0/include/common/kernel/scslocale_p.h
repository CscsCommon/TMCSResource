#ifndef SCSLOCALEPRIV_H
#define SCSLOCALEPRIV_H
#include "scsstring.h"

BEGIN_NAMESPACE(Gemini)

struct CscsLocalePrivate
{
public:
   const CscsChar &decimal() const { return reinterpret_cast<const CscsChar&>(m_decimal); }
    const CscsChar &group() const { return reinterpret_cast<const CscsChar&>(m_group); }
    const CscsChar &list() const { return reinterpret_cast<const CscsChar&>(m_list); }
    const CscsChar &percent() const { return reinterpret_cast<const CscsChar&>(m_percent); }
    const CscsChar &zero() const { return reinterpret_cast<const CscsChar&>(m_zero); }
    CscsChar plus() const { return CscsLatin1Char('+'); }
    const CscsChar &minus() const { return reinterpret_cast<const CscsChar&>(m_minus); }
    const CscsChar &exponential() const { return reinterpret_cast<const CscsChar&>(m_exponential); }
    CscsString infinity() const;
    CscsString nan() const;

    uint32 languageId() const { return m_language_id; }
    uint32 countryId() const { return m_country_id; }

    enum DoubleForm {
        DFExponent = 0,
        DFDecimal,
        DFSignificantDigits,
        _DFMax = DFSignificantDigits
    };

    enum Flags {
        NoFlags             = 0,
        Alternate           = 0x01,
        ZeroPadded          = 0x02,
        LeftAdjusted        = 0x04,
        BlankBeforePositive = 0x08,
        AlwaysShowSign      = 0x10,
        ThousandsGroup      = 0x20,
        CapitalEorX         = 0x40
    };

    enum GroupSeparatorMode {
        FailOnGroupSeparators,
        ParseGroupSeparators
    };

    CscsString doubleToString(double d,
                           int precision = -1,
                           DoubleForm form = DFSignificantDigits,
                           int width = -1,
                           unsigned flags = NoFlags) const;
    CscsString longLongToString(int64 l, int precision = -1,
                             int base = 10,
                             int width = -1,
                             unsigned flags = NoFlags) const;
    CscsString unsLongLongToString(uint64 l, int precision = -1,
                                int base = 10,
                                int width = -1,
                                unsigned flags = NoFlags) const;
    double stringToDouble(const CscsString &num, bool *ok, GroupSeparatorMode group_sep_mode) const;
    int64 stringToLongLong(const CscsString &num, int base, bool *ok, GroupSeparatorMode group_sep_mode) const;
    uint64 stringToUnsLongLong(const CscsString &num, int base, bool *ok, GroupSeparatorMode group_sep_mode) const;


    static double bytearrayToDouble(const char *num, bool *ok);
    static int64 bytearrayToLongLong(const char *num, int base, bool *ok);
    static uint64 bytearrayToUnsLongLong(const char *num, int base, bool *ok);

    bool numberToCLocale(const CscsString &num,
    	    	    	  GroupSeparatorMode group_sep_mode,
                          bytearray *result) const;

    char digitToCLocale(CscsChar in) const;
                          
    uint32 m_language_id, m_country_id;
    uint16 m_decimal, m_group, m_list, m_percent,
        m_zero, m_minus, m_exponential;

    static bytearray systemLocaleName();
};

END_NAMESPACE

#endif
