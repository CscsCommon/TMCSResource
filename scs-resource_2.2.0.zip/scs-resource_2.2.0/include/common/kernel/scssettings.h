#ifndef SCSSETTINGS_H
#define SCSSETTINGS_H
#include "scsobject.h"
#include "scsvariant.h"
#include "scsstring.h"
#include "scsmap.h"

BEGIN_NAMESPACE(Gemini)
class CscsDevice;
class CscsSettingsPrivate;

class  CscsSettings : public CscsObject
{

    CscsSettingsPrivate* d_func()const;
public:
    enum Status {
        NoError = 0,
        AccessError,
        FormatError
    };

    enum Format {
        NativeFormat,
        IniFormat,

        InvalidFormat = 16,
        CustomFormat1,
        CustomFormat2,
        CustomFormat3,
        CustomFormat4,
        CustomFormat5,
        CustomFormat6,
        CustomFormat7,
        CustomFormat8,
        CustomFormat9,
        CustomFormat10,
        CustomFormat11,
        CustomFormat12,
        CustomFormat13,
        CustomFormat14,
        CustomFormat15,
        CustomFormat16
    };

    enum Scope {
        UserScope,
        SystemScope
    };

    explicit CscsSettings(const CscsString &organization,
                       const CscsString &application = CscsString(), CscsObject *parent = 0);
    CscsSettings(Scope scope, const CscsString &organization,
              const CscsString &application = CscsString(), CscsObject *parent = 0);
    CscsSettings(Format format, Scope scope, const CscsString &organization,
	      const CscsString &application = CscsString(), CscsObject *parent = 0);
    CscsSettings(const CscsString &fileName, Format format, CscsObject *parent = 0);
    explicit CscsSettings(CscsObject *parent = 0);

    ~CscsSettings();

    void clear();
    void sync();
    Status status() const;

    void beginGroup(const CscsString &prefix);
    void endGroup();
    CscsString group() const;

    int beginReadArray(const CscsString &prefix);
    void beginWriteArray(const CscsString &prefix, int size = -1);
    void endArray();
    void setArrayIndex(int i);

    CscsStringList allKeys() const;
    CscsStringList childKeys() const;
    CscsStringList childGroups() const;
    bool isWritable() const;

    void setValue(const CscsString &key, const CscsVariant &value);
    CscsVariant value(const CscsString &key, const CscsVariant &defaultValue = CscsVariant()) const;

    void remove(const CscsString &key);
    bool contains(const CscsString &key) const;

    void setFallbacksEnabled(bool b);
    bool fallbacksEnabled() const;

    CscsString fileName() const;
    Format format() const;
    Scope scope() const;
    CscsString organizationName() const;
    CscsString applicationName() const;

    static void setDefaultFormat(Format format);
    static Format defaultFormat();
    static void setSystemIniPath(const CscsString &dir);
    static void setUserIniPath(const CscsString &dir);
    static void setPath(Format format, Scope scope, const CscsString &path);

    typedef CscsMap<CscsString, CscsVariant> SettingsMap;
    typedef bool (*ReadFunc)(CscsDevice &device, SettingsMap &map);
    typedef bool (*WriteFunc)(CscsDevice &device, const SettingsMap &map);

    static Format registerFormat(const CscsString &extension, ReadFunc readFunc, WriteFunc writeFunc,
                                 CscsString::CaseSensitivity caseSensitivity = CscsString::CaseSensitive);

protected:
    bool event(CscsEvent *event);
};

END_NAMESPACE

#endif