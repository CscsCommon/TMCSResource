#ifndef SCSSOCKETLAYER_H
#define SCSSOCKETLAYER_H

#include "scsabstractsocket.h"
#include "scsaddress.h"

#include <kernel/scstypes.h>
#include <kernel/scsnocopy.hpp>
#include <string>

BEGIN_NAMESPACE(Gemini)

class CscsSocketLayerPrivate;

class CscsSocketLayer:public CscsNoCopyable{
public:
    enum SocketOption{
      NonBlockingSocketOption,
      BroadcastSocketOption,
      ReceiveBufferSocketOption,
      SendBufferSocketOption,
      AddressReusable
    };

    CscsSocketLayer();
    ~CscsSocketLayer();

    bool init(CscsAbstractSocket::SocketType type, CscsAbstractSocket::NetWorkProtocol protocol=CscsAbstractSocket::IPv4Protocol);
    bool init(int socketDescriptor, CscsAbstractSocket::SocketState socketState=CscsAbstractSocket::ConnectedState);

    CscsAbstractSocket::SocketType socketType()const;
    CscsAbstractSocket::NetWorkProtocol protocol()const;

    int socketDescriptor()const; 

    bool isValid()const;


    bool connectedToHost(const CscsAddress& addr, uint16 port);
    bool bind(const CscsAddress& addr, uint16 port);
    bool listen();
    int accept();
    void close();

    int64 bytesAvailable()const;
    int64 read(char* data, int64 maxlen);
    int64 write(const char* data, int64 len);

    int64 readDatagram(char* data, int64 maxlen, CscsAddress* addr=0, uint16* port=0);
    int64 writeDatagram(const char* data, int64 len, const CscsAddress& addr, uint16 port);
    bool hasPendingDatagrams()const;
    int64 pendingDatagramSize()const;

    CscsAbstractSocket::SocketState state()const;

    CscsAddress localAddress()const;
    uint16 localPort()const;
    CscsAddress peerAddress()const;
    uint16 peerPort()const;

    int64 receiveBufferSize()const;
    void setReceiveBufferSize(int size);

    int64 sendBufferSize()const;
    void setSendBufferSize(int size);

    int option(SocketOption option)const;
    bool setOption(SocketOption option, int value);

    bool waitForRead(int msecs=30000, bool* timedOut=0)const;
    bool waitForWrite(int msecs=30000, bool* timedOut=0)const;
    bool waitForReadOrWrite(bool* readyToRead, bool* readyToWrite, bool checkRead, bool checkWrite,
                            int msecs=30000, bool* timedOut=0)const;

    CscsAbstractSocket::SocketError error()const;
    std::string errorString()const;

  private:
    CscsSocketLayerPrivate* d;
};

#ifdef D_WIN32
class CscsWindowsSockInit
{
public:
    CscsWindowsSockInit();
    ~CscsWindowsSockInit();
    int version;
};
#endif

class CscsSocketLayerPrivate{
public:
  CscsSocketLayerPrivate(CscsSocketLayer* layer=nullptr);
  ~CscsSocketLayerPrivate();

  int socketDescriptor;
  CscsAbstractSocket::SocketType socketType;
  CscsAbstractSocket::NetWorkProtocol socketProtocol;
  CscsAbstractSocket::SocketState socketState;
  mutable CscsAbstractSocket::SocketError socketError;
  mutable std::string socketErrString;
  CscsAddress peerAddress;
  uint16 peerPort;

  CscsAddress localAddress;
  uint16 localPort;
  #ifdef D_WIN32
  CscsWindowsSockInit winSock;
  #endif
  enum ErrorString{
    NonBlockingInitFailedErrorString,
    BroadcastingInitFailedErrorString,
    NoIpV6ErrorString,
    RemoteHostClosedErrorString,
    TimeOutErrorString,
    ResourceErrorString,
    OperationUnsupportedErrorString,
    ProtocolUnsupportedErrorString,
    InvalidSocketErrorString,
    UnreachableErrorString,
    AccessErrorString,
    ConnectionTimeOutErrorString,
    ConnectionRefusedErrorString,
    AddressInuseErrorString,
    AddressNotAvailableErrorString,
    AddressProtectedErrorString,
    DatagramTooLargeErrorString,
    SendDatagramErrorString,
    ReceiveDatagramErrorString,
    WriteErrorString,
    ReadErrorString,
    PortInuseErrorString
  };

  void setError(CscsAbstractSocket::SocketError error, ErrorString errorString) const;

  int option(CscsSocketLayer::SocketOption option) const;
  bool setOption(CscsSocketLayer::SocketOption, int value);

  bool createNewSocket(CscsAbstractSocket::SocketType type, CscsAbstractSocket::NetWorkProtocol protocol);

  bool nativeConnect(const CscsAddress& addr, uint16 port);
  bool nativeBind(const CscsAddress& addr, uint16 port);
  bool nativeListen(int backlog);
  int nativeAccept();
  int64 nativeBytesAvailable()const;

  bool nativeHasPendingDatagrams()const;
  int64 nativePendingDatagramSize()const;
  int64 nativeReceiveDatagram(char* data, int64 maxlen, CscsAddress* addr, uint16* port);
  int64 nativeSendDatagram(const char* data, int len, const CscsAddress& addr, uint16 port);

  int64 nativeWrite(const char* data, int len);
  int64 nativeRead(char* data, int maxlen);

  int nativeSelect(int timeout, bool selectedForRead)const;
  int nativeSelect(int timeout, bool checkRead, bool checkWrite, bool* selectedForRead, bool* selectForWrite)const;

  void nativeClose();
  bool fetchConnectionParameters();

  CscsSocketLayer* mm;
};

END_NAMESPACE

#endif
