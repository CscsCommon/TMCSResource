#ifndef SCSABSTRACTSOCKET_H
#define SCSABSTRACTSOCKET_H
#include <kernel/scsdevice.h>
#include <kernel/scsobject.h>
#include <kernel/scstypes.h>
#include <string>
#include <list>
#include <kernel/scsmessagebus.hpp>
#include <kernel/scssender.hpp>


BEGIN_NAMESPACE(Gemini)

class CscsAbstractSocketPrivate;
class CscsAddress;

class CscsAbstractSocket:public CscsDevice{
public:
    enum SocketType{
      TcpSocket,
      UdpSocket,
      UnknownSocketType=-1
    };
    enum NetWorkProtocol{
      IPv4Protocol,
      IPv6Protocol,
      UnknownNetworkProtocol=-1
    };

    enum SocketError{
        ConnectionRefusedError,
        RemoteHostClosedError,
        HostNotFoundError,
        SocketAccessError,
        SocketResourceError,
        SocketTimeoutError,                     /* 5 */
        DatagramTooLargeError,
        NetworkError,
        AddressInUseError,
        SocketAddressNotAvailableError,
        UnsupportedSocketOperationError,        /* 10 */
        UnfinishedSocketOperationError,
        ProxyAuthenticationRequiredError,
        SslHandshakeFailedError,
        ProxyConnectionRefusedError,
        ProxyConnectionClosedError,             /* 15 */
        ProxyConnectionTimeoutError,
        ProxyNotFoundError,
        ProxyProtocolError,
        OperationError,
        SslInternalError,                       /* 20 */
        SslInvalidUserDataError,
        TemporaryError,

        UnknownSocketError = -1
    };

    enum SocketState{
      UnconnectedState,
      HostLookupState,
      ConnectingState,
      ConnectedState,
      BoundState,
      ListeningState,
      ClosingState
    };

    CscsAbstractSocket(SocketType type, CscsObject* parent=nullptr);
    virtual ~CscsAbstractSocket();

    void connectToHost(const std::string& hostName, uint16 port, SCSOpenMode mode=ReadWrite);
    void connectToHost(const CscsAddress& hostAddress,uint16 port, SCSOpenMode mode=ReadWrite);
    void disconnectFromHost();

    bool isValid()const;
    int64 bytesAvailable()const;
    int64 bytesToWrite()const;
    bool canReadLine()const;
    uint16 localPort()const;
    CscsAddress localAddress()const;
    uint16 peerPort()const;
    CscsAddress peerAddress()const;
    std::string peerName()const;
    int64 readBufferSize()const;
    void  setReadBufferSize(int64 size);

    void abort();
    int socketDescriptor()const;
    bool setSocketDescriptor(int socketDescriptor, SocketState state=ConnectedState, SCSOpenMode mode=ReadWrite);
    SocketType socketType()const;
    SocketState state()const;
    SocketError error()const;

    void close();
    bool isSequential()const;
    bool atEnd()const;
    bool flush();

    bool waitForConnected(int msecs=30000);
    bool waitForReadyRead(int msecs=30000);
    bool waitForBytesWritten(int msecs=30000);
    bool waitForDisconnected(int msecs=30000);

//signals
  SIGNALS:
    void hostFound(){

    }

    void connected(){

    }

    void disconnected(){

    }

    void stateChanged(CscsAbstractSocket::SocketState){

    }

    void error(CscsAbstractSocket::SocketError){

    }



protected:
    int64 readData(char* data, int64 maxlen);
    int64 readLineData(char* data, int64 maxlen);
    int64 writeData(const char* data, int64 maxlen);

    CscsAbstractSocketPrivate* d_func()const;

    void setSocketState(SocketState state);
    void setSocketError(SocketError socketError);
private:
    CscsAbstractSocketPrivate* d;

};

END_NAMESPACE

#endif
