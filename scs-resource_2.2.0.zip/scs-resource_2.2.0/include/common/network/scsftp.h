#ifndef SCSFTP_H
#define SCSFTP_H
#include "scsurlinfo.h"
#include <kernel/scsobject.h>
#include <kernel/scsstring.h>

BEGIN_NAMESPACE(Gemini)

class CscsFtpPrivate;
class  CscsFtp : public CscsObject
{
public:
    explicit CscsFtp(CscsObject *parent = nullptr);
    virtual ~CscsFtp();

    enum State {
        Unconnected,
        HostLookup,
        Connecting,
        Connected,
        LoggedIn,
        Closing
    };
    enum Error {
        NoError,
        UnknownError,
        HostNotFound,
        ConnectionRefused,
        NotConnected
    };
    enum Command {
        None,
        SetTransferMode,
        SetProxy,
        ConnectToHost,
        Login,
        Close,
        List,
        Cd,
        Get,
        Put,
        Remove,
        Mkdir,
        Rmdir,
        Rename,
        RawCommand
    };
    enum TransferMode {
        Active,
        Passive
    };
    enum TransferType {
        Binary,
        Ascii
    };

    int setProxy(const CscsString &host, uint16 port);
    int connectToHost(const CscsString &host, uint16 port=21);
    int login(const CscsString &user = CscsString(), const CscsString &password = CscsString());
    int close();
    int setTransferMode(TransferMode mode);
    int list(const CscsString &dir = CscsString());
    int cd(const CscsString &dir);
    int get(const CscsString &file, CscsDevice *dev=0, TransferType type = Binary);
    int put(const CscsByteArray &data, const CscsString &file, TransferType type = Binary);
    int put(CscsDevice *dev, const CscsString &file, TransferType type = Binary);
    int remove(const CscsString &file);
    int mkdir(const CscsString &dir);
    int rmdir(const CscsString &dir);
    int rename(const CscsString &oldname, const CscsString &newname);

    int rawCommand(const CscsString &command);

    int64 bytesAvailable() const;
    int64 read(char *data, int64 maxlen);
    CscsByteArray readAll();

    int currentId() const;
    CscsDevice* currentDevice() const;
    Command currentCommand() const;
    bool hasPendingCommands() const;
    void clearPendingCommands();

    State state() const;

    Error error() const;
    CscsString errorString() const;

SLOTS:
    void abort();

SIGNALS:
    void stateChanged(int){}
    void listInfo(const CscsUrlInfo&){}
    void readyRead(){}
    void dataTransferProgress(int64, int64){}
    void rawCommandReply(int, const CscsString&){}

    void commandStarted(int){}
    void commandFinished(int, bool){}
    void done(bool){}


private:
    CscsFtpPrivate* d_func()const;
    friend class CscsFtpPrivate;
};

END_NAMESPACE

#endif