#ifndef SCSURLINFO_H
#define SCSURLINFO_H
#include <kernel/scstime.h>
#include <kernel/scsstring.h>
#include <kernel/scsdevice.h>

BEGIN_NAMESPACE(Gemini)

class CscsUrl;
class CscsUrlInfoPrivate;

class  CscsUrlInfo
{
public:
    enum PermissionSpec {
        ReadOwner = 00400, WriteOwner = 00200, ExeOwner = 00100,
        ReadGroup = 00040, WriteGroup = 00020, ExeGroup = 00010,
        ReadOther = 00004, WriteOther = 00002, ExeOther = 00001 };

    CscsUrlInfo();
    CscsUrlInfo(const CscsUrlInfo &ui);
    CscsUrlInfo(const CscsString &name, int permissions, const CscsString &owner,
             const CscsString &group, int64 size, const CscsDateTime &lastModified,
             const CscsDateTime &lastRead, bool isDir, bool isFile, bool isSymLink,
             bool isWritable, bool isReadable, bool isExecutable);
    CscsUrlInfo(const CscsUrl &url, int permissions, const CscsString &owner,
             const CscsString &group, int64 size, const CscsDateTime &lastModified,
             const CscsDateTime &lastRead, bool isDir, bool isFile, bool isSymLink,
             bool isWritable, bool isReadable, bool isExecutable);
    CscsUrlInfo &operator=(const CscsUrlInfo &ui);
    virtual ~CscsUrlInfo();

    virtual void setName(const CscsString &name);
    virtual void setDir(bool b);
    virtual void setFile(bool b);
    virtual void setSymLink(bool b);
    virtual void setOwner(const CscsString &s);
    virtual void setGroup(const CscsString &s);
    virtual void setSize(int64 size);
    virtual void setWritable(bool b);
    virtual void setReadable(bool b);
    virtual void setPermissions(int p);
    virtual void setLastModified(const CscsDateTime &dt);

    bool isValid() const;

    CscsString name() const;
    int permissions() const;
    CscsString owner() const;
    CscsString group() const;
    int64 size() const;
    CscsDateTime lastModified() const;
    CscsDateTime lastRead() const;
    bool isDir() const;
    bool isFile() const;
    bool isSymLink() const;
    bool isWritable() const;
    bool isReadable() const;
    bool isExecutable() const;

    static bool greaterThan(const CscsUrlInfo &i1, const CscsUrlInfo &i2,
                             int sortBy);
    static bool lessThan(const CscsUrlInfo &i1, const CscsUrlInfo &i2,
                          int sortBy);
    static bool equal(const CscsUrlInfo &i1, const CscsUrlInfo &i2,
                       int sortBy);

    bool operator==(const CscsUrlInfo &i) const;

private:
    CscsUrlInfoPrivate *d;
};

END_NAMESPACE

#endif
