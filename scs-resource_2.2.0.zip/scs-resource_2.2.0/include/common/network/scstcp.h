#ifndef SCSTCP_H
#define SCSTCP_H
#include "scsabstractsocket.h"

BEGIN_NAMESPACE(Gemini)

class CscsTcp:public CscsAbstractSocket{
public:
	CscsTcp(CscsObject* parent=nullptr);
	virtual ~CscsTcp();
};

END_NAMESPACE

#endif