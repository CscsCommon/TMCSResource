#ifndef SCSPLOTSERIESITEM_H
#define SCSPLOTSERIESITEM_H
#include "scsplotitem.h"
#include "scsplotscalediv.h"
#include "scsplotseriesdata.h"
#include "scsplotseriesstore.h"
#include <window/scsenum.h>

BEGIN_NAMESPACE(Gemini)

class  CscsPlotSeriesItem: public CscsPlotItem,
    public virtual CscsPlotAbstractSeriesStore
{
public:
    explicit CscsPlotSeriesItem( const CscsString &title = CscsString::null );
    explicit CscsPlotSeriesItem( const CscsPlotText &title );

    virtual ~CscsPlotSeriesItem();

    void setOrientation( SCS::Orientation );
    SCS::Orientation orientation() const;

    virtual void draw( CscsPainter *p,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF & ) const;

    virtual void drawSeries( CscsPainter *painter,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect, int from, int to ) const = 0;

    virtual CscsRectF boundingRect() const;

    virtual void updateScaleDiv( 
        const CscsPlotScaleDiv &, const CscsPlotScaleDiv & );

protected:
    virtual void dataChanged();

private:
    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE


#endif