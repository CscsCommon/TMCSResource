#ifndef SCSPLOTLEGEND_H
#define SCSPLOTLEGEND_H
#include "scsplotabstractlegend.h"
#include <kernel/scslist.h>
#include <kernel/scsvariant.h>

BEGIN_NAMESPACE(Gemini)

class CscsScrollBar;

class  WIDGET_EXPORT CscsPlotLegend : public CscsPlotAbstractLegend
{

public:
    explicit CscsPlotLegend( CscsWidget *parent = nullptr );
    virtual ~CscsPlotLegend();

    void setMaxColumns( uint numColums );
    uint maxColumns() const;

    void setDefaultItemMode( CscsPlotLegendData::Mode );
    CscsPlotLegendData::Mode defaultItemMode() const;

    CscsWidget *contentsWidget();
    const CscsWidget *contentsWidget() const;

    CscsWidget *legendWidget( const CscsVariant &  ) const;
    CscsList<CscsWidget *> legendWidgets( const CscsVariant & ) const;

    CscsVariant itemInfo( const CscsWidget * ) const;

    virtual bool eventFilter( CscsObject *, CscsEvent * );

    virtual CscsSize sizeHint() const;
    virtual int heightForWidth( int w ) const;

    CscsScrollBar *horizontalScrollBar() const;
    CscsScrollBar *verticalScrollBar() const;

    virtual void renderLegend( CscsPainter *, 
        const CscsRectF &, bool fillBackground ) const;

    virtual void renderItem( CscsPainter *, 
        const CscsWidget *, const CscsRectF &, bool fillBackground ) const;

    virtual bool isEmpty() const;
    virtual int scrollExtent( SCS::Orientation ) const;

SIGNALS:

    void clicked( const CscsVariant &itemInfo, int index ){}
    void checked( const CscsVariant &itemInfo, bool on, int index ){}

SLOTS:
    virtual void updateLegend( const CscsVariant &,
        const CscsList<CscsPlotLegendData> & );

    void itemClicked();
    void itemChecked( bool );

protected:
    virtual CscsWidget *createWidget( const CscsPlotLegendData & );
    virtual void updateWidget( CscsWidget *widget, const CscsPlotLegendData &data );

private:
    void updateTabOrder();

    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE

#endif