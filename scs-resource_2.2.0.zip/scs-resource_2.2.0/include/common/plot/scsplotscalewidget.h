#ifndef SCSPLOTSCALEWIDGET_H
#define SCSPLOTSCALEWIDGET_H
#include "scsplottext.h"
#include "scsplotscaledraw.h"
#include <window/scswidget.h>
#include <painting/scsfont.h>
#include <painting/scsrgba.h>
#include <kernel/scsstring.h>

BEGIN_NAMESPACE(Gemini)

class CscsPainter;
class CscsPlotTransform;
class CscsPlotScaleDiv;
class CscsPlotColorMap;

class WIDGET_EXPORT CscsPlotScaleWidget : public CscsWidget
{
public:
    enum LayoutFlag
    {
        TitleInverted = 1
    };

    //! Layout flags of the title
    typedef CscsFlags<LayoutFlag> LayoutFlags;

    explicit CscsPlotScaleWidget( CscsWidget *parent = NULL );
    explicit CscsPlotScaleWidget( CscsPlotScaleDraw::Alignment, CscsWidget *parent = NULL );
    virtual ~CscsPlotScaleWidget();

SIGNALS:
    //! Signal transmitted, whenever the scale division changes
    void scaleDivChanged(){}

public:
    void setTitle( const std::string &title );
    void setTitle( const CscsPlotText &title );
    CscsPlotText title() const;

    void setLayoutFlag( LayoutFlag, bool on );
    bool testLayoutFlag( LayoutFlag ) const;

    void setBorderDist( int start, int end );
    int startBorderDist() const;
    int endBorderDist() const;

    void getBorderDistHint( int &start, int &end ) const;

    void getMinBorderDist( int &start, int &end ) const;
    void setMinBorderDist( int start, int end );

    void setMargin( int );
    int margin() const;

    void setSpacing( int td );
    int spacing() const;

    void setScaleDiv( const CscsPlotScaleDiv &sd );
    void setTransformation( CscsPlotTransform * );

    void setScaleDraw( CscsPlotScaleDraw * );
    const CscsPlotScaleDraw *scaleDraw() const;
    CscsPlotScaleDraw *scaleDraw();

    void setLabelAlignment( SCS::Alignment );
    void setLabelRotation( double rotation );

    void setColorBarEnabled( bool );
    bool isColorBarEnabled() const;

    void setColorBarWidth( int );
    int colorBarWidth() const;

    void setColorMap( const CscsPlotInterval &, CscsPlotColorMap * );

    CscsPlotInterval colorBarInterval() const;
    const CscsPlotColorMap *colorMap() const;

    virtual CscsSize sizeHint() const;
    virtual CscsSize minimumSizeHint() const;

    int titleHeightForWidth( int width ) const;
    int dimForLength( int length, const CscsFont &scaleFont ) const;

    void drawColorBar( CscsPainter *painter, const CscsRectF & ) const;
    void drawTitle( CscsPainter *painter, CscsPlotScaleDraw::Alignment,
        const CscsRectF &rect ) const;

    void setAlignment( CscsPlotScaleDraw::Alignment );
    CscsPlotScaleDraw::Alignment alignment() const;

    CscsRectF colorBarRect( const CscsRectF& ) const;

protected:
    virtual void paintEvent( CscsPaintEvent * );
    virtual void resizeEvent( CscsResizeEvent * );
    void draw( CscsPainter *p ) const;

    void scaleChange();
    void layoutScale( bool update = true );

private:
    void initScale( CscsPlotScaleDraw::Alignment );

    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE

#endif