#ifndef SCSPLOTHISTOGRAM_H
#define SCSPLOTHISTOGRAM_H
#include "scsplotseriesitem.h"
#include "scsplotcolumnsymbol.h"
#include <painting/scsrgba.h>
#include <kernel/scsvector.h>

BEGIN_NAMESPACE(Gemini)

class CscsPlotIntervalData;
class CscsPolygonF;
class CscsPen;

class  CscsPlotHistogram: 
    public CscsPlotSeriesItem, public CscsPlotSeriesStore<CscsPlotIntervalSample>
{
public:
    enum HistogramStyle
    {
        Outline,
        Columns,
        Lines,
        UserStyle = 100
    };

    explicit CscsPlotHistogram( const std::string &title = std::string() );
    explicit CscsPlotHistogram( const CscsPlotText &title );
    virtual ~CscsPlotHistogram();

    virtual int rtti() const;

    void setPen( const CscsRgba &, double width = 0.0, CscsPen::PenType = CscsPen::SolidPen );
    void setPen( const CscsPen & );
    const CscsPen &pen() const;

    void setBrush( const CscsBrush & );
    const CscsBrush &brush() const;

    void setSamples( const CscsVector<CscsPlotIntervalSample> & );
    void setSamples( CscsPlotSeriesData<CscsPlotIntervalSample> * );

    void setBaseline( double reference );
    double baseline() const;

    void setStyle( HistogramStyle style );
    HistogramStyle style() const;

    void setSymbol( const CscsPlotColumnSymbol * );
    const CscsPlotColumnSymbol *symbol() const;

    virtual void drawSeries( CscsPainter *p,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect, int from, int to ) const;

    virtual CscsRectF boundingRect() const;

    virtual CscsImage legendIcon( int index, const CscsSizeF & ) const;

protected:
    virtual CscsPlotColumnRect columnRect( const CscsPlotIntervalSample &,
        const CscsPlotScaleMap &, const CscsPlotScaleMap & ) const;

    virtual void drawColumn( CscsPainter *, const CscsPlotColumnRect &,
        const CscsPlotIntervalSample & ) const;

    void drawColumns( CscsPainter *,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        int from, int to ) const;

    void drawOutline( CscsPainter *,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        int from, int to ) const;

    void drawLines( CscsPainter *,
         const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
         int from, int to ) const;

private:
    void init();
    void flushPolygon( CscsPainter *, double baseLine, CscsPolygonF & ) const;

    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE

#endif