#ifndef SCSPLOTPICKER_H
#define SCSPLOTPICKER_H
#include "scspicker.h"
#include <kernel/scsvector.h>

BEGIN_NAMESPACE(Gemini)

class CscsPlot;

class  CscsPlotPicker: public CscsPicker
{
public:
    explicit CscsPlotPicker( CscsWidget *canvas );
    virtual ~CscsPlotPicker();

    explicit CscsPlotPicker( int xAxis, int yAxis, CscsWidget * );

    explicit CscsPlotPicker( int xAxis, int yAxis,
        RubberBand rubberBand, DisplayMode trackerMode, CscsWidget * );

    virtual void setAxis( int xAxis, int yAxis );

    int xAxis() const;
    int yAxis() const;

    CscsPlot *plot();
    const CscsPlot *plot() const;

    CscsWidget *canvas();
    const CscsWidget *canvas() const;

SIGNALS:

    void selected( const CscsPointF &pos ){}
    void selected( const CscsRectF &rect ){}
    void selected( const CscsVector<CscsPointF> &pa ){}
    void appended( const CscsPointF &pos ){}
    void moved( const CscsPointF &pos ){}

protected:
    CscsRectF scaleRect() const;

    CscsRectF invTransform( const CscsRect & ) const;
    CscsRect transform( const CscsRectF & ) const;

    CscsPointF invTransform( const CscsPoint & ) const;
    CscsPoint transform( const CscsPointF & ) const;

    virtual CscsPlotText trackerText( const CscsPoint & ) const;
    virtual CscsPlotText trackerTextF( const CscsPointF & ) const;

    virtual void move( const CscsPoint & );
    virtual void append( const CscsPoint & );
    virtual bool end( bool ok = true );

private:
    int d_xAxis;
    int d_yAxis;
};

END_NAMESPACE

#endif