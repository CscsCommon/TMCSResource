#ifndef SCSPLOTMAGNIFIER_H
#define SCSPLOTMAGNIFIER_H
#include <kernel/scsobject.h>
#include <window/scsenum.h>
#include <window/scswindowevent.h>

BEGIN_NAMESPACE(Gemini)

class CscsWidget;
class CscsMouseEvent;
class CscsKeyEvent;



class  CscsPlotMagnifier: public CscsObject
{

public:
    explicit CscsPlotMagnifier( CscsWidget * );
    virtual ~CscsPlotMagnifier();

    CscsWidget *parentWidget();
    const CscsWidget *parentWidget() const;

    void setEnabled( bool );
    bool isEnabled() const;

    // mouse
    void setMouseFactor( double );
    double mouseFactor() const;
    void setMouseButton( SCS::MouseButton, SCS::KeyboardModifiers = SCS::NoModifier );
    void getMouseButton( SCS::MouseButton &, SCS::KeyboardModifiers & ) const;

    // keyboard
    void setKeyFactor( double );
    double keyFactor() const;

    void setZoomInKey( int key, SCS::KeyboardModifiers = SCS::NoModifier );
    void getZoomInKey( int &key, SCS::KeyboardModifiers & ) const;

    void setZoomOutKey( int key, SCS::KeyboardModifiers = SCS::NoModifier );
    void getZoomOutKey( int &key, SCS::KeyboardModifiers & ) const;

    virtual bool eventFilter( CscsObject *, CscsEvent * );

protected:
    /*!
       Rescale the parent widget
       \param factor Scale factor
     */
    virtual void rescale( double factor ) = 0;

    virtual void widgetMousePressEvent( CscsMouseEvent * );
    virtual void widgetMouseReleaseEvent( CscsMouseEvent * );
    virtual void widgetMouseMoveEvent( CscsMouseEvent * );
    virtual void widgetKeyPressEvent( CscsKeyEvent * );
    virtual void widgetKeyReleaseEvent( CscsKeyEvent * );

private:
    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE

#endif