#ifndef SCSPLOTABSTRACTLEGEND_H
#define SCSPLOTABSTRACTLEGEND_H
#include "scsplotlegenddata.h"
#include <window/widgets/scsframe.h>
#include <kernel/scslist.h>

BEGIN_NAMESPACE(Gemini)

class CscsVariant;

class  CscsPlotAbstractLegend : public CscsFrame
{
public:
    explicit CscsPlotAbstractLegend( CscsWidget *parent = nullptr );
    virtual ~CscsPlotAbstractLegend();
    virtual void renderLegend( CscsPainter *painter, 
        const CscsRectF &rect, bool fillBackground ) const = 0;
    virtual bool isEmpty() const = 0;

    virtual int scrollExtent( SCS::Orientation ) const;

SLOTS:
    virtual void updateLegend( const CscsVariant &itemInfo, 
        const CscsList<CscsPlotLegendData> &data ) = 0;
};

END_NAMESPACE

#endif