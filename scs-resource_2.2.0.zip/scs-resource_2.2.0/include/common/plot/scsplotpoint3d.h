#ifndef SCSPLOTPOINT3D_H
#define SCSPLOTPOINT3D_H
#include <painting/scspoint.h>

BEGIN_NAMESPACE(Gemini)

class  CscsPlotPoint3D
{
public:
    CscsPlotPoint3D();
    CscsPlotPoint3D( double x, double y, double z );
    CscsPlotPoint3D( const CscsPlotPoint3D & );
    CscsPlotPoint3D( const CscsPointF & );

    bool isNull()    const;

    double x() const;
    double y() const;
    double z() const;

    double &rx();
    double &ry();
    double &rz();

    void setX( double x );
    void setY( double y );
    void setZ( double y );

    CscsPointF toPoint() const;

    bool operator==( const CscsPlotPoint3D & ) const;
    bool operator!=( const CscsPlotPoint3D & ) const;

private:
    double d_x;
    double d_y;
    double d_z;
};

inline CscsPlotPoint3D::CscsPlotPoint3D():
    d_x( 0.0 ),
    d_y( 0.0 ),
    d_z( 0.0 )
{
}

inline CscsPlotPoint3D::CscsPlotPoint3D( double x, double y, double z = 0.0 ):
    d_x( x ),
    d_y( y ),
    d_z( z )
{
}

inline CscsPlotPoint3D::CscsPlotPoint3D( const CscsPlotPoint3D &other ):
    d_x( other.d_x ),
    d_y( other.d_y ),
    d_z( other.d_z )
{
}

inline CscsPlotPoint3D::CscsPlotPoint3D( const CscsPointF &other ):
    d_x( other.x() ),
    d_y( other.y() ),
    d_z( 0.0 )
{
}

inline bool CscsPlotPoint3D::isNull() const
{
    return d_x == 0.0 && d_y == 0.0 && d_z == 0.0;
}

inline double CscsPlotPoint3D::x() const
{
    return d_x;
}

inline double CscsPlotPoint3D::y() const
{
    return d_y;
}

inline double CscsPlotPoint3D::z() const
{
    return d_z;
}

inline double &CscsPlotPoint3D::rx()
{
    return d_x;
}

inline double &CscsPlotPoint3D::ry()
{
    return d_y;
}

inline double &CscsPlotPoint3D::rz()
{
    return d_z;
}

inline void CscsPlotPoint3D::setX( double x )
{
    d_x = x;
}

inline void CscsPlotPoint3D::setY( double y )
{
    d_y = y;
}

inline void CscsPlotPoint3D::setZ( double z )
{
    d_z = z;
}

inline CscsPointF CscsPlotPoint3D::toPoint() const
{
    return CscsPointF( d_x, d_y );
}

inline bool CscsPlotPoint3D::operator==( const CscsPlotPoint3D &other ) const
{
    return ( d_x == other.d_x ) && ( d_y == other.d_y ) && ( d_z == other.d_z );
}

inline bool CscsPlotPoint3D::operator!=( const CscsPlotPoint3D &other ) const
{
    return !operator==( other );
}


END_NAMESPACE

#endif