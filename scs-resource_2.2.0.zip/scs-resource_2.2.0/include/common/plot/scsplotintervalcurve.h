#ifndef SCSPLOTINTERVALCURVE_H
#define SCSPLOTINTERVALCURVE_H

#include "scsplotseriesitem.h"
#include "scsplotseriesdata.h"
#include <painting/scspen.h>
#include <painting/scsimage.h>

BEGIN_NAMESPACE(Gemini)

class CscsPlotIntervalSymbol;

class  CscsPlotIntervalCurve:
    public CscsPlotSeriesItem, public CscsPlotSeriesStore<CscsPlotIntervalSample>
{
public:
    enum CurveStyle
    {
        NoCurve,
        Tube,
        UserCurve = 100
    };
    enum PaintAttribute
    {
        ClipPolygons = 0x01,
        ClipSymbol   = 0x02
    };
    typedef CscsFlags<PaintAttribute> PaintAttributes;

    explicit CscsPlotIntervalCurve( const std::string &title = std::string() );
    explicit CscsPlotIntervalCurve( const CscsPlotText &title );

    virtual ~CscsPlotIntervalCurve();

    virtual int rtti() const;

    void setPaintAttribute( PaintAttribute, bool on = true );
    bool testPaintAttribute( PaintAttribute ) const;

    void setSamples( const CscsVector<CscsPlotIntervalSample> & );
    void setSamples( CscsPlotSeriesData<CscsPlotIntervalSample> * );

    void setPen( const CscsRgba &, double width = 0.0, CscsPen::PenType = CscsPen::SolidPen );
    void setPen( const CscsPen & );
    const CscsPen &pen() const;

    void setBrush( const CscsBrush & );
    const CscsBrush &brush() const;

    void setStyle( CurveStyle style );
    CurveStyle style() const;

    void setSymbol( const CscsPlotIntervalSymbol * );
    const CscsPlotIntervalSymbol *symbol() const;

    virtual void drawSeries( CscsPainter *,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect, int from, int to ) const;

    virtual CscsRectF boundingRect() const;

    virtual CscsImage legendIcon( int index, const CscsSizeF & ) const;

protected:

    void init();

    virtual void drawTube( CscsPainter *,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect, int from, int to ) const;

    virtual void drawSymbols( CscsPainter *, const CscsPlotIntervalSymbol &,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect, int from, int to ) const;

private:
    class PrivateData;
    PrivateData *d_data;
};

SCS_DECLARE_OPERATORS_FOR_FLAGS( CscsPlotIntervalCurve::PaintAttributes )

END_NAMESPACE

#endif