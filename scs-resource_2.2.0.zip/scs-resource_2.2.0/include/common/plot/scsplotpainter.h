#ifndef SCSPLOTPAINTER_H
#define SCSPLOTPAINTER_H
#include <painting/scspoint.h>
#include <painting/scsrect.h>
#include <painting/scspen.h>
#include <painting/scsline.h>
#include <painting/scspolygon.h>
#include <window/styles/scspalette.h>
#include <kernel/scsstring.h>
#include <window/scsenum.h>

BEGIN_NAMESPACE(Gemini)

class CscsPainter;
class CscsBrush;
class CscsRgba;
class CscsWidget;
class CscsRectF;
class CscsImage;
class CscsPlotInterval;
class CscsPath;
class CscsPlotColorMap;
class CscsPlotScaleMap;


class  CscsPlotPainter
{
public:
    static void setPolylineSplitting( bool );
    static bool polylineSplitting();

    static void setRoundingAlignment( bool );
    static bool roundingAlignment();
    static bool roundingAlignment(CscsPainter *);

    static void drawText( CscsPainter *, double x, double y, const CscsString & );
    static void drawText( CscsPainter *, const CscsPointF &, const CscsString & );
    static void drawText( CscsPainter *, double x, double y, double w, double h,
        int flags, const CscsString & );
    static void drawText( CscsPainter *, const CscsRectF &, 
        int flags, const CscsString & ,bool rotate=false);

    static void drawRect( CscsPainter *, double x, double y, double w, double h );
    static void drawRect( CscsPainter *, const CscsRectF &rect );
    static void fillRect( CscsPainter *, const CscsRectF &, const CscsBrush & );

    static void drawEllipse( CscsPainter *, const CscsRectF & );
    static void drawPie( CscsPainter *, const CscsRectF & r, int a, int alen );

    static void drawLine( CscsPainter *, double x1, double y1, double x2, double y2 );
    static void drawLine( CscsPainter *, const CscsPointF &p1, const CscsPointF &p2 );
    static void drawLine( CscsPainter *, const CscsLineF & );

    static void drawPolygon( CscsPainter *, const CscsPolygonF & );
    static void drawPolyline( CscsPainter *, const CscsPolygonF & );
    static void drawPolyline( CscsPainter *, const CscsPointF *, int pointCount );

    static void drawPolygon( CscsPainter *, const CscsPolygon & );
    static void drawPolyline( CscsPainter *, const CscsPolygon & );
    static void drawPolyline( CscsPainter *, const CscsPoint *, int pointCount );

    static void drawPoint( CscsPainter *, const CscsPoint & );
    static void drawPoints( CscsPainter *, const CscsPolygon & );
    static void drawPoints( CscsPainter *, const CscsPoint *, int pointCount );

    static void drawPoint( CscsPainter *, double x, double y );
    static void drawPoint( CscsPainter *, const CscsPointF & );
    static void drawPoints( CscsPainter *, const CscsPolygonF & );
    static void drawPoints( CscsPainter *, const CscsPointF *, int pointCount );

    static void drawPath( CscsPainter *, const CscsPath & );
    static void drawImage( CscsPainter *, const CscsRectF &, const CscsImage & );

    static void drawRoundFrame( CscsPainter *,
        const CscsRectF &, const CscsPalette &, int lineWidth, int frameStyle );

    static void drawRoundedFrame( CscsPainter *, 
        const CscsRectF &, double xRadius, double yRadius,
        const CscsPalette &, int lineWidth, int frameStyle );

    static void drawFrame( CscsPainter *, const CscsRectF &rect,
        const CscsPalette &palette, CscsPalette::ColorRole foregroundRole,
        int lineWidth, int midLineWidth, int frameStyle ); 

    static void drawFocusRect( CscsPainter *, const CscsWidget * );
    static void drawFocusRect( CscsPainter *, const CscsWidget *, const CscsRect & );

    static void drawColorBar( CscsPainter *painter,
        const CscsPlotColorMap &, const CscsPlotInterval &,
        const CscsPlotScaleMap &, SCS::Orientation, const CscsRectF & );

    static bool isAligning( CscsPainter *painter );
    static bool isX11GraphicsSystem();

    static void fillPixmap( const CscsWidget *, 
        CscsImage &, const CscsPoint &offset = CscsPoint() );

    static void drawBackgound( CscsPainter *painter,
        const CscsRectF &rect, const CscsWidget *widget );

    static CscsImage backingStore( CscsWidget *, const CscsSize & );

private:
    static bool d_polylineSplitting;
    static bool d_roundingAlignment;
};


inline void CscsPlotPainter::drawPoint( CscsPainter *painter, double x, double y )
{
    CscsPlotPainter::drawPoint( painter, CscsPointF( x, y ) );
}


inline void CscsPlotPainter::drawPoints( CscsPainter *painter, const CscsPolygon &polygon )
{
    drawPoints( painter, polygon.data(), polygon.size() );
}


inline void CscsPlotPainter::drawPoints( CscsPainter *painter, const CscsPolygonF &polygon )
{
    drawPoints( painter, polygon.data(), polygon.size() );
}


inline void CscsPlotPainter::drawLine( CscsPainter *painter,
    double x1, double y1, double x2, double y2 )
{
    CscsPlotPainter::drawLine( painter, CscsPointF( x1, y1 ), CscsPointF( x2, y2 ) );
}


inline void CscsPlotPainter::drawLine( CscsPainter *painter, const CscsLineF &line )
{
    CscsPlotPainter::drawLine( painter, line.p1(), line.p2() );
}


inline bool CscsPlotPainter::polylineSplitting()
{
    return d_polylineSplitting;
}


inline bool CscsPlotPainter::roundingAlignment()
{
    return d_roundingAlignment;
}


inline bool CscsPlotPainter::roundingAlignment(CscsPainter *painter)
{
    return d_roundingAlignment && isAligning(painter);
}

END_NAMESPACE

#endif