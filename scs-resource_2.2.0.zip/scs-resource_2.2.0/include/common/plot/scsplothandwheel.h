#ifndef SCSPLOTHANDWHEEL_H
#define SCSPLOTHANDWHEEL_H
#include "scsplotabstractslider.h"

BEGIN_NAMESPACE(Gemini)

class CscsPlotRoundScaleDraw;
class CscsPainter;

class  WIDGET_EXPORT CscsPlotHandWheel: public CscsPlotAbstractSlider
{

public:
    enum HandWheelStyle
    {
        Flat,
        Raised,
        Sunken,
        Styled
    };

    enum MarkerStyle 
    { 
        NoMarker = -1,
        Tick, 
        Triangle, 
        Dot,  
        Nub, 
        Notch 
    };

    explicit CscsPlotHandWheel( CscsWidget* parent = nullptr );
    virtual ~CscsPlotHandWheel();

    void setAlignment( SCS::Alignment );
    SCS::Alignment alignment() const;

    void setKnobWidth( int );
    int knobWidth() const;

    void setNumTurns( int );
    int numTurns() const;

    void setTotalAngle ( double angle );
    double totalAngle() const;

    void setHandWheelStyle( HandWheelStyle );
    HandWheelStyle knobStyle() const;

    void setBorderWidth( int bw );
    int borderWidth() const;

    void setMarkerStyle( MarkerStyle );
    MarkerStyle markerStyle() const;

    void setMarkerSize( int );
    int markerSize() const;

    virtual CscsSize sizeHint() const;
    virtual CscsSize minimumSizeHint() const;

    void setScaleDraw( CscsPlotRoundScaleDraw * );

    const CscsPlotRoundScaleDraw *scaleDraw() const;
    CscsPlotRoundScaleDraw *scaleDraw();

    CscsRect knobRect() const;

protected:
    virtual void paintEvent( CscsPaintEvent * );
    virtual void changeEvent( CscsEvent * );

    virtual void drawKnob( CscsPainter *, const CscsRectF & ) const;

    virtual void drawFocusIndicator( CscsPainter * ) const;

    virtual void drawMarker( CscsPainter *, 
        const CscsRectF &, double arc ) const;

    virtual double scrolledTo( const CscsPoint & ) const;
    virtual bool isScrollPosition( const CscsPoint & ) const;

private:
    class PrivateData;
    PrivateData *d_data;

BEGIN_PROPERTY(CscsPlotHandWheel, CscsPlotAbstractSlider)
    META_PROPERTY( HandWheelStyle, knobStyle, READ, knobStyle, WRITE, setHandWheelStyle )
    META_PROPERTY( int, knobWidth, READ, knobWidth, WRITE, setKnobWidth )
    META_PROPERTY( SCS::Alignment, alignment, READ, alignment, WRITE, setAlignment )
    META_PROPERTY( double, totalAngle, READ, totalAngle, WRITE, setTotalAngle )
    META_PROPERTY( int, numTurns, READ, numTurns, WRITE, setNumTurns )
    META_PROPERTY( MarkerStyle, markerStyle, READ, markerStyle, WRITE, setMarkerStyle )
    META_PROPERTY( int, markerSize, READ, markerSize, WRITE, setMarkerSize )
    META_PROPERTY( int, borderWidth, READ, borderWidth, WRITE, setBorderWidth )
END_PROPERTY
};

END_NAMESPACE

#endif