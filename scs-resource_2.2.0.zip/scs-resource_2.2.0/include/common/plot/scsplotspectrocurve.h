#ifndef SCSPLOTSPECTROCURVE_H
#define SCSPLOTSPECTROCURVE_H
#include "scsplotseriesitem.h"
#include "scsplotseriesdata.h"

BEGIN_NAMESPACE(Gemini)

class CscsPlotSymbol;
class CscsPlotColorMap;

class  CscsPlotSpectroCurve:
    public CscsPlotSeriesItem, CscsPlotSeriesStore<CscsPlotPoint3D>
{
public:
    enum PaintAttribute
    {
        ClipPoints = 1
    };
    typedef CscsFlags<PaintAttribute> PaintAttributes;

    explicit CscsPlotSpectroCurve( const std::string &title = std::string() );
    explicit CscsPlotSpectroCurve( const CscsPlotText &title );

    virtual ~CscsPlotSpectroCurve();

    virtual int rtti() const;

    void setPaintAttribute( PaintAttribute, bool on = true );
    bool testPaintAttribute( PaintAttribute ) const;

    void setSamples( const CscsVector<CscsPlotPoint3D> & );
    void setSamples( CscsPlotSeriesData<CscsPlotPoint3D> * );


    void setColorMap( CscsPlotColorMap * );
    const CscsPlotColorMap *colorMap() const;

    void setColorRange( const CscsPlotInterval & );
    CscsPlotInterval & colorRange() const;

    virtual void drawSeries( CscsPainter *,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect, int from, int to ) const;

    void setPenWidth( double );
    double penWidth() const;

protected:
    virtual void drawDots( CscsPainter *,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect, int from, int to ) const;

private:
    void init();

    class PrivateData;
    PrivateData *d_data;
};

SCS_DECLARE_OPERATORS_FOR_FLAGS( CscsPlotSpectroCurve::PaintAttributes )

END_NAMESPACE

#endif