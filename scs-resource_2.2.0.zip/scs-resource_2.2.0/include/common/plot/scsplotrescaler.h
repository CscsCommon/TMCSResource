#ifndef SCSPLOTRESCALER_H
#define SCSPLOTRESCALER_H
#include "scsplotinterval.h"
#include "scsplot.h"
#include <kernel/scsobject.h>

BEGIN_NAMESPACE(Gemini)

class CscsWidget;
class CscsResizeEvent;

class  CscsPlotRescaler: public CscsObject
{
public:
    enum RescalePolicy
    {
        Fixed,
        Expanding,
        Fitting
    };

    enum ExpandingDirection
    {
        ExpandUp,
        ExpandDown,
        ExpandBoth
    };

    explicit CscsPlotRescaler( CscsWidget *canvas,
        int referenceAxis = CscsPlot::xBottom,
        RescalePolicy = Expanding );

    virtual ~CscsPlotRescaler();

    void setEnabled( bool );
    bool isEnabled() const;

    void setRescalePolicy( RescalePolicy );
    RescalePolicy rescalePolicy() const;

    void setExpandingDirection( ExpandingDirection );
    void setExpandingDirection( int axis, ExpandingDirection );
    ExpandingDirection expandingDirection( int axis ) const;

    void setReferenceAxis( int axis );
    int referenceAxis() const;

    void setAspectRatio( double ratio );
    void setAspectRatio( int axis, double ratio );
    double aspectRatio( int axis ) const;

    void setIntervalHint( int axis, const CscsPlotInterval& );
    CscsPlotInterval intervalHint( int axis ) const;

    CscsWidget *canvas();
    const CscsWidget *canvas() const;

    CscsPlot *plot();
    const CscsPlot *plot() const;

    virtual bool eventFilter( CscsObject *, CscsEvent * );

    void rescale() const;

protected:
    virtual void canvasResizeEvent( CscsResizeEvent * );

    virtual void rescale( const CscsSize &oldSize, const CscsSize &newSize ) const;
    virtual CscsPlotInterval expandScale(
        int axis, const CscsSize &oldSize, const CscsSize &newSize ) const;

    virtual CscsPlotInterval syncScale(
        int axis, const CscsPlotInterval& reference,
        const CscsSize &size ) const;

    virtual void updateScales(
        CscsPlotInterval intervals[CscsPlot::axisCnt] ) const;

    SCS::Orientation orientation( int axis ) const;
    CscsPlotInterval interval( int axis ) const;
    CscsPlotInterval expandInterval( const CscsPlotInterval &,
        double width, ExpandingDirection ) const;

private:
    double pixelDist( int axis, const CscsSize & ) const;

    class AxisData;
    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE
#endif