#ifndef SCSPLOTPOINTMAPPER_H
#define SCSPLOTPOINTMAPPER_H
#include "scsplotseriesdata.h"
#include <painting/scsimage.h>

BEGIN_NAMESPACE(Gemini)

class CscsPlotScaleMap;
class CscsPolygonF;
class CscsPolygon;
class CscsPen;

class  CscsPlotPointMapper
{
public:
    enum TransformationFlag
    {
        RoundPoints = 0x01,
        WeedOutPoints = 0x02
    };

    typedef CscsFlags<TransformationFlag> TransformationFlags;

    CscsPlotPointMapper();
    ~CscsPlotPointMapper();

    void setFlags( TransformationFlags );
    TransformationFlags flags() const;

    void setFlag( TransformationFlag, bool on = true );
    bool testFlag( TransformationFlag ) const;

    void setBoundingRect( const CscsRectF & );
    CscsRectF boundingRect() const;

    CscsPolygonF toPolygonF( const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsPlotSeriesData<CscsPointF> *series, int from, int to ) const;

    CscsPolygon toPolygon( const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsPlotSeriesData<CscsPointF> *series, int from, int to ) const;

    CscsPolygon toPoints( const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsPlotSeriesData<CscsPointF> *series, int from, int to ) const;

    CscsPolygonF toPointsF( const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsPlotSeriesData<CscsPointF> *series, int from, int to ) const;

    CscsImage toImage( const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsPlotSeriesData<CscsPointF> *series, int from, int to, 
        const CscsPen &, bool antialiased, uint numThreads ) const;

private:
    class PrivateData;
    PrivateData *d_data;
};

SCS_DECLARE_OPERATORS_FOR_FLAGS( CscsPlotPointMapper::TransformationFlags )

END_NAMESPACE

#endif