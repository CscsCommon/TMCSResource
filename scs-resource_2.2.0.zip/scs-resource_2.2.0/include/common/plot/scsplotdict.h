#ifndef SCSPLOTDICT_H
#define SCSPLOTDICT_H
#include "scsplotitem.h"
#include <kernel/scslist.h>

BEGIN_NAMESPACE(Gemini)

typedef CscsList<CscsPlotItem* > CscsPlotItemList;
typedef CscsList<CscsPlotItem*>::ConstIterator CscsPlotItemIterator;

class  CscsPlotDict
{
public:
    explicit CscsPlotDict();
    virtual ~CscsPlotDict();

    void setAutoDelete( bool );
    bool autoDelete() const;

    const CscsPlotItemList& itemList() const;
    CscsPlotItemList itemList( int rtti ) const;

    void detachItems( int rtti = CscsPlotItem::Rtti_PlotItem,
        bool autoDelete = true );

protected:
    void insertItem( CscsPlotItem * );
    void removeItem( CscsPlotItem * );

private:
    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE

#endif