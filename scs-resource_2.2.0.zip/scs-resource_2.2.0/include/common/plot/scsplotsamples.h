#ifndef SCSPLOTSAMPLES_H
#define SCSPLOTSAMPLES_H
#include "scsplotinterval.h"
#include "scsplotmath.h"
#include <kernel/scsvector.h>

BEGIN_NAMESPACE(Gemini)

class  CscsPlotIntervalSample
{
public:
    CscsPlotIntervalSample();
    CscsPlotIntervalSample( double, const CscsPlotInterval & );
    CscsPlotIntervalSample( double value, double min, double max );

    bool operator==( const CscsPlotIntervalSample & ) const;
    bool operator!=( const CscsPlotIntervalSample & ) const;

    double value;


    CscsPlotInterval interval;
};

inline CscsPlotIntervalSample::CscsPlotIntervalSample():
    value( 0.0 )
{
}

inline CscsPlotIntervalSample::CscsPlotIntervalSample(
        double v, const CscsPlotInterval &intv ):
    value( v ),
    interval( intv )
{
}

inline CscsPlotIntervalSample::CscsPlotIntervalSample(
        double v, double min, double max ):
    value( v ),
    interval( min, max )
{
}

inline bool CscsPlotIntervalSample::operator==(
    const CscsPlotIntervalSample &other ) const
{
    return value == other.value && interval == other.interval;
}

inline bool CscsPlotIntervalSample::operator!=(
    const CscsPlotIntervalSample &other ) const
{
    return !( *this == other );
}

class  CscsPlotSetSample
{
public:
    CscsPlotSetSample();
    CscsPlotSetSample( double, const CscsVector<double> & = CscsVector<double>() );

    bool operator==( const CscsPlotSetSample &other ) const;
    bool operator!=( const CscsPlotSetSample &other ) const;

    double added() const;

    double value;

    CscsVector<double> set;
};

inline CscsPlotSetSample::CscsPlotSetSample():
    value( 0.0 )
{
}

inline CscsPlotSetSample::CscsPlotSetSample( double v, const CscsVector< double > &s ):
    value( v ),
    set( s )
{
}


inline bool CscsPlotSetSample::operator==( const CscsPlotSetSample &other ) const
{
    return value == other.value && set == other.set;
}


inline bool CscsPlotSetSample::operator!=( const CscsPlotSetSample &other ) const
{
    return !( *this == other );
}


inline double CscsPlotSetSample::added() const
{
    double y = 0.0;
    for ( int i = 0; i < set.size(); i++ )
        y += set[i];

    return y;
}

class  CscsPlotOHLCSample
{
public:
    CscsPlotOHLCSample( double time = 0.0,
        double open = 0.0, double high = 0.0,
        double low = 0.0, double close = 0.0 );

    CscsPlotInterval boundingInterval() const;

    bool isValid() const;

    double time;

    double open;

    double high;

    double low;

    double close;
};


inline CscsPlotOHLCSample::CscsPlotOHLCSample( double t,
        double o, double h, double l, double c ):
    time( t ),
    open( o ),
    high( h ),
    low( l ),
    close( c )
{
}

inline bool CscsPlotOHLCSample::isValid() const
{
    return ( low <= high )
        && ( open >= low )
        && ( open <= high )
        && ( close >= low )
        && ( close <= high );
}

inline CscsPlotInterval CscsPlotOHLCSample::boundingInterval() const
{
    double minY = open;
    minY = scsMin( minY, high );
    minY = scsMin( minY, low );
    minY = scsMin( minY, close );

    double maxY = open;
    maxY = scsMax( maxY, high );
    maxY = scsMax( maxY, low );
    maxY = scsMax( maxY, close );
    return CscsPlotInterval( minY, maxY );
}

END_NAMESPACE

#endif