#ifndef SCSPLOTSCALEITEM_H
#define SCSPLOTSCALEITEM_H

#include "scsplotitem.h"
#include "scsplotscaledraw.h"

BEGIN_NAMESPACE(Gemini)

class CscsPalette;

class  CscsPlotScaleItem: public CscsPlotItem
{
public:
    explicit CscsPlotScaleItem(
        CscsPlotScaleDraw::Alignment = CscsPlotScaleDraw::BottomScale,
        const double pos = 0.0 );

    virtual ~CscsPlotScaleItem();

    virtual int rtti() const;

    void setScaleDiv( const CscsPlotScaleDiv& );
    const CscsPlotScaleDiv& scaleDiv() const;

    void setScaleDivFromAxis( bool on );
    bool isScaleDivFromAxis() const;

    void setPalette( const CscsPalette & );
    CscsPalette palette() const;

    void setFont( const CscsFont& );
    CscsFont font() const;

    void setScaleDraw( CscsPlotScaleDraw * );

    const CscsPlotScaleDraw *scaleDraw() const;
    CscsPlotScaleDraw *scaleDraw();

    void setPosition( double pos );
    double position() const;

    void setBorderDistance( int numPixels );
    int borderDistance() const;

    void setAlignment( CscsPlotScaleDraw::Alignment );

    virtual void draw( CscsPainter *p,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &rect ) const;

    virtual void updateScaleDiv( const CscsPlotScaleDiv &, const CscsPlotScaleDiv & );

private:
    class PrivateData;
    PrivateData *d_data;
};

END_NAMESPACE
#endif