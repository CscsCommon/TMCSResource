#ifndef SCSPLOTSERIESDATA_H
#define SCSPLOTSERIESDATA_H

#include "scsplotsamples.h"
#include "scsplotpoint3d.h"
#include "scsplotpointpolar.h"
#include <kernel/scsvector.h>
#include <painting/scsrect.h>


BEGIN_NAMESPACE(Gemini)


template <typename T>
class CscsPlotSeriesData
{
public:
    CscsPlotSeriesData();
    virtual ~CscsPlotSeriesData();
    virtual size_t size() const = 0;
    virtual T sample( size_t i ) const = 0;
    virtual CscsRectF boundingRect() const = 0;
    virtual void setRectOfInterest( const CscsRectF &rect );

protected:
    mutable CscsRectF d_boundingRect;

private:
    CscsPlotSeriesData<T> &operator=( const CscsPlotSeriesData<T> & );
};

template <typename T>
CscsPlotSeriesData<T>::CscsPlotSeriesData():
    d_boundingRect( 0.0, 0.0, -1.0, -1.0 )
{
}

template <typename T>
CscsPlotSeriesData<T>::~CscsPlotSeriesData()
{
}

template <typename T>
void CscsPlotSeriesData<T>::setRectOfInterest( const CscsRectF & )
{
}

template <typename T>
class CscsPlotArraySeriesData: public CscsPlotSeriesData<T>
{
public:
    CscsPlotArraySeriesData();
    CscsPlotArraySeriesData( const CscsVector<T> &samples );
    void setSamples( const CscsVector<T> &samples );
    const CscsVector<T> samples() const;
    virtual size_t size() const;
    virtual T sample( size_t index ) const;

protected:
    CscsVector<T> d_samples;
};

template <typename T>
CscsPlotArraySeriesData<T>::CscsPlotArraySeriesData()
{
}

template <typename T>
CscsPlotArraySeriesData<T>::CscsPlotArraySeriesData( const CscsVector<T> &samples ):
    d_samples( samples )
{
}

template <typename T>
void CscsPlotArraySeriesData<T>::setSamples( const CscsVector<T> &samples )
{
    CscsPlotSeriesData<T>::d_boundingRect = CscsRectF( 0.0, 0.0, -1.0, -1.0 );
    d_samples = samples;
}

template <typename T>
const CscsVector<T> CscsPlotArraySeriesData<T>::samples() const
{
    return d_samples;
}

template <typename T>
size_t CscsPlotArraySeriesData<T>::size() const
{
    return d_samples.size();
}

template <typename T>
T CscsPlotArraySeriesData<T>::sample( size_t i ) const
{
    return d_samples[ static_cast<int>( i ) ];
}

class  CscsPlotPointSeriesData: public CscsPlotArraySeriesData<CscsPointF>
{
public:
    CscsPlotPointSeriesData(
        const CscsVector<CscsPointF> & = CscsVector<CscsPointF>() );

    virtual CscsRectF boundingRect() const;
};

class  CscsPlotPoint3DSeriesData: public CscsPlotArraySeriesData<CscsPlotPoint3D>
{
public:
    CscsPlotPoint3DSeriesData(
        const CscsVector<CscsPlotPoint3D> & = CscsVector<CscsPlotPoint3D>() );
    virtual CscsRectF boundingRect() const;
};

class  CscsPlotIntervalSeriesData: public CscsPlotArraySeriesData<CscsPlotIntervalSample>
{
public:
    CscsPlotIntervalSeriesData(
        const CscsVector<CscsPlotIntervalSample> & = CscsVector<CscsPlotIntervalSample>() );

    virtual CscsRectF boundingRect() const;
};

class  CscsPlotSetSeriesData: public CscsPlotArraySeriesData<CscsPlotSetSample>
{
public:
    CscsPlotSetSeriesData(
        const CscsVector<CscsPlotSetSample> & = CscsVector<CscsPlotSetSample>() );

    virtual CscsRectF boundingRect() const;
};

class  CscsPlotTradingChartData: public CscsPlotArraySeriesData<CscsPlotOHLCSample>
{
public:
    CscsPlotTradingChartData(
        const CscsVector<CscsPlotOHLCSample> & = CscsVector<CscsPlotOHLCSample>() );

    virtual CscsRectF boundingRect() const;
};

 CscsRectF plotBoundingRect(
    const CscsPlotSeriesData<CscsPointF> &, int from = 0, int to = -1 );

 CscsRectF plotBoundingRect(
    const CscsPlotSeriesData<CscsPlotPoint3D> &, int from = 0, int to = -1 );

 CscsRectF plotBoundingRect(
    const CscsPlotSeriesData<CscsPlotPointPolar> &, int from = 0, int to = -1 );

 CscsRectF plotBoundingRect(
    const CscsPlotSeriesData<CscsPlotIntervalSample> &, int from = 0, int to = -1 );

 CscsRectF plotBoundingRect(
    const CscsPlotSeriesData<CscsPlotSetSample> &, int from = 0, int to = -1 );

 CscsRectF plotBoundingRect(
    const CscsPlotSeriesData<CscsPlotOHLCSample> &, int from = 0, int to = -1 );

template <typename T, typename LessThan>
inline int plotUpperSampleIndex( const CscsPlotSeriesData<T> &series,
    double value, LessThan lessThan  ) 
{
    const int indexMax = series.size() - 1;

    if ( indexMax < 0 || !lessThan( value, series.sample( indexMax ) )  )
        return -1;

    int indexMin = 0;
    int n = indexMax;

    while ( n > 0 )
    {
        const int half = n >> 1;
        const int indexMid = indexMin + half;

        if ( lessThan( value, series.sample( indexMid ) ) )
        {
            n = half;
        }
        else
        {
            indexMin = indexMid + 1;
            n -= half + 1;
        }
    }

    return indexMin;
}

END_NAMESPACE

#endif
