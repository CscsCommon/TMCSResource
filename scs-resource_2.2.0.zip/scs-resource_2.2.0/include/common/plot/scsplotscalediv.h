#ifndef SCSPLOTSCALEDIV_H
#define SCSPLOTSCALEDIV_H
#include "scsplotinterval.h"
#include <kernel/scslist.h>

BEGIN_NAMESPACE(Gemini)

/*!
 * 刻度分量
 */

class  CscsPlotScaleDiv
{
public:
    //! Scale tick types
    enum TickType
    {
        NoTick = -1,
        MinorTick,
        MediumTick,
        MajorTick,
        NTickTypes
    };

    explicit CscsPlotScaleDiv( double lowerBound = 0.0, 
        double upperBound = 0.0 );

    explicit CscsPlotScaleDiv( const CscsPlotInterval &, CscsList<double>[NTickTypes] );

    explicit CscsPlotScaleDiv( double lowerBound, double upperBound,
        CscsList<double>[NTickTypes] );

    explicit CscsPlotScaleDiv( double lowerBound, double upperBound, 
        const CscsList<double> &minorTicks, const CscsList<double> &mediumTicks,
        const CscsList<double> &majorTicks );

    bool operator==( const CscsPlotScaleDiv & ) const;
    bool operator!=( const CscsPlotScaleDiv & ) const;

    void setInterval( double lowerBound, double upperBound );
    void setInterval( const CscsPlotInterval & );
    CscsPlotInterval interval() const;

    void setLowerBound( double );
    double lowerBound() const;

    void setUpperBound( double );
    double upperBound() const;

    double range() const;

    bool contains( double value ) const;

    void setTicks( int tickType, const CscsList<double> & );
    CscsList<double> ticks( int tickType ) const;

    bool isEmpty() const;
    bool isIncreasing() const;

    void invert();
    CscsPlotScaleDiv inverted() const;

    CscsPlotScaleDiv bounded( double lowerBound, double upperBound ) const;

private:
    double d_lowerBound;
    double d_upperBound;
    CscsList<double> d_ticks[NTickTypes];
};

END_NAMESPACE

#endif