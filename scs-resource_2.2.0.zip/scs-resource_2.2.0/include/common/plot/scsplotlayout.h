#ifndef SCSPLOTLAYOUT_H
#define SCSPLOTLAYOUT_H
#include "scsplot.h"

BEGIN_NAMESPACE(Gemini)

class  CscsPlotLayout
{
public:

    enum Option
    {
        AlignScales = 0x01,
        IgnoreScrollbars = 0x02,
        IgnoreFrames = 0x04,
        IgnoreLegend = 0x08,
        IgnoreTitle = 0x10,
        IgnoreFooter = 0x20
    };
    typedef CscsFlags<Option> Options;

    explicit CscsPlotLayout();
    virtual ~CscsPlotLayout();

    void setCanvasMargin( int margin, int axis = -1 );
    int canvasMargin( int axis ) const;

    void setAlignCanvasToScales( bool );

    void setAlignCanvasToScale( int axisId, bool );
    bool alignCanvasToScale( int axisId ) const;

    void setSpacing( int );
    int spacing() const;

    void setLegendPosition( CscsPlot::LegendPosition pos, double ratio );
    void setLegendPosition( CscsPlot::LegendPosition pos );
    CscsPlot::LegendPosition legendPosition() const;

    void setLegendRatio( double ratio );
    double legendRatio() const;

    virtual CscsSize minimumSizeHint( const CscsPlot * ) const;

    virtual void activate( const CscsPlot *,
        const CscsRectF &rect, Options options = 0x00 );

    virtual void invalidate();

    CscsRectF titleRect() const;
    CscsRectF footerRect() const;
    CscsRectF legendRect() const;
    CscsRectF scaleRect( int axis ) const;
    CscsRectF canvasRect() const;

    class LayoutData;

protected:

    void setTitleRect( const CscsRectF & );
    void setFooterRect( const CscsRectF & );
    void setLegendRect( const CscsRectF & );
    void setScaleRect( int axis, const CscsRectF & );
    void setCanvasRect( const CscsRectF & );

    CscsRectF layoutLegend( Options options, const CscsRectF & ) const;
    CscsRectF alignLegend( const CscsRectF &canvasRect,
        const CscsRectF &legendRect ) const;

    void expandLineBreaks( Options options, const CscsRectF &rect,
        int &dimTitle, int &dimFooter, int dimAxes[CscsPlot::axisCnt] ) const;

    void alignScales( Options options, CscsRectF &canvasRect,
        CscsRectF scaleRect[CscsPlot::axisCnt] ) const;

private:
    class PrivateData;
    PrivateData *d_data;
};

SCS_DECLARE_OPERATORS_FOR_FLAGS( CscsPlotLayout::Options )

END_NAMESPACE
#endif
