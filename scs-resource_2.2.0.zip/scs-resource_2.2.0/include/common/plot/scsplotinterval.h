#ifndef SCSPLOTINTERVAL_H
#define SCSPLOTINTERVAL_H
#include <kernel/scsflags.h>

BEGIN_NAMESPACE(Gemini)

class  CscsPlotInterval
{
public:

    enum BorderFlag
    {
        IncludeBorders = 0x00,
        ExcludeMinimum = 0x01,
        ExcludeMaximum = 0x02,
        ExcludeBorders = ExcludeMinimum | ExcludeMaximum
    };

    //! Border flags
    typedef CscsFlags<BorderFlag> BorderFlags;

    CscsPlotInterval();
    CscsPlotInterval( double minValue, double maxValue,
        BorderFlags = IncludeBorders );

    void setInterval( double minValue, double maxValue,
        BorderFlags = IncludeBorders );

    CscsPlotInterval normalized() const;
    CscsPlotInterval inverted() const;
    CscsPlotInterval limited( double minValue, double maxValue ) const;

    bool operator==( const CscsPlotInterval & ) const;
    bool operator!=( const CscsPlotInterval & ) const;

    void setBorderFlags( BorderFlags );
    BorderFlags borderFlags() const;

    double minValue() const;
    double maxValue() const;

    double width() const;

    void setMinValue( double );
    void setMaxValue( double );

    bool contains( double value ) const;

    bool intersects( const CscsPlotInterval & ) const;
    CscsPlotInterval intersect( const CscsPlotInterval & ) const;
    CscsPlotInterval unite( const CscsPlotInterval & ) const;

    CscsPlotInterval operator|( const CscsPlotInterval & ) const;
    CscsPlotInterval operator&( const CscsPlotInterval & ) const;

    CscsPlotInterval &operator|=( const CscsPlotInterval & );
    CscsPlotInterval &operator&=( const CscsPlotInterval & );

    CscsPlotInterval extend( double value ) const;
    CscsPlotInterval operator|( double ) const;
    CscsPlotInterval &operator|=( double );

    bool isValid() const;
    bool isNull() const;
    void invalidate();

    CscsPlotInterval symmetrize( double value ) const;

private:
    double d_minValue;
    double d_maxValue;
    BorderFlags d_borderFlags;
};

inline CscsPlotInterval::CscsPlotInterval():
    d_minValue( 0.0 ),
    d_maxValue( -1.0 ),
    d_borderFlags( IncludeBorders )
{
}

inline CscsPlotInterval::CscsPlotInterval(
        double minValue, double maxValue, BorderFlags borderFlags ):
    d_minValue( minValue ),
    d_maxValue( maxValue ),
    d_borderFlags( borderFlags )
{
}

inline void CscsPlotInterval::setInterval(
    double minValue, double maxValue, BorderFlags borderFlags )
{
    d_minValue = minValue;
    d_maxValue = maxValue;
    d_borderFlags = borderFlags;
}

inline void CscsPlotInterval::setBorderFlags( BorderFlags borderFlags )
{
    d_borderFlags = borderFlags;
}

inline CscsPlotInterval::BorderFlags CscsPlotInterval::borderFlags() const
{
    return d_borderFlags;
}

inline void CscsPlotInterval::setMinValue( double minValue )
{
    d_minValue = minValue;
}

inline void CscsPlotInterval::setMaxValue( double maxValue )
{
    d_maxValue = maxValue;
}

inline double CscsPlotInterval::minValue() const
{
    return d_minValue;
}

inline double CscsPlotInterval::maxValue() const
{
    return d_maxValue;
}

inline bool CscsPlotInterval::isValid() const
{
    if ( ( d_borderFlags & ExcludeBorders ) == 0 )
        return d_minValue <= d_maxValue;
    else
        return d_minValue < d_maxValue;
}

inline double CscsPlotInterval::width() const
{
    return isValid() ? ( d_maxValue - d_minValue ) : 0.0;
}

inline CscsPlotInterval CscsPlotInterval::operator&(
    const CscsPlotInterval &other ) const
{
    return intersect( other );
}

inline CscsPlotInterval CscsPlotInterval::operator|(
    const CscsPlotInterval &other ) const
{
    return unite( other );
}

inline bool CscsPlotInterval::operator==( const CscsPlotInterval &other ) const
{
    return ( d_minValue == other.d_minValue ) &&
           ( d_maxValue == other.d_maxValue ) &&
           ( d_borderFlags == other.d_borderFlags );
}

inline bool CscsPlotInterval::operator!=( const CscsPlotInterval &other ) const
{
    return ( !( *this == other ) );
}


inline CscsPlotInterval CscsPlotInterval::operator|( double value ) const
{
    return extend( value );
}

inline bool CscsPlotInterval::isNull() const
{
    return isValid() && d_minValue >= d_maxValue;
}

inline void CscsPlotInterval::invalidate()
{
    d_minValue = 0.0;
    d_maxValue = -1.0;
}

SCS_DECLARE_OPERATORS_FOR_FLAGS( CscsPlotInterval::BorderFlags )

END_NAMESPACE

#endif