#ifndef SCSPLOTCLIPPER_H
#define SCSPLOTCLIPPER_H
#include "scsplotinterval.h"
#include <painting/scspolygon.h>
#include <kernel/scsvector.h>

BEGIN_NAMESPACE(Gemini)

class CscsRect;
class CscsRectF;

class  CscsPlotClipper
{
public:
    static CscsPolygon clipPolygon( const CscsRect &,
        const CscsPolygon &, bool closePolygon = false );
    static CscsPolygon clipPolygon( const CscsRectF &,
        const CscsPolygon &, bool closePolygon = false );

    static CscsPolygonF clipPolygonF( const CscsRectF &,
        const CscsPolygonF &, bool closePolygon = false );

    static CscsVector<CscsPlotInterval> clipCircle(
        const CscsRectF &, const CscsPointF &, double radius );
};

END_NAMESPACE

#endif