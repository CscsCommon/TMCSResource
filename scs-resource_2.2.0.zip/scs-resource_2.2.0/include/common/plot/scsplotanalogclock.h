#ifndef SCSPLOTANALOGCLOCK_H
#define SCSPLOTANALOGCLOCK_H
#include "scsplotdial.h"
#include "scsplotdialneedle.h"
#include <kernel/scstime.h>

BEGIN_NAMESPACE(Gemini)

class  WIDGET_EXPORT CscsPlotAnalogClock: public CscsPlotDial
{
public:
    enum Hand
    {
        SecondHand,
        MinuteHand,
        HourHand,
        NHands
    };

    explicit CscsPlotAnalogClock( CscsWidget* parent = nullptr );
    virtual ~CscsPlotAnalogClock();

    void setHand( Hand, CscsPlotDialNeedle * );

    const CscsPlotDialNeedle *hand( Hand ) const;
    CscsPlotDialNeedle *hand( Hand );

SLOTS:
    void setCurrentTime();
    void setTime( const CscsTime & );

protected:
    virtual void drawNeedle( CscsPainter *, const CscsPointF &,
        double radius, double direction, CscsPalette::ColorGroup ) const;

    virtual void drawHand( CscsPainter *, Hand, const CscsPointF &,
        double radius, double direction, CscsPalette::ColorGroup ) const;

private:
    // use setHand instead
    void setNeedle( CscsPlotDialNeedle * );

    CscsPlotDialNeedle *d_hand[NHands];
};


END_NAMESPACE

#endif