#ifndef SCSPLOTRASTERDATA_H
#define SCSPLOTRASTERDATA_H
#include "scsplotinterval.h"
#include <window/scsenum.h>
#include <kernel/scsflags.h>
#include <kernel/scsmap.h>
#include <kernel/scslist.h>
#include <painting/scspolygon.h>
#include <kernel/scsnocopy.hpp>

BEGIN_NAMESPACE(Gemini)

class CscsPlotScaleMap;
class  CscsPlotRasterData:public CscsNoCopyable
{
public:
    typedef CscsMap<double, CscsPolygonF> ContourLines;
    enum ConrecFlag
    {
        IgnoreAllVerticesOnLevel = 0x01,
        IgnoreOutOfRange = 0x02
    };

    typedef CscsFlags<ConrecFlag> ConrecFlags;

    CscsPlotRasterData();
    virtual ~CscsPlotRasterData();

    virtual void setInterval( SCS::Axis, const CscsPlotInterval & );
    const CscsPlotInterval &interval(SCS::Axis) const;

    virtual CscsRectF pixelHint( const CscsRectF & ) const;

    virtual void initRaster( const CscsRectF &, const CscsSize& raster );
    virtual void discardRaster();

    virtual double value( double x, double y ) const = 0;

    virtual ContourLines contourLines( const CscsRectF &rect,
        const CscsSize &raster, const CscsList<double> &levels,
        ConrecFlags ) const;

    class Contour3DPoint;
    class ContourPlane;

private:
    CscsPlotInterval d_intervals[3];
};


inline const CscsPlotInterval &CscsPlotRasterData::interval( SCS::Axis axis) const
{
    return d_intervals[axis];
}

SCS_DECLARE_OPERATORS_FOR_FLAGS( CscsPlotRasterData::ConrecFlags )

END_NAMESPACE
#endif