#ifndef SCSPLOTTRANSFORM_H
#define SCSPLOTTRANSFORM_H
#include <kernel/scsnamespace.h>

BEGIN_NAMESPACE(Gemini)

/*!
	\brief 坐标系之间转换
 */

class  CscsPlotTransform
{
public:
    CscsPlotTransform();
    virtual ~CscsPlotTransform();

    virtual double bounded( double value ) const;
    virtual double transform( double value ) const = 0;
    virtual double invTransform( double value ) const = 0;

    virtual CscsPlotTransform *copy() const = 0;
};

class  CscsPlotNullTransform: public CscsPlotTransform
{
public:
    CscsPlotNullTransform();
    virtual ~CscsPlotNullTransform();

    virtual double transform( double value ) const;
    virtual double invTransform( double value ) const;

    virtual CscsPlotTransform *copy() const;
};

class  CscsPlotLogTransform: public CscsPlotTransform
{   
public:
    CscsPlotLogTransform();
    virtual ~CscsPlotLogTransform();
    
    virtual double transform( double value ) const;
    virtual double invTransform( double value ) const;

    virtual double bounded( double value ) const;

    virtual CscsPlotTransform *copy() const;

    static const double LogMin;
    static const double LogMax;
};

class  CscsPlotPowerTransform: public CscsPlotTransform
{
public:
    CscsPlotPowerTransform( double exponent );
    virtual ~CscsPlotPowerTransform();

    virtual double transform( double value ) const;
    virtual double invTransform( double value ) const;

    virtual CscsPlotTransform *copy() const;

private:
    const double d_exponent;
};

END_NAMESPACE

#endif