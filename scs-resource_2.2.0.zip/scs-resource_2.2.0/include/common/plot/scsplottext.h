#ifndef SCSPLOTTEXT_H
#define SCSPLOTTEXT_H

#include <painting/scssize.h>
#include <painting/scsfont.h>
#include <kernel/scsstring.h>

BEGIN_NAMESPACE(Gemini)

class CscsRgba;
class CscsPen;
class CscsBrush;
class CscsRectF;
class CscsPainter;
class CscsPlotTextEngine;

class  CscsPlotText
{
public:
    enum TextFormat
    {
        AutoText = 0,
        PlainText,
    };

    enum PaintAttribute
    {
        PaintUsingTextFont = 0x01,
        PaintUsingTextColor = 0x02,
        PaintBackground = 0x04
    };
    typedef CscsFlags<PaintAttribute> PaintAttributes;

    enum LayoutAttribute
    {
        MinimumLayout = 0x01
    };
    typedef CscsFlags<LayoutAttribute> LayoutAttributes;

    CscsPlotText( const CscsString & = CscsString::null,
             TextFormat textFormat = AutoText );
    CscsPlotText( const CscsPlotText & );
    ~CscsPlotText();

    CscsPlotText &operator=( const CscsPlotText & );

    bool operator==( const CscsPlotText & ) const;
    bool operator!=( const CscsPlotText & ) const;

    void setText( const CscsString &,
        CscsPlotText::TextFormat textFormat = AutoText );
    CscsString text() const;

    bool isNull() const;
    bool isEmpty() const;

    void setFont( const CscsFont & );
    CscsFont font() const;

    CscsFont usedFont( const CscsFont & ) const;

    void setRenderFlags( int flags );
    int renderFlags() const;

    void setColor( const CscsRgba & );
    CscsRgba color() const;

    CscsRgba usedColor( const CscsRgba & ) const;

    void setBorderRadius( double );
    double borderRadius() const;

    void setBorderPen( const CscsPen & );
    CscsPen borderPen() const;

    void setBackgroundBrush( const CscsBrush & );
    CscsBrush backgroundBrush() const;

    void setPaintAttribute( PaintAttribute, bool on = true );
    bool testPaintAttribute( PaintAttribute ) const;

    void setLayoutAttribute( LayoutAttribute, bool on = true );
    bool testLayoutAttribute( LayoutAttribute ) const;

    double heightForWidth( double width, const CscsFont & = CscsFont() ) const;
    CscsSizeF textSize( const CscsFont & = CscsFont() ) const;

    void draw( CscsPainter *painter, const CscsRectF &rect,bool rotate=false ) const;

    static const CscsPlotTextEngine *textEngine( 
        const CscsString &text, CscsPlotText::TextFormat = AutoText );

    static const CscsPlotTextEngine *textEngine( CscsPlotText::TextFormat );
    static void setTextEngine( CscsPlotText::TextFormat, CscsPlotTextEngine * );

private:
    class PrivateData;
    PrivateData *d_data;

    class LayoutCache;
    LayoutCache *d_layoutCache;
};

inline bool CscsPlotText::isNull() const
{
    return text().isNull();
}

inline bool CscsPlotText::isEmpty() const
{
    return text().isEmpty();
}

SCS_DECLARE_OPERATORS_FOR_FLAGS( CscsPlotText::PaintAttributes )
SCS_DECLARE_OPERATORS_FOR_FLAGS( CscsPlotText::LayoutAttributes )

SCS_DECLARE_TYPEINFO(CscsPlotText)

END_NAMESPACE

#endif