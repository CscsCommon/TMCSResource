#ifndef SCSPLOTABSTRACTSCALEDRAW_H
#define SCSPLOTABSTRACTSCALEDRAW_H
#include "scsplotscalediv.h"
#include "scsplottext.h"
#include <kernel/scsflags.h>

BEGIN_NAMESPACE(Gemini)

class CscsPalette;
class CscsPainter;
class CscsFont;
class CscsPlotTransform;
class CscsPlotScaleMap;


class  CscsPlotAbstractScaleDraw
{
public:
    enum ScaleComponent
    {
        Backbone = 0x01,
        Ticks = 0x02,
        Labels = 0x04
    };
    typedef CscsFlags<ScaleComponent> ScaleComponents;

    CscsPlotAbstractScaleDraw();
    virtual ~CscsPlotAbstractScaleDraw();

    void setScaleDiv( const CscsPlotScaleDiv &s );
    const CscsPlotScaleDiv& scaleDiv() const;

    void setTransformation( CscsPlotTransform * );
    const CscsPlotScaleMap &scaleMap() const;
    CscsPlotScaleMap &scaleMap();

    void enableComponent( ScaleComponent, bool enable = true );
    bool hasComponent( ScaleComponent ) const;

    void setTickLength( CscsPlotScaleDiv::TickType, double length );
    double tickLength( CscsPlotScaleDiv::TickType ) const;
    double maxTickLength() const;

    void setSpacing( double margin );
    double spacing() const;

    void setPenWidth( int width );
    int penWidth() const;

    virtual void draw( CscsPainter *, const CscsPalette & ) const;

    virtual CscsPlotText label( double ) const;
    virtual double extent( const CscsFont &font ) const = 0;

    void setMinimumExtent( double );
    double minimumExtent() const;

protected:
    virtual void drawTick( CscsPainter *painter, double value, double len ) const = 0;
    virtual void drawBackbone( CscsPainter *painter ) const = 0;
    virtual void drawLabel( CscsPainter *painter, double value ) const = 0;

    void invalidateCache();
    const CscsPlotText &tickLabel( const CscsFont &, double value ) const;

private:
    CscsPlotAbstractScaleDraw( const CscsPlotAbstractScaleDraw & );
    CscsPlotAbstractScaleDraw &operator=( const CscsPlotAbstractScaleDraw & );

    class PrivateData;
    PrivateData *d_data;
};

SCS_DECLARE_OPERATORS_FOR_FLAGS( CscsPlotAbstractScaleDraw::ScaleComponents )

END_NAMESPACE

#endif