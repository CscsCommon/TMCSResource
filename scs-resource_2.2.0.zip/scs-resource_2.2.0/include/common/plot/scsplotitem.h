#ifndef SCSPLOTITEM_H
#define SCSPLOTITEM_H

#include "scsplottext.h"
#include "scsplotlegenddata.h"
#include <painting/scsrect.h>
#include <kernel/scslist.h>
#include <kernel/scstypeinfo.h>

BEGIN_NAMESPACE(Gemini)

class CscsPainter;
class CscsPlotScaleMap;
class CscsPlotScaleDiv;
class CscsPlot;


class  CscsPlotItem
{
public:
    enum RttiValues
    {
        Rtti_PlotItem = 0,
        Rtti_PlotGrid,
        Rtti_PlotScale,
        Rtti_PlotLegend,
        Rtti_PlotMarker,
        Rtti_PlotCurve,
        Rtti_PlotSpectroCurve,
        Rtti_PlotIntervalCurve,
        Rtti_PlotHistogram,
        Rtti_PlotSpectrogram,
        Rtti_PlotTradingCurve,
        Rtti_PlotBarChart,
        Rtti_PlotMultiBarChart,
        Rtti_PlotShape,
        Rtti_PlotTextLabel,
        Rtti_PlotZone,
        Rtti_PlotUserItem = 1000
    };

    enum ItemAttribute
    {
        Legend = 0x01,
        AutoScale = 0x02,
        Margins = 0x04
    };
    typedef CscsFlags<ItemAttribute> ItemAttributes;

    enum ItemInterest
    {
        ScaleInterest = 0x01,
        LegendInterest = 0x02
    };
    typedef CscsFlags<ItemInterest> ItemInterests;

    enum RenderHint
    {
        RenderAntialiased = 0x1
    };
    typedef CscsFlags<RenderHint> RenderHints;

    explicit CscsPlotItem( const CscsPlotText &title = CscsPlotText() );
    virtual ~CscsPlotItem();

    void attach( CscsPlot *plot );
    void detach();

    CscsPlot *plot() const;

    void setTitle( const CscsString &title );
    void setTitle( const CscsPlotText &title );
    const CscsPlotText &title() const;

    virtual int rtti() const;

    void setItemAttribute( ItemAttribute, bool on = true );
    bool testItemAttribute( ItemAttribute ) const;

    void setItemInterest( ItemInterest, bool on = true );
    bool testItemInterest( ItemInterest ) const;

    void setRenderHint( RenderHint, bool on = true );
    bool testRenderHint( RenderHint ) const;

    void setRenderThreadCount( uint numThreads );
    uint renderThreadCount() const;

    void setLegendIconSize( const CscsSize & );
    CscsSize legendIconSize() const;

    double z() const;
    void setZ( double z );

    void show();
    void hide();
    virtual void setVisible( bool );
    bool isVisible () const;

    void setAxes( int xAxis, int yAxis );

    void setXAxis( int axis );
    int xAxis() const;

    void setYAxis( int axis );
    int yAxis() const;

    virtual void itemChanged();
    virtual void legendChanged();

    virtual void draw( CscsPainter *painter,
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasRect ) const = 0;

    virtual CscsRectF boundingRect() const;

    virtual void getCanvasMarginHint( 
        const CscsPlotScaleMap &xMap, const CscsPlotScaleMap &yMap,
        const CscsRectF &canvasSize,
        double &left, double &top, double &right, double &bottom) const;

    virtual void updateScaleDiv( 
        const CscsPlotScaleDiv&, const CscsPlotScaleDiv& );

    virtual void updateLegend( const CscsPlotItem *,
        const CscsList<CscsPlotLegendData> & );

    CscsRectF scaleRect( const CscsPlotScaleMap &, const CscsPlotScaleMap & ) const;
    CscsRectF paintRect( const CscsPlotScaleMap &, const CscsPlotScaleMap & ) const;

    virtual CscsList<CscsPlotLegendData> legendData() const;

    virtual CscsImage legendIcon( int index, const CscsSizeF  & ) const;

protected:
    CscsImage defaultIcon( const CscsBrush &, const CscsSizeF & ) const;

private:
    // Disabled copy constructor and operator=
    CscsPlotItem( const CscsPlotItem & );
    CscsPlotItem &operator=( const CscsPlotItem & );

    class PrivateData;
    PrivateData *d_data;
};

SCS_DECLARE_OPERATORS_FOR_FLAGS( CscsPlotItem::ItemAttributes )
SCS_DECLARE_OPERATORS_FOR_FLAGS( CscsPlotItem::ItemInterests )
SCS_DECLARE_OPERATORS_FOR_FLAGS( CscsPlotItem::RenderHints )

SCS_DECLARE_TYPEINFO(CscsPlotItem*)

END_NAMESPACE

#endif