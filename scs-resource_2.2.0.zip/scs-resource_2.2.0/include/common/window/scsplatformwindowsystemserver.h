#ifndef SCSPLATFORMWINDOWSYSTEMSERVER_H
#define SCSPLATFORMWINDOWSYSTEMSERVER_H
#include <kernel/scsobject.h>
#include <kernel/scstime.h>
#include <string>
#include <map>

BEGIN_NAMESPACE(Gemini)

class CscsRect;
class CscsPoint;
class CscsRegion;
class CscsBrush;
class CscsCursorWrapper;
class CscsWindowCommand;
class CscsEventData;
class CscsVncServer;

class CscsPlatformWindowSystemServer:public CscsObject{
public:
	CscsPlatformWindowSystemServer(int flags, CscsObject* parent=nullptr);
	~CscsPlatformWindowSystemServer();
	virtual void sendKeyEvent(int unicode, int keycode, int modifiers, bool isPress, bool autoRepeat);
	virtual void processKeyEvent(int unicode, int keycode, int modifiers, bool isPress, bool autoRepeat);

	virtual void setMaxWindowRect(const CscsRect& r);
	virtual void sendMouseEvent(const CscsPoint& pos, int state, int wheel);
	virtual void setBackground(const CscsBrush& brush);
	virtual void processEventQueue();
	virtual void initServer(int flags);

	static void startUpVncServer();
	static void shutDownVncServer();
	static CscsVncServer* vncServer();

   	enum WindowEvent{
		Create=0x0001, Destroy=0x0002, Hide=0x0004, Show=0x0008,
        Raise=0x0010, Lower=0x0020, Geometry=0x0040, Active = 0x0080,
        Name=0x0100
	};
	static CscsVncServer* vnc;


};



class CscsPlatformWindowSystemClient:public CscsObject{
public:
	CscsPlatformWindowSystemClient(CscsObject* parent, int id);
	~CscsPlatformWindowSystemClient();

	void setIdentity(const std::string& );
	std::string identity(){return id;}
	void sendEvent(CscsEventData* e);

	void sendMaxWindowRectEvent(const CscsRect& r);
	int clientId()const{return cid;}
	CscsWindowCommand* readMore();

SIGNALS:
	void connectionClosed(){}
	void readyRead(){}
	
	std::map<int , CscsCursorWrapper*> cursors;
	CscsWindowCommand* command;
	bool isClosed;
	std::string id;
	int cid;
};

extern CscsPlatformWindowSystemServer* scsServer;

END_NAMESPACE

#endif