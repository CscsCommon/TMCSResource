#ifndef SCSMIME_H
#define SCSMIME_H
#include "scsmimedata.h"

BEGIN_NAMESPACE(Gemini)

class CscsMimeSource{
	public:
		virtual ~CscsMimeSource();
		virtual const char* format(int n=0)const=0;
		virtual bool provides(const char*)const;
		virtual CscsByteArray encodeData(const char*)const=0;
};

END_NAMESPACE

#endif