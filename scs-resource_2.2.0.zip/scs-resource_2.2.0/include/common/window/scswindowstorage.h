 /*Created by J.Wong 2018/10/29
 version:    version 1.0,
 dependency: base on  or greater than c++11
 function: type erase
 gcc4.9+
 */

#ifndef SCSWINDOWSTORAGE_H
#define SCSWINDOWSTORAGE_H
#include <string>
#include <kernel/scstypes.h>
#include <kernel/scsmap.h>
#include <painting/scsregion.h>

BEGIN_NAMESPACE(Gemini)

class CscsPlatformWindowSystemClient;
class CscsBackingStore;
class CscsImage;
class CscsSurfaceView;
class CscsWidget;

/*
 * 多窗体系统
 */

class CscsWindowStorage{
public:
	CscsWindowStorage(int i,CscsPlatformWindowSystemClient* c, CscsWidget* handler=nullptr);
	~CscsWindowStorage();

	int winId()const{return m_id;}
	CscsWidget* handle()const;
	void setHandle(CscsWidget* handler);
	const std::string& name()const{return m_rgnName;}
	const std::string& caption()const{return m_rgnCaption;}
	CscsRegion requestedRegion()const{return m_requestedRegion;}
	bool isVisible()const{return !m_requestedRegion.isEmpty();}
	bool isFullyObscured() const{return false;}
	CscsPlatformWindowSystemClient* client()const;

	void raise();
	void lower();
	void show();
	void hide();
	void setActive();

	bool isOpaque()const{return m_opaque&&m_opacity==255;}

private:
	bool hidden()const{return m_requestedRegion.isEmpty();}

	void setName(const std::string& name);
	void setCaption(const std::string& caption);

	void focus(bool get);
	int  focusPriority()const{return m_lastFocusTime;}
	void shuttingDown(){m_lastFocusTime=0;}
	void blendToScreen(const CscsRegion& r);

	int m_id;
	CscsPlatformWindowSystemClient* cli;
	std::string m_rgnName;
	std::string m_rgnCaption;
	bool m_opaque;

	bool m_modified;
	bool m_onTop; 
	uint8 m_opacity;
	int m_lastFocusTime;
	CscsRegion m_requestedRegion;
	CscsRegion m_exposedRegion;
	CscsBackingStore* backingStore;
	CscsWidget* 	m_handler;
	friend class CscsWindowSystemServer;

};


class CscsBackingStore
{
public:
    CscsBackingStore();
    ~CscsBackingStore();

    void create(CscsSize size);
    void attach(int shmid, CscsSize size);
    void detach();

    void lock(bool write=false);
    void unlock();

    CscsImage* image()const;
	void setImage(CscsImage* image);

	CscsSurfaceView* surfaceView()const;
	void setSurfaceView(const CscsSurfaceView* view);

    int memoryId() const { return shmid; }
    CscsSize size() const;

private:
    CscsImage *pix;
    CscsSurfaceView* view;
    int shmid;
    void *shmaddr;
    #ifdef D_WIN32
	static CscsMap<int,int> shmid_ref;
	#endif
};

END_NAMESPACE

#endif