#ifndef SCSWINDOWCOMMAND_H
#define SCSWINDOWCOMMAND_H
#include <string>
#include <kernel/scstypes.h>

BEGIN_NAMESPACE(Gemini)

class CscsRect;
class CscsWidget;
struct CscsWindowProtocol
{
    CscsWindowProtocol(int t, int len, char *ptr) : type(t),
        simpleLen(len), rawLen(-1), deleteRaw(false), simpleDataPtr(ptr),
        rawDataPtr(0), bytesRead(0) { }
    virtual ~CscsWindowProtocol();


    // data
    int type;
    int simpleLen;
    int rawLen;
    bool deleteRaw;

    // functions
    void copyFrom(const CscsWindowProtocol *item);

    virtual void setData(const char *data, int len, bool allocateMem = true);

    char *simpleDataPtr;
    char *rawDataPtr;
    // temp variables
    int bytesRead;
};



struct CscsWindowCommand:public CscsWindowProtocol{

	CscsWindowCommand(int t, int len, char *ptr) : CscsWindowProtocol(t,len,ptr) {}

	enum Type {
        Unknown = 0,
        Create,
        Destroy,
        Region,
        RegionMove,
        RegionDestroy,
        RequestFocus,
        ChangeAltitude,
        SetOpacity,
        DefineCursor,
        SelectCursor,
        PositionCursor,
        GrabMouse,
        RegionName,
        Identify,
        RepaintRegion,
        IMUpdate
    };
    static CscsWindowCommand *factory(int type);
};


struct CscsIdentifyCommand : public CscsWindowCommand
{
    CscsIdentifyCommand() :
        CscsWindowCommand(CscsWindowCommand::Identify,
                   sizeof(simpleData), reinterpret_cast<char *>(&simpleData)) {}

    void setData(const char *d, int len, bool allocateMem) {
        CscsWindowCommand::setData(d, len, allocateMem);
        id = std::string(reinterpret_cast<const char*>(d), simpleData.idLen);
    }

    void setId(const std::string& i)
    {
        id = i;
        simpleData.idLen = id.size()+1;
        setData(reinterpret_cast<const char*>(id.data()), simpleData.idLen, true);
    }

    struct SimpleData {
        int idLen;
    } simpleData;
    std::string id;
};


struct CscsCreateCommand : public CscsWindowCommand
{
    CscsCreateCommand() :
        CscsWindowCommand(CscsWindowCommand::Create, 0, 0) {}
};


struct CscsRegionNameCommand : public CscsWindowCommand
{
    CscsRegionNameCommand();

    void setData(const char *d, int len, bool allocateMem) {
        CscsWindowCommand::setData(d, len, allocateMem);
        name = std::string(reinterpret_cast<const char*>(d), simpleData.nameLen);
        d += simpleData.nameLen;
        caption = std::string(reinterpret_cast<const char*>(d), simpleData.captionLen);
    }

    void setName(const std::string& n, const std::string &c)
    {
        name = n;
        caption = c;
        int l = simpleData.nameLen = name.size()+1;
        l += simpleData.captionLen = caption.size()+1;
        char *d = new char[l];
        memcpy(d, name.data(), simpleData.nameLen);
        memcpy(d+simpleData.nameLen, caption.data(), simpleData.captionLen);
        setData(d, l, true);
        delete[] d;
    }

    struct SimpleData {
        int windowid;
        int nameLen;
        int captionLen;
    } simpleData;
    CscsWidget* handler;
    std::string name;
    std::string caption;
};

struct CscsRegionCommand : public CscsWindowCommand
{
    CscsRegionCommand() :
        CscsWindowCommand(CscsWindowCommand::Region, sizeof(simpleData),
                    reinterpret_cast<char*>(&simpleData)) {}

    void setData(const char *d, int len, bool allocateMem = true) {
        CscsWindowCommand::setData(d, len, allocateMem);
        rectangles = reinterpret_cast<CscsRect*>(rawDataPtr);
    }

    struct SimpleData {
        int windowid;
        int shmid;
        bool opaque;
        int nrectangles;
    } simpleData;

    CscsRect *rectangles;

};


struct CscsRegionMoveCommand : public CscsWindowCommand
{
    CscsRegionMoveCommand() :
        CscsWindowCommand(CscsWindowCommand::RegionMove, sizeof(simpleData),
                    reinterpret_cast<char*>(&simpleData)) {}

    struct SimpleData {
        int windowid;
        int dx;
        int dy;
    } simpleData;

};


struct CscsRegionDestroyCommand : public CscsWindowCommand
{
    CscsRegionDestroyCommand() :
        CscsWindowCommand(CscsWindowCommand::RegionDestroy, sizeof(simpleData),
                    reinterpret_cast<char*>(&simpleData)) {}

    struct SimpleData {
        int windowid;
    } simpleData;

};


struct CscsRequestFocusCommand : public CscsWindowCommand
{
    CscsRequestFocusCommand() :
        CscsWindowCommand(CscsWindowCommand::RequestFocus, sizeof(simpleData), reinterpret_cast<char*>(&simpleData)) {}

    struct SimpleData {
        int windowid;
        int flag;
    } simpleData;
};

struct CscsChangeAltitudeCommand : public CscsWindowCommand
{
    CscsChangeAltitudeCommand() :
        CscsWindowCommand(CscsWindowCommand::ChangeAltitude, sizeof(simpleData), reinterpret_cast<char*>(&simpleData)) {}

    struct SimpleData {
        int windowid;
        int altitude;
        bool fixed;
    } simpleData;

};


struct CscsRepaintRegionCommand : public CscsWindowCommand
{
    CscsRepaintRegionCommand() :
        CscsWindowCommand(CscsWindowCommand::RepaintRegion, sizeof(simpleData),
                    reinterpret_cast<char*>(&simpleData)) {}

    void setData(const char *d, int len, bool allocateMem = true) {
        CscsWindowCommand::setData(d, len, allocateMem);
        rectangles = reinterpret_cast<CscsRect *>(rawDataPtr);
    }

    struct SimpleData {
        int windowid;
        bool opaque;
        int nrectangles;
    } simpleData;

    CscsRect * rectangles;

};


struct CscsIMUpdateCommand: public CscsWindowCommand
{
    CscsIMUpdateCommand() :
        CscsWindowCommand(CscsWindowCommand::IMUpdate,
                    sizeof(simpleData), reinterpret_cast<char *>(&simpleData)) {}

    enum UpdateType {Update, FocusIn, FocusOut, Reset, Destroyed};
    struct SimpleData {
        int windowid;
        int type;
        int widgetid;
    } simpleData;
};


struct CscsSetOpacityCommand : public CscsWindowCommand
{
    CscsSetOpacityCommand() :
        CscsWindowCommand(CscsWindowCommand::SetOpacity, sizeof(simpleData),
                    reinterpret_cast<char*>(&simpleData)) {}

    struct SimpleData {
        int windowid;
        uint8 opacity;
    } simpleData;
};

struct CscsDefineCursorCommand : public CscsWindowCommand
{
    CscsDefineCursorCommand() :
        CscsWindowCommand(CscsWindowCommand::DefineCursor,
                    sizeof(simpleData), reinterpret_cast<char *>(&simpleData)) {}

    void setData(const char *d, int len, bool allocateMem = true) {
        CscsWindowCommand::setData(d, len, allocateMem);
        data = reinterpret_cast<unsigned char *>(rawDataPtr);
    }

    struct SimpleData {
        int width;
        int height;
        int hotX;
        int hotY;
        int id;
    } simpleData;

    unsigned char *data;
};

struct CscsSelectCursorCommand : public CscsWindowCommand
{
    CscsSelectCursorCommand() :
        CscsWindowCommand(CscsWindowCommand::SelectCursor,
                    sizeof(simpleData), reinterpret_cast<char *>(&simpleData)) {}

    struct SimpleData {
        int windowid;
        int id;
    } simpleData;
};

struct CscsPositionCursorCommand : public CscsWindowCommand
{
    CscsPositionCursorCommand() :
        CscsWindowCommand(CscsWindowCommand::PositionCursor,
                    sizeof(simpleData), reinterpret_cast<char *>(&simpleData)) {}

    struct SimpleData {
        int newX;
        int newY;
    } simpleData;
};

struct CscsGrabMouseCommand : public CscsWindowCommand
{
    CscsGrabMouseCommand() :
        CscsWindowCommand(CscsWindowCommand::GrabMouse,
                    sizeof(simpleData), reinterpret_cast<char *>(&simpleData)) {}

    struct SimpleData {
        int windowid;
        bool grab;  // grab or ungrab?
    } simpleData;
};

END_NAMESPACE

#endif