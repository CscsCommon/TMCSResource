#ifndef SCSITEMSELECTIONMODEL_H
#define SCSITEMSELECTIONMODEL_H
#include <kernel/scsvector.h>
#include <kernel/scslist.h>
#include "scsabstractitemmodel.h"

BEGIN_NAMESPACE(Gemini)

class  CscsItemSelectionRange
{

public:
    inline CscsItemSelectionRange() {}
    inline CscsItemSelectionRange(const CscsItemSelectionRange &other)
        : tl(other.tl), br(other.br) {}
    inline CscsItemSelectionRange(const CscsModelIndex &topLeft, const CscsModelIndex &bottomRight);
    inline CscsItemSelectionRange(const CscsModelIndex &index)
        { tl = index; br = tl; }

    inline int top() const { return tl.row(); }
    inline int left() const { return tl.column(); }
    inline int bottom() const { return br.row(); }
    inline int right() const { return br.column(); }
    inline int width() const { return br.column() - tl.column() + 1; }
    inline int height() const { return br.row() - tl.row() + 1; }

    inline CscsModelIndex topLeft() const { return CscsModelIndex(tl); }
    inline CscsModelIndex bottomRight() const { return CscsModelIndex(br); }
    inline CscsModelIndex parent() const { return tl.parent(); }
    inline const CscsAbstractItemModel *model() const { return tl.model(); }

    inline bool contains(const CscsModelIndex &index) const
    {
        return (parent() == index.parent()
                && tl.row() <= index.row() && tl.column() <= index.column()
                && br.row() >= index.row() && br.column() >= index.column());
    }

    inline bool contains(int row, int column, const CscsModelIndex &parentIndex) const
    {
        return (parent() == parentIndex
                && tl.row() <= row && tl.column() <= column
                && br.row() >= row && br.column() >= column);
    }


    bool intersects(const CscsItemSelectionRange &other) const;
    CscsItemSelectionRange intersect(const CscsItemSelectionRange &other) const;
    inline CscsItemSelectionRange intersected(const CscsItemSelectionRange &other) const
        { return intersect(other); }

    inline bool operator==(const CscsItemSelectionRange &other) const
        { return (tl == other.tl && br == other.br); }
    inline bool operator!=(const CscsItemSelectionRange &other) const
        { return !operator==(other); }

    inline bool isValid() const
    {
        return (tl.isValid() && br.isValid() && tl.parent() == br.parent()
                && top() <= bottom() && left() <= right());
    }

    CscsModelIndexList indexes() const;

private:
    CscsPersistentModelIndex tl, br;
};
SCS_DECLARE_TYPENAME_INFO(CscsItemSelectionRange, SCS_MOVABLE_TYPE)

inline CscsItemSelectionRange::CscsItemSelectionRange(const CscsModelIndex &atopLeft,
                                                const CscsModelIndex &abottomRight)
{ tl = atopLeft; br = abottomRight; }

class CscsItemSelection;
class CscsItemSelectionModelPrivate;

class  CscsItemSelectionModel : public CscsObject
{
    CscsItemSelectionModelPrivate* d_func()const;

public:

    enum SelectionFlag {
        NoUpdate       = 0x0000,
        Clear          = 0x0001,
        Select         = 0x0002,
        Deselect       = 0x0004,
        Toggle         = 0x0008,
        Current        = 0x0010,
        Rows           = 0x0020,
        Columns        = 0x0040,
        SelectCurrent  = Select | Current,
        ToggleCurrent  = Toggle | Current,
        ClearAndSelect = Clear | Select
    };

    SCS_DECLARE_FLAGS(SelectionFlags, SelectionFlag)

    explicit CscsItemSelectionModel(CscsAbstractItemModel *model);
    explicit CscsItemSelectionModel(CscsAbstractItemModel *model, CscsObject *parent);
    virtual ~CscsItemSelectionModel();

    CscsModelIndex currentIndex() const;

    bool isSelected(const CscsModelIndex &index) const;
    bool isRowSelected(int row, const CscsModelIndex &parent) const;
    bool isColumnSelected(int column, const CscsModelIndex &parent) const;

    bool rowIntersectsSelection(int row, const CscsModelIndex &parent) const;
    bool columnIntersectsSelection(int column, const CscsModelIndex &parent) const;

    bool hasSelection() const;

    CscsModelIndexList selectedIndexes() const;
    CscsModelIndexList selectedRows(int column = 0) const;
    CscsModelIndexList selectedColumns(int row = 0) const;
    const CscsItemSelection selection() const;

    const CscsAbstractItemModel *model() const;

SLOTS:
    void setCurrentIndex(const CscsModelIndex &index, CscsItemSelectionModel::SelectionFlags command);
    virtual void select(const CscsModelIndex &index, CscsItemSelectionModel::SelectionFlags command);
    virtual void select(const CscsItemSelection &selection, CscsItemSelectionModel::SelectionFlags command);
    virtual void clear();
    virtual void reset();
    void clearSelection();

SIGNALS:
    void selectionChanged(const CscsItemSelection &selected, const CscsItemSelection &deselected){}
    void currentChanged(const CscsModelIndex &current, const CscsModelIndex &previous){}
    void currentRowChanged(const CscsModelIndex &current, const CscsModelIndex &previous){}
    void currentColumnChanged(const CscsModelIndex &current, const CscsModelIndex &previous){}

protected:
    CscsItemSelectionModel(CscsItemSelectionModelPrivate* dd, CscsAbstractItemModel *model);
    void emitSelectionChanged(const CscsItemSelection &newSelection, const CscsItemSelection &oldSelection);

};

SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsItemSelectionModel::SelectionFlags)

inline uint scsHash(const CscsItemSelectionRange &) { return 0; }

class  CscsItemSelection : public CscsList<CscsItemSelectionRange>
{
public:
    CscsItemSelection() {}
    CscsItemSelection(const CscsModelIndex &topLeft, const CscsModelIndex &bottomRight);
    void select(const CscsModelIndex &topLeft, const CscsModelIndex &bottomRight);
    bool contains(const CscsModelIndex &index) const;
    CscsModelIndexList indexes() const;
    void merge(const CscsItemSelection &other, CscsItemSelectionModel::SelectionFlags command);
    static void split(const CscsItemSelectionRange &range,
                      const CscsItemSelectionRange &other,
                      CscsItemSelection *result);
};

END_NAMESPACE
#endif