#ifndef SCSEVENTDATA_H
#define SCSEVENTDATA_H
#include "scswindowcommand.h"
#include <painting/scsrect.h>

BEGIN_NAMESPACE(Gemini)

class CscsMouseEventData;

struct CscsEventData: CscsWindowProtocol{

    CscsEventData(int t, int len, char *ptr) : CscsWindowProtocol(t,len,ptr) {}

    enum Type {
        None,
        Connected,
        Mouse,
        Focus,
        Key,
        Unused_RegionModified,
        Creation,
        MaxWindowRect,
        WindowOperation,
        NEventData
    };
    CscsMouseEventData* asMouse(){
    	return type==Mouse?reinterpret_cast<CscsMouseEventData*>(this):0;
    }
    int window() { return *(reinterpret_cast<int*>(simpleDataPtr)); }
    static CscsEventData *factory(int type);
};


struct CscsMaxWindowRectEventData: CscsEventData {
    CscsMaxWindowRectEventData()
        : CscsEventData(CscsEventData::MaxWindowRect, sizeof(simpleData), reinterpret_cast<char*>(&simpleData)) { }
    struct SimpleData {
        int window; //winId
        CscsRect rect;
    } simpleData;
};


struct CscsFocusEventData: CscsEventData {
    CscsFocusEventData()
        : CscsEventData(CscsEventData::Focus, sizeof(simpleData), reinterpret_cast<char*>(&simpleData))
        { memset(reinterpret_cast<char*>(&simpleData),0,sizeof(simpleData)); }
    struct SimpleData {
        int window; //winId
        uint get_focus:1;
    } simpleData;
};


struct CscsCreationEventData : CscsEventData {
    CscsCreationEventData()
        : CscsEventData(CscsEventData::Creation, sizeof(simpleData),
              reinterpret_cast<char*>(&simpleData)) {}
    struct SimpleData {
        int objectid; //winId
    } simpleData;
};


struct CscsWindowOperationEventData : CscsEventData {
    CscsWindowOperationEventData()
        : CscsEventData(CscsEventData::WindowOperation, sizeof(simpleData), reinterpret_cast<char*>(&simpleData)) { }

    enum Operation { Show, Hide, ShowMaximized, ShowNormal, ShowMinimized, Close };
    struct SimpleData {
        int window; //winId
        Operation op;
    } simpleData;
};


struct CscsMouseEventData:CscsEventData{
	CscsMouseEventData()
		:CscsEventData(CscsEventData::Mouse,sizeof(simpleData),reinterpret_cast<char*>(&simpleData)){

	}

	struct SimpleData{
		int window;
		int x_root, y_root, state, delta;
		int time;
	}simpleData;
};

struct CscsKeyEventData:CscsEventData{
	CscsKeyEventData()
		:CscsEventData(CscsEventData::Key,sizeof(simpleData),reinterpret_cast<char*>(&simpleData)){

	}
	struct SimpleData{
		int window;
		uint keycode;
		uint16 unicode;
        int modifiers;
		bool is_press;
		bool is_repeat;
	}simpleData;
};

END_NAMESPACE

#endif