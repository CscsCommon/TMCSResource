
#ifndef SCSPALETTE_H
#define SCSPALETTE_H

#include <memory>
#include <painting/scsrgba.h>
#include <painting/scsbrush.h>

BEGIN_NAMESPACE(Gemini)

class CscsPaletteData;

class CscsPalette{

public:
	CscsPalette();
	CscsPalette(const CscsRgba& button);
	CscsPalette(const CscsRgba& button, const CscsRgba& background);
	CscsPalette(const CscsBrush& foreground, const CscsBrush& button,
			    const CscsBrush& light, const CscsBrush& dark,
			    const CscsBrush& mid, const CscsBrush& text, const CscsBrush& bright_text,
			    const CscsBrush& base, const CscsBrush& background);
	CscsPalette(const CscsRgba& foreground, const CscsRgba& background, const CscsRgba& light,
				const CscsRgba& dark, const CscsRgba& mid, const CscsRgba& text, const CscsRgba& base);
	CscsPalette(const CscsPalette& pal);
	CscsPalette& operator=(const CscsPalette& pal);
	~CscsPalette();

	enum ColorGroup{
		Active,
		Disabled,
		Inactive,
		NColorGroups,
		Current,
		All,
		Normal=Active
	};

	enum ColorRole{
		Foreground,
		Button,
		Light,
		Midlight,
		Dark,
		Mid,
		Text,
		BrightText,
		ButtonText,
		Base,
		Background,
		Shadow,
		Highlight,
		HighlightedText,
		Link,
		LinkVisited,
		AlternateBase,
		NColorRoles,
		NoRole=NColorRoles,
		WindowText=Foreground,
		Window=Background
	};

	inline CscsPalette::ColorGroup currentColorGroup()const{
		return static_cast<CscsPalette::ColorGroup>(current_group);
	}
	inline void setCurrentColorGroup(ColorGroup cg){
		current_group=cg;
	}

	inline const CscsRgba color(ColorGroup cg, ColorRole cr)const{
		return brush(cg, cr).color();
	}

	const CscsBrush& brush(ColorGroup cg, ColorRole cr)const;

	inline void setColor(ColorGroup cg, ColorRole cr, const CscsRgba& c);
	inline void setColor(ColorRole cr, const CscsRgba& c);
	inline void setBrush(ColorRole cr, const CscsBrush& brush);
	void setBrush(ColorGroup cg, ColorRole cr, const CscsBrush& brush);

	void setColorGroup(ColorGroup cg, const CscsBrush& foreground, const CscsBrush& button, 
					   const CscsBrush& light, const CscsBrush& dark, const CscsBrush& mid,
					   const CscsBrush& text, const CscsBrush& bright_text, const CscsBrush& base,
					   const CscsBrush& background);
	bool isEqual(ColorGroup cr1, ColorGroup cr2)const;

	inline const CscsRgba color(ColorRole cr)const{return color(Current,cr);}
	inline const CscsBrush& brush(ColorRole cr)const{return brush(Current, cr);}
	inline const CscsBrush& foreground()const{return brush(Foreground);}
	inline const CscsBrush& button()const{return brush(Button);}
	inline const CscsBrush& light()const{return brush(Light);}
	inline const CscsBrush& dark()const{return brush(Dark);}
	inline const CscsBrush& mid()const{return brush(Mid);}
	inline const CscsBrush& text()const{return brush(Text);}
	inline const CscsBrush& base()const{return brush(Base);}
	inline const CscsBrush& alternateBase()const{return brush(AlternateBase);}
	inline const CscsBrush& background()const{return brush(Background);}
	inline const CscsBrush& window()const{return brush(Window);}
	inline const CscsBrush& midlight()const{return brush(Midlight);}
	inline const CscsBrush& brightText()const{return brush(BrightText);}
	inline const CscsBrush& buttonText()const{return brush(ButtonText);}
	inline const CscsBrush& shadow()const{return brush(Shadow);}
	inline const CscsBrush& highlight()const{return brush(Highlight);}
	inline const CscsBrush& highlightedText()const{return brush(HighlightedText);}
	inline const CscsBrush& link()const{return brush(Link);}
	inline const CscsBrush& linkVisited()const{return brush(LinkVisited);}

	bool operator==(const CscsPalette& p)const;
	inline bool operator!=(const CscsPalette& p)const{return !(*this==p);}
	bool isCopyOf(const CscsPalette& p)const;

	int serialNumber()const;

	CscsPalette resolve(const CscsPalette& )const;
	inline uint resolve()const{return resolve_mask;}
	inline void resolve(uint mask){resolve_mask=mask;}

private:
	void setColorGroup(ColorGroup cg, const CscsBrush& foreground, const CscsBrush& button,
					 	const CscsBrush& light, const CscsBrush& dark, const CscsBrush& mid,
					 	const CscsBrush& text, const CscsBrush& bright_text, const CscsBrush& base,
					 	const CscsBrush& alternate_base, const CscsBrush& background, const CscsBrush& midlight,
					 	const CscsBrush& button_text, const CscsBrush& shadow,
					 	const CscsBrush& hightlight, const CscsBrush& hightlighted_text,
					 	const CscsBrush& link, const CscsBrush& link_visited);
	void init();
	void detach();
	CscsPaletteData* data;
	uint current_group:4;
	uint resolve_mask:28;


};
SCS_DECLARE_TYPEINFO(CscsPalette)

inline void CscsPalette::setColor(CscsPalette::ColorGroup cg, CscsPalette::ColorRole cr,
								  const CscsRgba& c){
	setBrush(cg, cr, CscsBrush(c));
}

inline void CscsPalette::setColor(CscsPalette::ColorRole cr, const CscsRgba& c){
	setColor(All,cr, c);
}

inline void CscsPalette::setBrush(CscsPalette::ColorRole cr, const CscsBrush& brush){
	setBrush(All,cr,brush);
}

END_NAMESPACE

#endif
