#ifndef SCSDRAWHELPER_H
#define SCSDRAWHELPER_H
#include <kernel/scsnamespace.h>

BEGIN_NAMESPACE(Gemini)

class CscsPainter;
class CscsPalette;
class CscsRect;
class CscsBrush;
class CscsRgba;
class CscsPoint;

void scsDrawShadeLine(CscsPainter *p, int x1, int y1, int x2, int y2,
                              const CscsPalette &pal, bool sunken = true,
                              int lineWidth = 1, int midLineWidth = 0);

void scsDrawShadeLine(CscsPainter *p, const CscsPoint &p1, const CscsPoint &p2,
                              const CscsPalette &pal, bool sunken = true,
                              int lineWidth = 1, int midLineWidth = 0);

void scsDrawShadeRect(CscsPainter *p, int x, int y, int w, int h,
                              const CscsPalette &pal, bool sunken = false,
                              int lineWidth = 1, int midLineWidth = 0,
                              const CscsBrush *fill = 0);

void scsDrawShadeRect(CscsPainter *p, const CscsRect &r,
                              const CscsPalette &pal, bool sunken = false,
                              int lineWidth = 1, int midLineWidth = 0,
                              const CscsBrush *fill = 0);

void scsDrawShadePanel(CscsPainter *p, int x, int y, int w, int h,
                               const CscsPalette &pal, bool sunken = false,
                               int lineWidth = 1, const CscsBrush *fill = 0);

void scsDrawShadePanel(CscsPainter *p, const CscsRect &r,
                               const CscsPalette &pal, bool sunken = false,
                               int lineWidth = 1, const CscsBrush *fill = 0);

void scsDrawWinButton(CscsPainter *p, int x, int y, int w, int h,
                              const CscsPalette &pal, bool sunken = false,
                              const CscsBrush *fill = 0);

void scsDrawWinButton(CscsPainter *p, const CscsRect &r,
                              const CscsPalette &pal, bool sunken = false,
                              const CscsBrush *fill = 0);

void scsDrawWinPanel(CscsPainter *p, int x, int y, int w, int h,
                              const CscsPalette &pal, bool sunken = false,
                             const CscsBrush *fill = 0);

void scsDrawWinPanel(CscsPainter *p, const CscsRect &r,
                              const CscsPalette &pal, bool sunken = false,
                             const CscsBrush *fill = 0);

void scsDrawPlainRect(CscsPainter *p, int x, int y, int w, int h, const CscsRgba &,
                              int lineWidth = 1, const CscsBrush *fill = 0);

void scsDrawPlainRect(CscsPainter *p, const CscsRect &r, const CscsRgba &,
                              int lineWidth = 1, const CscsBrush *fill = 0);
END_NAMESPACE

#endif