/*
 * Created by J.Wong 2018/11/27
 */
#ifndef SCSBASESTYLE_H
#define SCSBASESTYLE_H

#include <kernel/scsobject.h>
#include <kernel/scsflags.h>
#include <painting/scsrect.h>
#include <painting/scspainter.h>
#include <string>
#include "../widgets/scsicon.h"
#include "scspalette.h"
#include "../scsenum.h"

BEGIN_NAMESPACE(Gemini)

class CscsWidget;
class CscsApplication;
class CscsFont;
class CscsStyleOption;
class CscsPainter;
class CscsStyleOptionComplex;
class CscsStyleHintReturn;


class CscsBaseStyle:public CscsObject{
public:
	CscsBaseStyle();
	virtual ~CscsBaseStyle();
	virtual void polish(CscsWidget* w);
	virtual void unpolish(CscsWidget* w);
    virtual void polish(CscsPalette& pal);

	virtual void polish(CscsApplication* app);
	virtual void unpolish(CscsApplication* app);

	virtual CscsRect itemTextRect(const CscsFont& font, const CscsRect& r, int flags, bool enabled, const std::string& text)const;
	virtual CscsRect itemPixmapRect(const CscsRect& r, int flags, const CscsImage& image)const;

	virtual void drawItemText(CscsPainter* painter, const CscsRect& r, int flags,const CscsPalette &pal, bool enabled, 
            const std::string& text, CscsPalette::ColorRole textRole=(CscsPalette::Text),bool rotate=false)const;
	virtual void drawItemPixmap(CscsPainter* painter, const CscsRect& r, int alignment, const CscsImage& pixmap)const;

    virtual CscsPalette standardPalette()const;

	enum StateFlag{
		StateNone=			 0x00000000,
		StateEnabled =       0x00000001,
        StateRaised =        0x00000002,
        StateSunken =        0x00000004,
        StateOff =           0x00000008,
        StateNoChange =      0x00000010,
        StateOn =            0x00000020,
        StateDownArrow =     0x00000040,
        StateHorizontal =    0x00000080,
        StateHasFocus =      0x00000100,
        StateTop =           0x00000200,
        StateBottom =        0x00000400,
        StateFocusAtBorder = 0x00000800,
        StateAutoRaise =     0x00001000,
        StateMouseOver =     0x00002000,
        StateUpArrow =       0x00004000,
        StateSelected =      0x00008000,
        StateActive =        0x00010000,
        StateWindow =       0x00020000,
        StateOpen =          0x00040000,
        StateChildren =      0x00080000,
        StateItem =          0x00100000,
        StateSibling =       0x00200000,
        StateEditing =       0x00400000,
        StateKeyboardFocusChange = 0x00800000,
        StateHasEditFocus=         0x01000000, 
        StateReadOnly =            0x02000000,
        StateSmall =               0x04000000,
        StateMini =                0x08000000
	};
	SCS_DECLARE_FLAGS(State, StateFlag)

	enum PrimitiveElement {
        Frame,
        FrameDefaultButton,
        FrameDockWidget,
        FrameFocusRect,
        FrameGroupBox,
        FrameLineEdit,
        FrameMenu,
        FrameStatusBar,
        FrameTabWidget,
        FrameWindow,
        FrameButtonBevel,
        FrameButtonTool,
        FrameTabBarBase,

        PanelButtonCommand,
        PanelButtonBevel,
        PanelButtonTool,
        PanelMenuBar,
        PanelToolBar,
        PanelLineEdit,
        PanelItemViewRow,
        Widget,

        IndicatorArrowDown,
        IndicatorArrowLeft,
        IndicatorArrowRight,
        IndicatorArrowUp,
        IndicatorBranch,
        IndicatorButtonDropDown,
        IndicatorViewItemCheck,
        IndicatorCheckBox,
        IndicatorDockWidgetResizeHandle,
        IndicatorHeaderArrow,
        IndicatorMenuCheckMark,
        IndicatorProgressChunk,
        IndicatorRadioButton,
        IndicatorSpinDown,
        IndicatorSpinMinus,
        IndicatorSpinPlus,
        IndicatorSpinUp,
        IndicatorToolBarHandle,
        IndicatorToolBarSeparator,
        PanelTipLabel,
        IndicatorTabTear,

        // do not add any values below/greater this
        PECustomBase = 0xf000000
    };

    virtual void drawPrimitive(PrimitiveElement pe, const CscsStyleOption* op, CscsPainter* p, const CscsWidget* w=0)const =0;
     enum ControlElement {
        PushButton,
        PushButtonBevel,
        PushButtonLabel,

        CheckBox,
        CheckBoxLabel,

        RadioButton,
        RadioButtonLabel,

        TabBarTab,
        TabBarTabShape,
        TabBarTabLabel,

        ProgressBar,
        ProgressBarGroove,
        ProgressBarContents,
        ProgressBarLabel,

        MenuItem,
        MenuScroller,
        MenuVMargin,
        MenuHMargin,
        MenuTearoff,
        MenuEmptyArea,

        MenuBarItem,
        MenuBarEmptyArea,

        ToolButtonLabel,

        Header,
        HeaderSection,
        HeaderLabel,
        HeaderEmptyArea,
        ToolBoxTab,
        SizeGrip,
        Splitter,
        RubberBand,
        DockWidgetTitle,

        ScrollBarAddLine,
        ScrollBarSubLine,
        ScrollBarAddPage,
        ScrollBarSubPage,
        ScrollBarSlider,
        ScrollBarFirst,
        ScrollBarLast,

        FocusFrame,
        ComboBoxLabel,
        ToolBar,

        // do not add any values below/greater than this
        CECustomBase = 0xf0000000
    };

    virtual void drawControl(ControlElement e, const CscsStyleOption* op, CscsPainter* p,const CscsWidget* w=0)const=0;

    enum SubElement
    {
        SubPushButtonContents,
        SubPushButtonFocusRect,

        SubCheckBoxIndicator,
        SubCheckBoxContents,
        SubCheckBoxFocusRect,
        SubCheckBoxClickRect,

        SubRadioButtonIndicator,
        SubRadioButtonContents,
        SubRadioButtonFocusRect,
        SubRadioButtonClickRect,

        SubComboBoxFocusRect,

        SubSliderFocusRect,

        SubLineEditContents,
        SubFrameContents,

        SubProgressBarGroove,
        SubProgressBarContents,
        SubProgressBarLabel,


        SubDialogButtonAccept,
        SubDialogButtonReject,
        SubDialogButtonApply,
        SubDialogButtonHelp,
        SubDialogButtonAll,
        SubDialogButtonAbort,
        SubDialogButtonIgnore,
        SubDialogButtonRetry,
        SubDialogButtonCustom,

        SubToolBoxTabContents,

        SubHeaderLabel,
        SubHeaderArrow,

        SubTabWidgetTabBar,
        SubTabWidgetTabPane,
        SubTabWidgetTabContents,
        SubTabWidgetLeftCorner,
        SubTabWidgetRightCorner,

        SubViewItemCheckIndicator,
        SubItemViewItemCheckIndicator=SubViewItemCheckIndicator,
        SubTabBarTearIndicator,

        SubToolBarHandle,
        SubTreeViewDisclosureItem,

        SubItemViewItemDecoration,
        SubItemViewItemText,
        SubItemViewItemFocusRect,

        // do not add any values below/greater than this
        SubCustomBase = 0xf0000000
    };

    virtual CscsRect subElementRect(SubElement e, const CscsStyleOption* op, const CscsWidget* w=0)const=0;
    enum ComplexControl {
        SpinBox,
        ComboBox,
        ScrollBar,
        Slider,
        ToolButton,
        TitleBar,
        Dial,

        // do not add any values below/greater than this
        CCCustomBase = 0xf0000000
    };

    enum SubControl {
        SubNone =                  0x00000000,

        SubScrollBarAddLine =      0x00000001,
        SubScrollBarSubLine =      0x00000002,
        SubScrollBarAddPage =      0x00000004,
        SubScrollBarSubPage =      0x00000008,
        SubScrollBarFirst =        0x00000010,
        SubScrollBarLast =         0x00000020,
        SubScrollBarSlider =       0x00000040,
        SubScrollBarGroove =       0x00000080,

        SubSpinBoxUp =             0x00000001,
        SubSpinBoxDown =           0x00000002,
        SubSpinBoxFrame =          0x00000004,
        SubSpinBoxEditField =      0x00000008,


        SubComboBoxFrame =         0x00000001,
        SubComboBoxEditField =     0x00000002,
        SubComboBoxArrow =         0x00000004,
        SubComboBoxListBoxPopup =  0x00000008,

        SubSliderGroove =          0x00000001,
        SubSliderHandle =          0x00000002,
        SubSliderTickmarks =       0x00000004,

        SubToolButton =            0x00000001,
        SubToolButtonMenu =        0x00000002,

        SubTitleBarSysMenu =       0x00000001,
        SubTitleBarMinButton =     0x00000002,
        SubTitleBarMaxButton =     0x00000004,
        SubTitleBarCloseButton =   0x00000008,
        SubTitleBarNormalButton =  0x00000010,
        SubTitleBarShadeButton =   0x00000020,
        SubTitleBarUnshadeButton = 0x00000040,
        SubTitleBarContextHelpButton = 0x00000080,
        SubTitleBarLabel =         0x00000100,


        SubDialGroove =            0x00000001,
        SubDialHandle =            0x00000002,
        SubDialTickmarks =         0x00000004,

        SubGroupBoxCheckBox =      0x00000001,
        SubGroupBoxLabel =         0x00000002,
        SubGroupBoxContents =      0x00000004,
        SubGroupBoxFrame =         0x00000008,

        SubMdiMinButton     =      0x00000001,
        SubMdiNormalButton  =      0x00000002,
        SubMdiCloseButton   =      0x00000004,

        SubAll =                   0xffffffff
    };
    SCS_DECLARE_FLAGS(SubControls, SubControl)

    virtual void drawComplexControl(ComplexControl cc, const CscsStyleOptionComplex* op, CscsPainter* p, const CscsWidget* w=0)const=0;
    virtual SubControl hitTestComplexControl(ComplexControl cc, const CscsStyleOptionComplex* op, const CscsPoint& p, const CscsWidget* w=0)const=0;
    virtual CscsRect subControlRect(ComplexControl cc, const CscsStyleOptionComplex* opt, SubControl sc, const CscsWidget* w=0)const=0;

    enum PixelMetric {
        PMButtonMargin,
        PMButtonDefaultIndicator,
        PMMenuButtonIndicator,
        PMButtonShiftHorizontal,
        PMButtonShiftVertical,

        PMDefaultFrameWidth,
        PMSpinBoxFrameWidth,
        PMComboBoxFrameWidth,

        PMMaximumDragDistance,

        PMScrollBarExtent,
        PMScrollBarSliderMin,

        PMSliderThickness,             // total slider thickness
        PMSliderControlThickness,      // thickness of the business part
        PMSliderLength,                // total length of slider
        PMSliderTickmarkOffset,        //
        PMSliderSpaceAvailable,        // available space for slider to move

        PMDockWidgetSeparatorExtent,
        PMDockWidgetHandleExtent,
        PMDockWidgetFrameWidth,

        PMTabBarTabOverlap,
        PMTabBarTabHSpace,
        PMTabBarTabVSpace,
        PMTabBarBaseHeight,
        PMTabBarBaseOverlap,

        PMProgressBarChunkWidth,

        PMSplitterWidth,
        PMTitleBarHeight,

        PMMenuScrollerHeight,
        PMMenuHMargin,
        PMMenuVMargin,
        PMMenuPanelWidth,
        PMMenuTearoffHeight,
        PMMenuDesktopFrameWidth,

        PMMenuBarPanelWidth,
        PMMenuBarItemSpacing,
        PMMenuBarVMargin,
        PMMenuBarHMargin,

        PMIndicatorWidth,
        PMIndicatorHeight,
        PMExclusiveIndicatorWidth,
        PMExclusiveIndicatorHeight,
        PMCheckListButtonSize,
        PMCheckListControllerSize,

        PMDialogButtonsSeparator,
        PMDialogButtonsButtonWidth,
        PMDialogButtonsButtonHeight,

        PMMDIFrameWidth,
        PMMDIMinimizedWidth,
        PMHeaderMargin,
        PMHeaderMarkSize,
        PMHeaderGripMargin,
        PMTabBarTabShiftHorizontal,
        PMTabBarTabShiftVertical,
        PMTabBarScrollButtonWidth,

        PMToolBarFrameWidth,
        PMToolBarHandleExtent,
        PMToolBarItemSpacing,
        PMToolBarItemMargin,
        PMToolBarSeparatorExtent,
        PMToolBarExtensionExtent,

        PMSpinBoxSliderHeight,

        PMDefaultTopLevelMargin,
        PMDefaultChildMargin,
        PMDefaultLayoutSpacing,

        PMToolBarIconSize,
        PMListViewIconSize,
        PMIconViewIconSize,
        PMSmallIconSize,
        PMLargeIconSize,

        PMFocusFrameVMargin,
        PMFocusFrameHMargin,

        PMToolTipLabelFrameWidth,
        PMButtonIconSize,
        PMDefaultSeparatorWidth,
        PMRadioButtonLabelSpacing,
        PMCheckBoxLabelSpacing,

        // do not add any values below/greater than this
        PMCustomBase = 0xf0000000
    };

    virtual int pixelMetric(PixelMetric metric, const CscsStyleOption *op = 0,
                            const CscsWidget *w = 0) const = 0;
    enum ContentsType {
        ConPushButton,
        ConCheckBox,
        ConRadioButton,
        ConToolButton,
        ConComboBox,
        ConSplitter,
        ConProgressBar,
        ConMenuItem,
        ConMenuBarItem,
        ConMenuBar,
        ConMenu,
        ConTabBarTab,
        ConSlider,
        ConScrollBar,
        ConLineEdit,
        ConSpinBox,
        ConSizeGrip,
        ConTabWidget,
        ConDialogButtons,
        ConHeaderSection,
        // do not add any values below/greater than this
        ConCustomBase = 0xf0000000
    };
    virtual CscsSize sizeFromContents(ContentsType ct, const CscsStyleOption *op,
                                   const CscsSize &size, const CscsWidget *w = 0) const = 0;

    enum StyleHint {
        EtchDisabledText,
        DitherDisabledText,
        ScrollBar_MiddleClickAbsolutePosition,
        ScrollBar_ScrollWhenPointerLeavesControl,
        TabBar_SelectMouseType,
        TabBar_Alignment,
        Header_ArrowAlignment,
        Slider_SnapToValue,
        Slider_SloppyKeyEvents,
        ProgressDialog_CenterCancelButton,
        ProgressDialog_TextLabelAlignment,
        PrintDialog_RightAlignButtons,
        MainWindow_SpaceBelowMenuBar,
        FontDialog_SelectAssociatedText,
        Menu_AllowActiveAndDisabled,
        Menu_Mask,
        Menu_SpaceActivatesItem,
        Menu_SubMenuPopupDelay,
        ItemView_MovementWithoutUpdatingSelection,
        ScrollView_FrameOnlyAroundContents,
        MenuBar_AltKeyNavigation,
        ComboBox_ListMouseTracking,
        Menu_MouseTracking,
        MenuBar_MouseTracking,
        ItemView_ChangeHighlightOnFocus,
        Widget_ShareActivation,
        Workspace_FillSpaceOnMaximize,
        ComboBox_Popup,
        TitleBar_NoBorder,
        ScrollBar_StopMouseOverSlider,
        BlinkCursorWhenTextSelected,
        RichText_FullWidthSelection,
        Menu_Scrollable,
        GroupBox_TextLabelVerticalAlignment,
        GroupBox_TextLabelColor,
        Menu_SloppySubMenus,
        Table_GridLineColor,
        LineEdit_PasswordCharacter,
        DialogButtons_DefaultButton,
		DialogButtonLayout,
        ComboBox_PopupFrameStyle,
		DialogButtonBox_ButtonsHaveIcons,
        ToolBox_SelectedPageTitleBold,
        TabBar_PreferNoArrows,
        ScrollBar_LeftClickAbsolutePosition,
        UnderlineShortcut,
        SpinBox_AnimateButton,
        SpinBox_KeyPressAutoRepeatRate,
        SpinBox_ClickAutoRepeatRate,
        Menu_FillScreenWithScroll,
        ToolTipLabel_Opacity,
        DrawMenuBarSeparator,
        TitleBar_ModifyNotification,
        Button_FocusPolicy,
        MenuBar_DismissOnSecondClick,
        MessageBox_UseBorderForButtonSpacing,
        TitleBar_AutoRaise,
        ToolButton_PopupDelay,
        FocusFrame_Mask,
        RubberBand_Mask,
        WindowFrame_Mask,
        SpinControls_DisableOnBounds,
        Dial_BackgroundRole,
        ComboBox_LayoutDirection,
        ItemView_EllipsisLocation,
        ItemView_ShowDecorationSelected,
        ItemView_ActivateItemOnSingleClick,
        ItemView_ArrowKeysNavigateIntoChildren,
        ItemView_PaintAlternatingRowColorsForEmptyArea,
        TextControl_FocusIndicatorTextCharFormat,
        // Add new style hint values here

        SHCustomBase = 0xf0000000
    };

    virtual int styleHint(StyleHint stylehint, const CscsStyleOption *op = 0,
                          const CscsWidget *w = 0, CscsStyleHintReturn* returnData = 0) const = 0;

     enum StandardPixmap {
        StandardTitleBarMenuButton,
        StandardTitleBarMinButton,
        StandardTitleBarMaxButton,
        StandardTitleBarCloseButton,
        StandardTitleBarNormalButton,
        StandardTitleBarShadeButton,
        StandardTitleBarUnshadeButton,
        StandardTitleBarContextHelpButton,
        StandardDockWidgetCloseButton,
        StandardMessageBoxInformation,
        StandardMessageBoxWarning,
        StandardMessageBoxCritical,
        StandardMessageBoxQuestion,
        StandardDesktopIcon,
        StandardTrashIcon,
        StandardComputerIcon,
        StandardDriveFDIcon,
        StandardDriveHDIcon,
        StandardDriveCDIcon,
        StandardDriveDVDIcon,
        StandardDriveNetIcon,
        StandardDirOpenIcon,
        StandardDirClosedIcon,
        StandardDirLinkIcon,
        StandardFileIcon,
        StandardFileLinkIcon,
        StandardToolBarHorizontalExtensionButton,
        StandardToolBarVerticalExtensionButton,
        StandardFileDialogStart,
        StandardFileDialogEnd,
        StandardFileDialogToParent,
        StandardFileDialogNewFolder,
        StandardFileDialogDetailedView,
        StandardFileDialogInfoView,
        StandardFileDialogContentsView,
        StandardFileDialogListView,
        StandardFileDialogBack,
		StandardDialogOkButton,
        StandardDialogCancelButton,
        StandardDialogHelpButton,
        StandardDialogOpenButton,
        StandardDialogSaveButton,
        StandardDialogCloseButton,
        StandardDialogApplyButton,
        StandardDialogResetButton,
        StandardDialogDiscardButton,
        StandardDialogYesButton,
        StandardDialogNoButton,

        // do not add any values below/greater than this
        StandardCustomBase = 0xf0000000
    };

    virtual CscsImage standardPixmap(StandardPixmap standardPixmap, const CscsStyleOption *opt = 0,
                                   const CscsWidget *w = 0) const = 0;

    virtual CscsImage generatedIconPixmap(CscsIcon::Mode iconMode, const CscsImage &pixmap,
                                    const CscsStyleOption *opt) const = 0;
    static CscsRect visualRect(SCS::LayoutDirection direction, const CscsRect &boundingRect,
                            const CscsRect &logicalRect);
    static CscsPoint visualPos(SCS::LayoutDirection direction, const CscsRect &boundingRect,
                            const CscsPoint &logicalPos);
    static int sliderPositionFromValue(int min, int max, int val, int space,
                                       bool upsideDown = false);
    static int sliderValueFromPosition(int min, int max, int pos, int space,
                                       bool upsideDown = false);
    static SCS::Alignment visualAlignment(SCS::LayoutDirection direction, SCS::Alignment alignment);
    static CscsRect alignedRect(SCS::LayoutDirection direction, SCS::Alignment alignment,
                             const CscsSize &size, const CscsRect &r);
};

SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsBaseStyle::State)
SCS_DECLARE_OPERATORS_FOR_FLAGS(CscsBaseStyle::SubControls)

END_NAMESPACE

#endif