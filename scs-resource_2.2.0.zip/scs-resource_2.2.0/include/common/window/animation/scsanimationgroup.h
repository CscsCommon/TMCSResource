#ifndef SCSANIMATIONGROUP_H
#define SCSANIMATIONGROUP_H
#include "scsabstractanimation.h"

BEGIN_NAMESPACE(Gemini)

class CscsAnimationGroupPrivate;
class  CscsAnimationGroup : public CscsAbstractAnimation
{
public:
    CscsAnimationGroup(CscsObject *parent = nullptr);
    ~CscsAnimationGroup();

    CscsAbstractAnimation *animationAt(int index) const;
    int animationCount() const;
    int indexOfAnimation(CscsAbstractAnimation *animation) const;
    void addAnimation(CscsAbstractAnimation *animation);
    void insertAnimation(int index, CscsAbstractAnimation *animation);
    void removeAnimation(CscsAbstractAnimation *animation);
    CscsAbstractAnimation *takeAnimation(int index);
    void clear();

protected:
    CscsAnimationGroup(CscsAnimationGroupPrivate* dd, CscsObject *parent);
    bool event(CscsEvent *event);

private:
   CscsAnimationGroupPrivate* d_func()const;
};

END_NAMESPACE

#endif