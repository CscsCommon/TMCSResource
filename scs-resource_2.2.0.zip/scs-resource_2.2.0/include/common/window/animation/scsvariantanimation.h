#ifndef SCSVARIANTANIMATION_H
#define SCSVARIANTANIMATION_H

#include "scsabstractanimation.h"
#include <kernel/scsvector.h>
#include <kernel/scsvariant.h>
#include <utility>
#include <typeindex>

BEGIN_NAMESPACE(Gemini)

class CscsEasingCurve;
class CscsVariantAnimationPrivate;
class CscsVariantAnimation : public CscsAbstractAnimation
{
	CscsVariantAnimationPrivate* d_func()const;
public:
    typedef std::pair<double, CscsVariant> KeyValue;
    typedef CscsVector<KeyValue> KeyValues;

    CscsVariantAnimation(CscsObject *parent = nullptr);
    ~CscsVariantAnimation();

    CscsVariant startValue() const;
    void setStartValue(const CscsVariant &value);

    CscsVariant endValue() const;
    void setEndValue(const CscsVariant &value);

    CscsVariant keyValueAt(double step) const;
    void setKeyValueAt(double step, const CscsVariant &value);

    KeyValues keyValues() const;
    void setKeyValues(const KeyValues &values);

    CscsVariant currentValue() const;

    int duration() const;
    void setDuration(int msecs);

    CscsEasingCurve easingCurve() const;
    void setEasingCurve(const CscsEasingCurve &easing);

    typedef CscsVariant (*Interpolator)(const void *from, const void *to, double progress);

SIGNALS:
    void valueChanged(const CscsVariant &value);

protected:
    CscsVariantAnimation(CscsVariantAnimationPrivate* dd, CscsObject *parent = nullptr);
    bool event(CscsEvent *event);

    void updateCurrentTime(int);
    void updateState(CscsAbstractAnimation::State newState, CscsAbstractAnimation::State oldState);

    virtual void updateCurrentValue(const CscsVariant &value);
    virtual CscsVariant interpolated(const CscsVariant &from, const CscsVariant &to, double progress) const;

private:
    template <typename T> friend void scsRegisterAnimationInterpolator(CscsVariant (*func)(const T &, const T &, double));
    static void registerInterpolator(Interpolator func, int interpolationType);
	friend class CscsVariantAnimationPrivate;
};

template <typename T>
void scsRegisterAnimationInterpolator(CscsVariant (*func)(const T &from, const T &to, double progress)) {
    CscsVariantAnimation::registerInterpolator(reinterpret_cast<CscsVariantAnimation::Interpolator>(func), std::type_index(typeid(T)).hash_code());
}

END_NAMESPACE
#endif