#ifndef SCSCOMMONITEMMODEL_H
#define SCSCOMMONITEMMODEL_H

#include <window/scsabstractitemmodel.h>
#include <painting/scsbrush.h>
#include <painting/scsfont.h>
#include <window/widgets/scsicon.h>
#include <window/scsenum.h>

BEGIN_NAMESPACE(Gemini)

template <class T> class CscsList;

class CscsCommonItemModel;

class CscsCommonItemPrivate;
class  CscsCommonItem
{
public:
    CscsCommonItem();
    CscsCommonItem(const std::string &text);
    CscsCommonItem(const CscsIcon &icon, const std::string &text);
    CscsCommonItem(int rows, int columns = 1);
    virtual ~CscsCommonItem();

    virtual CscsVariant data(int role = SCS::UserRole + 1) const;
    virtual void setData(const CscsVariant &value, int role = SCS::UserRole + 1);

    inline std::string text() const {
        return std::string(scsvariant_cast<CscsString>(data(SCS::DisplayRole)).toUtf8());
    }
    inline void setText(const std::string &text);

    inline CscsIcon icon() const {
        return scsvariant_cast<CscsIcon>(data(SCS::DecorationRole));
    }
    inline void setIcon(const CscsIcon &icon);

    inline CscsSize sizeHint() const {
        return scsvariant_cast<CscsSize>(data(SCS::SizeHintRole));
    }
    inline void setSizeHint(const CscsSize &sizeHint);

    inline CscsFont font() const {
        return scsvariant_cast<CscsFont>(data(SCS::FontRole));
    }
    inline void setFont(const CscsFont &font);

    inline SCS::Alignment textAlignment() const {
        return SCS::Alignment(scsvariant_cast<int>(data(SCS::TextAlignmentRole)));
    }
    inline void setTextAlignment(SCS::Alignment textAlignment);

    inline CscsBrush background() const {
        return scsvariant_cast<CscsBrush>(data(SCS::BackgroundRole));
    }
    inline void setBackground(const CscsBrush &brush);

    inline CscsBrush foreground() const {
        return scsvariant_cast<CscsBrush>(data(SCS::ForegroundRole));
    }
    inline void setForeground(const CscsBrush &brush);

    inline SCS::CheckState checkState() const {
        return SCS::CheckState(scsvariant_cast<int>(data(SCS::CheckStateRole)));
    }
    inline void setCheckState(SCS::CheckState checkState);

    inline CscsString accessibleText() const {
        return scsvariant_cast<CscsString>(data(SCS::AccessibleTextRole));
    }
    inline void setAccessibleText(const CscsString &accessibleText);

    inline CscsString accessibleDescription() const {
        return scsvariant_cast<CscsString>(data(SCS::AccessibleDescriptionRole));
    }
    inline void setAccessibleDescription(const CscsString &accessibleDescription);

    SCS::ItemFlags flags() const;
    void setFlags(SCS::ItemFlags flags);

    inline bool isEnabled() const {
        return (flags() & SCS::ItemIsEnabled) != 0;
    }
    void setEnabled(bool enabled);

    inline bool isEditable() const {
        return (flags() & SCS::ItemIsEditable) != 0;
    }
    void setEditable(bool editable);

    inline bool isSelectable() const {
        return (flags() & SCS::ItemIsSelectable) != 0;
    }
    void setSelectable(bool selectable);

    inline bool isCheckable() const {
        return (flags() & SCS::ItemIsUserCheckable) != 0;
    }
    void setCheckable(bool checkable);

    inline bool isTristate() const {
        return (flags() & SCS::ItemIsTristate) != 0;
    }
    void setTristate(bool tristate);

    CscsCommonItem *parent() const;
    int row() const;
    int column() const;
    CscsModelIndex index() const;
    CscsCommonItemModel *model() const;

    int rowCount() const;
    void setRowCount(int rows);
    int columnCount() const;
    void setColumnCount(int columns);

    bool hasChildren() const;
    CscsCommonItem *child(int row, int column = 0) const;
    void setChild(int row, int column, CscsCommonItem *item);
    inline void setChild(int row, CscsCommonItem *item);

    void insertRow(int row, const CscsList<CscsCommonItem*> &items);
    void insertColumn(int column, const CscsList<CscsCommonItem*> &items);
    void insertRows(int row, const CscsList<CscsCommonItem*> &items);
    void insertRows(int row, int count);
    void insertColumns(int column, int count);

    void removeRow(int row);
    void removeColumn(int column);
    void removeRows(int row, int count);
    void removeColumns(int column, int count);

    inline void appendRow(const CscsList<CscsCommonItem*> &items);
    inline void appendRows(const CscsList<CscsCommonItem*> &items);
    inline void appendColumn(const CscsList<CscsCommonItem*> &items);
    inline void insertRow(int row, CscsCommonItem *item);
    inline void appendRow(CscsCommonItem *item);

    CscsCommonItem *takeChild(int row, int column = 0);
    CscsList<CscsCommonItem*> takeRow(int row);
    CscsList<CscsCommonItem*> takeColumn(int column);

    void sortChildren(int column, SCS::SortOrder order = SCS::AscendingOrder);

    virtual CscsCommonItem *clone() const;

    enum ItemType { Type = 0, UserType = 1000 };
    virtual int type() const;

    virtual bool operator<(const CscsCommonItem &other) const;

protected:
    CscsCommonItem(const CscsCommonItem &other);
    CscsCommonItem(CscsCommonItemPrivate* dd);
    CscsCommonItem &operator=(const CscsCommonItem &other);
    CscsCommonItemPrivate *d;

    void emitDataChanged();

private:
    CscsCommonItemPrivate* d_func()const;
    friend class CscsCommonItemModelPrivate;
    friend class CscsCommonItemModel;
    friend class CscsCommonItemPrivate;
};

inline void CscsCommonItem::setText(const std::string &atext)
{
    CscsVariant var=atext;
    setData(atext, SCS::DisplayRole);
}

inline void CscsCommonItem::setIcon(const CscsIcon &aicon)
{ setData(aicon, SCS::DecorationRole); }


inline void CscsCommonItem::setSizeHint(const CscsSize &asizeHint)
{ setData(asizeHint, SCS::SizeHintRole); }

inline void CscsCommonItem::setFont(const CscsFont &afont)
{ setData(afont, SCS::FontRole); }

inline void CscsCommonItem::setTextAlignment(SCS::Alignment atextAlignment)
{ setData(int(atextAlignment), SCS::TextAlignmentRole); }

inline void CscsCommonItem::setBackground(const CscsBrush &abrush)
{ setData(abrush, SCS::BackgroundRole); }

inline void CscsCommonItem::setForeground(const CscsBrush &abrush)
{ setData(abrush, SCS::ForegroundRole); }

inline void CscsCommonItem::setCheckState(SCS::CheckState acheckState)
{ setData(acheckState, SCS::CheckStateRole); }

inline void CscsCommonItem::setAccessibleText(const CscsString &aaccessibleText)
{ setData(aaccessibleText, SCS::AccessibleTextRole); }

inline void CscsCommonItem::setAccessibleDescription(const CscsString &aaccessibleDescription)
{ setData(aaccessibleDescription, SCS::AccessibleDescriptionRole); }

inline void CscsCommonItem::setChild(int arow, CscsCommonItem *aitem)
{ setChild(arow, 0, aitem); }

inline void CscsCommonItem::appendRow(const CscsList<CscsCommonItem*> &aitems)
{ insertRow(rowCount(), aitems); }

inline void CscsCommonItem::appendRows(const CscsList<CscsCommonItem*> &aitems)
{ insertRows(rowCount(), aitems); }

inline void CscsCommonItem::appendColumn(const CscsList<CscsCommonItem*> &aitems)
{ insertColumn(columnCount(), aitems); }

inline void CscsCommonItem::insertRow(int arow, CscsCommonItem *aitem)
{ insertRow(arow, CscsList<CscsCommonItem*>() << aitem); }

inline void CscsCommonItem::appendRow(CscsCommonItem *aitem)
{ insertRow(rowCount(), aitem); }

class CscsCommonItemModelPrivate;

class CscsCommonItemModel : public CscsAbstractItemModel
{
public:
    explicit CscsCommonItemModel(CscsObject *parent = 0);
    CscsCommonItemModel(int rows, int columns, CscsObject *parent = 0);
    ~CscsCommonItemModel();

    CscsModelIndex index(int row, int column, const CscsModelIndex &parent = CscsModelIndex()) const;
    CscsModelIndex parent(const CscsModelIndex &child) const;

    int rowCount(const CscsModelIndex &parent = CscsModelIndex()) const;
    int columnCount(const CscsModelIndex &parent = CscsModelIndex()) const;
    bool hasChildren(const CscsModelIndex &parent = CscsModelIndex()) const;

    CscsVariant data(const CscsModelIndex &index, int role = SCS::DisplayRole) const;
    bool setData(const CscsModelIndex &index, const CscsVariant &value, int role = SCS::EditRole);

    CscsVariant headerData(int section, SCS::Orientation orientation,
                        int role = SCS::DisplayRole) const;
    bool setHeaderData(int section, SCS::Orientation orientation, const CscsVariant &value,
                       int role = SCS::EditRole);

    bool insertRows(int row, int count, const CscsModelIndex &parent = CscsModelIndex());
    bool insertColumns(int column, int count, const CscsModelIndex &parent = CscsModelIndex());
    bool removeRows(int row, int count, const CscsModelIndex &parent = CscsModelIndex());
    bool removeColumns(int column, int count, const CscsModelIndex &parent = CscsModelIndex());

    SCS::ItemFlags flags(const CscsModelIndex &index) const;

    CscsMap<int, CscsVariant> itemData(const CscsModelIndex &index) const;
    bool setItemData(const CscsModelIndex &index, const CscsMap<int, CscsVariant> &roles);

    void clear();

    using CscsObject::parent;

    void sort(int column, SCS::SortOrder order = SCS::AscendingOrder);

    CscsCommonItem *itemFromIndex(const CscsModelIndex &index) const;
    CscsModelIndex indexFromItem(const CscsCommonItem *item) const;

    CscsCommonItem *item(int row, int column = 0) const;
    void setItem(int row, int column, CscsCommonItem *item);
    inline void setItem(int row, CscsCommonItem *item);
    CscsCommonItem *invisibleRootItem() const;

    CscsCommonItem *horizontalHeaderItem(int column) const;
    void setHorizontalHeaderItem(int column, CscsCommonItem *item);
    CscsCommonItem *verticalHeaderItem(int row) const;
    void setVerticalHeaderItem(int row, CscsCommonItem *item);

    void setHorizontalHeaderLabels(const CscsStringList &labels);
    void setVerticalHeaderLabels(const CscsStringList &labels);

    void setRowCount(int rows);
    void setColumnCount(int columns);

    void appendRow(const CscsList<CscsCommonItem*> &items);
    void appendColumn(const CscsList<CscsCommonItem*> &items);
    inline void appendRow(CscsCommonItem *item);

    void insertRow(int row, const CscsList<CscsCommonItem*> &items);
    void insertColumn(int column, const CscsList<CscsCommonItem*> &items);
    inline void insertRow(int row, CscsCommonItem *item);

    inline bool insertRow(int row, const CscsModelIndex &parent = CscsModelIndex());
    inline bool insertColumn(int column, const CscsModelIndex &parent = CscsModelIndex());

    CscsCommonItem *takeItem(int row, int column = 0);
    CscsList<CscsCommonItem*> takeRow(int row);
    CscsList<CscsCommonItem*> takeColumn(int column);

    CscsCommonItem *takeHorizontalHeaderItem(int column);
    CscsCommonItem *takeVerticalHeaderItem(int row);

    const CscsCommonItem *itemPrototype() const;
    void setItemPrototype(const CscsCommonItem *item);

    CscsList<CscsCommonItem*> findItems(const std::string &text,
                                    SCS::MatchFlags flags = SCS::MatchExactly,
                                    int column = 0) const;

    int sortRole() const;
    void setSortRole(int role);

SIGNALS:
    void itemChanged(CscsCommonItem *item){}

protected:
    CscsCommonItemModel(CscsCommonItemModelPrivate* dd, CscsObject *parent = 0);

private:
    friend class CscsCommonItemPrivate;
    friend class CscsCommonItem;
    CscsCommonItemModelPrivate* d_func()const;

BEGIN_PROPERTY(CscsCommonItemModel, CscsAbstractItemModel)
    META_PROPERTY(int, sortRole, READ, sortRole, WRITE, setSortRole);
END_PROPERTY

};

inline void CscsCommonItemModel::setItem(int arow, CscsCommonItem *aitem)
{ setItem(arow, 0, aitem); }

inline void CscsCommonItemModel::appendRow(CscsCommonItem *aitem)
{ appendRow(CscsList<CscsCommonItem*>() << aitem); }

inline void CscsCommonItemModel::insertRow(int arow, CscsCommonItem *aitem)
{ insertRow(arow, CscsList<CscsCommonItem*>() << aitem); }

inline bool CscsCommonItemModel::insertRow(int arow, const CscsModelIndex &aparent)
{ return CscsAbstractItemModel::insertRow(arow, aparent); }
inline bool CscsCommonItemModel::insertColumn(int acolumn, const CscsModelIndex &aparent)
{ return CscsAbstractItemModel::insertColumn(acolumn, aparent); }

END_NAMESPACE
#endif