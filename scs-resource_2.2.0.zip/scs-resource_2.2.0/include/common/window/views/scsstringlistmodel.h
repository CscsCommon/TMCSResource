#ifndef SCSSTRINGLISTMODEL_H
#define SCSSTRINGLISTMODEL_H
#include <kernel/scsstringlist.h>
#include "scsabstractitemview.h"

BEGIN_NAMESPACE(Gemini)

class  CscsStringListModel : public CscsAbstractListModel
{
public:
    explicit CscsStringListModel(CscsObject *parent = nullptr);
    CscsStringListModel(const CscsStringList &strings, CscsObject *parent = nullptr);

    int rowCount(const CscsModelIndex &parent = CscsModelIndex()) const;

    CscsVariant data(const CscsModelIndex &index, int role) const;
    bool setData(const CscsModelIndex &index, const CscsVariant &value, int role = SCS::EditRole);

    SCS::ItemFlags flags(const CscsModelIndex &index) const;
    
    bool insertRows(int row, int count, const CscsModelIndex &parent = CscsModelIndex());
    bool removeRows(int row, int count, const CscsModelIndex &parent = CscsModelIndex());

    CscsStringList stringList() const;
    void setStringList(const CscsStringList &strings);

private:
    CscsStringList lst;
};

END_NAMESPACE
#endif