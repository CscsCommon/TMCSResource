/*
* Created by J.Wong 2020/01/02
*/
#ifndef SCSPLATFORMSCREEN_H
#define SCSPLATFORMSCREEN_H
#include <kernel/scstypes.h>
#include <list>
#include <atomic>

#include <painting/scsregion.h>
#include <painting/scspoint.h>
#include "scswindowcommand.h"

BEGIN_NAMESPACE(Gemini)

class CscsEventData;
class CscsWriteReadLock;
class CscsWidget;
class CscsImage;

struct CscsWindowInfo{
	int winid;
	uint clientid;
	std::string name;
};

class CscsPlatformScreen{
public:
	CscsPlatformScreen();
	virtual ~CscsPlatformScreen();

	virtual bool eventPending()const;
	virtual CscsEventData* getEvent();

	virtual int width()const;
	virtual int height()const;
	virtual int depth()const;
	virtual int pixmapDepth()const;
	virtual bool supportDepth(int depth)const;

	virtual std::list<CscsWindowInfo> windowList();

	virtual int windowAt(const CscsPoint& pos);

	virtual void setIdentity(const std::string& appName);
	virtual void nameRegion(int winId, const std::string& n, const std::string& cap, CscsWidget* handler=nullptr);
	virtual void requestRegion(int winId, int shmid, bool opaque, CscsRegion r);
	virtual void repaintRegion(int winId, bool opaque, CscsRegion r);
	virtual void setGeometry(int winId, const CscsRect& r);
	virtual void createRegion(int winId, bool opaque, const CscsRect& r, CscsWidget* handler=nullptr);
	virtual void moveRegion(int winId, int dx, int dy);
	virtual void resizeRegion(int winId, const CscsSize& size);
	virtual void repaintRegion(int winId, const CscsRegion& r);
	virtual void destroyRegion(int winId);
	virtual void show(int winId);
	virtual void hide(int winId);

	virtual void requestFocus(int winId, bool get);

	virtual void setWindowCaption(CscsWidget* w, const std::string& c);

	virtual void setAltitude(int winId, int altitude, bool fixed=false);

	virtual void setOpacity(int winId, int opacity);

	virtual int takeId();

	virtual void defineCursor(int id, const CscsImage& curs, const CscsImage& mask, int hotX, int hotY);
	virtual void selectCursor(CscsWidget* w, uint id);
	virtual void setCursorPosition(int x, int y);

	virtual void grabMouse(CscsWidget* w, bool grab);
	static void initLock();
	static bool grabbed(){return false;}
	static void grab();
	static void grab(bool write);
	static void ungrab();

private:
	static CscsWriteReadLock* lock;
};

extern CscsPlatformScreen* scs_screen;
extern int* scs_last_x;
extern int* scs_last_y;

END_NAMESPACE
#endif