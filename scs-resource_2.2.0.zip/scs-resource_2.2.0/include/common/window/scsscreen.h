#ifndef SCSSCREEN_H
#define SCSSCREEN_H
#include <kernel/scstypes.h>
#include <list>
#include <atomic>

#include <painting/scsregion.h>
#include <painting/scspoint.h>
#include "scswindowcommand.h"
#include "scsplatformscreen.h"

BEGIN_NAMESPACE(Gemini)

class CscsMouseEventData;
class CscsObject;


class CscsScreen:public CscsPlatformScreen{
public:
	CscsScreen();
	~CscsScreen();

	bool eventPending()const;
	CscsEventData* getEvent();

	uint8* frameBuffer()const;

	int width()const;
	int height()const;
	int depth()const;
	int pixmapDepth()const;
	bool supportDepth(int depth)const;

	uint8* sharedRam()const;
	int sharedRamSize()const;

	void setIdentity(const std::string& appName);
	void nameRegion(int winId, const std::string& n, const std::string& cap,CscsWidget* handler=nullptr);
	void requestRegion(int winId, int shmid, bool opaque, CscsRegion r);
	void repaintRegion(int winId, bool opaque, CscsRegion r);
	void moveRegion(int winId, int dx, int dy);
	void destroyRegion(int winId);
	void requestFocus(int winId, bool get);
	void repaintRegion(int winId, const CscsRegion& r);

	void setWindowCaption(CscsWidget* w, const std::string& c);

	void setAltitude(int winId, int altitude, bool fixed=false);

	void setOpacity(int winId, int opacity);

	int takeId();

	void defineCursor(int id, const CscsImage& curs, const CscsImage& mask, int hotX, int hotY);
	void selectCursor(CscsWidget* w, uint id);
	void setCursorPosition(int x, int y);
	void grabMouse(CscsWidget* w, bool grab);

private:
	class Data;
	Data* d;
};

class CscsScreen::Data{
public:
	Data(CscsObject* parent);
	~Data();

	void flush();

	bool queueNotEmpty();
	CscsEventData* dequeue();
	CscsEventData* peek();

	bool directServerConnection(){
		return true;
	}

	void fillQueue();
	void waitForConnection();
	void waitForCreation();

	void init();

	void create();

	void sendCommand(CscsWindowCommand& );

	CscsEventData* readMore();

	int takeId();





	uint8* sharedRam;
	int sharedRamSize;
	int ramid;


private:
	std::list<CscsEventData*> queue;
	CscsMouseEventData* mouse_event;

	CscsPoint region_offset;
	int region_offset_window;
	int mouse_event_count;
	CscsEventData* currentEvent;
	std::list<int> unused_identifiers;

	friend class CscsScreen;
};

extern bool servermaxrect;

END_NAMESPACE

#endif