#ifndef SCSTEXTLAYOUT_H
#define SCSTEXTLAYOUT_H

//#include "scstextengine_p.h"
#include <kernel/scsnocopy.hpp>
#include <painting/scsrect.h>
#include <window/scsenum.h>
#include <kernel/scsvector.h>

BEGIN_NAMESPACE(Gemini)

class CscsTextEngine;
class CscsTextOption;
class CscsTextLine;
class CscsFont;
class CscsPainter;
class CscsTextFormat;
class CscsTextBlock;

class  CscsTextInlineObject
{
public:
    CscsTextInlineObject(int i, CscsTextEngine *e) : itm(i), eng(e) {}
    inline CscsTextInlineObject() : itm(0), eng(0) {}
    inline bool isValid() const { return eng; }

    CscsRectF rect() const;
    double width() const;
    double ascent() const;
    double descent() const;
    double height() const;

    SCS::LayoutDirection textDirection() const;

    void setWidth(double w);
    void setAscent(double a);
    void setDescent(double d);

    int textPosition() const;

    int formatIndex() const;
    CscsTextFormat format() const;

private:
    friend class CscsTextLayout;
    int itm;
    CscsTextEngine *eng;
};

class CscsTextLayout:public CscsNoCopyable{
public:
	CscsTextLayout();
	CscsTextLayout(const CscsString& text);
	CscsTextLayout(const CscsString& text, const CscsFont& font);
	CscsTextLayout(const CscsTextBlock &b);
	~CscsTextLayout();
	
	void setFont(const CscsFont& f);
	CscsFont font()const;
	
	void setText(const CscsString& text);
	CscsString text()const;

	void setTextOption(const CscsTextOption& option);
	CscsTextOption textOption()const;

	CscsPointF position()const;
	void setPosition(const CscsPointF& p);

	CscsRectF boundingRect()const;
	double minimumWidth() const;
    double maximumWidth() const;

	void beginLayout();
	void endLayout();
	void clearLayout();

	CscsTextLine createLine();

	int lineCount()const;
	CscsTextLine lineAt(int i)const;
	CscsTextLine lineForTextPosition(int pos)const;
	struct FormatRange {
        int start;
        int length;
        //CscsTextCharFormat format;
    };

    void setCacheEnabled(bool enable);
    bool cacheEnabled() const;
    
    enum CursorMode {
        SkipCharacters,
        SkipWords
    };

    bool isValidCursorPosition(int pos) const;
    int nextCursorPosition(int oldPos, CursorMode mode = SkipCharacters) const;
    int previousCursorPosition(int oldPos, CursorMode mode = SkipCharacters) const;
   	void drawCursor(CscsPainter *p, const CscsPointF &pos, int cursorPosition) const;
   	void drawCursor(CscsPainter *p, const CscsPointF &pos, int cursorPosition, int width) const;

    void draw(CscsPainter *p, const CscsPointF &pos, const CscsVector<FormatRange> &selections = CscsVector<FormatRange>(),
         const CscsRectF &clip = CscsRectF()) const;

	CscsTextEngine* engine()const{
		return d;
	}

private:
	CscsTextLayout(CscsTextEngine* e):d(e){}
	CscsTextEngine* d;

};


class CscsTextLine{
public:
	inline CscsTextLine():i(0),eng(0){}
	inline bool isValid()const{ return eng;}

	CscsRectF rect()const;
	double x()const;
	double y()const;
	double width()const;
	double ascent()const;
	double descent()const;
	double height()const;
	double naturalTextWidth()const;
	CscsRectF naturalTextRect()const;


	enum Edge{
		Leading,
		Trailing
	};

	enum CursorPosition{
		CursorBetweenCharacters,
		CursorOnCharacter
	};

	double cursorToX(int *cursorPos, Edge edge = Leading) const;
    inline double cursorToX(int cursorPos, Edge edge = Leading) const { return cursorToX(&cursorPos, edge); }
    int xToCursor(double x, CursorPosition = CursorBetweenCharacters) const;

	void setLineWidth(double width);
	void setNumColumns(int columns);
	void setNumColumns(int columns, double alignmentWidth);
	void setPosition(const CscsPointF &pos);
	CscsPointF position()const;
	int textStart()const;
	int textLength()const;
	int lineNumber()const{
		return i;
	}

	void draw(CscsPainter *p, const CscsPointF &point, const CscsTextLayout::FormatRange *selection = 0) const;

private:
	CscsTextLine(int line, CscsTextEngine* e):i(line),eng(e){}
	void layout_helper(int nums);
	friend class CscsTextLayout;
	int i;
	CscsTextEngine* eng;
};

END_NAMESPACE
#endif