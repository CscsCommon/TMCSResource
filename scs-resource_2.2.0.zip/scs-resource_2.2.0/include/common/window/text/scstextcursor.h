#ifndef SCSTEXTCURSOR_H
#define SCSTEXTCURSOR_H

#include <kernel/scsstring.h>
#include <kernel/scsshareddata.h>
#include "scstextformat.h"

BEGIN_NAMESPACE(Gemini)

class CscsTextDocument;
class CscsTextCursorPrivate;
class CscsTextDocumentFragment;
class CscsTextCharFormat;
class CscsTextBlockFormat;
class CscsTextListFormat;
class CscsTextTableFormat;
class CscsTextFrameFormat;
class CscsTextImageFormat;
class CscsTextDocumentPrivate;
class CscsTextList;
class CscsTextTable;
class CscsTextFrame;
class CscsTextBlock;

class  CscsTextCursor
{
public:
    CscsTextCursor();
    explicit CscsTextCursor(CscsTextDocument *document);
    CscsTextCursor(CscsTextDocumentPrivate *p, int pos);
    explicit CscsTextCursor(CscsTextFrame *frame);
    explicit CscsTextCursor(const CscsTextBlock &block);
    explicit CscsTextCursor(CscsTextCursorPrivate *d);
    CscsTextCursor(const CscsTextCursor &cursor);
    CscsTextCursor &operator=(const CscsTextCursor &other);
    ~CscsTextCursor();

    bool isNull() const;

    enum MoveMode {
        MoveAnchor,
        KeepAnchor
    };

    void setPosition(int pos, MoveMode mode = MoveAnchor);
    int position() const;

    int anchor() const;

    void insertText(const CscsString &text);
    void insertText(const CscsString &text, const CscsTextCharFormat &format);

    enum MoveOperation {
        NoMove,

        Start,
        Up,
        StartOfLine,
        StartOfBlock,
        StartOfWord,
        PreviousBlock,
        PreviousCharacter,
        PreviousWord,
        Left,
        WordLeft,

        End,
        Down,
        EndOfLine,
        EndOfWord,
        EndOfBlock,
        NextBlock,
        NextCharacter,
        NextWord,
        Right,
        WordRight
    };

    bool movePosition(MoveOperation op, MoveMode = MoveAnchor, int n = 1);

    bool visualNavigation() const;
    void setVisualNavigation(bool b);

    void deleteChar();
    void deletePreviousChar();

    enum SelectionType {
        WordUnderCursor,
        LineUnderCursor,
        BlockUnderCursor,
        Document
    };
    void select(SelectionType selection);

    bool hasSelection() const;
    bool hasComplexSelection() const;
    void removeSelectedText();
    void clearSelection();
    int selectionStart() const;
    int selectionEnd() const;

    CscsString selectedText() const;
    CscsTextDocumentFragment selection() const;
    void selectedTableCells(int *firstRow, int *numRows, int *firstColumn, int *numColumns) const;

    CscsTextBlock block() const;

    CscsTextCharFormat charFormat() const;
    void setCharFormat(const CscsTextCharFormat &format);
    void mergeCharFormat(const CscsTextCharFormat &modifier);

    CscsTextBlockFormat blockFormat() const;
    void setBlockFormat(const CscsTextBlockFormat &format);
    void mergeBlockFormat(const CscsTextBlockFormat &modifier);

    CscsTextCharFormat blockCharFormat() const;
    void setBlockCharFormat(const CscsTextCharFormat &format);
    void mergeBlockCharFormat(const CscsTextCharFormat &modifier);

    bool atBlockStart() const;
    bool atBlockEnd() const;
    bool atStart() const;
    bool atEnd() const;

    void insertBlock();
    void insertBlock(const CscsTextBlockFormat &format);
    void insertBlock(const CscsTextBlockFormat &format, const CscsTextCharFormat &charFormat);

    CscsTextList *insertList(const CscsTextListFormat &format);
    CscsTextList *insertList(CscsTextListFormat::Style style);

    CscsTextList *createList(const CscsTextListFormat &format);
    CscsTextList *createList(CscsTextListFormat::Style style);
    CscsTextList *currentList() const;

    CscsTextTable *insertTable(int rows, int cols, const CscsTextTableFormat &format);
    CscsTextTable *insertTable(int rows, int cols);
    CscsTextTable *currentTable() const;

    CscsTextFrame *insertFrame(const CscsTextFrameFormat &format);
    CscsTextFrame *currentFrame() const;

    void insertFragment(const CscsTextDocumentFragment &fragment);

    void insertImage(const CscsTextImageFormat &format, CscsTextFrameFormat::Position alignment);
    void insertImage(const CscsTextImageFormat &format);
    void insertImage(const CscsString &name);

    void beginEditBlock();
    void joinPreviousEditBlock();
    void endEditBlock();

    bool operator!=(const CscsTextCursor &rhs) const;
    bool operator<(const CscsTextCursor &rhs) const;
    bool operator<=(const CscsTextCursor &rhs) const;
    bool operator==(const CscsTextCursor &rhs) const;
    bool operator>=(const CscsTextCursor &rhs) const;
    bool operator>(const CscsTextCursor &rhs) const;

    bool isCopyOf(const CscsTextCursor &other) const;

    int blockNumber() const;
    int columnNumber() const;

private:
    CscsSharedDataPointer<CscsTextCursorPrivate> d;
    friend class CscsTextDocumentFragmentPrivate;
    friend class CscsTextCopyHelper;
};
END_NAMESPACE
#endif