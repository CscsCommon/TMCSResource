#ifndef SCSTEXTDOCUMENTFRAGMENT_H
#define SCSTEXTDOCUMENTFRAGMENT_H
#include <kernel/scsstring.h>


BEGIN_NAMESPACE(Gemini)


class CscsTextDocument;
class CscsTextDocumentFragmentPrivate;
class CscsTextCursor;

class  CscsTextDocumentFragment
{
public:
    CscsTextDocumentFragment();
    explicit CscsTextDocumentFragment(const CscsTextDocument *document);
    explicit CscsTextDocumentFragment(const CscsTextCursor &range);
    CscsTextDocumentFragment(const CscsTextDocumentFragment &rhs);
    CscsTextDocumentFragment &operator=(const CscsTextDocumentFragment &rhs);
    ~CscsTextDocumentFragment();

    bool isEmpty() const;

    CscsString toPlainText() const;
    static CscsTextDocumentFragment fromPlainText(const CscsString &plainText);

private:
    CscsTextDocumentFragmentPrivate *d;
    friend class CscsTextCursor;
};

END_NAMESPACE

#endif