#ifndef SCSAPPLICATION_H
#define SCSAPPLICATION_H
#include <kernel/scsapplicationplus.h>
#include "scswindowdefs.h"
#include "styles/scspalette.h"
#include "widgets/scscursor.h"
#include "scswindowevent.h"

BEGIN_NAMESPACE(Gemini)

class CscsEventData;

class CscsApplicationPrivate;
class CscsApplication;
class CscsWidget;
class CscsPoint;
class CscsBaseStyle;
class CscsDesktopWidget;
class CscsFont;
class CscsTranslator;

#define scsApp (static_cast<CscsApplication*>(CscsApplicationPlus::instance()))

class CscsApplication:public CscsApplicationPlus{

public:
	CscsApplication(int argc=0, char** argv=nullptr);
	virtual ~CscsApplication();

	static int exec();
	bool notify(CscsObject* r, CscsEvent* e);

	int processEventData(CscsEventData* e);

	CscsApplicationPrivate* d_func()const;
	static CscsSize applicationWindowSize();
	static void setApplicationWindowSize(const CscsSize& size);
	static CscsSize globalStrut();
	static void   setGlobalStrut(const CscsSize& strut);
	static CscsWidget* 	focusWidget();
	static const CscsWidgetVector& allWidgets();
	static const CscsWidgetVector& topLevelWidgets();
	static CscsWidget* activeWindow();
	static void setActiveWindow(CscsWidget* active);
	static CscsWidget* widgetAt(const CscsPoint& p);
	static CscsWidget* widgetAt(int x, int y){
		return widgetAt(CscsPoint(x,y));
	}
	static CscsWidget* topLevelAt(const CscsPoint& p);
	static CscsWidget* topLevelAt(int x, int y){
		return topLevelAt(CscsPoint(x,y));
	}
	

	static void installTranslator(CscsTranslator* translator);
	static CscsTranslator* translator();
	static void setCurrentLanguage(const std::string& lanKey);


	static CscsDesktopWidget *desktop();
	static CscsWidget* activePopupWidget();
	static CscsWidget* activeModalWidget();

	static const CscsPalette& palette();
	static const CscsPalette& palette(const CscsWidget* w);
	static const CscsPalette& palette(const char* classname);
	static void setPalette(const CscsPalette& pal, const char* classname=0);
	static CscsBaseStyle* style();
	static void setStyle(const CscsBaseStyle* style);


	static const CscsFont& font(const CscsWidget* w=0);
	static void setFont(const CscsFont& f, const char* classname=0);

	static int doubleClickInterval();
	static void setDoubleClickInterval(int ms);
	static SCS::MouseButtons mouseButtons();
	static SCS::KeyboardModifiers keyboardModifiers();

	static void setCursorTwinkingTime(int ms);
	static int 	cursorTwinkingTime();
	static CscsCursor* overrideCursor();
	static void setOverrideCursor(const CscsCursor& curs);
	static void changeOverrideCursor(const CscsCursor& curs);
	static void restoreOverrideCursor();

	
	static void setLayoutDirection(SCS::LayoutDirection dir);
	static  SCS::LayoutDirection layoutDirection();
	static inline bool isRightToLeft(){return layoutDirection()==(SCS::RightToLeft);}
	static inline bool isLeftToRight(){return layoutDirection()==(SCS::LeftToRight);}

	static void startUpVncServer();
	static void shutDownVncServer();

	static void enableKeyNavigation();
	static void disableKeyNavigation();
	static bool keyNavigation();

	std::string styleSheet()const;
	void setStyleSheet(const std::string& sheet);
//slot
public:
	static void closeAllWindows();

protected:
	bool event(CscsEvent* e);

	bool mergeEvent(CscsEvent* e, CscsObject* r, CscsPostEventList* pl);


};

//字串翻译
std::string tr(const std::string& key);

END_NAMESPACE

#endif