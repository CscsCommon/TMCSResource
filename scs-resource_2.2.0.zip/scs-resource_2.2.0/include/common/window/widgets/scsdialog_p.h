#ifndef SCSDIALOGPRIV_H
#define SCSDIALOGPRIV_H

#include "../scswidget_p.h"
#include "scsdialog.h"

BEGIN_NAMESPACE(Gemini)

class CscsEventLoop;
class CscsPushButton;

class CscsDialogPrivate : public CscsWidgetPrivate
{
public:

    CscsDialogPrivate()
        : mainDef(0), orientation(SCS::Horizontal),extension(0), doShowExtension(false),
          rescode(0), eventLoop(0)
        {}

    CscsDialog* mm_func()const{
    	return reinterpret_cast<CscsDialog*>(mm);
    }

    CscsPushButton* mainDef;
    SCS::Orientation orientation;
    CscsWidget* extension;
    bool doShowExtension;
    CscsSize size, min, max;

    CscsPoint lastRMBPress;

    void        setDefault(CscsPushButton* );
    void        setMainDefault(CscsPushButton* );
    void        hideDefault();

    int rescode;

    CscsEventLoop* eventLoop;
};

END_NAMESPACE

#endif