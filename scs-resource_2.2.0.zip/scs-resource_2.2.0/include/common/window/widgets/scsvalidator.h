#ifndef SCSVALIDATOR_H
#define SCSVALIDATOR_H
#include <kernel/scsobject.h>
#include <kernel/scsregexp.h>
#include <string>

BEGIN_NAMESPACE(Gemini)

class  CscsValidator : public CscsObject
{

public:
    explicit CscsValidator(CscsObject * parent);
    ~CscsValidator();

    enum State {
        Invalid,
        Intermediate,
        Acceptable
    };

    virtual State validate(std::string&, int &) const = 0;
    virtual void fixup(std::string& ) const;

};

class  CscsIntValidator : public CscsValidator
{
public:
    explicit CscsIntValidator(CscsObject * parent);
    CscsIntValidator(int bottom, int top, CscsObject * parent);
    ~CscsIntValidator();

    CscsValidator::State validate(std::string&, int& ) const;

    void setBottom(int);
    void setTop(int);
    virtual void setRange(int bottom, int top);

    int bottom() const { return b; }
    int top() const { return t; }


private:
    int b;
    int t;
};

class CscsDoubleValidator:public CscsValidator
{
public:
     enum Notation {
        StandardNotation,
        ScientificNotation
    };
    explicit CscsDoubleValidator(CscsObject * parent);
    CscsDoubleValidator(double bottom, double top, int decimals, CscsObject * parent);
    ~CscsDoubleValidator();

    CscsValidator::State validate(std::string&, int &) const;

    virtual void setRange(double bottom, double top, int decimals = 0);
    void setBottom(double);
    void setTop(double);
    void setDecimals(int);
    void setNotation(Notation);
    Notation notation() const;

    double bottom() const { return b; }
    double top() const { return t; }
    int decimals() const { return d; }

private:
    double b;
    double t;
    int d;
    CscsDoubleValidator::Notation n;
};


class CscsRegExpValidator : public CscsValidator
{
public:
    explicit CscsRegExpValidator(CscsObject *parent);
    CscsRegExpValidator(const CscsRegExp& rx, CscsObject *parent);
    ~CscsRegExpValidator();

    virtual CscsValidator::State validate(std::string& input, int& pos) const;

    void setRegExp(const CscsRegExp& rx);
    const CscsRegExp& regExp() const { return r; }


private:
    CscsRegExp r;
};

END_NAMESPACE

#endif