#ifndef SCSLAYOUT_H
#define SCSLAYOUT_H
#include "scslayoutitem.h"
#include "scssizepolicy.h"
#include <kernel/scsobject.h>
#include <painting/scsrect.h>

BEGIN_NAMESPACE(Gemini)

class CscsLayoutPrivate;

class CscsLayout : public CscsObject, public CscsLayoutItem
{


public:
    enum SizeConstraint {
        SetDefaultConstraint,
        SetNoConstraint,
        SetMinimumSize,
        SetFixedSize,
        SetMaximumSize,
        SetMinAndMaxSize
    };

    CscsLayout(CscsWidget *parent);
    CscsLayout();
    ~CscsLayout();

    CscsLayoutPrivate* d_func()const;

    int margin() const;
    int spacing() const;

    void setMargin(int);
    void setSpacing(int);

    bool setAlignment(CscsWidget *w, SCS::Alignment alignment);
    bool setAlignment(CscsLayout *l, SCS::Alignment alignment);

    using CscsLayoutItem::setAlignment;

    void setSizeConstraint(SizeConstraint);
    SizeConstraint sizeConstraint() const;
    void setMenuBar(CscsWidget *w);
    CscsWidget *menuBar() const;

    CscsWidget *parentWidget() const;

    void invalidate();
    CscsRect geometry() const;
    bool activate();
    void update();

    void addWidget(CscsWidget *w);
    virtual void addItem(CscsLayoutItem *) = 0;

    void removeWidget(CscsWidget *w);
    void removeItem(CscsLayoutItem *);

    SCS::Orientations expandingDirections() const;
    CscsSize minimumSize() const;
    CscsSize maximumSize() const;
    void setGeometry(const CscsRect&) = 0;
    virtual CscsLayoutItem *itemAt(int index) const = 0;
    virtual CscsLayoutItem *takeAt(int index) = 0;
    virtual int indexOf(CscsWidget *) const;
    virtual int count() const = 0;
    bool isEmpty() const;

    int totalHeightForWidth(int w) const;
    CscsSize totalMinimumSize() const;
    CscsSize totalMaximumSize() const;
    CscsSize totalSizeHint() const;
    CscsLayout *layout();

    void setEnabled(bool);
    bool isEnabled() const;


    static CscsSize closestAcceptableSize(const CscsWidget *w, const CscsSize &s);

protected:
    void widgetEvent(CscsEvent *);
    void childEvent(CscsChildEvent *e);
    void addChildLayout(CscsLayout *l);
    void addChildWidget(CscsWidget *w);

    CscsRect alignmentRect(const CscsRect&) const;
protected:
    CscsLayout(CscsLayoutPrivate* d, CscsLayout*, CscsWidget*);

private:

    static void activateRecursiveHelper(CscsLayoutItem *item);
    friend class CscsApplicationPrivate;
    friend class CscsWidget;


};

END_NAMESPACE

#endif

