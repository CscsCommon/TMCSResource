#ifndef SCSDIALOG_H
#define SCSDIALOG_H
#include "../scswidget.h"

BEGIN_NAMESPACE(Gemini)

class CscsPushButton;
class CscsDialogPrivate;

class  CscsDialog : public CscsWidget
{
    
    CONTAINER_WIDGET

    friend class CscsPushButton;
public:
    explicit CscsDialog(CscsWidget *parent = 0, SCS::WindowFlags f = 0);
    ~CscsDialog();

    enum DialogCode { Rejected, Accepted };

    int result() const;

    void setVisible(bool visible);

    void setOrientation(SCS::Orientation orientation);
    SCS::Orientation orientation() const;

    void setExtension(CscsWidget* extension);
    CscsWidget* extension() const;

    CscsSize sizeHint() const;
    CscsSize minimumSizeHint() const;


    void setModal(bool modal);


    void setResult(int r);

SLOTS:
    int exec();
    virtual void done(int);
    virtual void accept();
    virtual void reject();

    void showExtension(bool);

protected:
    CscsDialog(CscsDialogPrivate*, CscsWidget *parent, SCS::WindowFlags f = 0);
    void keyPressEvent(CscsKeyEvent *);
    void closeEvent(CscsCloseEvent *);
    void showEvent(CscsShowEvent *);
    void resizeEvent(CscsResizeEvent *);
    bool eventFilter(CscsObject *, CscsEvent *);
    void adjustPosition(CscsWidget*);
private:
	CscsDialogPrivate* d_func()const;

BEGIN_PROPERTY(CscsDialog,CscsWidget)
    META_PROPERTY(bool, modal, READ, isModal, WRITE, setModal)
END_PROPERTY

};

END_NAMESPACE

#endif