#ifndef SCSSPLASHSCREEN_H
#define SCSSPLASHSCREEN_H
#include <painting/scsimage.h>
#include "../scswidget.h"

BEGIN_NAMESPACE(Gemini)
class CscsSplashScreenPrivate;
class CscsPainter;

class CscsSplashScreen:public CscsWidget{
public:
	explicit CscsSplashScreen(const CscsImage& image=CscsImage(),SCS::WindowFlags f=0);
	CscsSplashScreen(CscsWidget* parent, const CscsImage& image=CscsImage(),SCS::WindowFlags f=0);
	virtual ~CscsSplashScreen();

	void setImage(const CscsImage& image);
	const CscsImage image()const;

	void finish(CscsWidget* w);
	void repaint();

SLOTS:
	void showMessage(const std::string& message, int alignment=SCS::AlignLeft,const CscsRgba& color=Gemini::Black);
	void clearMessage();

SIGNALS:
	void messageChanged(const std::string& message);

protected:
	bool event(CscsEvent* e);
	virtual void drawContents(CscsPainter* painter);
	void mousePressEvent(CscsMouseEvent* e);

	CscsSplashScreenPrivate* d_func()const;
	friend class CscsSplashScreenPrivate;
};

END_NAMESPACE
#endif