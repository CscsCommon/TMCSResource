#ifndef SCSFOCUSFRAME_H
#define SCSFOCUSFRAME_H
#include "../scswidget.h"

BEGIN_NAMESPACE(Gemini)

class CscsFocusFramePrivate;
class CscsFocusFrame:public CscsWidget{
	public:
		CscsFocusFrame(CscsWidget* parent=0);
		~CscsFocusFrame();
		void setWidget(CscsWidget* widget);
		CscsWidget* widget()const;

		CscsFocusFramePrivate* d_func()const;
	protected:
		void paintEvent(CscsPaintEvent* e);

};

END_NAMESPACE

#endif