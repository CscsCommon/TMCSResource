#ifndef SCSABSTRACTBUTTONPRIV_H
#define SCSABSTRACTBUTTONPRIV_H
#include "../scswidget_p.h"
#include "scsicon.h"
#include <kernel/scsbasictimer.h>
#include <kernel/scslist.h>
#include <kernel/scsstring.h>

BEGIN_NAMESPACE(Gemini)

class CscsButtonGroup;
class CscsAbstractButton;

class CscsAbstractButtonPrivate : public CscsWidgetPrivate
{
public:
    CscsAbstractButtonPrivate();
    CscsAbstractButton* mm_func()const;
    std::string text;
    CscsIcon icon;
    CscsSize iconSize;
    uint checkable :1;
    uint checked :1;
	uint pressed :1;
    uint autoRepeat :1;
    uint autoExclusive :1;
    uint down :1;
    uint blockRefresh :1;

   
    CscsButtonGroup* group;
    CscsBasicTimer repeatTimer;
    CscsBasicTimer animateTimer;

	int autoRepeatDelay, autoRepeatInterval;

	mutable CscsSize sizeHint;

	void init();
	void click();
	void refresh();

    CscsList<CscsAbstractButton *>queryButtonList() const;
    CscsAbstractButton *queryCheckedButton() const;
    void notifyChecked();
    void moveFocus(int key);
    void fixFocusPolicy();
   void transmitPressed();
	void transmitReleased();
	void transmitClicked();
	void transmitToggled(bool checked);
};

END_NAMESPACE

#endif