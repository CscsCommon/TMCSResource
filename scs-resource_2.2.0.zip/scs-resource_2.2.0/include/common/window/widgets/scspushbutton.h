#ifndef SCSPUSHBUTTON_H
#define SCSPUSHBUTTON_H
#include "../../painting/scssize.h"
#include "scsabstractbutton.h"

BEGIN_NAMESPACE(Gemini)

class CscsPushButtonPrivate;
class CscsStyleOptionButton;

class WIDGET_EXPORT CscsPushButton:public CscsAbstractButton
{

public:
	explicit CscsPushButton(CscsWidget *parent = 0);
	explicit CscsPushButton(const std::string &text, CscsWidget *parent = 0);
	explicit CscsPushButton(const CscsIcon& icon, const std::string &text, CscsWidget *parent = nullptr);
	~CscsPushButton();

	CscsSize sizeHint() const override;
	CscsSize minimumSizeHint() const override;

	bool autoDefault() const;
	void setAutoDefault(bool);
	bool isDefault();
	void setDefault(bool);

	void setFlat(bool);
	bool isFlat() const;
	void initStyleOption(CscsStyleOptionButton *option) const;

	CscsPushButtonPrivate* d_func() const;

protected:
	bool event(CscsEvent *e) override;
	void paintEvent(CscsPaintEvent *) override;
	void keyPressEvent(CscsKeyEvent *) override;
	void focusInEvent(CscsFocusEvent *) override;
	void focusOutEvent(CscsFocusEvent *) override;
	CscsPushButton(CscsPushButtonPrivate *dd, CscsWidget *parent = nullptr);

BEGIN_PROPERTY(CscsPushButton,CscsAbstractButton)
	META_PROPERTY(bool, autoDefault, READ, autoDefault, WRITE, setAutoDefault)
    META_PROPERTY(bool, default, READ, isDefault, WRITE, setDefault)
    META_PROPERTY(bool, flat, READ, isFlat, WRITE, setFlat)
END_PROPERTY

};

END_NAMESPACE

#endif
