#ifndef SCSRUBBERBAND_H
#define SCSRUBBERBAND_H
#include "../scswidget.h"

BEGIN_NAMESPACE(Gemini)

class CscsRubberBandPrivate;

class  CscsRubberBand : public CscsWidget
{
public:
    enum Shape { Line, Rectangle };
    explicit CscsRubberBand(Shape, CscsWidget * =0);
    ~CscsRubberBand();

    Shape shape() const;

    void setGeometry(const CscsRect &r);

    inline void setGeometry(int x, int y, int w, int h);
    inline void move(int x, int y);
    inline void move(const CscsPoint &p)
    { move(p.x(), p.y()); }
    inline void resize(int w, int h)
    { setGeometry(geometry().x(), geometry().y(), w, h); }
    inline void resize(const CscsSize &s)
    { resize(s.width(), s.height()); }


protected:

    void paintEvent(CscsPaintEvent *);
    void changeEvent(CscsEvent *);

private:
    CscsRubberBandPrivate* d_func()const;
};

inline void CscsRubberBand::setGeometry(int ax, int ay, int aw, int ah)
{ setGeometry(CscsRect(ax, ay, aw, ah)); }
inline void CscsRubberBand::move(int ax, int ay)
{ setGeometry(ax + geometry().x() - CscsWidget::x(),
              ay - geometry().y() - CscsWidget::y(),
              width(), height()); }

END_NAMESPACE

#endif