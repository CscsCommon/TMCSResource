#ifndef SCSCOMBOBOX_H
#define SCSCOMBOBOX_H
#include "../scswidget.h"
#include "../scsenum.h"
#include <kernel/scsvariant.h>
#include "scsicon.h"

BEGIN_NAMESPACE(Gemini)

class CscsAbstractItemView;
class CscsLineEdit;
class CscsComboBoxPrivate;
class CscsValidator;
class CscsAbstractItemDelegate;
class CscsAbstractItemModel;
class CscsModelIndex;
class CscsStyleOptionComboBox;

class WIDGET_EXPORT CscsComboBox:public CscsWidget{

public:
	explicit CscsComboBox(CscsWidget* parent=nullptr);
	~CscsComboBox();

	int maxVisibleItems()const;
	void setMaxVisibleItems(int maxItems);

	int count()const;
	void setMaxCount(int max);
	int maxCount()const;

	bool duplicatesEnabled()const;
	void setDuplicatesEnabled(bool enable);

	void setFrame(bool);
	bool hasFrame()const;

	inline int findText(const std::string& text,SCS::MatchFlags flags=static_cast<SCS::MatchFlags>(SCS::MatchExactly|SCS::MatchCaseSensitive))const{
		return findData(text, SCS::DisplayRole,flags);
	}

	int findData(const CscsVariant& data, int role=SCS::UserRole,SCS::MatchFlags flags=
		static_cast<SCS::MatchFlags>(SCS::MatchExactly|SCS::MatchCaseSensitive))const;

	enum InsertPolicy {
        NoInsert,
        InsertAtTop,
        InsertAtCurrent,
        InsertAtBottom,
        InsertAfterCurrent,
        InsertBeforeCurrent,
        InsertAlphabetically
    };

    InsertPolicy insertPolicy() const;
    void setInsertPolicy(InsertPolicy policy);

    enum SizeAdjustPolicy {
        AdjustToContents,
        AdjustToContentsOnFirstShow,
        AdjustToMinimumContentsLength,
        AdjustToMinimumContentsLengthWithIcon
    };

    SizeAdjustPolicy sizeAdjustPolicy() const;
    void setSizeAdjustPolicy(SizeAdjustPolicy policy);
    int minimumContentsLength() const;
    void setMinimumContentsLength(int characters);

    CscsSize iconSize() const;
    void setIconSize(const CscsSize &size);
    bool isEditable() const;
    void setEditable(bool editable);
    void setLineEdit(CscsLineEdit *edit);
    CscsLineEdit *lineEdit() const;
	void setValidator(const CscsValidator *v);
    const CscsValidator *validator() const;

    CscsAbstractItemDelegate *itemDelegate() const;
    void setItemDelegate(CscsAbstractItemDelegate *delegate);

    CscsAbstractItemModel *model() const;
    void setModel(CscsAbstractItemModel *model);

    CscsModelIndex rootModelIndex() const;
    void setRootModelIndex(const CscsModelIndex &index);

    int modelColumn() const;
    void setModelColumn(int visibleColumn);

    int currentIndex() const;
    std::string currentText() const;
   // CscsVariant currentData(int role = SCS::UserRole) const;

    std::string itemText(int index) const;
    CscsIcon itemIcon(int index) const;
    CscsVariant itemData(int index, int role = SCS::UserRole) const;

    inline void addItem(const std::string &text, const CscsVariant &userData = CscsVariant());
    inline void addItem(const CscsIcon &icon, const std::string &text,
                        const CscsVariant &userData = CscsVariant());
    inline void addItems(const CscsStringList &texts)
        { insertItems(count(), texts); }

    inline void insertItem(int index, const std::string &text, const CscsVariant &userData = CscsVariant());
    void insertItem(int index, const CscsIcon &icon, const std::string &text,
                    const CscsVariant &userData = CscsVariant());
    void insertItems(int index, const CscsStringList &texts);
    void insertSeparator(int index);

    void removeItem(int index);

    void setItemText(int index, const std::string &text);
    void setItemIcon(int index, const CscsIcon &icon);
    void setItemData(int index, const CscsVariant &value, int role = SCS::UserRole);

    CscsAbstractItemView *view() const;
    void setView(CscsAbstractItemView *itemView);

    CscsSize sizeHint() const ;
    CscsSize minimumSizeHint() const ;
    bool    popup()const;
    virtual void showPopup();
    virtual void hidePopup();

    bool event(CscsEvent *event);

SLOTS:
    void clear();
    void clearEditText();
    void setEditText(const std::string &text);
    void setCurrentIndex(int index);
    //void setCurrentText(const std::string &text);

SIGNALS:
    void editTextChanged(const std::string &){}
    void activated(int index){}
    void activated(const std::string &){}
    void highlighted(int){}
    void highlighted(const std::string &){}
    void currentIndexChanged(int){}
    void currentIndexChanged(const std::string &){}
    void currentTextChanged(const std::string &){}

protected:
    void focusInEvent(CscsFocusEvent *e) ;
    void focusOutEvent(CscsFocusEvent *e) ;
    void changeEvent(CscsEvent *e) ;
    void resizeEvent(CscsResizeEvent *e) ;
    void paintEvent(CscsPaintEvent *e) ;
    void showEvent(CscsShowEvent *e) ;
    void hideEvent(CscsHideEvent *e) ;
    void mousePressEvent(CscsMouseEvent *e) ;
    void mouseReleaseEvent(CscsMouseEvent *e) ;
    void keyPressEvent(CscsKeyEvent *e) ;
    void keyReleaseEvent(CscsKeyEvent *e) ;
    void initStyleOption(CscsStyleOptionComboBox *option) const;


protected:
    CscsComboBox(CscsComboBoxPrivate &, CscsWidget *);
private:
	CscsComboBoxPrivate* d_func()const;
    friend class CscsComboBoxPrivate;
    
BEGIN_PROPERTY(CscsComboBox,CscsWidget)
    META_PROPERTY(bool, editable, READ, isEditable, WRITE, setEditable)
    META_READ_PROPERTY(int, count, READ, count)
    META_READ_PROPERTY(std::string, currentText, READ, currentText)
    //META_PROPERTY(std::string, currentText, READ, currentText, WRITE, setCurrentText)
    META_PROPERTY(int, currentIndex, READ, currentIndex, WRITE, setCurrentIndex)
    //META_READ_PROPERTY(CscsVariant, currentData, READ, currentData)
    META_PROPERTY(int, maxVisibleItems, READ, maxVisibleItems, WRITE, setMaxVisibleItems)
    META_PROPERTY(int, maxCount, READ, maxCount, WRITE, setMaxCount)
    META_PROPERTY(InsertPolicy, insertPolicy, READ, insertPolicy, WRITE, setInsertPolicy)
    META_PROPERTY(SizeAdjustPolicy, sizeAdjustPolicy, READ, sizeAdjustPolicy, WRITE, setSizeAdjustPolicy)
    META_PROPERTY(int, minimumContentsLength, READ, minimumContentsLength, WRITE, setMinimumContentsLength)
    META_PROPERTY(CscsSize, iconSize, READ, iconSize, WRITE, setIconSize)
    META_PROPERTY(bool, duplicatesEnabled, READ, duplicatesEnabled, WRITE, setDuplicatesEnabled)
    META_PROPERTY(bool, frame, READ, hasFrame, WRITE, setFrame)
    META_PROPERTY(int, modelColumn, READ, modelColumn, WRITE, setModelColumn)
END_PROPERTY

};


inline void CscsComboBox::addItem(const std::string &atext, const CscsVariant &auserData)
{ insertItem(count(), atext, auserData); }
inline void CscsComboBox::addItem(const CscsIcon &aicon, const std::string &atext,
                               const CscsVariant &auserData)
{ insertItem(count(), aicon, atext, auserData); }

inline void CscsComboBox::insertItem(int aindex, const std::string &atext,
                                  const CscsVariant &auserData)
{ insertItem(aindex, CscsIcon(), atext, auserData); }

END_NAMESPACE
#endif