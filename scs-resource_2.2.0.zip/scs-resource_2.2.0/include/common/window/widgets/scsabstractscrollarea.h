#ifndef SCSABSTRACTSCROLLAREA_H
#define SCSABSTRACTSCROLLAREA_H
#include <window/widgets/scsframe.h>

BEGIN_NAMESPACE(Gemini)

class CscsScrollBar;
class CscsAbstractScrollAreaPrivate;
class  CscsAbstractScrollArea:public CscsFrame
{
public:
    explicit CscsAbstractScrollArea(CscsWidget* parent=0);
    ~CscsAbstractScrollArea();

    SCS::ScrollBarPolicy verticalScrollBarPolicy() const;
    void setVerticalScrollBarPolicy(SCS::ScrollBarPolicy);
    CscsScrollBar *verticalScrollBar() const;

    SCS::ScrollBarPolicy horizontalScrollBarPolicy() const;
    void setHorizontalScrollBarPolicy(SCS::ScrollBarPolicy);
    CscsScrollBar *horizontalScrollBar() const;

    CscsWidget *viewport() const;
    CscsSize maximumViewportSize() const;

    CscsSize minimumSizeHint() const;

    CscsSize sizeHint() const;

    CscsAbstractScrollAreaPrivate* d_func() const;

protected:
    CscsAbstractScrollArea(CscsAbstractScrollAreaPrivate* dd, CscsWidget *parent = 0);
    void setViewportMargins(int left, int top, int right, int bottom);

    bool event(CscsEvent *);
    virtual bool viewportEvent(CscsEvent *);

    void resizeEvent(CscsResizeEvent *);
    void paintEvent(CscsPaintEvent *);
    void mousePressEvent(CscsMouseEvent *);
    void mouseReleaseEvent(CscsMouseEvent *);
    void mouseDoubleClickEvent(CscsMouseEvent *);
    void mouseMoveEvent(CscsMouseEvent *);

    void keyPressEvent(CscsKeyEvent *);

    virtual void scrollContentsBy(int dx, int dy);
    friend class CscsAbstractScrollAreaPrivate;

BEGIN_PROPERTY(CscsAbstractScrollArea,CscsFrame)
    META_PROPERTY(SCS::ScrollBarPolicy, verticalScrollBarPolicy, READ, verticalScrollBarPolicy, WRITE, setVerticalScrollBarPolicy)
    META_PROPERTY(SCS::ScrollBarPolicy, horizontalScrollBarPolicy, READ, horizontalScrollBarPolicy, WRITE, setHorizontalScrollBarPolicy)
END_PROPERTY

};

END_NAMESPACE

#endif