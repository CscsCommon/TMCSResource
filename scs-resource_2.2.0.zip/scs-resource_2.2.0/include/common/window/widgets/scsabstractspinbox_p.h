#ifndef SCSABSTRACTSPINBOXPRIV_H
#define SCSABSTRACTSPINBOXPRIV_H
#include "scsabstractspinbox.h"
#include "scslineedit.h"
#include "scsvalidator.h"
#include "../styles/scsstyleoption.h"
#include "../scswidget_p.h"

BEGIN_NAMESPACE(Gemini)

enum EmitPolicy {
    EmitIfChanged,
    AlwaysEmit,
    NeverEmit
};

enum Button {
    None = 0x000,
    Keyboard = 0x001,
    Mouse = 0x002,
    Wheel = 0x004,
    ButtonMask = 0x008,
    Up = 0x010,
    Down = 0x020,
    DirectionMask = 0x040
};


class CscsSpinBoxValidator;
class CscsAbstractSpinBoxPrivate : public CscsWidgetPrivate
{
public:
    CscsAbstractSpinBoxPrivate();
    ~CscsAbstractSpinBoxPrivate();
    CscsAbstractSpinBox* mm_func()const{
    	return reinterpret_cast<CscsAbstractSpinBox*>(mm);
    }

    //child should override these functions
    virtual void setRange(const CscsAny &min, const CscsAny &max){}
    virtual void setValue(const CscsAny &val, EmitPolicy ep, bool updateEdit = true){}
    virtual CscsAny bound(const CscsAny &val, const CscsAny &old = CscsAny(), int steps = 0) const{return CscsAny();}
    virtual std::string textFromValue(const CscsAny &n) const{return std::string("");}
    virtual CscsAny valueFromText(const std::string &input) const{return CscsAny();}
    virtual CscsAny getZeroVariant() const{return CscsAny();}

    void init();
    void reset();
    void updateState(bool up);
    std::string stripped(const std::string &text, int *pos = 0) const;
    bool specialValue() const;

    CscsLineEdit *lineEdit();
    void updateSpinBox();
    void update();
    void updateEdit() const;

    virtual CscsStyleOptionSpinBox getStyleOption() const;
    virtual void transmitSignals(EmitPolicy ep, const CscsAny &old);
    virtual void interpret(EmitPolicy ep);
  

    void editorTextChanged(const std::string &);
    virtual void editorCursorPositionChanged(int oldpos, int newpos);

    CscsBaseStyle::SubControl newHoverControl(const CscsPoint &pos);
    bool updateHoverControl(const CscsPoint &pos);

    CscsLineEdit *edit;
    std::string prefix, suffix, specialValueText;
    CscsAny value, minimum, maximum, singleStep;
    int spinClickTimerId, spinClickTimerInterval, spinClickThresholdTimerId, spinClickThresholdTimerInterval;
    uint buttonState;
    mutable uint dirty : 1;
    mutable std::string cachedText;
    mutable CscsAny cachedValue;
    mutable CscsValidator::State cachedState;
    uint pendingEmit : 1;
    uint spindownEnabled : 1;
    uint spinupEnabled : 1;
    uint readOnly : 1;
    uint wrapping : 1;
    uint ignoreCursorPositionChanged : 1;
    uint frame : 1;
    CscsBaseStyle::SubControl hoverControl;
    CscsRect hoverRect;
    CscsAbstractSpinBox::ButtonSymbols buttonSymbols;
    CscsSpinBoxValidator *validator;

    friend class CscsAbstractSpinbox;
};

class CscsSpinBoxValidator : public CscsValidator
{
public:
    CscsSpinBoxValidator(CscsAbstractSpinBox *mptr, CscsAbstractSpinBoxPrivate *dptr);
    CscsValidator::State validate(std::string &input, int &) const;
    void fixup(std::string& ) const;
private:
    CscsAbstractSpinBox *mptr;
    CscsAbstractSpinBoxPrivate *dptr;
};

END_NAMESPACE

#endif