#ifndef SCSPIXMAPCACHE_H
#define SCSPIXMAPCACHE_H

#include <painting/scsimage.h>

BEGIN_NAMESPACE(Gemini)

class  CscsPixmapCache                                // global pixmap cache
{
public:
    static int cacheLimit();
    static void setCacheLimit(int);
    static CscsImage *find(const std::string &key);
    static bool find(const std::string &key, CscsImage&);
    static bool insert(const std::string &key, const CscsImage&);
    static void remove(const std::string &key);
    static void clear();
};

END_NAMESPACE

#endif
