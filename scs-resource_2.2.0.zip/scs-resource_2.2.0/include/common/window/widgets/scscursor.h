#ifndef SCSCURSOR_H
#define SCSCURSOR_H
#include <atomic>
#include <painting/scspoint.h>
#include "../scsenum.h"

BEGIN_NAMESPACE(Gemini)

class CscsImage;
class CscsCursorData;
class CscsCursor{
	public:
		CscsCursor();
		CscsCursor(SCS::CursorShape shape);
		CscsCursor(const CscsCursor& cursor);
		~CscsCursor();

		CscsCursor& operator=(const CscsCursor& cursor);

		SCS::CursorShape shape()const;
		void setShape(SCS::CursorShape newShape);

		CscsPoint hotSpot()const;

		static CscsPoint pos();
		static void setPos(int x, int y);
		inline static void setPos(const CscsPoint& p) {setPos(p.x(), p.y());}

		int handle()const;

	private:
		CscsCursorData* d;
};

struct CscsCursorData{
	CscsCursorData(SCS::CursorShape s=(SCS::ArrowCursor));
	~CscsCursorData();

	static void initialize();
	static void cleanup();

	std::atomic<int> ref;
	SCS::CursorShape shape;

	uint16 hx, hy;
	int id;
	static bool initialized;
	void update();

	static CscsCursorData* setImage(const CscsImage& bitmap, const CscsImage& mask, int hotX, int hotY);
};

END_NAMESPACE

#endif