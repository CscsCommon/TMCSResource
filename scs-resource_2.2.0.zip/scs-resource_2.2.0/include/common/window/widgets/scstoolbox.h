#ifndef SCSTOOLBOX_H
#define SCSTOOLBOX_H
#include "scsframe.h"
#include "scsicon.h"

BEGIN_NAMESPACE(Gemini)

class CscsToolBoxPrivate;

class WIDGET_EXPORT CscsToolBox :public CscsFrame
{

	CONTAINER_WIDGET
public:
	explicit CscsToolBox(CscsWidget *parent = 0, SCS::WindowFlags f = 0);
	~CscsToolBox();

	int addItem(CscsWidget *widget, const std::string &text);	
	int addItem(CscsWidget *widget, const CscsIcon &icon, const std::string &text);
	int insertItem(int index, CscsWidget *widget, const std::string &text);	
	int insertItem(int index, CscsWidget *widget, const CscsIcon &icon, const std::string &text);

	void removeItem(int index);

	void setItemEnabled(int index, bool enable);
	bool isItemEnabled(int index) const;

	void setItemText(int index, const std::string &text);
	std::string itemText(int index) const;	

	void setItemIcon(int index, const CscsIcon &icon);
    CscsIcon itemIcon(int index) const;

	void setItemToolTip(int index, const std::string &toolTip);
	std::string itemToolTip(int index) const;	

	int currentIndex() const;
	CscsWidget *currentWidget() const;
	CscsWidget *widget(int index) const;
	int indexOf(CscsWidget *widget) const;
	int count() const;

	CscsToolBoxPrivate *d_func() const;

SLOTS:
	void setCurrentIndex(int index);
	void setCurrentWidget(CscsWidget *widget);

SIGNALS:
	void currentChanged(int index){}

protected:
	virtual void itemInserted(int index);
	virtual void itemRemoved(int index);
	void showEvent(CscsShowEvent *e);
	void changeEvent(CscsEvent *);

BEGIN_PROPERTY(CscsToolBox, CscsFrame)
	META_PROPERTY(int, currentIndex, READ, currentIndex, WRITE, setCurrentIndex)
    META_READ_PROPERTY(int, count, READ, count)
END_PROPERTY

};


inline int CscsToolBox::addItem(CscsWidget *item, const std::string &text)
{ return insertItem(-1, item, CscsIcon(), text); }
inline int CscsToolBox::addItem(CscsWidget *item, const CscsIcon &iconSet,
                              const std::string &text)
{ return insertItem(-1, item, iconSet, text); }
inline int CscsToolBox::insertItem(int index, CscsWidget *item, const std::string &text)
{ return insertItem(index, item, CscsIcon(), text); }

END_NAMESPACE

#endif
