#ifndef SCSMAINWINDOWLAYOUT_H
#define SCSMAINWINDOWLAYOUT_H
#include "scsmainwindow.h"
#include "scslayout.h"
#include <kernel/file/scstextstream.h>
#include <kernel/scsvector.h>

BEGIN_NAMESPACE(Gemini)

class CscsToolBar;
class CscsDockWidget;
class CscsDockWidgetLayout;

class CscsMainWindowLayout : public CscsLayout
{
public:
    explicit CscsMainWindowLayout(CscsMainWindow *mainwindow);
    ~CscsMainWindowLayout();

    CscsLayoutItem *statusbar;

    
    CscsWidget *centralWidget() const;
    void setCentralWidget(CscsWidget *cw);

    CscsDockWidgetLayout *layoutForArea(SCS::DockWidgetArea area);
    void addDockWidget(SCS::DockWidgetArea area, CscsDockWidget *dockwidget,
                       SCS::Orientation orientation);
    void splitDockWidget(CscsDockWidget *after, CscsDockWidget *dockwidget,
                         SCS::Orientation orientation);
    SCS::DockWidgetArea dockWidgetArea(CscsDockWidget *dockwidget) const;

    enum { // sentinel values used to validate state data
        VersionMarker = 0xff,
        ToolBarStateMarker = 0xfe,
        DockWidgetStateMarker = 0xfd
    };
    void saveState(CscsTextStream &stream) const;
    bool restoreState(CscsTextStream &stream);


    void addItem(CscsLayoutItem *item);
    void setGeometry(const CscsRect &r);
    CscsLayoutItem *itemAt(int index) const;
    CscsLayoutItem *takeAt(int index);
    int count() const;

    CscsSize sizeHint() const;
    CscsSize minimumSize() const;
    mutable CscsSize szHint;
    mutable CscsSize minSize;

    void invalidate();

    void removeRecursive(CscsDockWidget *dockwidget);


    // utility functions

    CscsInternal::RelayoutType relayout_type;
    void relayout(CscsInternal::RelayoutType type = CscsInternal::RelayoutNormal);

    void saveLayoutInfo();
    void resetLayoutInfo();
    void discardLayoutInfo();

    void beginConstrain();
    void endConstrain();
    int constrain(CscsDockWidgetLayout *dock, int delta);
    
    SCS::DockWidgetArea locateDockWidget(CscsDockWidget *dockwidget, const CscsPoint &mouse) const;
    CscsRect placeDockWidget(CscsDockWidget *dockwidget, const CscsRect &r, const CscsPoint &mouse);
    void dropDockWidget(CscsDockWidget *dockwidget, const CscsRect &r, const CscsPoint &mouse);
    
    
    // dock/center-widget layout data
    SCS::DockWidgetArea corners[4];
    struct CscsMainWindowLayoutInfo
    {
	CscsLayoutItem *item;
	CscsLayoutItem *sep;
	CscsSize size;
	uint is_dummy : 1;
    };
    CscsVector<CscsMainWindowLayoutInfo> layout_info, *save_layout_info;
};

END_NAMESPACE

#endif