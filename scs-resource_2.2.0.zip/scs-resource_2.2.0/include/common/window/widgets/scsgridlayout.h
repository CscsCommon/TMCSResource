#ifndef SCSGRIDLAYOUT_H
#define SCSGRIDLAYOUT_H
#include "scslayout.h"

BEGIN_NAMESPACE(Gemini)

class CscsGridLayoutPrivate;

class CscsGridLayout : public CscsLayout
{

public:
    explicit CscsGridLayout(CscsWidget *parent);
    CscsGridLayout();


    ~CscsGridLayout();
    CscsGridLayoutPrivate* d_func()const;
    CscsSize sizeHint() const;
    CscsSize minimumSize() const;
    CscsSize maximumSize() const;

    void setRowStretch(int row, int stretch);
    void setColumnStretch(int column, int stretch);
    int rowStretch(int row) const;
    int columnStretch(int column) const;

    void setRowMinimumHeight(int row, int minSize);
    void setColumnMinimumWidth(int column, int minSize);
    int rowMinimumHeight(int row) const;
    int columnMinimumWidth(int column) const;

    int columnCount() const;
    int rowCount() const;

    CscsRect cellRect(int row, int column) const;


    bool hasHeightForWidth() const;
    int heightForWidth(int) const;
    int minimumHeightForWidth(int) const;

    SCS::Orientations expandingDirections() const;
    void invalidate();

    inline void addWidget(CscsWidget *w) { CscsLayout::addWidget(w); }
    void addWidget(CscsWidget *, int row, int column, SCS::Alignment = 0);
    void addWidget(CscsWidget *, int row, int column, int rowSpan, int columnSpan, SCS::Alignment = 0);
    void addLayout(CscsLayout *, int row, int column, SCS::Alignment = 0);
    void addLayout(CscsLayout *, int row, int column, int rowSpan, int columnSpan, SCS::Alignment = 0);

    inline void addElement(CscsWidget *w) { CscsLayout::addWidget(w); }
    inline void addElement(CscsWidget *, int row, int column, SCS::Alignment = 0);
    inline void addElement(CscsWidget *, int row, int column, int rowSpan, int columnSpan, SCS::Alignment = 0);
    inline void addElement(CscsLayout *, int row, int column, SCS::Alignment = 0);
    inline void addElement(CscsLayout *, int row, int column, int rowSpan, int columnSpan, SCS::Alignment = 0);

    void setOriginCorner(SCS::Corner);
    SCS::Corner originCorner() const;


    CscsLayoutItem *itemAt(int) const;
    CscsLayoutItem *takeAt(int);
    int count() const;
    void setGeometry(const CscsRect&);

    void addItem(CscsLayoutItem *item, int row, int column, int rowSpan = 1, int columnSpan = 1, SCS::Alignment = 0);

    void setDefaultPositioning(int n, SCS::Orientation orient);
    void getItemPosition(int idx, int *row, int *column, int *rowSpan, int *columnSpan);

protected:

    void addItem(CscsLayoutItem *);

private:
};

inline void CscsGridLayout::addElement(CscsWidget * w, int row, int column, SCS::Alignment align){
    addWidget(w,row,column,align);
}
inline void CscsGridLayout::addElement(CscsWidget * w, int row, int column, int rowSpan, int columnSpan, SCS::Alignment align){
    addWidget(w,row,column,rowSpan,columnSpan,align);
}
inline void CscsGridLayout::addElement(CscsLayout * l, int row, int column, SCS::Alignment align){
    addLayout(l,row,column,align);
}
inline void CscsGridLayout::addElement(CscsLayout * l, int row, int column, int rowSpan, int columnSpan, SCS::Alignment align){
    addLayout(l,row,column,rowSpan,columnSpan,align);
}

END_NAMESPACE

#endif