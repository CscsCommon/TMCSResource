#ifndef SCSICON_H
#define SCSICON_H
#include <painting/scsimage.h>
#include <painting/scsrect.h>
#include "../scsenum.h"

BEGIN_NAMESPACE(Gemini)

class CscsIconPrivate;
class CscsIconEngine;
class CscsPainter;

class  CscsIcon
{
public:
    enum Mode { Normal, Disabled, Active, Selected };
    enum State { On, Off };

    CscsIcon();
    CscsIcon(const CscsImage &pixmap);
    CscsIcon(const CscsIcon &other);
    explicit CscsIcon(const std::string &fileName); // file or resource name
    explicit CscsIcon(CscsIconEngine *engine);
    ~CscsIcon();
    CscsIcon &operator=(const CscsIcon &other);
   
    CscsImage pixmap(const CscsSize &size, Mode mode = Normal, State state = Off) const;
    inline CscsImage pixmap(int w, int h, Mode mode = Normal, State state = Off) const
        { return pixmap(CscsSize(w, h), mode, state); }
    inline CscsImage pixmap(int extent, Mode mode = Normal, State state = Off) const
        { return pixmap(CscsSize(extent, extent), mode, state); }

    CscsSize actualSize(const CscsSize &size, Mode mode = Normal, State state = Off) const;
    void paint(CscsPainter *painter, const CscsRect &rect, SCS::Alignment alignment=SCS::AlignCenter, Mode mode=Normal, State state=Off) const;
    inline void paint(CscsPainter *painter, int x, int y, int w, int h, SCS::Alignment alignment = SCS::AlignCenter, Mode mode = Normal, State state = Off) const
    { paint(painter, CscsRect(x, y, w, h), alignment, mode, state); }

    bool isNull() const;
    bool isDetached() const;

    int serialNumber() const;

    void addPixmap(const CscsImage &pixmap, Mode mode = Normal, State state = Off);
    void addFile(const std::string &fileName, const CscsSize &size = CscsSize(), Mode mode = Normal, State state = Off);


private:
    CscsIconPrivate *d;
};
SCS_DECLARE_TYPEINFO(CscsIcon)
SCS_DECLARE_TYPENAME_INFO(CscsIcon,SCS_MOVABLE_TYPE)
END_NAMESPACE
#endif