#ifndef SCSMAINWINDOW_H
#define SCSMAINWINDOW_H
#include <window/scswidget.h>

BEGIN_NAMESPACE(Gemini)

class CscsDockWidget;
class CscsMainWindowPrivate;


class   CscsMainWindow : public CscsWidget
{
    CONTAINER_WIDGET
public:
    explicit CscsMainWindow(CscsWidget *parent = 0, SCS::WindowFlags flags = 0);
    ~CscsMainWindow();

    CscsSize iconSize() const;
    void setIconSize(const CscsSize &iconSize);

    SCS::ToolButtonStyle toolButtonStyle() const;
    void setToolButtonStyle(SCS::ToolButtonStyle toolButtonStyle);


    CscsWidget *centralWidget() const;
    void setCentralWidget(CscsWidget *widget);

    void setCorner(SCS::Corner corner, SCS::DockWidgetArea area);
    SCS::DockWidgetArea corner(SCS::Corner corner) const;
  
    void addDockWidget(SCS::DockWidgetArea area, CscsDockWidget *dockwidget);
    void addDockWidget(SCS::DockWidgetArea area, CscsDockWidget *dockwidget,
                       SCS::Orientation orientation);
    void splitDockWidget(CscsDockWidget *after, CscsDockWidget *dockwidget,
                         SCS::Orientation orientation);
    void removeDockWidget(CscsDockWidget *dockwidget);

    SCS::DockWidgetArea dockWidgetArea(CscsDockWidget *dockwidget) const;  

    CscsByteArray saveState(int version = 0) const;
    bool restoreState(const CscsByteArray &state, int version = 0);



SIGNALS:
    void iconSizeChanged(const CscsSize &iconSize);
    void toolButtonStyleChanged(SCS::ToolButtonStyle toolButtonStyle);

protected:
    bool event(CscsEvent *event);

private:
    CscsMainWindowPrivate* d_func()const;

BEGIN_PROPERTY(CscsMainWindow,CscsWidget)
    META_PROPERTY(CscsSize, iconSize, READ, iconSize, WRITE, setIconSize)
    META_PROPERTY(SCS::ToolButtonStyle, toolButtonStyle, READ, toolButtonStyle, WRITE, setToolButtonStyle)
END_PROPERTY

};

END_NAMESPACE

#endif