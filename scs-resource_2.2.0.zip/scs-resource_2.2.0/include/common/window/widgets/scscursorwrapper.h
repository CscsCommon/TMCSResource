#ifndef SCSCURSORWRAPPER_H
#define SCSCURSORWRAPPER_H
#include <kernel/scstypes.h>
#include <painting/scspoint.h>
#include <painting/scsimage.h>
#include <painting/scsregion.h>

BEGIN_NAMESPACE(Gemini)

class CscsCursorWrapper{
	public:
		CscsCursorWrapper(){}
		CscsCursorWrapper(const uint8* data, const uint8* mask, int width, int height, int hotX, int hotY){
			set(data, mask, width, height, hotX, hotY);
		}

		void set(const uint8* data, const uint8* mask, int width, int height, int hotX, int hotY);
		CscsPoint hotSpot()const{return hot;}
		CscsImage& image(){ return cursor;}
		const CscsRegion region()const{return rgn;}
		static CscsCursorWrapper* systemCursor(int id);

private:
		static void createSystemCursor(int id);
		void createDrapShadow(int dropx, int dropy);

		CscsPoint hot;
		CscsImage cursor;
		CscsRegion rgn;
};

END_NAMESPACE
#endif