#ifndef SCSRADIOBUTTON_H
#define SCSRADIOBUTTON_H
#include "scsabstractbutton.h"

BEGIN_NAMESPACE(Gemini)

class  WIDGET_EXPORT CscsRadioButton : public CscsAbstractButton
{
public:
    explicit CscsRadioButton(CscsWidget *parent=0);
    explicit CscsRadioButton(const std::string &text, CscsWidget *parent=0);

    CscsSize sizeHint() const;

protected:
    bool hitButton(const CscsPoint &) const;
    void paintEvent(CscsPaintEvent *);

private:
};

END_NAMESPACE

#endif