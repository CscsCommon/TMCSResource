#ifndef SCSABSTRACTSLIDER_H
#define SCSABSTRACTSLIDER_H
#include "../scswidget.h"

BEGIN_NAMESPACE(Gemini)

class CscsAbstractSliderPrivate;

class  CscsAbstractSlider:public CscsWidget{

	friend class CscsAbstractSliderPrivate;
public:
    explicit CscsAbstractSlider(CscsWidget *parent=0);
    ~CscsAbstractSlider();

    CscsAbstractSliderPrivate* d_func()const;

    SCS::Orientation orientation() const;

    void setMinimum(int);
    int minimum() const;

    void setMaximum(int);
    int maximum() const;

    void setRange(int min, int max);

    void setSingleStep(int);
    int singleStep() const;

    void setPageStep(int);
    int pageStep() const;

    void setTracking(bool enable);
    bool hasTracking() const;

    void setSliderDown(bool);
    bool isSliderDown() const;

    void setSliderPosition(int);
    int sliderPosition() const;

    void setInvertedAppearance(bool);
    bool invertedAppearance() const;

    void setInvertedControls(bool);
    bool invertedControls() const;

    enum SliderAction {
        SliderNoAction,
        SliderSingleStepAdd,
        SliderSingleStepSub,
        SliderPageStepAdd,
        SliderPageStepSub,
        SliderToMinimum,
        SliderToMaximum,
        SliderMove
    };

    int value() const;

    void triggerAction(SliderAction action);

SLOTS:
    void setValue(int);
    void setOrientation(SCS::Orientation);

SIGNALS:
    void valueChanged(int value){}

    void sliderPressed(){}
    void sliderMoved(int position){}
    void sliderReleased(){}

    void rangeChanged(int min, int max){}

    void actionTriggered(int action){}

protected:
    void setRepeatAction(SliderAction action, int thresholdTime = 500, int repeatTime = 50);
    SliderAction repeatAction() const;

    enum SliderChange {
        SliderRangeChange,
        SliderOrientationChange,
        SliderStepsChange,
        SliderValueChange
    };
    virtual void sliderChange(SliderChange change);

    void keyPressEvent(CscsKeyEvent *ev);
    void timerEvent(CscsTimerEvent *);
    void changeEvent(CscsEvent *e);

protected:
    CscsAbstractSlider(CscsAbstractSliderPrivate* dd, CscsWidget *parent=0);

BEGIN_PROPERTY(CscsAbstractSlider,CscsWidget)
    META_PROPERTY(int, minimum, READ, minimum, WRITE, setMinimum)
    META_PROPERTY(int, maximum, READ, maximum, WRITE, setMaximum)
    META_PROPERTY(int, singleStep, READ, singleStep, WRITE, setSingleStep)
    META_PROPERTY(int, pageStep, READ, pageStep, WRITE, setPageStep)
    META_PROPERTY(int, value, READ, value, WRITE, setValue)
    META_PROPERTY(int, sliderPosition, READ, sliderPosition, WRITE, setSliderPosition)
    META_PROPERTY(bool, tracking, READ, hasTracking, WRITE, setTracking)
    META_PROPERTY(SCS::Orientation, orientation, READ, orientation, WRITE, setOrientation)
    META_PROPERTY(bool, invertedAppearance, READ, invertedAppearance, WRITE, setInvertedAppearance)
    META_PROPERTY(bool, invertedControls, READ, invertedControls, WRITE, setInvertedControls)
END_PROPERTY

};
END_NAMESPACE
#endif