#ifndef SCSBOXLAYOUT_H
#define SCSBOXLAYOUT_H
#include "scslayout.h"
#include "../scswidget.h"

BEGIN_NAMESPACE(Gemini)

class CscsBoxLayoutPrivate;

class  CscsBoxLayout : public CscsLayout
{
public:
    enum Direction { LeftToRight, RightToLeft, TopToBottom, BottomToTop,
                     Down = TopToBottom, Up = BottomToTop };

    explicit CscsBoxLayout(Direction, CscsWidget *parent = 0);

    ~CscsBoxLayout();

	CscsBoxLayoutPrivate* d_func()const;

    Direction direction() const;
    void setDirection(Direction);

    void addSpacing(int size);
    void addStretch(int stretch = 0);
    void addWidget(CscsWidget *, int stretch = 0, SCS::Alignment alignment = 0);
    void addLayout(CscsLayout *layout, int stretch = 0);
    void addStrut(int);
    void addItem(CscsLayoutItem *);

    inline void addElement(CscsWidget * w, int stretch = 0, SCS::Alignment alignment = 0);
    inline void addElement(CscsLayout *layout, int stretch = 0);
    inline void addElement(CscsLayoutItem *);


    void insertSpacing(int index, int size);
    void insertStretch(int index, int stretch = 0);
    void insertWidget(int index, CscsWidget *widget, int stretch = 0, SCS::Alignment alignment = 0);
    void insertLayout(int index, CscsLayout *layout, int stretch = 0);

    bool setStretchFactor(CscsWidget *w, int stretch);
    bool setStretchFactor(CscsLayout *l, int stretch);
    bool setStretch(int index, int stretch);
    int  stretch(int index)const;

    CscsSize sizeHint() const;
    CscsSize minimumSize() const;
    CscsSize maximumSize() const;

    bool hasHeightForWidth() const;
    int heightForWidth(int) const;
    int minimumHeightForWidth(int) const;

    SCS::Orientations expandingDirections() const;
    void invalidate();
    CscsLayoutItem *itemAt(int) const;
    CscsLayoutItem *takeAt(int);
    int count() const;
    void setGeometry(const CscsRect&);
protected:
    void insertItem(int index, CscsLayoutItem *);

};

class  CscsHBoxLayout : public CscsBoxLayout
{
public:
    CscsHBoxLayout();
    explicit CscsHBoxLayout(CscsWidget *parent);
    ~CscsHBoxLayout();
};

class  CscsVBoxLayout : public CscsBoxLayout
{
public:
    CscsVBoxLayout();
    explicit CscsVBoxLayout(CscsWidget *parent);
    ~CscsVBoxLayout();
};


inline void CscsBoxLayout::addElement(CscsWidget * w, int stretch, SCS::Alignment alignment){
    addWidget(w,stretch,alignment);
}

inline void CscsBoxLayout::addElement(CscsLayout *layout, int stretch){
    addLayout(layout,stretch);
}

inline void CscsBoxLayout::addElement(CscsLayoutItem * item){
    addItem(item);
}

END_NAMESPACE

#endif