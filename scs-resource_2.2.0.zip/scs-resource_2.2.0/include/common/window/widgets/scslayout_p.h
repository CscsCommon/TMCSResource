#ifndef SCSLAYOUTPRIV_H
#define SCSLAYOUTPRIV_H
#include <kernel/scsobject_p.h>
#include "scslayout.h"

BEGIN_NAMESPACE(Gemini)

class CscsLayoutPrivate : public CscsObjectPrivate
{
  
public:
    CscsLayoutPrivate();

    CscsLayout* mm_func()const;
    void doResize(const CscsSize &);

    void reparentChildWidgets(CscsWidget *mw);

    int insideSpacing;
    int outsideBorder;
    uint topLevel : 1;
    uint enabled : 1;
    uint activated : 1;
    uint autoNewChild : 1;
    CscsLayout::SizeConstraint constraint;
    CscsRect rect;
    CscsWidget *menubar;
};

END_NAMESPACE

#endif