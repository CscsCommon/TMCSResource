#ifndef SCSTABBAR_H
#define SCSTABBAR_H
#include "../scswidget.h"

BEGIN_NAMESPACE(Gemini)

class CscsVariant;
class CscsIcon;
class CscsTabBarPrivate;

class WIDGET_EXPORT CscsTabBar: public CscsWidget
{

public:
    explicit CscsTabBar(CscsWidget* parent=0);
    ~CscsTabBar();

    enum Shape { RoundedNorth, RoundedSouth, RoundedWest, RoundedEast,
                 TriangularNorth, TriangularSouth, TriangularWest, TriangularEast
    };

    Shape shape() const;
    void setShape(Shape shape);

    int addTab(const std::string& text);
    int addTab(const CscsIcon& icon, const std::string &text);

    int insertTab(int index, const std::string &text);
    int insertTab(int index, const CscsIcon& icon, const std::string &text);

    void removeTab(int index);

    bool isTabEnabled(int index) const;
    void setTabEnabled(int index, bool);

    std::string tabText(int index) const;
    void setTabText(int index, const std::string &text);

    CscsIcon tabIcon(int index) const;
    void setTabIcon(int index, const CscsIcon &icon);

    void setTabToolTip(int index, const std::string &tip);
    std::string tabToolTip(int index) const;

    void setTabData(int index, const CscsVariant &data);
    CscsVariant tabData(int index) const;

    CscsRect tabRect(int index) const;

    int currentIndex() const;
    int count() const;

    CscsSize sizeHint() const;
    CscsSize minimumSizeHint() const;

    void setDrawBase(bool drawTheBase);
    bool drawBase() const;

SLOTS:
    void setCurrentIndex(int index);

SIGNALS:
    void currentChanged(int index){}

protected:
    virtual CscsSize tabSizeHint(int index) const;
    virtual void tabInserted(int index);
    virtual void tabRemoved(int index);
    virtual void tabLayoutChange();

    bool event(CscsEvent *);
    void resizeEvent(CscsResizeEvent *);
    void showEvent(CscsShowEvent *);
    void paintEvent(CscsPaintEvent *);
    void mousePressEvent (CscsMouseEvent *);
    void mouseMoveEvent (CscsMouseEvent *);
    void mouseReleaseEvent (CscsMouseEvent *);
    void keyPressEvent(CscsKeyEvent *);
    void changeEvent(CscsEvent *);

private:
    CscsTabBarPrivate* d_func()const;
    friend class CscsTabBarPrivate;

BEGIN_PROPERTY(CscsTabBar, CscsWidget)
    META_PROPERTY(Shape, shape, READ, shape, WRITE, setShape)
    META_PROPERTY(int, currentIndex, READ, currentIndex, WRITE, setCurrentIndex)
    META_READ_PROPERTY(int, count, READ, count)
    META_PROPERTY(bool, drawBase, READ, drawBase, WRITE, setDrawBase)
END_PROPERTY

};

END_NAMESPACE

#endif