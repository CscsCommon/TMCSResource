#ifndef SCSSIZEGRIP_H
#define SCSSIZEGRIP_H

#include <window/scswidget.h>

BEGIN_NAMESPACE(Gemini)

class CscsSizeGripPrivate;
class  CscsSizeGrip : public CscsWidget
{
public:
    explicit CscsSizeGrip(CscsWidget *parent);
    ~CscsSizeGrip();

    CscsSize sizeHint() const;

    void setVisible(bool);
protected:
    void paintEvent(CscsPaintEvent *);
    void mousePressEvent(CscsMouseEvent *);
    void mouseMoveEvent(CscsMouseEvent *);

    bool eventFilter(CscsObject *, CscsEvent *);
    bool event(CscsEvent *);

private:
   CscsSizeGripPrivate* d_func()const;
};

END_NAMESPACE

#endif