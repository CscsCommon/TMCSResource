#ifndef SCSFRAMEPRIVATE_H
#define SCSFRAMEPRIVATE_H
#include "../scswidget_p.h"

BEGIN_NAMESPACE(Gemini)

class CscsFrame;

class CscsFramePrivate:public CscsWidgetPrivate{
	public:
		CscsFramePrivate();
		void updateFrameWidth();
		CscsFrame* mm_func()const;
		CscsRect frect;
		int frameStyle;
		uint16 lineWidth;
		uint16 midLineWidth;
		uint16 frameWidth;
};

END_NAMESPACE

#endif