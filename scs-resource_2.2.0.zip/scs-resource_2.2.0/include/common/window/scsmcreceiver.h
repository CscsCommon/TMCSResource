#ifndef SCSMCRECEIVER_H
#define SCSMCRECEIVER_H
#include <painting/scspoint.h>
#include <vector>

BEGIN_NAMESPACE(Gemini)

class CscsMCReceiver{
public:
	static void  sendFilter(const CscsPoint& p, int button);
	static void  mouseChanged(const CscsPoint& p, int button, int wheel=0);
	static void  createScsmcReceiver();
	static void* processScsmcReceiver(void* params);

private:
	static CscsPoint mousePos;
	static int sampleTimes;
	static int currentSample;
	static int numSamples;
	static std::vector<CscsPoint> samples;
};
END_NAMESPACE
#endif
