#ifndef SCSDATADISTRIBUTEFACTORY_H
#define SCSDATADISTRIBUTEFACTORY_H
#include <datatransfer/scsdatadistribute.h>

BEGIN_NAMESPACE(Gemini)

class CscsDataDistribute;
class CscsDataDistributeFactory{

private:
    CscsDataDistributeFactory();
    ~CscsDataDistributeFactory();

public:
    static CscsDataDistributeFactory *instance();
    static void ruinInstance();
    CscsDataDistribute *get();

private:
    static CscsDataDistributeFactory *m_factory;
    static CscsDataDistribute        *m_data;

};

END_NAMESPACE
#endif