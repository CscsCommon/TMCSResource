#ifndef SCSDATADISTRIBUTE_H
#define SCSDATADISTRIBUTE_H

#include <datastorage/scsdatastoragefactory.h>
#include <datastorage/scsabstractdatastorage.h>
#include "scscommsourcefactory.h"

BEGIN_NAMESPACE(Gemini)

class CscsDataDistribute{
    
public:
    CscsDataDistribute();
    ~CscsDataDistribute();

    void setDataOperatorType(CscsAbstractDataStorage::DataOperatorType type);
    CscsAbstractDataStorage::DataOperatorType dataOperatorType()const;

    void setValue(uint id, const CscsVariant& value,bool merge=true, bool sender=true);
    void setValue(const std::string& nameID, const CscsVariant& value,bool merge=true, bool sender=true);
    void setValueList(const std::vector<uint>& ids,const std::vector<CscsVariant>& datas,bool merge=true, bool sender=true);
    void setValueList(const std::vector<std::string>& ids,const std::vector<CscsVariant>& datas,bool merge=true, bool sender=true);
 
    void setMaxValue(uint id, const CscsVariant& value);
    void setMaxValue(const std::string& nameID, const CscsVariant& value);
    void setMaxValueList(const std::vector<std::string>& ids,const std::vector<CscsVariant>& datas);
    void setMaxValueList(const std::vector<uint>& ids,const std::vector<CscsVariant>& datas);

    void setMinValue(uint id, const CscsVariant& value);
    void setMinValue(const std::string& nameID, const CscsVariant& value);
    void setMinValueList(const std::vector<std::string>& ids,const std::vector<CscsVariant>& datas);
    void setMinValueList(const std::vector<uint>& ids,const std::vector<CscsVariant>& datas);


    CscsVariant value(uint id)const;
    CscsVariant  value(const std::string& nameID)const;
    std::vector<CscsVariant> valueList(const std::vector<uint>& ids)const;
    std::vector<CscsVariant> valueList(const std::vector<std::string>& nameIDs)const;

    CscsVariant maxValue(uint id)const;
    CscsVariant minValue(uint id)const;
    CscsVariant maxValue(const std::string& nameID);
    CscsVariant minValue(const std::string& nameID);
    std::vector<CscsVariant> maxValueList(const std::vector<uint>& ids)const;
    std::vector<CscsVariant> minValueList(const std::vector<std::string>& nameIDs)const;

    // void setArrayElement(uint id, int index, const CscsVariant& value);
    // void setArrayElement(const std::string& nameID, int index, const CscsVariant& value);
    // CscsVariant arrayElement(uint id, int index)const;
    // CscsVariant arrayElement(uint id, int index)const;
private:
    CscsDBStorageFactory *m_factory;
    CscsAbstractDataStorage::DataOperatorType  m_operatorType;
};

END_NAMESPACE

#endif