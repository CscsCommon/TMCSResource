#ifndef SCSPAINTDEVICE_H
#define SCSPAINTDEVICE_H
#include <memory>
#include <cairo/cairo.h>
#include "scsregion.h"
#include "scspoint.h"
#include "scsfont.h"

BEGIN_NAMESPACE(Gemini)

class CscsSurfaceView;
class CscsImage;
class CscsPaintDeviceData;
class CscsPaintDevice{
public:
	CscsPaintDevice();
	CscsPaintDevice(cairo_surface_t* surface, cairo_device_t* dev=nullptr);
	CscsPaintDevice(CscsImage* image);
	CscsPaintDevice(CscsSurfaceView* view);

	void setPaintDevice(CscsSurfaceView* view);
	void setPaintDevice(CscsImage* image);
	void setPaintDevice(cairo_surface_t* surface,cairo_device_t* dev=nullptr);
	bool isSupportEGL()const;
	CscsImage* paintDevice()const;
	CscsSurfaceView* paintEGLDevice()const;

	void setClipRegion(const CscsRegion& clip);
	void setOrigin(const CscsPoint& p);
	void setRedirected(const CscsImage* image, const CscsPoint& p, const CscsRegion& clip);
	void setRedirected(const CscsSurfaceView* view, const CscsPoint& p, const CscsRegion& clip);
	void setRedirected(cairo_surface_t* surface,cairo_device_t* dev, const CscsPoint& p, const CscsRegion& clip);
	void setFont(const CscsFont& fnt);
private:
	CscsPaintDeviceData* data;
	friend class CscsPainter;
};

struct CscsPaintDeviceData{
	CscsPaintDeviceData();
	CscsImage*  image;
	CscsSurfaceView* view;
	cairo_surface_t* surface;
	cairo_device_t* device;
	CscsRegion clip;
	CscsPoint  origin;
	CscsFont   fnt;
};

END_NAMESPACE

#endif