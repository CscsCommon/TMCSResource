/*
 * Created by J.Wong 2019/10/12
 */

#ifndef SCSMOLDSETDATA_H
#define SCSMOLDSETDATA_H
#include "scsabstractcontroldata.h"
#include <kernel/scsbytearray.h>

BEGIN_NAMESPACE(Gemini)

class CscsMoldSetData:public CscsAbstractControlData{
public:
	CscsMoldSetData(CscsObject* parent=nullptr);
	~CscsMoldSetData();
	bool addMoldLog(const std::string& szMoldName);
	bool restoreMoldLog(const std::string& szMoldName);
	bool deleteMoldLog(const std::string& szMoldName);

private:
	void composeMoldData(CscsByteArray& data);
	bool parseMoldData(const CscsByteArray& data);
	
};

END_NAMESPACE
#endif