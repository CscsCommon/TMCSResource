/*
 * Created by J.Wong 2019/10/12
 */

#ifndef SCSCURVEDATA_H
#define SCSCURVEDATA_H

#include "scsabstractcontroldata.h"

BEGIN_NAMESPACE(Gemini)
class CscsCurveData:public CscsAbstractControlData{
public:
	CscsCurveData(CscsObject* parent=nullptr);
	~CscsCurveData();

	bool addCurveLog(uint type, const CurveData& data);
	
	uint currentCurveLogCount(uint type)const;
	uint curveLogCount(uint type, int index)const;
	CurveData currentCurveLog(uint type)const;
	std::vector<CurveData> currentCurveLogs(uint type, uint start, uint count)const;
	std::vector<CurveData> curveLogs(uint type, uint index)const;
	bool clearCurveLogs(uint type);
	uint curveLogsCount(uint type)const;
	bool saveCurveLog(uint index);
private:
	typedef struct tagCurveLogs{
		bool complete;
		uint index;
		std::vector<CurveData>* pCurve;
	}CurveLogs;

	static std::map<uint,CurveLogs*> m_currentCurves;
	void prepareCurveTable();
};

END_NAMESPACE

#endif