/*
 * Created by J.Wong 2019/10/12
 */
#ifndef SCSABSTRACTCONTROLDATA_H
#define SCSABSTRACTCONTROLDATA_H
#include <kernel/scsobject.h>
#include <kernel/scsvariant.h>

BEGIN_NAMESPACE(Gemini)

typedef struct tagErrorData{
	uint dwErrorID;
	uint dwShotCount;
	uint16 wGrade;
	uint16 wDevice;
	uint16 wIndex;
	uint16 wSubIndex;
	uint16 wSource;
	uint   dateStart;
	uint64 timeStart;
	uint   dateFixed;
	uint64 timeFixed;
	std::string szUserID;
}ErrorData;

typedef struct tagMoniData{
	uint16 wIndex; //索引
	uint dwShotCount;//开模总数
	uint dwCycleTime;//循环时间
	uint dwOpenMoldTime;//开模时间
	uint dwCloseMoldTime;//关模时间
	uint dwCloseMoldHPress;//关模高压
	uint dwCloseMoldLPress;//关模低压
	uint dwInjeTime;//射出时间
	uint dwTurn2HoldTime;//转保压时间
	uint dwChargeTime;//储料时间
	int  iInjeStartPos;//射出开始位置
	int  iTurn2HoldPos;//转保压位置
	int  iInjeEndPos;//射出结束位置
	int  iInjeCushionPos;//射出保护位置
	int  iInjePeakPos;//射出尖压位置
	uint dwInjePeakTime; //射出尖压时间
	int  iTurn2HoldPress; //转保压力
	uint dwChargeRPM; //储料转速
	uint dwSuckBackTime; //储料退时间
	uint dwEjeTime;//托模时间
	uint dwEjeFWDTime;//托模进时间
	uint dwEjeBWDTime;//托模退时间
	int  iInjePeakPress;//射出尖压
	int  iChargePeakPress;//储料尖压
	uint dwPickupTime;//打包时间
	int  iOpenMoldEndPos;//开模终点
	uint dwInjeMaxSpeed;//射出最大速度
	int  iOilTemp;//油温 
}MoniData;


typedef struct tagCurveData{
	double x;
	double y;
	double z;
	double w;
	double r[8];
}CurveData;


typedef struct tagRecordData{
	uint index;
	uint ID;
	CscsVariant newValue;
	CscsVariant oldValue;
	uint date;
	uint64 time;
	std::string szUserID; 
}RecordData;

typedef struct tagUserData{
	std::string szUserID;
	std::string szPwd;
	uint priv;
}UserData;

typedef struct tagMoldHDR{
	std::string szMoldName; //模具名称
	std::string szMaterial; //材料
	std::string szColor; //颜色
	uint unitCount; 
	uint media;	//存储媒介
	uint date; //存储日期
	uint64 time;//存储时间
}MoldHDR;

#define LOGIN_NULL			-1  //无效登陆
#define LOGIN_INVALIDID 	-2 //无效用户名
#define LOGIN_INVALIDPWD	-3 //无效密码

class CscsAbstractControlData: public CscsObject{
public:
	enum ErrorLog{
		UnKnown,
		OilError,
		SimError,
		AustoneError,
		RS485Error,
		N2CError,
		MNTError,
		COM2Error,
		E2CError,
		RobotRS485Error,
		UserError=16
	};

	enum ControlDevice{
		DeviceAustone=1,
		DeviceAustoneInOne=2,
		DeviceESR=3,
		DevicePLC=100,
		DeviceAxis=101,
		DeviceHmi=10000
	};

	enum AlarmType{
		WarningType=1,
		ErrorType=2
	};

	enum CurveType{
		InjeCurve=1,
		OpenMoldCurve=2,
		CloseMoldCurve=3,
		EjeFWDCurve=4,
		EjeBWDCurve=5,
		NozlFWDCurve=6,
		NozlBWDCurve=7,
		CustomCurve=128
	};

	CscsAbstractControlData(CscsObject* parent=nullptr);
	~CscsAbstractControlData();

	virtual bool addErrorLog(uint dwID, uint16 wSource=OilError,uint16 wAlarmType=ErrorType) { return false; }
	virtual bool clearErrorLog() { return false; }
	virtual uint errorLogCount()const {return 0; }
	virtual ErrorData currentErrorLog()const { return ErrorData(); }
	virtual ErrorData errorLog(uint index)const { return ErrorData(); };
	virtual std::vector<ErrorData> errorLogs(uint start, uint count)const{ return std::vector<ErrorData>(); }
	virtual bool fixedErrorLog(ErrorData* error) { return false; }
	virtual bool addErrorLog(ErrorData* error) { return false;}
	virtual bool fixedErrorLog(uint dwID, uint16 wSource=OilError) { return false; }

	virtual bool addMoniLog() { return false; }
	virtual bool clearMoniLog() { return false; }
	virtual uint moniLogCount()const { return 0; }
	virtual MoniData currentMoniLog()const { return MoniData(); }
	virtual MoniData moniLog(uint index)const {return MoniData(); }
	virtual std::vector<MoniData> moniLogs(uint start, uint count)const{ return std::vector<MoniData>(); }


	virtual bool addCurveLog(uint type, const CurveData& data) { return false; }
	virtual uint currentCurveLogCount(uint type)const { return 0; }
	virtual uint curveLogCount(uint type, int index)const {return 0; }
	virtual CurveData currentCurveLog(uint type)const { return CurveData(); }
	virtual std::vector<CurveData> currentCurveLogs(uint type, uint start, uint count)const { return std::vector<CurveData>(); }
	virtual std::vector<CurveData> curveLogs(uint type, uint index)const { return std::vector<CurveData>(); }
	virtual uint curveLogsCount(uint type)const { return 0; }
	virtual bool clearCurveLogs(uint type) { return false; }
	virtual bool saveCurveLog(uint type){ return false; }


	virtual bool addRecordLog(const RecordData& data) { return false; }
	virtual bool clearRecordLog() { return false; }
	virtual uint recordLogCount()const { return 0; }
	virtual RecordData currentRecordLog()const { return RecordData(); }
	virtual RecordData recordLog(uint index)const { return RecordData(); }
	virtual std::vector<RecordData> recordLogs(uint start, uint count)const {return std::vector<RecordData>();}


	virtual bool addUserLog(const UserData& data) {return false; }
	virtual bool deleteUserLog(const std::string& szUserID) { return false; }
	virtual UserData userLog(const std::string& szUserID)const { return UserData(); }
	virtual bool modifyUserLog(const UserData& data) { return false; }
	virtual uint userLogCount()const { return 0; }
	virtual std::string loginUser()const { return std::string("NOLOGIN"); }
	virtual bool logout()const{ return false; }
	virtual int login(const std::string& szUserID, const std::string& szPwd) { return LOGIN_NULL; }

	virtual MoldHDR currentMoldHDRLog() { return  MoldHDR(); }
	virtual bool addMoldHDRLog(const MoldHDR& hdr) { return false; }
	virtual bool modifyMoldHDRLog(const MoldHDR& hdr) { return false; }
	virtual uint moldHDRLogCount(){ return 0; }
	virtual MoldHDR moldHDRLog(const std::string& szMoldName){ return MoldHDR();}
	virtual MoldHDR moldHDRLog(uint index)const { return MoldHDR(); }
	virtual std::vector<MoldHDR> moldHDRLogs(uint start, uint count){ return std::vector<MoldHDR>(); }
	virtual bool restoreMoldHDRLog(const std::string& szMoldName) { return false; }
	virtual bool deleteMoldHDRLog(const std::string& szMoldName) { return false; }

	virtual bool addMoldLog(const std::string& szMoldName) { return false; }
	virtual bool restoreMoldLog(const std::string& szMoldName) { return false; }
	virtual bool deleteMoldLog(const std::string& szMoldName) { return false; }
	

	virtual bool addCustomLog(void* data){ return false;}
	virtual bool deleteCustomLog(void* data){ return false;}
	virtual bool clearCustomLog(){ return false;}
	virtual uint customLogCount()const{ return 0;}
	virtual bool modifyCustomLog(void* data){ return false;}
	virtual void* currentCustomLog()const{ return nullptr;}
	virtual void* customLog(uint index)const{ return nullptr;}
	virtual std::vector<void*> customLogs(uint start, uint count)const { return std::vector<void*>();}




	virtual bool restoreFromFile(const std::string& szFile) { return false; }
	virtual bool saveToFile(const std::string& szFile) { return false;}
};

END_NAMESPACE

#endif