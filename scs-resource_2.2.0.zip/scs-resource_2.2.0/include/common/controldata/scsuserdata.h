/*
 * Created By J.Wong 2019/10/17
 */
#ifndef SCSUSERDATA_H
#define SCSUSERDATA_H

#include "scsabstractcontroldata.h"

BEGIN_NAMESPACE(Gemini)
class CscsUserData:public CscsAbstractControlData{
public:
	CscsUserData(CscsObject* parent=nullptr);
	~CscsUserData();
	bool addUserLog(const UserData& data);
	bool deleteUserLog(const std::string& szUserID);
	UserData userLog(const std::string& szUserID)const;
	bool modifyUserLog(const UserData& data);
	uint userLogCount()const;
	/*
	 * 当前登陆用户
	 */
	std::string loginUser()const;
	/*
	 * 登陆用户名不匹配返回LOGIN_INVALIDID
	 * 登陆密码不匹配返回LOGIN_INVALIDPWD
	 * 登陆成功返回用户权级
	 */
	int login(const std::string& szUserID, const std::string& szPwd);
	bool logout()const;
private:
	static std::string m_currentLoginUser;
	uint64 encode(const std::string& szPwd);
	void prepareUserTable();
};
END_NAMESPACE
#endif