#ifndef SCSCONTROLDATAFACTORY_H
#define SCSCONTROLDATAFACTORY_H
#include <vector>

BEGIN_NAMESPACE(Gemini)

class CscsAbstractControlData;
class CscsControlDataFactory{

public:	
	enum ControlType{
		AlarmControl,
		MoniControl,
		CurveControl,
		MoldHDRControl,
		RecordControl,
		UserControl,
		CustomControl=128
	};

	static CscsControlDataFactory* instance();
	static void ruinInstance();

	static void addCustomControl(CscsControlDataFactory::ControlType customType, CscsAbstractControlData* custom=nullptr);
	static  void removeCustomControl(CscsControlDataFactory::ControlType customType);

	static CscsAbstractControlData* get(CscsControlDataFactory::ControlType type);
private:
	CscsControlDataFactory();
	~CscsControlDataFactory();
	static CscsControlDataFactory *m_instance;
    static CscsAbstractControlData  *m_alarm;
    static CscsAbstractControlData  *m_moni;
    static CscsAbstractControlData  *m_curve;
    static CscsAbstractControlData	*m_record;
    static CscsAbstractControlData  *m_moldset;
    static CscsAbstractControlData	*m_user;
    static std::map<uint,CscsAbstractControlData*> m_customs; 
};

END_NAMESPACE
#endif 	