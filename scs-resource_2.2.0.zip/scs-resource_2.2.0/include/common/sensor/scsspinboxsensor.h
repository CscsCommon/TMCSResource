#ifndef SCSSPINBOXSENSOR_H
#define SCSSPINBOXSENSOR_H

#include <window/widgets/scsspinbox.h>

BEGIN_NAMESPACE(Gemini)

class CscsDataSensorEvent;

class WIDGET_EXPORT CscsSpinBoxSensor:public CscsSpinBox{

	SENSOR_WIDGET
public:
	explicit CscsSpinBoxSensor(CscsWidget* parent=nullptr);
	void setMaxDataID(uint id);
	void setMinDataID(uint id);
	void setDataID(uint id);
	uint maxDataID()const;
	uint minDataID()const;
	uint dataID()const;
	void setMaximum(int val);
	void setMinimum(int val);
protected:
	void dataSensorEvent(CscsDataSensorEvent* e);
SLOTS:
	void setValue(int val);
private:
	void reBindID(uint id,uint& oid);
	void setDataValue(uint id, int value);
	uint uid;
	uint mxid;
	uint mnid;

	
	

};

class WIDGET_EXPORT CscsDoubleSpinBoxSensor:public CscsDoubleSpinBox{
	SENSOR_WIDGET
public:
	explicit CscsDoubleSpinBoxSensor(CscsWidget* parent=nullptr);
	void setMaxDataID(uint id);
	void setMinDataID(uint id);
	void setDataID(uint id);
	uint maxDataID()const;
	uint minDataID()const;
	uint dataID()const;
	void setMaximum(double val);
	void setMinimum(double val);
protected:
	void dataSensorEvent(CscsDataSensorEvent* e);
	
SLOTS:
	void setValue(double val);

private:
	void reBindID(uint id,uint& oid);
	void setDataValue(uint id, double value);
	uint uid;
	uint mxid;
	uint mnid;
};

END_NAMESPACE
#endif